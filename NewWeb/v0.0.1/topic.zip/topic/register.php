<?php
session_start();
include 'config.php'; 

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = trim($_POST['user_id']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $job = $_POST['job'];
    
    if (empty($user_id) || empty($email) || empty($password) || empty($repassword) || empty($firstname) || empty($lastname)) {
        $message = "所有欄位都是必填的！";
    } elseif ($password !== $repassword) {
        $message = "兩次輸入的密碼不一致！";
    } else {
        $stmt_check = $conn->prepare("SELECT user_id FROM users WHERE email = ? OR user_id = ?");
        $stmt_check->bind_param("ss", $email, $user_id);
        $stmt_check->execute();
        $stmt_check->store_result();
        
        if ($stmt_check->num_rows > 0) {
            $message = "此電子郵件或學號已被註冊。";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt_insert = $conn->prepare("INSERT INTO users (user_id, email, password, first_name, last_name, job) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt_insert->bind_param("sssssi", $user_id, $email, $hashed_password, $firstname, $lastname, $job);

            if ($stmt_insert->execute()) {
                $message = "註冊成功！您現在可以<a href='login.php'>登入</a>了。";
            } else {
                $message = "註冊失敗：" . $stmt_insert->error;
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
    }
}

$conn->close();
?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>註冊</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
            background-color: #f0f2f5;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
            background-color: #f8f9fa;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .navbar-logo img {
            height: 50px;
        }
        .navbar-links a {
            text-decoration: none;
            color: #333;
            padding: 10px 15px;
            margin-left: 10px;
            border: 1px solid transparent;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .navbar-links a.button {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .navbar-links a.button:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .header-banner {
            background-image: url("https://images.unsplash.com/photo-1542435503-956c469947f6");
            background-size: cover;
            background-position: center;
            height: 250px;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            position: relative;
        }
        .header-banner::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
        }
        .header-content {
            position: relative;
            z-index: 1;
        }
        .header-content h1 {
            font-size: 2em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
        }
        .registration-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 40px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        .registration-container h3 {
            text-align: center;
            margin-bottom: 25px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .form-group input:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
        }
        .message { color: red; text-align: center; }
        .btn-submit {
            width: 100%;
            padding: 12px;
            border: none;
            background-color: #007bff;
            color: white;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        /* 修正單選按鈕排版 */
        .radio-container-group {
            display: flex; /* 使用 flexbox 讓選項並排 */
            justify-content: space-between; /* 在選項之間產生間距 */
            margin-bottom: 20px;
        }
        .radio-container-group label {
            width: 48%; /* 讓每個選項各佔一半寬度 */
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="fh5co-loader"></div>
    
    <div id="page">
    <nav class="navbar">
        <div class="navbar-logo">
            <a href="index.php"><img src="https://csie.nfu.edu.tw/upload/logo/20221014174252ML34.png" alt="LOGO"></a>
        </div>
        <div class="navbar-links">
            <a href="index.php" class="button">首頁</a>
            <a href="login.php" class="button">登入</a>
        </div>
    </nav>
    <div class="header-banner">
        <div class="header-content">
            <h1>
                基於大語言模型之<br>程式作業自動評分與建議回饋系統
            </h1>
        </div>
    </div>
    <div class="registration-container">
        <h3>註冊</h3>
        <form action="register.php" method="POST">
            <?php if (isset($message) && !empty($message)): ?>
                <p class="message"><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>
            
            <div class="form-group">
                <input type="text" id="user_id" name="user_id" class="form-control" placeholder="學號 (UserID)" required>
            </div>
            <div class="form-group">
                <input type="text" id="fname" name="firstname" class="form-control" placeholder="姓" required>
            </div>
            <div class="form-group">
                <input type="text" id="lname" name="lastname" class="form-control" placeholder="名" required>
            </div>
            <div class="form-group">
                <input type="text" id="email" name="email" class="form-control" placeholder="電子信箱(帳號)" required>
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" class="form-control" placeholder="輸入密碼" required>
            </div>
            <div class="form-group">
                <input type="password" id="repassword" name="repassword" class="form-control" placeholder="再次輸入密碼" required>
            </div>
            
            <div class="radio-container-group">
                <label class="radio-container">
                    <input type="radio" name="job" value="0" required>學生
                </label>
                <label class="radio-container">
                    <input type="radio" name="job" value="1">老師
                </label>
            </div>

            <div class="form-group">
                <input type="submit" value="註冊" class="btn-submit">
            </div>
        </form>
    </div>
</body>
</html>