<?php
session_start();
include_once 'config.php'; 

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_or_id = $_POST['username'];
    $password = $_POST['password'];

    // 使用預處理語法查詢資料庫
    $stmt = $conn->prepare("SELECT id, user_id, password, first_name FROM users WHERE user_id = ? OR email = ?");
    $stmt->bind_param("ss", $username_or_id, $username_or_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // 登入成功，將使用者資訊存入 Session
            $_SESSION['loggedin'] = true;
            $_SESSION['UserID'] = $row['user_id'];
            $_SESSION['first_name'] = $row['first_name'];
            header("location: index.php");
            exit;
        } else {
            $error = "密碼錯誤。";
        }
    } else {
        $error = "找不到此帳號。";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>登入</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
            background-color: #f0f2f5; /* 為了模擬背景顏色 */
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
            background-color: #f8f9fa;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .navbar-logo img {
            height: 50px;
        }
        .navbar-links a {
            text-decoration: none;
            color: #333;
            padding: 10px 15px;
            margin-left: 10px;
            border: 1px solid transparent;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .navbar-links a.button {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .navbar-links a.button:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .header-banner {
            background-image: url("https://images.unsplash.com/photo-1542435503-956c469947f6");
            background-size: cover;
            background-position: center;
            height: 250px;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            position: relative;
        }
        .header-banner::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
        }
        .header-content {
            position: relative;
            z-index: 1;
        }
        .header-content h1 {
            font-size: 2em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
        }
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 40px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h3 {
            margin-bottom: 25px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .error-message {
            color: #dc3545;
            font-size: 14px;
            margin-top: -10px;
            margin-bottom: 10px;
        }
        .btn-submit {
            width: 100%;
            padding: 12px;
            border: none;
            background-color: #007bff;
            color: white;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .links {
            margin-top: 20px;
            font-size: 14px;
        }
        .links a {
            color: #007bff;
            text-decoration: none;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="navbar-logo">
        <a href="index.php"><img src="https://csie.nfu.edu.tw/upload/logo/20221014174252ML34.png" alt="LOGO"></a>
    </div>
    <div class="navbar-links">
        <a href="index.php" class="button">首頁</a>
        <a href="register.php" class="button">註冊</a>
    </div>
</nav>

<div class="header-banner">
    <div class="header-content">
        <h1>
            基於大語言模型之<br>程式作業自動評分與建議回饋系統
        </h1>
    </div>
</div>

<div class="login-container">
    <h3>使用者登入</h3>
    <?php if (!empty($error)): ?>
        <p class="error-message"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form action="login.php" method="POST">
        <div class="form-group">
            <input type="text" id="username" name="username" placeholder="電子郵件或學號" required>
        </div>
        <div class="form-group">
            <input type="password" id="password" name="password" placeholder="密碼" required>
        </div>
        <button type="submit" class="btn-submit">登入</button>
    </form>
    <div class="links">
        還沒有帳號？ <a href="register.php">點此註冊</a>
    </div>
</div>

</body>
</html>