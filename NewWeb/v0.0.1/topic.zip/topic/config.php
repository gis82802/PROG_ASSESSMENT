<?php
// 這個檔案用來設定資料庫連線
$servername = "localhost";
$username = "root"; // XAMPP 預設使用者
$password = ""; // XAMPP 預設密碼為空
$dbname = "topic"; // 資料庫名稱應與您在 phpMyAdmin 中建立的一致

// 建立連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("連線失敗: " . $conn->connect_error);
}
?>