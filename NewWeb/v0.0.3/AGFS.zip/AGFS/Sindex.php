<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>首頁</title>
    <style>
        /* 頁面基本樣式 */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }
        
        /* 導覽列樣式 */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
            background-color: #f8f9fa;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .navbar-logo img {
            height: 50px;
        }
        .navbar-links a {
            text-decoration: none;
            color: #333;
            padding: 10px 15px;
            margin-left: 10px;
            border: 1px solid transparent;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .navbar-links a.button {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .navbar-links a.button:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        
        /* 首頁橫幅區塊 */
        .header-banner {
            background-image: url("https://images.unsplash.com/photo-1542435503-956c469947f6");
            background-size: cover;
            background-position: center;
            height: 400px;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            position: relative;
        }
        .header-banner::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
        }
        .header-content {
            position: relative;
            z-index: 1;
        }
        .header-content h1 {
            font-size: 3em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
        }
        
        /* 統計數字區塊 */
        .stats-section {
            display: flex;
            justify-content: space-around;
            padding: 50px 20px;
            background-color: #f1f1f1;
        }
        .stat-item {
            text-align: center;
        }
        .stat-item h2 {
            font-size: 3em;
            color: #007bff;
            margin: 0;
        }
        .stat-item p {
            font-size: 1.2em;
            color: #555;
            margin: 0;
        }

        /* 底部資訊區塊 */
        .footer-section {
            text-align: center;
            padding: 30px 20px;
            background-color: #343a40;
            color: #fff;
        }
        .footer-section p {
            margin: 5px 0;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="navbar-logo">
        <a href="index.php"><img src="https://csie.nfu.edu.tw/upload/logo/20221014174252ML34.png" alt="LOGO"></a>
    </div>
    <div class="navbar-links">
        <a href="index.php" class="button">首頁</a>
        <a href="upload.php" class="button">上傳作業</a>
    </div>
</nav>

/* 程式碼*/


<div class="footer-section">
    <p>國立虎尾科技大學 資工系</p>
    <p>版權所有 © 2025</p>
</div>

</body>
</html>