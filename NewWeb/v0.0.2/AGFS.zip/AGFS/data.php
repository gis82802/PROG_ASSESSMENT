<?php
include 'config.php'; // 引入連線設定

// 準備 SQL 查詢
$sql = "SELECT id, name FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>使用者列表</title>
    <style>
        body { font-family: sans-serif; text-align: center; }
        table { margin: 20px auto; border-collapse: collapse; width: 50%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    </style>
</head>
<body>
    <h1>資料庫使用者列表</h1>
    <?php
    if ($result->num_rows > 0) {
        echo "<table><tr><th>ID</th><th>姓名</th></tr>";
        // 輸出每一行的資料
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["id"]. "</td><td>" . $row["name"]. "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>目前資料庫中沒有使用者資料。</p>";
    }
    $conn->close();
    ?>
    <br>
    <a href="index.html">返回首頁</a>
</body>
</html>