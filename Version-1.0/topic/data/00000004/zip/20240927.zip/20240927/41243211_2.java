public class app_char
{
	public static void main(String args[])
	{
		char ch[]={'\u864E','\u5C3E','\u79D1','\u5927','\u0020','\u0034','\u0031','\u0032','\u0034','\u0033','\u0032','\u0031','\u0031','\u0020','\u738B','\u7FD4','\u79B9'};

		for(char c:ch)
			System.out.print(c);
		
	}
}