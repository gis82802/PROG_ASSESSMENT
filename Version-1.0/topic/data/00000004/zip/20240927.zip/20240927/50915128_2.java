public class java3_6 {
    public static void main(String[] args) {
        char c1 = '\u570b'; 
        char c2 = '\u7acb'; 
        char c3 = '\u864e'; 
        char c4 = '\u5c3e'; 
        char c5 = '\u79d1'; 
        char c6 = '\u6280'; 
        char c7 = '\u5927'; 
        char c8 = '\u5b78'; 
        char c9 = '\u6797'; 
        char c10 = '\u7f8e'; 
        char c11 = '\u5448'; 

        
        System.out.println(c1 + " (" + (int) c1 + ")");
        System.out.println(c2 + " (" + (int) c2 + ")");
        System.out.println(c3 + " (" + (int) c3 + ")");
        System.out.println(c4 + " (" + (int) c4 + ")");
        System.out.println(c5 + " (" + (int) c5 + ")");
        System.out.println(c6 + " (" + (int) c6 + ")");
        System.out.println(c7 + " (" + (int) c7 + ")");
        System.out.println(c8 + " (" + (int) c8 + ")");
        System.out.println(c9 + " (" + (int) c9 + ")");
        System.out.println(c10 + " (" + (int) c10 + ")");
        System.out.println(c11 + " (" + (int) c11 + ")");


    }
}
