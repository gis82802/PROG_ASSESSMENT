public class J_0927_1 {
	public  static void main(String[] args){
		String ch1 = new String();
		String ch2 = new String();
		ch1 = "\u570B(u570B)\u7ACB(u7ACB)\u864E(u864E)\u5C3E(u5C3E)\u79D1(u79D1)\u6280(u79D1)\u5927(u5927)\u5B78(u5B78)"; //國立虎尾科技大學
		ch2 = "\u8521(u8521)\u54C1(u54C1)\u8FB0(u8FB0)"; //蔡品辰
		System.out.println(ch1);
		System.out.println(ch2);
		
	}
}
