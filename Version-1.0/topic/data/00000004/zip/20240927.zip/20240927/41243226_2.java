public class nameuni
{
	public static void main(String[] args)
	{
		String[] ch={"國","立","虎","尾","科","技","大","學","張","立","名"};
		int[] uni={'國','立','虎','尾','科','技','大','學','張','立','名'};
		for(int i=0;i<=11;i++)
		{
			System.out.print(ch[i]+"("+uni[i]+")"+"\n");
		}
	}
}