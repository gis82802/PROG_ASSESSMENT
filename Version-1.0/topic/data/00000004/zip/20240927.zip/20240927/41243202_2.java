public class uni
{
	public static void main(String[] args)
	{
		int uni='國';
		int uni1='立';
		int uni2='虎';
		int uni3='尾';
		int uni4='科';
		int uni5='技';
		int uni6='大';
		int uni7='學';
		int uni8='林';
		int uni9='沛';
		int uni10='慧';
		
		
		System.out.println("國("+(int)'國'+")立("+(int)'立'+")虎("+(int)'虎'+")尾("+(int)'尾'+")科("+(int)'科'+")技("+(int)'技'+")大("+(int)'大'+")學("+(int)'學'+")\n");
		System.out.println("林("+(int)'林'+")沛("+(int)'沛'+")慧("+(int)'慧'+")");
	}
}