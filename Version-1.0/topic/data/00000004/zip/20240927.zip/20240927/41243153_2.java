public class hw1
{
	public static void main(String args[])
	{

		System.out.println("國("+(int)'國'+")");
		System.out.println("立("+(int)'立'+")");
		System.out.println("虎("+(int)'虎'+")");
		System.out.println("尾("+(int)'尾'+")");
		System.out.println("科("+(int)'科'+")");
		System.out.println("技("+(int)'技'+")");
		System.out.println("大("+(int)'大'+")");
		System.out.println("學("+(int)'學'+")");
		System.out.println("\n蔡("+(int)'蔡'+")");
		System.out.println("承("+(int)'承'+")");
		System.out.println("廷("+(int)'廷'+")");
	}
}