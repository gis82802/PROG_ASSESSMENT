public class unicode{
public static void main(String[] args){
String name = "國立虎尾科技大學李宗燁";
for (int i = 0; i < name.length(); i++) {
char n = name.charAt(i);
System.out.println(n+'\n');
}
}
}