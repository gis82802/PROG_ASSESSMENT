public class ex2
{
	public static void main(String[] args) throws Exception
	{
		while(true)
		{
			System.out.print("\r|   ");
			Thread.sleep(100);
			System.out.print("\r/   ");
			Thread.sleep(100);
			System.out.print("\r一  ");
			Thread.sleep(100);
			System.out.print("\r\\   ");
			Thread.sleep(100);
		}
	}
}
			