public class owoblue_java04
{
public static void main(String args[])
{
System.out.println((int)'藍'+" "+(int)'憲'+" "+(int)'廷');
char num1=34253;
char num2=25010;
char num3=24311;
System.out.println(""+num1+num2+num3);
}
}