public class wait
{
	public static void main (String[] args)throws Exception
	{
		System.out.println("|");
		Thread.sleep(1000);
		System.out.println("/");
		Thread.sleep(1000);
		System.out.println("-");
		Thread.sleep(1000);
		System.out.println("\\");
		Thread.sleep(1000);
		System.out.println("|");
		Thread.sleep(1000);
		System.out.println("/");
		Thread.sleep(1000);
		System.out.println("-");
		Thread.sleep(1000);
		System.out.println("\\");
		Thread.sleep(1000);
		System.out.println("|");
		Thread.sleep(1000);
		System.out.println("結束");
	}
}