/*
filename: app3_2
function: Loading animation
author: PoXsun
date: 2024/09/27
version:23
*/
public class app3_2 {
    public static void main(String[] args) throws Exception{
            {
            while (true) {
                System.out.print("\r\\");
                Thread.sleep(100);
                System.out.print("\r|");
                Thread.sleep(100);
                System.out.print("\r/");
                Thread.sleep(100);
                System.out.print("\r-");
                Thread.sleep(100);
            }
        }
    }
}
