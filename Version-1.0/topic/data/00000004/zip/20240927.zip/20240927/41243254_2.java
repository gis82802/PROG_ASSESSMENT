//filename:app3_3
//function:顯示名字學校和unicode
//author:xiao
//date:9/27
//version:11.0.12
public class app3_3
{
  public static void main(String args[])
  {
    char ch = '蕭';
    System.out.println(ch+"("+(int)ch+")");
    ch = '楷';
    System.out.println(ch+"("+(int)ch+")");
    ch = '翰';
    System.out.println(ch+"("+(int)ch+")");
    ch = '國';
    System.out.println(ch+"("+(int)ch+")");
    ch = '立';
    System.out.println(ch+"("+(int)ch+")");
    ch = '虎';
    System.out.println(ch+"("+(int)ch+")");
    ch = '尾';
    System.out.println(ch+"("+(int)ch+")");
    ch = '科';
    System.out.println(ch+"("+(int)ch+")");
    ch = '技';
    System.out.println(ch+"("+(int)ch+")");
    ch = '大';
    System.out.println(ch+"("+(int)ch+")");
    ch = '學';
    System.out.println(ch+"("+(int)ch+")");

  }

}