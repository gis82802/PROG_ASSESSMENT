public class hw {
   public static void main(String[] args){
	char ch1='\u694a';
	char ch2='\u627f';
	char ch3='\u7a4e';
	char ch4='\u864e';
	char ch5='\u79d1';
	char ch6='\u5927';	
	System.out.println("41243245"+" "+ch4+"(u864e)"+ch5+"(u79d1)"+ch6+"(u5927)"+" "+ch1+"(u694a)"+ch2+"(u627f)"+ch3+"(u7a4e)");	
   }
}