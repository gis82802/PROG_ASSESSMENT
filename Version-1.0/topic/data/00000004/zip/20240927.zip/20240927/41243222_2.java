/*
filename:app3_1
funtion:print uincode
auther:ToBoShu
date:2024/09/27
version:jdk23
*/
public class app3_1
{
	public static void main(String args[])
	{
		char ch1 = '林';
		System.out.println(ch1 + " = " + (int)ch1);
		char ch2 = '諺';
		System.out.println(ch2 + " = " + (int)ch2);
		char ch3 = '晟';
		System.out.println(ch3 + " = " + (int)ch3);
		char ch4 = '國';
		System.out.println(ch4 + " = " + (int)ch4);
		char ch5 = '立';
		System.out.println(ch5 + " = " + (int)ch5);
		char ch6 = '虎';
		System.out.println(ch6 + " = " + (int)ch6);
		char ch7 = '尾';
		System.out.println(ch7 + " = " + (int)ch7);
		char ch8 = '科';
		System.out.println(ch8 + " = " + (int)ch8);
		char ch9 = '技';
		System.out.println(ch9 + " = " + (int)ch9);
		char ch10 = '大';
		System.out.println(ch10 + " = " + (int)ch10);
		char ch11 = '學';
		System.out.println(ch11 + " = " + (int)ch11);
	}
}