public class Ch3_9{
	public static void main(String arg[]){
		char name1='\u675c';
		char name2='\u9577';
		char name3='\u52f3';
		System.out.println(name1+"uni="+(int)name1);
		System.out.println(name2+"uni="+(int)name2);
		System.out.println(name3+"uni="+(int)name3);
		char name4='\u570b';
		char name5='\u7acb';
		char name6='\u864e';
		char name7='\u5c3e';
		char name8='\u79d1';
		char name9='\u6280';
		char name10='\u5927';
		char name11='\u5b78';
		System.out.println(name4+"uni="+(int)name4);
		System.out.println(name5+"uni="+(int)name5);
		System.out.println(name6+"uni="+(int)name6);
		System.out.println(name7+"uni="+(int)name7);
		System.out.println(name8+"uni="+(int)name8);
		System.out.println(name9+"uni="+(int)name9);
		System.out.println(name10+"uni="+(int)name10);
		System.out.println(name11+"uni="+(int)name11);
}
}