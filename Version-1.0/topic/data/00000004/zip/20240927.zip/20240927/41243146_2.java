public class test1 {
    public static void main(String[] args) {
        String sname = "虎尾科技大學黃境安";
        for (int i = 0; i < sname.length(); i++) {
		System.out.println((char)sname.charAt(i) + " (" + (int)sname.charAt(i) + ") ");
        }
    }
}


