/*
filename:app3_1
function:輸出姓名與學校及內碼
author:傅學呈
data:2024/09/27
version:11.0.12
*/
public class app3_1
{
	public static void main(String args[])
	{
		char ch1='傅';
		char ch2='學';
		char ch3='呈';
		char ch4='國';
		char ch5='立';
		char ch6='虎';
		char ch7='尾';
		char ch8='科';
		char ch9='技';
		char ch10='大';
		char ch11='學';
		System.out.println("傅="+(int)ch1);
		System.out.println("學="+(int)ch2);
		System.out.println("呈="+(int)ch3);
		System.out.println("國="+(int)ch4);
		System.out.println("立="+(int)ch5);
		System.out.println("虎="+(int)ch6);
		System.out.println("尾="+(int)ch7);
		System.out.println("科="+(int)ch8);
		System.out.println("技="+(int)ch9);
		System.out.println("大="+(int)ch10);
		System.out.println("學="+(int)ch11);
		System.out.println(""+ch1+ch2+ch3);
		System.out.println(""+ch4+ch5+ch6+ch7+ch8+ch9+ch10+ch11);
	}
}