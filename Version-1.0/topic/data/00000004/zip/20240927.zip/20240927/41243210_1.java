public class Mystick 
{
    public static void main(String[] args) throws Exception {
            while (true) {
                    System.out.print("\r-"); 
                    Thread.sleep(200); 
                    System.out.print("\r/"); 
                    Thread.sleep(200); 
                    System.out.print("\r|"); 
                    Thread.sleep(200); 
                    System.out.print("\r\\"); 
                    Thread.sleep(200); 

        } 
    }
}
