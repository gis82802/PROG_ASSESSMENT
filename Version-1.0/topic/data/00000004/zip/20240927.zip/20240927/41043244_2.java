public class Main {
    public static void main(String[] args) {
        char ch = '賴';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '明';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '賢';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '國';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '立';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '虎';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '尾';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '科';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '技';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '大';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '學';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '資';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '訊';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '系';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '工';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '程';
        System.out.printf("%c(%d)", ch, (int) ch);
        ch = '系';
        System.out.printf("%c(%d)", ch, (int) ch);
    }
}
