public class app3_5
{
    public static void main(String arg[])
    {
	char chname1='\u6797';
	char chname2='\u6986';
	char chname3='\u5091';
	char chname4='\u570b';
	char chname5='\u7acb';
	char chname6='\u864e';
	char chname7='\u5c3e';
	char chname8='\u79d1';
	char chname9='\u6280';
	char chname10='\u5927';
	char chname11='\u5b78';
	System.out.println(""+chname1+"(26519)"+chname2+"(27014)"+chname3+"(20625)");
	System.out.println(""+chname4+"(22283)"+chname5+"(31435)"+chname6+"(34382)"+chname7
	+"(23614)"+chname8+"(31185)"+chname9+"(25216)"+chname10+"(22823)"+chname11+"(23416)");
    }
}