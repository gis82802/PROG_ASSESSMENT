public class hw1{
	public static void main(String args[]){
		int i=java.lang.Integer.MAX_VALUE;
		int j=java.lang.Integer.MAX_VALUE;
		char ch1='郭',ch2='思',ch3='翰',ch4='國',ch5='立',ch6='虎',
		     ch7='尾',ch8='科',ch9='技',ch10='大',ch11='學';
		int x;
		
		x=i-(j-ch1);
		System.out.println(ch1+"="+x);x=i-(j-ch2);
		System.out.println(ch2+"="+x);x=i-(j-ch3);
		System.out.println(ch3+"="+x);x=i-(j-ch4);
		System.out.println(ch4+"="+x);x=i-(j-ch5);
		System.out.println(ch5+"="+x);x=i-(j-ch6);
		System.out.println(ch6+"="+x);x=i-(j-ch7);
		System.out.println(ch7+"="+x);x=i-(j-ch8);
		System.out.println(ch8+"="+x);x=i-(j-ch9);
		System.out.println(ch9+"="+x);x=i-(j-ch10);
		System.out.println(ch10+"="+x);x=i-(j-ch11);
		System.out.println(ch11+"="+x);	
	}
}