public class Myname
{
    public static void main(String[] args)
    {
     char[] myname={'國','立','虎','尾','科','技','大','學','王','宜','平'};
     for (int i=0;i<11;i++)
     {
      System.out.println(myname[i]+"("+(int)myname[i]+")");
     }
    }
}