public class name
{
	public static void main (String[] args)
	{
		char nm1='\u4F0D';   //十進制20365
		char nm2='\u7FCA';   //十進制32714
		char nm3='\u7444';   //十進制29764
		char sch1='\u864E';  //十進制34382
		char sch2='\u5C3E';  //十進制23614
		char sch3='\u79D1';  //十進制31185
		char sch4='\u6280';  //十進制25216	
		char sch5='\u5927';  //十進制22823
		char sch6='\u5B78';  //十進制23416
		char sch7='\u8CC7';  //十進制36039
		char sch8='\u8A0A';  //十進制35338
		char sch9='\u5DE5';  //十進制24037
		char sch10='\u7A0B'; //十進制31243
		char sch11='\u7cfb';  //十進制31995
		System.out.println("nm:"+nm1+"("+(int)nm1+")"+nm2+"("+(int)nm2+")"+nm3+"("+(int)nm3+")");
		System.out.println("sch:"+sch1+"("+(int)sch1+")");   //虎
		System.out.println(sch2+"("+(int)sch2+")");
		System.out.println(sch3+"("+(int)sch3+")");
		System.out.println(sch4+"("+(int)sch4+")");
		System.out.println(sch5+"("+(int)sch5+")");
		System.out.println(sch6+"("+(int)sch6+")");
		System.out.println(sch7+"("+(int)sch7+")");
		System.out.println(sch8+"("+(int)sch8+")");
		System.out.println(sch9+"("+(int)sch9+")");
		System.out.println(sch10+"("+(int)sch10+")");
		System.out.println(sch11+"("+(int)sch11+")");
	}
}