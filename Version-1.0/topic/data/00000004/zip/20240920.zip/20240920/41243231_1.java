
/*
    Filename: "app1_1"
    Function: Print "Hello Java"
    Author: Xu
    Version: 11.0.12
    date: 2024/9/20
*/


public class app1_1
{
    public static void main(String[] args)
    {
        System.out.println("Hello Java!");
    }
}