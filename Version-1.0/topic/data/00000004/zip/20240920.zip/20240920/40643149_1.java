public class hw40643149_240920
{
   public static void main(String args[])
   {
      System.out.println("Hello World!");
   }
}
