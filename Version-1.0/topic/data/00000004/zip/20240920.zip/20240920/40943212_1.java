/*
	filename:Java_0920
	function:Java Hello World
	author:���ʫ� 40943212
	datetime:2024/09/20
	version:1.0
*/

public class Java_0920
{
	public static void main(String arg[])
	{
		System.out.println("Hello, World!");
		
	}
}
