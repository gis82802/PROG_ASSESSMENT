public class ex3
{
	public static void main(String args[])
	{
		System.out.println(args.length);
		System.out.println(args[0]+args[1]+args[2]+args[3]);
	}
}