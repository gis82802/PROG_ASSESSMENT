

public class helloword{

    public static void main(String args[]){
        System.out.println("hello fuck");
    }

}