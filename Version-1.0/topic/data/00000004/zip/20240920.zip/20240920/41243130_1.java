// app1_1,Hello Java
public class app1_1
{
	public static void main(String arg[])
	{
		System.out.println("Hello World!!");
		int num=240920;
		System.out.println("字串+數字-->"+num);
		System.out.println("輸入了幾個參數:"+arg.length);
		for(int i=0;i<arg.length;i++)
		{
			System.out.println("arg["+i+"]="+arg[i]);
		}
	}
}