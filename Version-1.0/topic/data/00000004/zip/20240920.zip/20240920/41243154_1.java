public class J_0920_01 {
	public  static void main(String[] args){
		System.out.println("Hello Java by Aino.");
		
	}
}
