// app1_1 helloworld java
public class app1_1{

    public static void main(String args[])
    {
		System.out.println("hello world");
		
		/*System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);*/
		//int num=5;
		//num=5;
        //System.out.println("I have " + num + " apples.");
    }
}