/*
filename:ch2_1.java
funtion:print My first Java Program
author:劉宗修
date:2024/9/20
version:jdk23
*/
public class ch2_1 {
	public static void main(String[] args){
		System.out.println("My first Java Program");
	}
}