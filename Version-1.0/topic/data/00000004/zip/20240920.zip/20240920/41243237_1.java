/*
filename:app1_1
funtion:print Hello Java
author:PoXsun
date:2024/09/20
version:11.0.12
*/
public class app1_1
{
	public static void main(String args[])
	{
		System.out.println("Hello Java!!");
	}
}