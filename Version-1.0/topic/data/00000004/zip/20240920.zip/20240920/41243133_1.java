public class java123{

 public static void main(String args[]){
  
  System.out.println("Hallo Java");


  
}
}