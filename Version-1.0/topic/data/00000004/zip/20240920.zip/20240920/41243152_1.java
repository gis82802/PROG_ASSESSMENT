public class jy {
	public static void main(String[] args){
		System.out.println("Hallo JAVA");	
	}
}