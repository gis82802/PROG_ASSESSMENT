public class java0920{

	public static void main(String[] args){
		System.out.println("Hello Java");
	}
}