#ifndef POLYNOMIAL1_HPP
#define POLYNOMIAL1_HPP

#include <string>
#include <sstream>
#include <cmath>

struct Term {
    double coef; // �Y��
    int exp;     // ���ơ]�D�t�^

    Term() : coef(0.0), exp(0) {}
    Term(double c, int e) : coef(c), exp(e) {}

    // �Ω�Ƨǡ]�Ѥj��p�^
    bool operator<(const Term& other) const {
        return exp > other.exp;
    }

    bool isZero(double eps = 1e-12) const {
        return std::abs(coef) <= eps;
    }

    // ��X�C�@���]���t���t���^
    std::string bodyString() const {
        std::ostringstream oss;
        double absC = coef < 0 ? -coef : coef;
        if (exp == 0) {
            if (std::floor(absC) == absC)
                oss << (long long)absC;
            else
                oss << absC;
        }
        else {
            if (std::abs(absC - 1.0) > 1e-12) {
                if (std::floor(absC) == absC)
                    oss << (long long)absC;
                else
                    oss << absC;
            }
            oss << "x";
            if (exp != 1) oss << "^" << exp;
        }
        return oss.str();
    }
};

#endif // POLYNOMIAL1_HPP
