#include <iostream>
#include "Polynomial1.hpp"
#include "Polynomial2.h"
using namespace std;

int main(int argc, const char* argv[]) {
    Polynomial a, b;
    cout << "��J�h���� A�G" << endl;
    cin >> a;

    cout << "\n��J�h���� B�G" << endl;
    cin >> b;

    cout << "\n���G" << endl;
    cout << "A(x) = " << a << endl;
    cout << "B(x) = " << b << endl;
    cout << "A(x) + B(x) = " << a.Add(b) << endl;

    return 0;
}