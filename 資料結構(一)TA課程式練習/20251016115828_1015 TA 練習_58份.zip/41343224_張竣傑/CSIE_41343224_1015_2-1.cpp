#include "CSIE_41343224_1015_2.h"
#include <iostream>
using namespace std;

Polynomial::Polynomial(int numTerm) {
    terms = numTerm;
    cap = 10;
    termArray = new Term[cap];
}


istream& operator>>(istream& in, Polynomial& p) {
    int numTerms;
    float c;
    int e;
    cout<<"input the num of term";
    cin>>numTerms;
    for(int i = 0;i<numTerms;i++){
        cout<<"input the "<<i<<"th coeff:";
        cin>>c;
        cout<<"input the "<<i<<"th exp:";
        cin>>e;
        p.NewTerm(c,e);
    }
    return in;
}

ostream& operator<<(ostream& out, const Polynomial& p) {
   int c,e;
    string sign;
    for(int i = 0 ; i <p.terms ;i++){
        c=p.termArray[i].coef;
        e=p.termArray[i].exp;
        if(i>0 && c>0)sign="+";
        else sign = "";
        cout<<sign<<c;
        if(e>1)cout<<"x^"<<e;
        else if (e==1) cout<<"x";
    }
    return out;
}

void Polynomial::NewTerm(const float coef, const int exp) {
    if (terms == cap) {
        cap *= 2;
        Term* temp = new Term[cap];
        for (int i = 0; i < terms; i++) temp[i] = termArray[i];
        delete[] termArray;
        termArray = temp;
    }
    termArray[terms].coef = coef;
    termArray[terms].exp = exp;
    terms++;
}

Polynomial Polynomial::Add(Polynomial b){
    Polynomial c;
    int aPos = 0, bPos = 0;
    while (aPos < terms && bPos < b.terms) {
        if (termArray[aPos].exp == b.termArray[bPos].exp) {
            float x = termArray[aPos].coef + b.termArray[bPos].coef;
            if (x) c.NewTerm(x, termArray[aPos].exp);
            aPos++; bPos++;
        } else if (termArray[aPos].exp < b.termArray[bPos].exp) {
            c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
            bPos++;
        } else {
            c.NewTerm(termArray[aPos].coef, termArray[aPos].exp);
            aPos++;
        }
    }
    while (aPos < terms) {
        c.NewTerm(termArray[aPos].coef, termArray[aPos].exp);
        aPos++;
    }
    while (bPos < b.terms) {
        c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
        bPos++;
    }
    return c;
}
