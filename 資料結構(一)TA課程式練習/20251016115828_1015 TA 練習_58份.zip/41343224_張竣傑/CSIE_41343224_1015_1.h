#ifndef CSIE_41343224_1015_1
#define CSIE_41343224_10_1

#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned int value;

public:
    NatureNumber();
    NatureNumber(unsigned int v);

    friend istream& operator>>(istream& in, NatureNumber& n);
    friend ostream& operator<<(ostream& out, const NatureNumber& n);

    NatureNumber operator+(const NatureNumber& other) const;
    NatureNumber operator-(const NatureNumber& other) const;
    bool operator==(const NatureNumber& other) const;
};

#endif
