#ifndef CSIE_41343224_1015_2_H
#define CSIE_41343224_1015_2_H

#include <iostream>
#include "CSIE_41343224_1015_2-1.h"

using namespace std;

class Polynomial {
        friend istream& operator>>(istream& in, Polynomial& p);
        friend ostream& operator<<(ostream& out, const Polynomial& p);
    private:
        Term *termArray;
        int cap;
        int terms;
    public:
        Polynomial(int numTerm = 0);
        Polynomial Add(Polynomial b);
        void NewTerm(const float c,const int e);
};

#endif
