#ifndef CSIE_41343224_1015_2_1_H
#define CSIE_41343224_1015_2_1_H
#include<iostream>
using namespace std;
class Term {
    public:
        float coef; 
        int exp;
};

#endif
