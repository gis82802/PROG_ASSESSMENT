#include "CSIE_41343224_1015_1.h"

NatureNumber::NatureNumber() : value(0) {}

NatureNumber::NatureNumber(unsigned int v) : value(v) {}

istream& operator>>(istream& in, NatureNumber& n) {
    in >> n.value;
    return in;
}

ostream& operator<<(ostream& out, const NatureNumber& n) {
    out << n.value;
    return out;
}

NatureNumber NatureNumber::operator+(const NatureNumber& other) const {
    return NatureNumber(value + other.value);
}

NatureNumber NatureNumber::operator-(const NatureNumber& other) const {
    if (value < other.value)
        return NatureNumber(0);
    return NatureNumber(value - other.value);
}

bool NatureNumber::operator==(const NatureNumber& other) const {
    return value == other.value;
}
