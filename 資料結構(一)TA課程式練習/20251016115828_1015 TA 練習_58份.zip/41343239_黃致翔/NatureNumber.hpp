#ifndef NATURENUMBER_HPP
#define NATURENUMBER_HPP

#include <iostream>
#include <stdexcept>

class NatureNumber {
public:
    using value_t = unsigned long long;

private:
    value_t value;

public:
    NatureNumber() : value(0ULL) {}
    NatureNumber(value_t v) : value(v) {}

    value_t get() const { return value; }

    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
        unsigned long long tmp;
        if (!(is >> tmp)) return is;
        n.value = tmp;
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        os << n.value;
        return os;
    }

    friend NatureNumber operator+(const NatureNumber& a, const NatureNumber& b) {
        return NatureNumber(a.value + b.value);
    }

    friend long long operator-(const NatureNumber& a, const NatureNumber& b) {
       
        long long ai = static_cast<long long>(a.value);
        long long bi = static_cast<long long>(b.value);
        return ai - bi;
    }

    friend bool operator==(const NatureNumber& a, const NatureNumber& b) {
        return a.value == b.value;
    }
    friend bool operator!=(const NatureNumber& a, const NatureNumber& b) {
        return !(a == b);
    }
};

#endif 
