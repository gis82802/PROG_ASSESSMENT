#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>

struct Term {
    long long coeff; 
    unsigned int exp;

    Term() : coeff(0), exp(0) {}
    Term(long long c, unsigned int e) : coeff(c), exp(e) {}
};

#endif 
