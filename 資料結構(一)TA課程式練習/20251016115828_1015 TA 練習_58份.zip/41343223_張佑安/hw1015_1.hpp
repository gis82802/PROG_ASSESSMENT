
#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned int value;  // �ϥεL����ơA�T�O���۵M��

public:
    // �w�]�غc�l
    NatureNumber(unsigned int v = 0) : value(v) {}

    // ���o��
    unsigned int getValue() const {
        return value;
    }

    // �[�k�B��l
    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(value + other.value);
    }

    // ��k�B��l�]�קK�X�{�t�ơ^
    NatureNumber operator-(const NatureNumber& other) const {
        if (value >= other.value)
            return NatureNumber(value - other.value);
        else
            return NatureNumber(0);
    }

    // �۵��P�_
    bool operator==(const NatureNumber& other) const {
        return value == other.value;
    }

    // ��X�B��l
    friend ostream& operator<<(ostream& os, const NatureNumber& n) {
        os << n.value;
        return os;
    }

    // ��J�B��l
    friend istream& operator>>(istream& is, NatureNumber& n) {
        int temp;
        is >> temp;
        if (temp < 0)
            temp = 0;  // �۰ʭץ����۵M��
        n.value = static_cast<unsigned int>(temp);
        return is;
    }
};

#endif
