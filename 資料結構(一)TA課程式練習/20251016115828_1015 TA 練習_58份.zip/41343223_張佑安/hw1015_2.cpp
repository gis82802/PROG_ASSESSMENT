#include<iostream>
#include"hw1015_2.hpp"
#include"TERM.hpp"

using namespace std;
int main(int argc, const char* argv[]) {
	Polynomial a, b;
	cout << "input poly A " << endl;
	cin >> a;

	cout << "input poly B " << endl;
	cin >> b;

	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
	cout << "a+b=" << a.Add(b) << endl;
	cout << "a-b=" << a.sub(b) << endl;


	return 0;
}