#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <cmath>
#include "Term.hpp" // �ݭn Term ���w�q

class Polynomial {
private:
    std::vector<Term> terms;

    void normalize() {
        if (terms.empty()) return;

        std::sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exponent > b.exponent;
            });

    }

public:
    // 1. �غc�l
    Polynomial() {}

    // 2. �[�k��k (a.Add(b))
    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        size_t i = 0, j = 0;

        // �����Ӧh�������X�ֻP�ۥ[
        while (i < this->terms.size() || j < other.terms.size()) {
            Term current_term;
            if (i < this->terms.size() && j < other.terms.size()) {
                const Term& t1 = this->terms[i];
                const Term& t2 = other.terms[j];

                if (t1.exponent == t2.exponent) {
                    // �P�����G�ۥ[�Y��
                    double new_coeff = t1.coefficient + t2.coefficient;
                    if (std::abs(new_coeff) > 1e-9) { // �קK�[�J�Y�Ƭ� 0 ����
                        current_term = Term(new_coeff, t1.exponent);
                        result.terms.push_back(current_term);
                    }
                    i++; j++;
                }
                else if (t1.exponent > t2.exponent) {
                    // t1 �����Ƹ��j�G�����[�J t1
                    result.terms.push_back(t1);
                    i++;
                }
                else {
                    // t2 �����Ƹ��j�G�����[�J t2
                    result.terms.push_back(t2);
                    j++;
                }
            }
            else if (i < this->terms.size()) {
                // �u�� this ����
                result.terms.push_back(this->terms[i++]);
            }
            else if (j < other.terms.size()) {
                // �u�� other ����
                result.terms.push_back(other.terms[j++]);
            }
        }
        return result;
    }

    // 3. I/O �ާ@�ŭ��� (�@���ͤ����)

    // ��X�ާ@�ŭ��� (<<)
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& poly) {
        if (poly.terms.empty()) {
            os << "0";
            return os;
        }

        bool first_term = true;
        for (const auto& term : poly.terms) {
            if (term.coefficient == 0.0) continue;

            if (!first_term && term.coefficient > 0) {
                os << " + ";
            }
            else if (!first_term && term.coefficient < 0) {
                os << " "; // ���F���[�A�t�����۫Y��
            }

            if (first_term && term.coefficient < 0) {
                // �� Term::operator<< �B�z�t��
                os << term;
            }
            else {
                // ���ƶ��ΫD����
                os << term;
            }

            first_term = false;
        }

        if (first_term) os << "0"; // �p�G�Ҧ������Q����F
        return os;
    }

    friend std::istream& operator>>(std::istream& is, Polynomial& poly) {
        std::cout << "Enter polynomial (e.g., 5x^3 - 2x + 1):" << std::endl;
        std::string line;
        if (!std::getline(is, line)) return is;

        poly.terms.clear();
        int N;
        std::cout << "��J�`����: ";
        if (!(is >> N)) return is;

        for (int i = 0; i < N; ++i) {
            double coeff;
            int exp;
            std::cout << "��J�� " << i + 1 << " �Y�ƻP����: ";
            if (!(is >> coeff >> exp)) {
                is.setstate(std::ios::failbit);
                return is;
            }
            if (std::abs(coeff) > 1e-9) {
                poly.terms.push_back(Term(coeff, exp));
            }
        }
        poly.normalize();
        return is;
    }
};

#endif // POLYNOMIAL_HPP