#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>

class Polynomial;

class Term {
    friend class Polynomial;
    friend std::istream& operator>>(std::istream&, Polynomial&);
    friend std::ostream& operator<<(std::ostream&, const Polynomial&);

private:
    float coef;
    int exp;
};

#endif
