#include <iostream>

class NatureNumber {
private:
    int value;

public:
    NatureNumber(int v = 1) : value(v >= 0 ? v : 1) {}

    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        int result = this->value - other.value;
        return NatureNumber(result >= 0 ? result : 1);
    }

    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
        int input;
        is >> input;
        n.value = (input > 0) ? input : 1;
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        os << n.value;
        return os;
    }
};
