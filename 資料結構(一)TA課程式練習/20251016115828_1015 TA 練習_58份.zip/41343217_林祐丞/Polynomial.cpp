#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Polynomial;

class Term {
    friend class Polynomial;
    friend istream& operator>>(istream&, Polynomial&);
    friend ostream& operator<<(ostream&, const Polynomial&);

private:
    float coef;
    int exp;
};

class Polynomial {
public:
    Polynomial();
    Polynomial Add(const Polynomial& b) const;

private:
    vector<Term> terms;
    friend istream& operator>>(istream& in, Polynomial& p);
    friend ostream& operator<<(ostream& out, const Polynomial& p);
};

Polynomial::Polynomial() {}

Polynomial Polynomial::Add(const Polynomial& b) const {
    Polynomial result;
    int i = 0, j = 0;
    const auto& a_terms = this->terms;
    const auto& b_terms = b.terms;

    while (i < a_terms.size() && j < b_terms.size()) {
        if (a_terms[i].exp > b_terms[j].exp) {
            result.terms.push_back(a_terms[i]);
            i++;
        }
        else if (a_terms[i].exp < b_terms[j].exp) {
            result.terms.push_back(b_terms[j]);
            j++;
        }
        else {
            float sum = a_terms[i].coef + b_terms[j].coef;
            if (sum != 0) {
                Term t;
                t.coef = sum;
                t.exp = a_terms[i].exp;
                result.terms.push_back(t);
            }
            i++;
            j++;
        }
    }

    while (i < a_terms.size()) result.terms.push_back(a_terms[i++]);
    while (j < b_terms.size()) result.terms.push_back(b_terms[j++]);

    return result;
}

istream& operator>>(istream& in, Polynomial& p) {
    int count;
    in >> count;
    p.terms.resize(count);
    for (int i = 0; i < count; ++i) {
        in >> p.terms[i].coef >> p.terms[i].exp;
    }

    sort(p.terms.begin(), p.terms.end(), [](const Term& a, const Term& b) {
        return a.exp > b.exp;
        });
    return in;
}

ostream& operator<<(ostream& out, const Polynomial& p) {
    if (p.terms.empty()) {
        out << 0;
        return out;
    }

    for (size_t i = 0; i < p.terms.size(); ++i) {
        const Term& t = p.terms[i];
        if (i > 0 && t.coef > 0) {
            out << "+";
        }

        if (t.exp == 0) {
            out << t.coef;
        }
        else if (t.exp == 1) {
            if (t.coef == 1) out << "x";
            else if (t.coef == -1) out << "-x";
            else out << t.coef << "x";
        }
        else {
            if (t.coef == 1) out << "x^" << t.exp;
            else if (t.coef == -1) out << "-x^" << t.exp;
            else out << t.coef << "x^" << t.exp;
        }
    }
    return out;
}


int main(int argc, const char* argv[]) {
    Polynomial a, b;

    cout << "input poly A " << endl;
    cin >> a;

    cout << "input poly B " << endl;
    cin >> b;

    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "a+b=" << a.Add(b) << endl;
    system("pause");
    return 0;
}
