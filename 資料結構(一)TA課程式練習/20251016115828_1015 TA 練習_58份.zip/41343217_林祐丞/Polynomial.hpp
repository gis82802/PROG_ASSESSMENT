#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include "Term.hpp"

class Polynomial {
public:
    Polynomial();
    Polynomial Add(const Polynomial& b) const;

private:
    std::vector<Term> terms;
    friend std::istream& operator>>(std::istream& in, Polynomial& p);
    friend std::ostream& operator<<(std::ostream& out, const Polynomial& p);
};

std::istream& operator>>(std::istream& in, Polynomial& p);
std::ostream& operator<<(std::ostream& out, const Polynomial& p);

#endif
