#include "natureNum.hpp"

NatureNumber::NatureNumber() : m_val(0ULL) {}
NatureNumber::NatureNumber(unsigned long long v) : m_val(v) {}
unsigned long long NatureNumber::value() const { return m_val; }
NatureNumber NatureNumber::operator+(const NatureNumber& rhs) const { return NatureNumber(m_val + rhs.m_val); }
NatureNumber NatureNumber::operator-(const NatureNumber& rhs) const {
    if (m_val >= rhs.m_val) return NatureNumber(m_val - rhs.m_val);
    return NatureNumber(0ULL);
}
bool NatureNumber::operator==(const NatureNumber& rhs) const { return m_val == rhs.m_val; }
bool NatureNumber::operator!=(const NatureNumber& rhs) const { return !(*this == rhs); }
istream& operator>>(istream& is, NatureNumber& n) {
    long long x;
    if (is >> x) n.m_val = (x < 0) ? 0ULL : static_cast<unsigned long long>(x);
    return is;
}
ostream& operator<<(ostream& os, const NatureNumber& n) {
    os << n.m_val;
    return os;
}

int main() {
    NatureNumber a, b;
    NatureNumber* c;
    cin >> a;
    cin >> b;
    cout << a + b << endl;
    cout << a - b << endl;
    if (a == b) {
        cout << "a==b" << endl;
    }
    else {
        cout << "a!=b" << endl;
    }
    system("pause");
    return 0;
}
