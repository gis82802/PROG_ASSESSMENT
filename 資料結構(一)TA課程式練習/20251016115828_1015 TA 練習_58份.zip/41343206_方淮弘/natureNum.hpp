#ifndef NATURE_NUM_HPP
#define NATURE_NUM_HPP

#include <iostream>
#include <stdexcept>
using namespace std;

class NatureNumber {
public:
    NatureNumber();
    explicit NatureNumber(unsigned long long v);
    unsigned long long value() const;
    NatureNumber operator+(const NatureNumber& rhs) const;
    NatureNumber operator-(const NatureNumber& rhs) const;
    bool operator==(const NatureNumber& rhs) const;
    bool operator!=(const NatureNumber& rhs) const;
    friend istream& operator>>(istream& is, NatureNumber& n);
    friend ostream& operator<<(ostream& os, const NatureNumber& n);
private:
    unsigned long long m_val;
};

#endif
