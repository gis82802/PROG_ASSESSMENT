#include "Polynomial.hpp"
#include <algorithm>

// Term
istream& operator>>(istream& in, Term& t) {
    in >> t.coef >> t.exp;
    return in;
}

ostream& operator<<(ostream& out, const Term& t) {
    if (t.exp == 0)
        out << t.coef;
    else if (t.exp == 1)
        out << t.coef << "x";
    else
        out << t.coef << "x^" << t.exp;
    return out;
}

// Polynomial
Polynomial::Polynomial() {}

istream& operator>>(istream& in, Polynomial& p) {
    int n;
    cout << "��J����: ";
    in >> n;
    p.terms.clear();
    for (int i = 0; i < n; i++) {
        Term t;
        cout << "��J��"<<i+1<<"�����Y�ƩM����: ";
        in >> t;
        p.terms.push_back(t);
    }
    sort(p.terms.begin(), p.terms.end(), [](const Term& a, const Term& b) {
        return a.getExp() > b.getExp();
    });
    return in;
}

ostream& operator<<(ostream& out, const Polynomial& p) {
    for (size_t i = 0; i < p.terms.size(); i++) {
        if (i > 0 && p.terms[i].getCoef() >= 0)
            out << "+";
        out << p.terms[i];
    }
    return out;
}

Polynomial Polynomial::Add(const Polynomial& b) const {
    Polynomial result;
    result.terms = terms;
    for (auto& tb : b.terms) {
        bool found = false;
        for (auto& tr : result.terms) {
            if (tr.getExp() == tb.getExp()) {
                tr.setCoef(tr.getCoef() + tb.getCoef());
                found = true;
                break;
            }
        }
        if (!found)
            result.terms.push_back(tb);
    }
    std::sort(result.terms.begin(), result.terms.end(), [](const Term& a, const Term& b) {
        return a.getExp() > b.getExp();
        });
    return result;
}

// main
int main() {
    Polynomial a, b;

    cout << "input poly A " << endl;
    cin >> a;

    cout << "input poly B " << endl;
    cin >> b;

    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "a+b=" << a.Add(b) << endl;

    system("pause");
    return 0;
}
