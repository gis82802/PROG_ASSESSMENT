#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
private:
    int coef;
    int exp;
public:
    Term(int c = 0, int e = 0) : coef(c), exp(e) {}
    int getCoef() const { return coef; }
    int getExp() const { return exp; }
    void setCoef(int c) { coef = c; }
    void setExp(int e) { exp = e; }

    friend istream& operator>>(istream& in, Term& t);
    friend ostream& operator<<(ostream& out, const Term& t);
};

#endif
