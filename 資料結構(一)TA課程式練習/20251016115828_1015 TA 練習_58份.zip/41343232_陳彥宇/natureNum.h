#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>


class NatureNumber {
private:
    unsigned int value;

public:
   
    NatureNumber() : value(0) {}
    explicit NatureNumber(unsigned int v) : value(v) {}

  
    unsigned int get() const { return value; }
    void set(unsigned int v) { value = v; }


    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

   
    NatureNumber operator-(const NatureNumber& other) const {
        if (this->value <= other.value) return NatureNumber(0);
        return NatureNumber(this->value - other.value);
    }


    bool operator==(const NatureNumber& other) const { return this->value == other.value; }
    bool operator!=(const NatureNumber& other) const { return !(*this == other); }


    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        os << n.value;
        return os;
    }


    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {

        is >> n.value;
        return is;
    }
};

#endif 
