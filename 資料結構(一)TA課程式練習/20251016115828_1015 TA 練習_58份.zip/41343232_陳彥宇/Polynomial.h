#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <vector>
#include <map>
#include <iostream>
#include "Term.h"

class Polynomial {
private:
    std::vector<Term> terms;

 
    void normalize() {
        std::map<int, double, std::greater<int>> m;
        for (const Term& t : terms) m[t.exp] += t.coeff;
        terms.clear();
        for (auto& p : m) {
            if (p.second != 0.0) terms.emplace_back(p.second, p.first);
        }
    }

public:
    Polynomial() = default;
    explicit Polynomial(const std::vector<Term>& t) : terms(t) { normalize(); }


    Polynomial Add(const Polynomial& other) const {
        Polynomial res;
      
        res.terms = this->terms;
        res.terms.insert(res.terms.end(), other.terms.begin(), other.terms.end());
        res.normalize();
        return res;
    }


    friend std::istream& operator>>(std::istream& in, Polynomial& p) {
        p.terms.clear();
        int n;
        in >> n;
        for (int i = 0; i < n; ++i) {
            Term t;
            in >> t;
            p.terms.push_back(t);
        }
        p.normalize();
        return in;
    }


    friend std::ostream& operator<<(std::ostream& out, const Polynomial& p) {
        if (p.terms.empty()) { out << 0; return out; }
        bool first = true;
        for (const Term& t : p.terms) {
            if (!first) {
                if (t.coeff >= 0) out << " + ";
                else out << " - ";
            }
            else {
                if (t.coeff < 0) out << "-";
            }
            double absc = (t.coeff < 0 ? -t.coeff : t.coeff);
            out << absc;
            if (t.exp != 0) out << "x^" << t.exp;
            first = false;
        }
        return out;
    }
};

#endif