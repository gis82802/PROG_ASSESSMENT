#include<iostream>
#include "natureNum.h";
using namespace std;
int main(void)
{
	NatureNumber a, b;
	NatureNumber* c;

	cout << "�п�J a: ";
	cin >> a;
	cout << "�п�J b: ";
	cin >> b;

	cout << "a + b =" << a + b << endl;
	cout << "a - b =" << a - b << endl;
	
	if (a == b)
		cout << "a == b" << endl;
	else
		cout << "a != b" << endl;

	c = new NatureNumber(a + b);
	cout << "����c�x�sa+b=" << *c << endl;

	delete c;
	return (0);
}