#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>

struct Term {
    double coeff;
    int exp;
    Term() : coeff(0.0), exp(0) {}
    Term(double c, int e) : coeff(c), exp(e) {}
};


inline std::istream& operator>>(std::istream& in, Term& t) {
    in >> t.coeff >> t.exp;
    return in;
}


inline std::ostream& operator<<(std::ostream& out, const Term& t) {
    out << t.coeff;
    if (t.exp != 0) out << "x^" << t.exp;
    return out;
}

#endif 
