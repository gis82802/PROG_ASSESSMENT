#include "NatureNumber.h"

NatureNumber::NatureNumber(int val) {
    if (val<0){
        cout << "not NatureNumber "<<endl;
        a = 0;
    }else{
    a = val;
    }
}

bool NatureNumber::operator==(const NatureNumber &s) const {
    return a == s.a;
}

NatureNumber operator+(const NatureNumber& x, const NatureNumber& y) {
    return NatureNumber(x.a + y.a);
}

NatureNumber operator-(const NatureNumber& x, const NatureNumber& y) {
    if (y.a>x.a){
        cout << "a-b cannot be negative";
        return NatureNumber(0);
    }else{
    return NatureNumber(x.a - y.a);
    }
}

ostream& operator<<(ostream& os, const NatureNumber& r) {
    os << r.a;
    return os;
}

istream& operator>>(istream& is, NatureNumber& r) {
    is >> r.a;
    if (r.a<0){
        cout<<"not naturenumber "<<endl;
        r.a = 0;
    } 
    return is;
}

int main() {
    NatureNumber a, b;
    NatureNumber* c = nullptr;
    
    cout <<"a= ";
    cin >> a;  
    cout <<"b= ";
    cin >> b;  

    cout << "a+b=" << a + b << endl;
    cout << "a-b="<<a - b << endl;

    if(a == b)
        cout << "a==b" << endl;
    else
        cout << "a!=b" << endl;

    return 0;
}
