#ifndef NATURENUMBER_HPP
#define NATURENUMBER_HPP

#include <iostream>
using namespace std;

class NatureNumber {
    friend ostream& operator<<(ostream& os, const NatureNumber& r);
    friend istream& operator>>(istream& is, NatureNumber& r);

public:
    NatureNumber(int val=0);  
    bool operator==(const NatureNumber &s) const;
    friend NatureNumber operator+(const NatureNumber& x, const NatureNumber& y);
    friend NatureNumber operator-(const NatureNumber& x, const NatureNumber& y);

private:
    int a;  
};

#endif
