#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include <iostream>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
public:
    vector<Term> terms;

    Polynomial() {}

    Polynomial Add(const Polynomial &p) const;

    friend ostream& operator<<(ostream &os, const Polynomial &p);
    friend istream& operator>>(istream &is, Polynomial &p);
};

#endif
