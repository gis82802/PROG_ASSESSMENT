#ifndef TERM_H
#define TERM_H

#include <iostream>
using namespace std;

class Term {
public:
    int coef;  // 係數
    int exp;   // 次方

    Term(int c=0, int e=0) : coef(c), exp(e) {}
};

#endif
