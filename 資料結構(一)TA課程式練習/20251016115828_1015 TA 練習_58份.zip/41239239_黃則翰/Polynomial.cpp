#include <iostream>
#include <vector>
using namespace std;

// ------------------- Term -------------------
class Term {
public:
    int coef;  // 係數
    int exp;   // 次方

    Term(int c=0, int e=0) : coef(c), exp(e) {}
};

// ------------------- Polynomial -------------------
class Polynomial {
public:
    vector<Term> terms;

    Polynomial() {}

    Polynomial Add(const Polynomial &p) const {
        Polynomial result = *this;

        for(const auto &t : p.terms) {
            bool added = false;
            for(auto &r : result.terms) {
                if(r.exp == t.exp) {
                    r.coef += t.coef;
                    added = true;
                    break;
                }
            }
            if(!added) result.terms.push_back(t);
        }
        return result;
    }

    friend ostream& operator<<(ostream &os, const Polynomial &p) {
        for(size_t i = 0; i < p.terms.size(); i++) {
            const Term &t = p.terms[i];
            if(i > 0 && t.coef > 0) os << "+";
            os << t.coef;
            if(t.exp != 0) os << "x^" << t.exp;
        }
        return os;
    }

    friend istream& operator>>(istream &is, Polynomial &p) {
        int n; // 幾項
        cout << "Enter number of terms: ";
        is >> n;
        p.terms.clear();
        for(int i = 0; i < n; i++) {
            int c,e;
            cout << "Enter coef and exp for term " << i+1 << ": ";
            is >> c >> e;
            p.terms.push_back(Term(c,e));
        }
        return is;
    }
};

int main(int argc, const char * argv[]){
    Polynomial a,b;

    cout << "input poly A" <<endl;
    cin >> a;

    cout << "input poly B" <<endl;
    cin >> b;

    cout << "a=" <<a<<endl;
    cout << "b=" <<b<<endl;
    cout << "a+b=" <<a.Add(b)<<endl;

    return 0;
}
