#ifndef NATURENUMBER_HPP
#define NATURENUMBER_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned long long value_;

public:
    NatureNumber();
    NatureNumber(unsigned long long v);

    NatureNumber operator+(const NatureNumber& other) const;
    NatureNumber operator-(const NatureNumber& other) const;
    NatureNumber operator*(const NatureNumber& other) const;

    bool operator==(const NatureNumber& other) const;
    bool operator!=(const NatureNumber& other) const;
    bool operator<(const NatureNumber& other) const;
    bool operator>(const NatureNumber& other) const;
    bool operator<=(const NatureNumber& other) const;
    bool operator>=(const NatureNumber& other) const;

    NatureNumber& operator++();
    NatureNumber operator++(int);
    NatureNumber& operator--();
    NatureNumber operator--(int);

    friend istream& operator>>(istream& is, NatureNumber& n);
    friend ostream& operator<<(ostream& os, const NatureNumber& n);
};

#endif
