#include "NatureNumber.hpp"
#include <stdexcept>

NatureNumber::NatureNumber() : value_(0) {}
NatureNumber::NatureNumber(unsigned long long v) : value_(v) {}

NatureNumber NatureNumber::operator+(const NatureNumber& other) const {
    return NatureNumber(value_ + other.value_);
}

NatureNumber NatureNumber::operator-(const NatureNumber& other) const {
    if (value_ < other.value_)
        throw underflow_error("result would be negative");
    return NatureNumber(value_ - other.value_);
}

NatureNumber NatureNumber::operator*(const NatureNumber& other) const {
    return NatureNumber(value_ * other.value_);
}

bool NatureNumber::operator==(const NatureNumber& other) const { return value_ == other.value_; }
bool NatureNumber::operator!=(const NatureNumber& other) const { return value_ != other.value_; }
bool NatureNumber::operator<(const NatureNumber& other) const { return value_ < other.value_; }
bool NatureNumber::operator>(const NatureNumber& other) const { return value_ > other.value_; }
bool NatureNumber::operator<=(const NatureNumber& other) const { return value_ <= other.value_; }
bool NatureNumber::operator>=(const NatureNumber& other) const { return value_ >= other.value_; }

NatureNumber& NatureNumber::operator++() {
    ++value_;
    return *this;
}

NatureNumber NatureNumber::operator++(int) {
    NatureNumber temp(*this);
    ++value_;
    return temp;
}

NatureNumber& NatureNumber::operator--() {
    if (value_ == 0)
        throw underflow_error("decrement would be negative");
    --value_;
    return *this;
}

NatureNumber NatureNumber::operator--(int) {
    if (value_ == 0)
        throw underflow_error("decrement would be negative");
    NatureNumber temp(*this);
    --value_;
    return temp;
}

istream& operator>>(istream& is, NatureNumber& n) {
    unsigned long long tmp;
    is >> tmp;
    n.value_ = tmp;
    return is;
}

ostream& operator<<(ostream& os, const NatureNumber& n) {
    os << n.value_;
    return os;
}

#include <iostream>
#include "NatureNumber.hpp"
using namespace std;

int main() {
    NatureNumber a, b;

    cout << "input  A " << endl;
    cin >> a;

    cout << "input  B " << endl;
    cin >> b;

    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "a+b=" << a + b << endl;
    cout << "a-b=" << a - b << endl; 

    if (a == b) {
        cout << "a=b" << endl;
    }
    else if (a != b) {
        cout << "a!=b" << endl;
    }

    return 0;
}
