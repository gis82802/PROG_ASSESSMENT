#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

public:
    Polynomial() {}

    void AddTerm(double coef, int exp) {
        if (coef == 0) return;


        for (auto& t : terms) {
            if (t.exp == exp) {
                t.coef += coef;
                if (t.coef == 0) {
                    terms.erase(remove_if(terms.begin(), terms.end(),
                        [&](const Term& x) { return x.exp == exp; }),
                        terms.end());
                }
                return;
            }
        }
        terms.push_back(Term(coef, exp));
        sort(terms.begin(), terms.end());
    }

    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;
        for (auto& t : other.terms) {
            result.AddTerm(t.coef, t.exp);
        }
        return result;
    }

    friend istream& operator>>(istream& in, Polynomial& poly) {
        int n;
        in >> n; 
        for (int i = 0; i < n; i++) {
            double c; int e;
            in >> c >> e;
            poly.AddTerm(c, e);
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& poly) {
        if (poly.terms.empty()) {
            out << "0";
            return out;
        }
        for (size_t i = 0; i < poly.terms.size(); i++) {
            const Term& t = poly.terms[i];
            if (i > 0 && t.coef > 0) out << "+";
            out << t.coef;
            if (t.exp != 0) out << "x^" << t.exp;
        }
        return out;
    }
};

#endif
