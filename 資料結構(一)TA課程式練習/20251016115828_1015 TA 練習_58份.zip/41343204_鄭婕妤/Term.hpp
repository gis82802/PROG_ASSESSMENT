#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
public:
    double coef; 
    int exp; 

    Term(double c = 0, int e = 0) : coef(c), exp(e) {}

    bool operator<(const Term& other) const {
        return exp > other.exp;
    }
    bool operator==(const Term& other) const {
        return exp == other.exp;
    }
};

#endif
