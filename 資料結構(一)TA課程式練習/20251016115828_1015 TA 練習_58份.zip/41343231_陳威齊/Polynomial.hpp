// Polynomial.hpp
#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include "Term.hpp"
#include <vector>
#include <algorithm>
using namespace std;

class Polynomial {
private:
    vector<Term> terms;  // �x�s�h��������

public:
    // �w�]�غc�l
    Polynomial() {}

    // ������J�B��l >>
    friend istream& operator>>(istream& in, Polynomial& poly) {
        int n;
        cout << "Enter the number of terms: ";
        in >> n;
        poly.terms.clear();
        for (int i = 0; i < n; i++) {
            Term t;
            in >> t;
            poly.terms.push_back(t);
        }
        return in;
    }

    // ������X�B��l <<
    friend ostream& operator<<(ostream& out, const Polynomial& poly) {
        if (poly.terms.empty()) {
            out << "0";
        }
        else {
            // �Nterms���ӫ��Ʊq����C�Ƨ�
            vector<Term> sortedTerms = poly.terms;
            sort(sortedTerms.begin(), sortedTerms.end(), greater<Term>());

            for (size_t i = 0; i < sortedTerms.size(); i++) {
                if (i > 0 && sortedTerms[i].getCoefficient() > 0)
                    out << " + ";
                out << sortedTerms[i];
            }
        }
        return out;
    }

    // �i��h�����[�k
    Polynomial add(const Polynomial& other) const {
        Polynomial result;
        size_t i = 0, j = 0;
        while (i < terms.size() && j < other.terms.size()) {
            if (terms[i].getExponent() == other.terms[j].getExponent()) {
                double newCoef = terms[i].getCoefficient() + other.terms[j].getCoefficient();
                if (newCoef != 0) {
                    result.terms.push_back(Term(newCoef, terms[i].getExponent()));
                }
                i++;
                j++;
            }
            else if (terms[i].getExponent() < other.terms[j].getExponent()) {
                result.terms.push_back(other.terms[j]);
                j++;
            }
            else {
                result.terms.push_back(terms[i]);
                i++;
            }
        }

        while (i < terms.size()) {
            result.terms.push_back(terms[i]);
            i++;
        }

        while (j < other.terms.size()) {
            result.terms.push_back(other.terms[j]);
            j++;
        }

        // ���G�Ƨ�
        sort(result.terms.begin(), result.terms.end(), greater<Term>());
        return result;
    }
};

#endif // POLYNOMIAL_HPP
