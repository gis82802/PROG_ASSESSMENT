#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
private:
    double coefficient;  // �Y��
    int exponent;        // ����

public:
    Term(double c = 0.0, int e = 0) : coefficient(c), exponent(e) {}

    int getExponent() const { return exponent; }
    double getCoefficient() const { return coefficient; }

    void setCoefficient(double c) { coefficient = c; }
    void setExponent(int e) { exponent = e; }

    bool operator<(const Term& other) const {
        return exponent < other.exponent;  // ������Ƥj�p
    }

    bool operator>(const Term& other) const {
        return exponent > other.exponent;
    }

    bool operator==(const Term& other) const {
        return exponent == other.exponent;
    }

    // ����<<�B��l�A���Term
    friend ostream& operator<<(ostream& out, const Term& term) {
        if (term.coefficient != 0) {
            if (term.exponent == 0)
                out << term.coefficient;
            else if (term.exponent == 1)
                out << term.coefficient << "x";
            else
                out << term.coefficient << "x^" << term.exponent;
        }
        return out;
    }

    // ����>>�B��l�A�q��JŪ��Term
    friend istream& operator>>(istream& in, Term& term) {
        in >> term.coefficient >> term.exponent;
        return in;
    }
};

#endif // TERM_HPP
