#include <iostream>
#include "NaturalNum.hpp"
using namespace std;

int main() {
    NaturalNumber a, b;
    NaturalNumber* c;

    cout << "a :";
    cin >> a;
    cout << "b :";
    cin >> b;


    cout << a + b << endl << a - b << endl;

    if (a == b) {
        cout << "a == b" << endl;

    }
    else {
        cout << " a != b" << endl;
    }

    system("pause");
    return 0;

}