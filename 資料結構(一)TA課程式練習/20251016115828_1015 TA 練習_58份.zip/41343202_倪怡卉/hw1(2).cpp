#include<iostream>
#include "Naturenum.h"

int main() {
	Naturenum a, b;

	std::cin >> a;
	std::cin >> b;

	std::cout << a + b << std::endl;
	std::cout << a - b << std::endl;

	if (a == b) {
		std::cout << "a==b" << std::endl;
	}
	else
	{
		std::cout << "a!=b" << std::endl;
	}

	system("pause");
	return 0;
}