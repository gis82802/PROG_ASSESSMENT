#pragma once
#include <iostream>
#include<string>
#include<algorithm>

class Naturenum {
private:
	std::string number;

	void removezeros() {
		size_t pos = number.find_first_not_of('0');
		if (pos == std::string::npos) {
			number = "0";
		}
		else {
			number = number.substr(pos);
		}
	}

	bool isvalidnumber(const std::string& str){
		if (str.empty()) return false;
		for (char c : str) {
			if (!isdigit(c)) return false;
		}
		return true;
	}
public:
	Naturenum(): number("0"){}
	Naturenum(const std::string& num) {
		if (isvalidnumber(num)) {
			number = num;
			removezeros();
		}
		else
		{
			number ="0";
		}
	}

	Naturenum operator+(const Naturenum& other) const {
		std::string result;
		int carry = 0;
		int i = (int)number.length() - 1;
		int j = (int)other.number.length() - 1;

		while (i >= 0 || j >= 0 || carry) {
			int sum = carry;
			if (i >= 0)sum += number[i--] - '0';
			if (j >= 0)sum += other.number[j--] - '0';

			result.push_back((sum % 10) + '0');
			carry = sum / 10;
		}

		std::reverse(result.begin(), result.end());
		return Naturenum(result);
		}

	Naturenum operator-(const Naturenum& other) const {
		if (*this< other) {
			return Naturenum("0");
		}

		std::string result;
		int borrow = 0;
		int i = (int)number.length() - 1;
		int j = (int)other.number.length() - 1;

		while (i >= 0) {
			int digit1 = number[i--]-'0';
			int digit2 = (j >= 0) ? other.number[j--] - '0':0;
		
			digit1 -= borrow;
			if (digit1 < digit2) {
				digit1 += 10;
				borrow = 1;
			}
			else
			{
				borrow = 0;
			}

			result.push_back((digit1 - digit2) + '0');
		}

		std::reverse(result.begin(), result.end());
		return Naturenum(result);
	}
	bool operator==(const Naturenum& other)const {
		return number == other.number;
	}

	bool operator<(const Naturenum& other)const {
		if (number.length()!=other.number.length()) {
			return number.length() < other.number.length();
		}
		return number < other.number;
	}

	friend std::istream& operator>>(std::istream& is, Naturenum& num) {
		std::string input;
		is >> input;

		bool valid = true;
		for (char c : input) {
			if (!isdigit(c)) {
				valid = false;
				break;
			}
		}

		if (valid&&!input.empty()) {
			num.number = input;
			num.removezeros();
		}
		else {
			num.number = "0";
		}
		return is;
	}

	friend std::ostream& operator<<(std::ostream& os, const Naturenum& num) {
		os << num.number;
		return os;
	}
};
