#ifndef term_hpp
#define term_hpp

#include <iostream>
#include <stdexcept>
#include <cmath>

class term {
private:
	double coeff;
	int exp;

public:

	term(double c=0.0,int e=0):coeff(c),exp(e){}

	double getcoeff() const { return coeff; }
	int getexp() const { return exp; }
	void setcoeff(double c) { coeff = c; }
	void setexp(int e) { exp = e; }


	bool operator<(const term& other)const {
		return exp > other.exp;
	}

	bool operator==(const term& other)const {
		return exp == other.exp;
	}

	term operator+(const term& other) const {
		if (exp != other.exp) {
			throw std::invalid_argument("exponents must be equal for addition");
		}
		return term(coeff + other.coeff, exp);
	}
};
inline std::istream& operator>>(std::istream& is,term&Term) {
	double coeff;
	int exp;

	if (is>> coeff >> exp) {
		Term.setcoeff(coeff);
		Term.setexp(exp);
	}

	return is;
}

inline std::ostream& operator<<(std::ostream& os, const term& Term) {
	double coeff = Term.getcoeff();
	int exp = Term.getexp();

	if (std::abs(coeff) < 1e-10) {
		return os;
	}

	if (std::abs(coeff - 1.0) < 1e-10 && exp != 0) {

	}
	else if (std::abs(coeff + 1.0) < 1e-10 && exp != 0) {
		os << "-";
	}
	else {
		if (coeff == static_cast<int>(coeff)) {
			os << static_cast<int>(coeff);
		}
		else {
			os << coeff;
		}
	}

	if (exp > 0) {
		os << "x";
		if (exp > 1) {
			os << "^" << exp;
		}
	}
	else if (exp == 0) {

		if (std::abs(std::abs(coeff) - 1.0) < 1e-10) {

			os << std::abs(coeff);
		}
	}

	return os;
}
#endif
