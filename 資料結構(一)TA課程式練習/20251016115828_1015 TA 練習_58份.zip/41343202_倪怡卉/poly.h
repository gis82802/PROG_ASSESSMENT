#ifndef poly_hpp
#define poly_hpp

#include"term.h"
#include<vector>
#include<algorithm>

class poly {
private:
	std::vector<term> Terms;

	void sim() {
		if (Terms.empty());

			std::sort(Terms.begin(), Terms.end());

			std::vector<term> sim;
			sim.push_back(Terms[0]);

			for (size_t i = 1; i < Terms.size(); i++) {
				if (Terms[i].getexp() == sim.back().getexp()) {

					double ncoeff = sim.back().getcoeff() + Terms[i].getcoeff();
					sim.back().setcoeff(ncoeff);
				}
				else {
					sim.push_back(Terms[i]);
				}
			}

			Terms.clear();
			for (const auto& term : sim) {
				if (term.getcoeff() != 0.0) {
					Terms.push_back(term);
				}
			}
	}
public:
	poly() = default;

	poly Add(const poly& other) const {
		poly result;

		result.Terms = this->Terms;

		for (const auto& term : other.Terms) {
			result.Terms.push_back(term);
		}

		result.sim();
		return result;
	}

	void ct() { Terms.clear(); }
	void at(const term& term) { Terms.push_back(term); }
	const std::vector<term>& gt()const { return Terms; }

	void simpoly() { sim(); }
};
inline std::istream& operator>>(std::istream& is,poly&Poly) {
	int termcount;

	if (is>>termcount) {
		Poly.ct();

		if (termcount==0) {
			return is;
		}

		for (int i = 0; i < termcount; i++) {
			term term;
			if (is>>term){
				if (term.getcoeff()!=0.0){
					Poly.at(term);
				}
			}
		}

		Poly.simpoly();
	}

	return is;
}
inline std::ostream& operator<<(std::ostream& os,const poly& Poly) {
	const std::vector<term>& terms = Poly.gt();

	if (terms.empty()) {
		os<<"0";
		return os;
	}

	bool ft = true;
	for (const auto& term : terms) {

		if (!ft&&term.getcoeff()>0) {
			os<<"+";
		}

		os << term;
		ft = false;
	}

	return os;
}
#endif
