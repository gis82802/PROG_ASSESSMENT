#pragma once
#include <vector>
#include <algorithm>
#include <iostream>
#include "Term.hpp"

class Polynomial {
public:
    Polynomial() {}

    // A + B�]���D�ت� main �ϥΦ����禡 Add�^
    Polynomial Add(const Polynomial& b) const {
        Polynomial r;
        r.terms_.reserve(terms_.size() + b.terms_.size());
        r.terms_.insert(r.terms_.end(), terms_.begin(), terms_.end());
        r.terms_.insert(r.terms_.end(), b.terms_.begin(), b.terms_.end());
        r.normalize_();
        return r;
    }

    // Ū�J�Gn ���ᱵ n �� (coef exp)
    friend std::istream& operator>>(std::istream& is, Polynomial& p) {
        std::size_t n;
        if (!(is >> n)) return is;
        std::vector<Term> v;
        v.reserve(n);
        for (std::size_t i = 0; i < n; ++i) {
            int c, e;
            if (!(is >> c >> e)) { is.setstate(std::ios::failbit); return is; }
            v.emplace_back(c, e);
        }
        p.terms_ = std::move(v);
        p.normalize_();
        return is;
    }

    // ��X�G�H���iŪ���h�����r�ˡ]�����B�X�֦P�����B���h�Y�� 1 �� x^k�^
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        if (p.terms_.empty()) { os << 0; return os; }
        bool first = true;
        for (const auto& t : p.terms_) {
            if (t.coef == 0) continue;
            int c = t.coef, e = t.exp;
            int absC = c < 0 ? -c : c;

            if (first) {
                if (c < 0) os << '-';
                if (e == 0 || absC != 1) os << absC;
            }
            else {
                os << (c < 0 ? " - " : " + ");
                if (e == 0 || absC != 1) os << absC;
            }

            if (e > 0) {
                os << 'x';
                if (e != 1) os << '^' << e;
            }
            first = false;
        }
        if (first) os << 0; // �����Y�Ƭ� 0
        return os;
    }

private:
    std::vector<Term> terms_; // �����G�����B�P����w�X�֡B�L 0 �Y��

    void normalize_() {
        // ���� exp �����Ƨ�
        std::sort(terms_.begin(), terms_.end(),
            [](const Term& a, const Term& b) { return a.exp > b.exp; });

        // �X�֦P���� + �h�� 0 �Y��
        std::vector<Term> merged;
        for (const auto& t : terms_) {
            if (t.coef == 0) continue;
            if (!merged.empty() && merged.back().exp == t.exp) {
                merged.back().coef += t.coef;
                if (merged.back().coef == 0) merged.pop_back(); // �X�֫��k�s�N����
            }
            else {
                merged.push_back(t);
            }
        }
        terms_.swap(merged);
    }
};
