// natureNum.hpp �X �u���ѥ[�k�P��k�]�t I/O�^
#pragma once
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
#include <cctype>
#include <stdexcept>

class NatureNumber {
public:
    NatureNumber() : d_{ 0 } {}
    explicit NatureNumber(const std::string& s) { fromString_(s); }

    // --- I/O ---
    friend std::istream& operator>>(std::istream& is, NatureNumber& x) {
        std::string s; is >> s;
        if (!is) return is;
        try { x.fromString_(s); }
        catch (...) { is.setstate(std::ios::failbit); }
        return is;
    }
    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& x) {
        for (std::size_t i = x.d_.size(); i-- > 0; ) os << char('0' + x.d_[i]);
        return os;
    }

    // --- �[�k ---
    friend NatureNumber operator+(const NatureNumber& a, const NatureNumber& b) {
        NatureNumber r;
        r.d_.assign(std::max(a.d_.size(), b.d_.size()) + 1, 0);
        unsigned carry = 0;
        for (std::size_t i = 0; i < r.d_.size(); ++i) {
            unsigned ai = (i < a.d_.size() ? a.d_[i] : 0);
            unsigned bi = (i < b.d_.size() ? b.d_[i] : 0);
            unsigned s = ai + bi + carry;
            r.d_[i] = static_cast<unsigned char>(s % 10);
            carry = s / 10;
        }
        r.trim_();
        return r;
    }

    // --- ��k�]�Y a<b�A�^�� 0 �H�����۵M�ơ^---
    friend NatureNumber operator-(const NatureNumber& a, const NatureNumber& b) {
        if (cmp_(a, b) < 0) return NatureNumber("0");
        NatureNumber r; r.d_.assign(a.d_.size(), 0);
        int borrow = 0;
        for (std::size_t i = 0; i < a.d_.size(); ++i) {
            int ai = a.d_[i] - borrow;
            int bi = (i < b.d_.size() ? b.d_[i] : 0);
            if (ai < bi) { ai += 10; borrow = 1; }
            else borrow = 0;
            r.d_[i] = static_cast<unsigned char>(ai - bi);
        }
        r.trim_();
        return r;
    }

private:
    // �H�p���x�s�Gd_[0] ���Ӧ�A�C��@��� 0..9
    std::vector<unsigned char> d_;

    void trim_() {
        while (d_.size() > 1 && d_.back() == 0) d_.pop_back();
    }
    void fromString_(const std::string& s) {
        std::string t; t.reserve(s.size());
        for (char c : s) {
            if (std::isspace(static_cast<unsigned char>(c))) continue;
            if (!std::isdigit(static_cast<unsigned char>(c)))
                throw std::invalid_argument("NatureNumber: �D�Ʀr�r��");
            t.push_back(c);
        }
        if (t.empty()) { d_ = { 0 }; return; }
        std::size_t i = 0;
        while (i + 1 < t.size() && t[i] == '0') ++i;   // �h�e�� 0
        d_.clear(); d_.reserve(t.size() - i);
        for (; i < t.size(); ++i) d_.push_back(static_cast<unsigned char>(t[i] - '0'));
        std::reverse(d_.begin(), d_.end());           // ���������ݡ]�p�ݡ^
        trim_();
    }
    // ��������Ga<b �^�� -1�Fa==b �^�� 0�Fa>b �^�� 1
    static int cmp_(const NatureNumber& a, const NatureNumber& b) {
        if (a.d_.size() != b.d_.size()) return (a.d_.size() < b.d_.size()) ? -1 : 1;
        for (std::size_t i = a.d_.size(); i-- > 0; ) {
            if (a.d_[i] != b.d_[i]) return (a.d_[i] < b.d_[i]) ? -1 : 1;
        }
        return 0;
    }
};
