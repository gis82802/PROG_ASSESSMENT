#ifndef POLYNOMIAL2_HPP
#define POLYNOMIAL2_HPP

#include "Polynomial1.hpp"
#include <vector>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cmath>

class Polynomial {
private:
    std::vector<Term> terms;

    void normalize() {
        if (terms.empty()) return;
        std::sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });

        std::vector<Term> tmp;
        double curCoef = terms[0].coef;
        int curExp = terms[0].exp;
        for (size_t i = 1; i < terms.size(); ++i) {
            if (terms[i].exp == curExp) {
                curCoef += terms[i].coef;
            }
            else {
                if (std::abs(curCoef) > 1e-12)
                    tmp.emplace_back(curCoef, curExp);
                curCoef = terms[i].coef;
                curExp = terms[i].exp;
            }
        }
        if (std::abs(curCoef) > 1e-12)
            tmp.emplace_back(curCoef, curExp);
        terms.swap(tmp);
    }

public:
    Polynomial() = default;
    explicit Polynomial(const std::vector<Term>& t) : terms(t) { normalize(); }

    Polynomial Add(const Polynomial& other) const {
        std::vector<Term> merged = terms;
        merged.insert(merged.end(), other.terms.begin(), other.terms.end());
        Polynomial result(merged);
        result.normalize();
        return result;
    }

    // �h������X
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        if (p.terms.empty()) {
            os << "0";
            return os;
        }
        bool first = true;
        for (const auto& t : p.terms) {
            double c = t.coef;
            if (first) {
                if (c < 0) os << "-";
                os << t.bodyString();
                first = false;
            }
            else {
                if (c < 0) os << "-";
                else os << "+";
                os << t.bodyString();
            }
        }
        return os;
    }

    // �h������J�]���崣�ܪ��^
    friend std::istream& operator>>(std::istream& is, Polynomial& p) {
        p.terms.clear();
        int n;
        std::cout << "�п�J�h���������ơG";
        is >> n;
        for (int i = 0; i < n; ++i) {
            double c;
            int e;
            std::cout << "�п�J�� " << (i + 1) << " �����Y�ƻP���ơ]�����H�ťդ��j�^�G";
            is >> c >> e;
            p.terms.emplace_back(c, e);
        }
        p.normalize();
        return is;
    }
};

#endif // POLYNOMIAL2_HPP
