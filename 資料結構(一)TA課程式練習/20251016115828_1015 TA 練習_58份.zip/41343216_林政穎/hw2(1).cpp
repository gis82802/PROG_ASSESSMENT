#include <iostream>
#include "Polynomial1.hpp"
#include "Polynomial2.hpp"
using namespace std;

int main(int argc, const char* argv[]) {
    Polynomial a, b;

    cout << "==== �h�����ۥ[�{�� ====" << endl;
    cout << "�п�J�h���� A�G" << endl;
    cin >> a;

    cout << "\n�п�J�h���� B�G" << endl;
    cin >> b;

    cout << "\n==== ���G ====" << endl;
    cout << "A(x) = " << a << endl;
    cout << "B(x) = " << b << endl;
    cout << "A(x) + B(x) = " << a.Add(b) << endl;

    cout << "===================" << endl;

    return 0;
}
