#ifndef Term_hpp
#define Term_hpp

#include <iostream>
#include<stdio.h>
using namespace std;
class Polynomial;
class Term {
    friend ostream& operator <<(ostream& output, const Polynomial& p);
    friend istream& operator >>(istream& iuput, const Polynomial& thePoly);
    friend Polynomial;
    private:
        int coef;
        int exp;
};

#endif
