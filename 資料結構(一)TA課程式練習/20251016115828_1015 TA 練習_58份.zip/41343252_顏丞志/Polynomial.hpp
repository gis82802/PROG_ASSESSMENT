#ifndef  Polynomial_hpp
#define  Polynomial_hpp
#include <iostream>
#include<stdio.h>
#include "Term.hpp"
using namespace std;
class Polynomial
{
friend ostream& operator <<(ostream& output, const Polynomial& p)
{
		int c, e;
		string sign;
		for (int i = 0; i < p.terms; i++) {
			c = p.termArray[i].coef;
			e = p.termArray[i].exp;
			if (i > 0 && c > 0) sign = "+";
			else sign = "";
			cout << sign << c;
			if (e > 1) cout << "x^" << e;
			else if (e == 1) cout << "x";
		}
		return output;
}
friend istream& operator >>(istream& input, Polynomial& p) {
		int numTerms;
		float c;
		int e;
		cout << "please input the num of tem of A poly ";
		cin >> numTerms;
		for (int i = 0; i < numTerms; i++) {
			cout << "input the " << i << "th coeff:";
			cin >> c;
			cout << "input the " << i << "th exp:";
			cin >> e;
			p.NewTerm(c, e);
		}
		return input;
}
private:
	Term* termArray;
	int capacity;
	int terms;
public:
	Polynomial(int numTerm=0)
	{
		terms = numTerm;
		capacity = 10;
		termArray = new Term[capacity];
	}
	void NewTerm(const float c, const int e) {
		if (terms == capacity) {
			capacity *= 2;
			Term* temp = new Term[capacity];
			copy(termArray, termArray + terms, temp);
			delete[] termArray;
			termArray = temp;
		}
		termArray[terms].coef = c;
		termArray[terms++].exp = e;
	}
	Polynomial Add(Polynomial b) {
		Polynomial c;
		int aPos = 0, bPos = 0;
		while ((aPos < terms) && (bPos < b.terms)) {
			if (termArray[aPos].exp == b.termArray[bPos].exp) {
				float t = termArray[aPos].coef + b.termArray[bPos].coef;
				if (t) c.NewTerm(t, termArray[aPos].exp);
				aPos++; bPos++;
			}
			else if (termArray[aPos].exp < b.termArray[bPos].exp) {
				c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
				bPos++;
			}
			else {
				c.NewTerm(termArray[aPos].coef, termArray[aPos].exp);
				aPos++;
			}
		}
		for (; aPos < terms; aPos++)
			c.NewTerm(termArray[aPos].coef, termArray[aPos].exp);
		for (; bPos < b.terms; bPos++)
			c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
		return c;
	}
};
#endif
