#ifndef natureNum_hpp
#define natureNum_hpp

#include <iostream>
#include <string>

class NatureNumber {
private:
    int a;

public:
    NatureNumber() : a(0) {}

    NatureNumber(int val) {
        if (val < 0) {
            std::cerr << "�۵M�Ƥ��ର�t��,�w�]�w��0" << std::endl;
            a = 0;
        }
        else {
            a = val;
        }
    }

    NatureNumber operator+(const NatureNumber& other) const;

    NatureNumber operator-(const NatureNumber& other) const;

    bool operator==(const NatureNumber& other) const;

    friend std::ostream& operator<<(std::ostream& output, const NatureNumber& n);

    friend std::istream& operator>>(std::istream& input, NatureNumber& n);
};

NatureNumber NatureNumber::operator+(const NatureNumber& other) const {
    return NatureNumber(this->a + other.a);
}

NatureNumber NatureNumber::operator-(const NatureNumber& other) const {
    return NatureNumber(this->a - other.a);
}

bool NatureNumber::operator==(const NatureNumber& other) const {
    return this->a == other.a;
}

std::ostream& operator<<(std::ostream& output, const NatureNumber& n) {
    output << n.a;
    return output;
}

std::istream& operator>>(std::istream& input, NatureNumber& n) {
    int temp_val;

    if (input >> temp_val) {
        if (temp_val < 0) {
            std::cerr << "��J���ର�t��,�w�]�w��0" << std::endl;
            n.a = 0;
        }
        else {
            n.a = temp_val;
        }
    }
    return input;
}

#endif // natureNum_hpp