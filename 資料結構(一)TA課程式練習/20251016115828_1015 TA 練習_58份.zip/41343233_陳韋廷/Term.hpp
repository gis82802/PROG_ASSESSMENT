#ifndef Term_hpp
#define Term_hpp
#include <stdio.h>
#include <iostream>
using namespace std;

class Polynomial;

class Term {
	friend ostream& operator<<(ostream& output, const Polynomial& p);
	friend istream& operator>>(istream& input, Polynomial& thePoly);
	friend Polynomial;
private:
	float coef;
	int exp;
};

#endif