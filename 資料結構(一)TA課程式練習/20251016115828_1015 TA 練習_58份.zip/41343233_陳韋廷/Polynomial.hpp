#ifndef Polynomial_hpp
#define Polynomial_hpp

#include <stdio.h>
#include"Term.hpp"
#include<iostream>

class Polynomial {
	friend ostream& operator<<(ostream& output, const Polynomial& thePoly);
	friend istream& operator>>(istream& input, Polynomial& thePoly);
public:
	Polynomial(int numTerm = 0);
	Polynomial add(Polynomial b);
	void NewTerm(const float c, const int e);

private:
	Term* termArray;
	int capacity;
	int terms;

};

Polynomial::Polynomial(int numTerm) {
	terms = numTerm;
	capacity = 10;
	termArray = new Term[capacity];
}

Polynomial Polynomial::add(Polynomial b) {
	Polynomial c;
	int aPos = 0, bPos = 0;
	while ((aPos < terms) && (bPos < b.terms)) {
		if (termArray[aPos].exp == b.termArray[bPos].exp) {
			float t = termArray[aPos].coef + b.termArray[bPos].coef;
			if (t) c.NewTerm(t, termArray[aPos].exp);
			aPos++; bPos++;
		}
		else if (termArray[aPos].exp < b.termArray[bPos].exp) {
			c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
			bPos++;
		}
		else {
			c.NewTerm(termArray[aPos].coef,termArray[aPos].exp);
			aPos++;
		}
	}
	for(;aPos<terms; aPos++)
		c.NewTerm(b.termArray[aPos].coef,termArray[aPos].exp);
	for(;bPos<b.terms;bPos++)
		c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
	 
	return c;
}

void Polynomial::NewTerm(const float theCoeff, const int theExp) {
	if (terms == capacity) {
		capacity *= 2;
		Term* temp = new Term[capacity];
		copy(termArray, termArray + terms, temp);
		delete[] termArray;
		termArray = temp;
	}
	termArray[terms].coef = theCoeff;
	termArray[terms++].exp = theExp;
}

ostream& operator<<(ostream& output, const Polynomial& p) {
	int c, e;
	string sign;
	for (int i = 0; i < p.terms; i++) {
		c = p.termArray[i].coef;
		e = p.termArray[i].exp;
		if (i > 0 && c > 0) sign = "+";
		else sign = "";
		cout << sign << c;
		if (e > 1) cout << "x^" << e;
		else if (e == 1) cout << "x";
	}
	return output;
}

istream& operator>>(istream& input, Polynomial& p) {
	int numTerms;
	float c;
	int e;
	cout << "Please input the number of terms: ";
	cin >> numTerms;
	for (int i = 0; i < numTerms; i++) {
		cout << "input the " << i << "th coeff:";
		cin >> c;
		cout << "input the " << i << "th exp:";
		cin >> e;
		p.NewTerm(c, e);
	}
	return input;
}

#endif