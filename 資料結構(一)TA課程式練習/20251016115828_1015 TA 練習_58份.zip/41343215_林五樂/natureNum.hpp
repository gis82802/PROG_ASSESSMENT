#ifndef NATURENUMBER_HPP
#define NATURENUMBER_HPP
#include <iostream>
class NatureNumber {
private:
    unsigned int value;
public:
    NatureNumber() : value(0) {}
    NatureNumber operator+(const NatureNumber& other) const {
        NatureNumber result;
        result.value = this->value + other.value;
        return result;
    }
    NatureNumber operator-(const NatureNumber& other) const {
        NatureNumber result;
        if (this->value > other.value) result.value = this->value - other.value;
        else result.value = 0;
        return result;
    }
    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }
    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& num) {
        os << num.value;
        return os;
    }
    friend std::istream& operator>>(std::istream& is, NatureNumber& num) {
        is >> num.value;
        return is;
    }
};
#endif