#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP
#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;
class Polynomial {
private:
    vector<Term> terms;
public:
    Polynomial() {}
    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "��J����: ";
        in >> n;
        p.terms.clear();
        for (int i = 0; i < n; ++i) {
            Term t;
            in >> t;
            p.terms.push_back(t);
        }
        sort(p.terms.begin(), p.terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });
        return in;
    }
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << "0";
            return out;
        }
        for (size_t i = 0; i < p.terms.size(); ++i) {
            if (i > 0 && p.terms[i].coef > 0)out << "+";
            out << p.terms[i];
        }
        return out;
    }
    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;
        for (const Term& t2 : other.terms) {
            bool merged = false;
            for (Term& t1 : result.terms) {
                if (t1.exp == t2.exp) {
                    t1.coef += t2.coef;
                    merged = true;
                    break;
                }
            }
            if (!merged)result.terms.push_back(t2);
        }
        sort(result.terms.begin(), result.terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });
        return result;
    }
};
#endif