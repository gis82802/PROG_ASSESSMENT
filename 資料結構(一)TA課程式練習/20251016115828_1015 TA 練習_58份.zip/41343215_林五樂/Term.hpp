#ifndef TERM_HPP
#define TERM_HPP
#include <iostream>
using namespace std;
class Term {
public:
    int coef;
    int exp;
    Term(int c = 0, int e = 0) : coef(c), exp(e) {}
    friend istream& operator>>(istream& in, Term& t) {
        cout << "��J�Y��: ";
        in >> t.coef;
        cout << "��J����: ";
        in >> t.exp;
        return in;
    }
    friend ostream& operator<<(ostream& out, const Term& t) {
        if (t.exp == 0)out << t.coef;
        else if (t.exp == 1)out << t.coef << "x";
        else out << t.coef << "x^" << t.exp;
        return out;
    }
};
#endif