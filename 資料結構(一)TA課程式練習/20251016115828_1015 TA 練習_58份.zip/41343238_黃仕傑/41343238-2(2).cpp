#include <iostream>
#include "Polynomial.hpp"
#include "Term.hpp"
using namespace std;

int main(int argc, const char* argv[]) {
    Polynomial a, b;

    // readin polynomial A
    cout << "input poly A " << endl;
    cin >> a;

    // readin polynomial B
    cout << "input poly B " << endl;
    cin >> b;

    // output
    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "a+b=" << a.Add(b) << endl;

    return 0;
}
