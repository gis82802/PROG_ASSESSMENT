#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"

class Polynomial {
public:
    Polynomial() = default;

    // A + B
    Polynomial Add(const Polynomial& rhs) const {
        Polynomial res;
        res.terms_ = terms_;
        res.terms_.insert(res.terms_.end(), rhs.terms_.begin(), rhs.terms_.end());
        res.normalize_();
        return res;
    }

    // ��X���ƾǱ`���榡�A�Ҧp�G3x^2-5x+1�F�Y�� 0 �h��X 0
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        if (p.terms_.empty()) { os << 0; return os; }

        bool first = true;
        for (const auto& t : p.terms_) {
            if (t.coef == 0) continue;

            if (!first) os << (t.coef >= 0 ? "+" : "-");
            else { if (t.coef < 0) os << "-"; first = false; }

            long long absC = t.coef >= 0 ? t.coef : -t.coef;

            if (t.exp == 0) {
                os << absC;
            }
            else if (t.exp == 1) {
                if (absC != 1) os << absC;
                os << "x";
            }
            else {
                if (absC != 1) os << absC;
                os << "x^" << t.exp;
            }
        }
        if (first) os << 0;
        return os;
    }

    // ��J�榡�G
    //   ����J���� n�A���ۿ�J n �աucoef exp�v
    //   �ҡG3  3 2  -5 1  1 0  => 3x^2 - 5x + 1
    friend std::istream& operator>>(std::istream& is, Polynomial& p) {
        size_t n;
        if (!(is >> n)) return is;
        std::vector<Term> tmp; tmp.reserve(n);
        for (size_t i = 0; i < n; ++i) {
            long long c; int e;
            is >> c >> e;
            tmp.emplace_back(c, e);
        }
        p.terms_.swap(tmp);
        p.normalize_();
        return is;
    }

private:
    std::vector<Term> terms_;

    // �X�֦P����B�R�� 0 �Y�ơB�̦���j���p�Ƨ�
    void normalize_() {
        std::sort(terms_.begin(), terms_.end()); // �� exp �Ѥj��p

        std::vector<Term> merged;
        for (const auto& t : terms_) {
            if (!merged.empty() && merged.back().exp == t.exp) {
                merged.back().coef += t.coef;
            }
            else {
                merged.push_back(t);
            }
        }
        std::vector<Term> cleaned;
        cleaned.reserve(merged.size());
        for (auto& t : merged) if (t.coef != 0) cleaned.push_back(t);
        terms_.swap(cleaned);
    }
};
