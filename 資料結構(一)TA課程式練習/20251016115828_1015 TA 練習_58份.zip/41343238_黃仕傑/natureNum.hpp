#pragma once
#include <iostream>

class NatureNumber {
public:
    using value_type = unsigned long long;

    explicit NatureNumber(value_type v = 0) : v_(v) {}

    value_type value() const { return v_; }

    NatureNumber& operator+=(const NatureNumber& rhs) { v_ += rhs.v_; return *this; }
    NatureNumber& operator-=(const NatureNumber& rhs) {
        v_ = (v_ >= rhs.v_) ? (v_ - rhs.v_) : 0;   // �O���۵M�ơA�קK�t��
        return *this;
    }

    friend NatureNumber operator+(NatureNumber lhs, const NatureNumber& rhs) { lhs += rhs; return lhs; }
    friend NatureNumber operator-(NatureNumber lhs, const NatureNumber& rhs) { lhs -= rhs; return lhs; }

    friend bool operator==(const NatureNumber& a, const NatureNumber& b) { return a.v_ == b.v_; }
    friend bool operator!=(const NatureNumber& a, const NatureNumber& b) { return !(a == b); }

    // ��J�G�Y��J�t�ơA�۰ʷ� 0�F��X�G�L�X�ƭ�
    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
        long long tmp;
        if (is >> tmp) n.v_ = (tmp >= 0) ? static_cast<value_type>(tmp) : 0ULL;
        return is;
    }
    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) { return os << n.v_; }

private:
    value_type v_;
};
