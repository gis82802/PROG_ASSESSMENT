#pragma once
#include <iostream>

struct Term {
    long long coef = 0; // �Y��
    int       exp = 0; // ����
    Term() = default;
    Term(long long c, int e) : coef(c), exp(e) {}
    // �ѱƧǡG����Ѥj��p
    bool operator<(const Term& other) const { return exp > other.exp; }
};
