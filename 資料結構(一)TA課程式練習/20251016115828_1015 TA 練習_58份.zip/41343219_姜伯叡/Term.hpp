#ifndef Term_hpp
#define Term_hpp

#include <iostream>

class Polynomial;

class Term{	
	friend std::ostream& operator<<(std::ostream &os, Polynomial &n);
	friend std::istream& operator>>(std::istream &is, Polynomial &n);
	friend Polynomial;
	public:
		double base;
		int pow;
		Term(): base(0.0), pow(0) {}
		Term(double b, int p): base(b), pow(p) {}
};

#endif

