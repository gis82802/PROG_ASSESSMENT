#include <iostream>

using namespace std;

class NatureNumber {
	private:
		unsigned long long num;	
	public:
		NatureNumber(): num(0) {}
		NatureNumber(unsigned long long in): num(in) {}
		friend NatureNumber operator+(NatureNumber a, NatureNumber& b) { return NatureNumber(a.num + b.num); }	
		friend NatureNumber operator-(NatureNumber a, NatureNumber& b) { 
			if (b.num >= a.num) return NatureNumber(0);
			else return NatureNumber(a.num - b.num);
		}	
		friend bool operator==(NatureNumber a, NatureNumber b) { return a.num == b.num; }	
		friend istream& operator>> (istream &is, NatureNumber &n){ 
			long long tmp;
	        if (!(is >> tmp)) return is;
	        if (tmp < 0) {
	            n.num = 0;
	        } else {
	            n.num = tmp;
	        }
        	return is; 
		}
		friend ostream& operator<< (ostream &os, NatureNumber n){
			os << n.num;
			return os;
		}	
};
