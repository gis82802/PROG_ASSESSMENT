#ifndef Polynomial_hpp
#define Polynomial_hpp

#include <iostream>
#include <vector>
#include "Term.hpp"

using namespace std;

class Polynomial {
	private:
		vector<Term> termAry;
		int terms;
	public:
		Polynomial(int numTerm=0){ terms = numTerm; }
		Polynomial Add(Polynomial b) { 
			Polynomial c;
			int aPos = 0, bPos = 0;
			while((aPos < terms) && (bPos < b.terms))
			{
				if(termAry[aPos].pow == b.termAry[bPos].pow)
				{
					double t = termAry[aPos].base + b.termAry[bPos].base;
					if(t) c.NewTerm(t, termAry[aPos].pow);
					aPos++; bPos++;
				}
				else if(termAry[aPos].pow < b.termAry[bPos].pow)
				{
					c.NewTerm(b.termAry[bPos].base, b.termAry[bPos].pow);
					bPos++;
				}
				else
				{
					c.NewTerm(termAry[aPos].base, termAry[aPos].pow);
					aPos++;
				}
			}
			for(; aPos < terms ; aPos++)
				c.NewTerm(termAry[aPos].base, termAry[aPos].pow);
			for(; bPos < b.terms ; bPos++)
				c.NewTerm(b.termAry[bPos].base, b.termAry[bPos].pow);
			return c;
		}	
		void NewTerm(double base, int pow)
		{
			termAry.push_back(Term(base, pow));
			terms++;
		}
		friend istream& operator>> (istream &is, Polynomial &n){ 
			int numTerms;
			double b;
			int p;
			
			cout << "please input the num of term of A poly ";
			cin >> numTerms;
			for(int i=0; i<numTerms; i++)
			{
				cout << "input the " << i << "th base number:";
				cin >> b;
				cout << "input the " << i << "th pow number:";
				cin >> p;
				n.NewTerm(b, p);
			}
	    	return is; 
		}
		friend ostream& operator<< (ostream &os, Polynomial n){
			double b;
			int p;
			for(int i=0;i<n.terms;i++)
			{
				b=n.termAry[i].base;
				p=n.termAry[i].pow;
				if(i>0 && b>0) os << "+" << b;
				else os << "" << b;
				if(p>1) os << "x^" << p;
				else if(p==1) os << "x"; 
			}
			return os;
		}		
};

#endif
