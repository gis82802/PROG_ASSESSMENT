#ifndef TERM_HPP
#define TERM_HPP
struct Term {
    int coef;
    int exp;
    Term(int c = 0, int e = 0) : coef(c), exp(e) {}
};
#endif