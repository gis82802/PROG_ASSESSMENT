#ifndef NATURE_NUM_H
#define NATURE_NUM_H

#include <iostream>
using namespace std;

class NatureNumber {
	int v;
public:
	NatureNumber(int x = 0) : v(x >= 0 ? x : 0) {

	}

	int value() const {
		return v;
	}

	// 讀入
	friend istream& operator >> (istream& in, NatureNumber& n) {
		int x;
		if (in >> x) {
			n.v = (x >= 0 ? x : 0);
		}
		return in;
	}

	// 比較
	friend bool operator == (const NatureNumber& a, const NatureNumber& b) {
		return a.v == b.v;
	}
	friend bool operator != (const NatureNumber& a, const NatureNumber& b) {
		return a.v != b.v;
	}

	// 加減
	friend int operator + (const NatureNumber& a, const NatureNumber& b) {
		return a.v + b.v;
	}
	friend int operator - (const NatureNumber& a, const NatureNumber& b) {
		if (a.v - b.v < 0){
			return 0;
		}else {
			return a.v - b.v;
		}
	}
};

#endif