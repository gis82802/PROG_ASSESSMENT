#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

public:
    // �A�O������
    Polynomial() {}

    // ����һ�
    void addTerm(double coef, int exp) {
        if (coef == 0) return;

        // ��ָ���Ѵ��ڣ��t�ρ�ͬ��
        for (auto& t : terms) {
            if (t.exp == exp) {
                t.coef += coef;
                return;
            }
        }
        terms.push_back(Term(coef, exp));
    }

    // �ӷ��\��
    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;
        for (const auto& t : other.terms)
            result.addTerm(t.coef, t.exp);
        result.simplify();
        return result;
    }

    // �������ʽ (�����c�Ƴ� 0 �S��)
    void simplify() {
        // �Ƴ� 0 �S���
        terms.erase(remove_if(terms.begin(), terms.end(),
            [](const Term& t) { return t.coef == 0; }),
            terms.end());
        // ��ָ���ɴ�С����
        sort(terms.begin(), terms.end(),
            [](const Term& a, const Term& b) { return a.exp > b.exp; });
    }

    // ݔ���\����
    friend istream& operator>>(istream& in, Polynomial& poly) {
        int n;
        cout << "Enter number of terms: ";
        in >> n;
        poly.terms.clear();
        for (int i = 0; i < n; i++) {
            double c; int e;
            cout << "Enter coef and exp: ";
            in >> c >> e;
            poly.addTerm(c, e);
        }
        poly.simplify();
        return in;
    }

    // ݔ���\����
    friend ostream& operator<<(ostream& out, const Polynomial& poly) {
        if (poly.terms.empty()) {
            out << "0";
            return out;
        }
        bool first = true;
        for (const auto& t : poly.terms) {
            if (!first && t.coef > 0) out << "+";
            if (t.exp == 0) out << t.coef;
            else if (t.exp == 1) out << t.coef << "x";
            else out << t.coef << "x^" << t.exp;
            first = false;
        }
        return out;
    }
};

#endif
