#include "Polynomial.h"
// #include "SparseMatrix.h"
#include "NatureNumber.h"


int main() {
    std::cout << "Question 1" << std::endl;
    NatureNumber n1, n2;
    std::cout << "Enter the first large number: ";
    std::cin >> n1;
    std::cout << "Enter the second large number: ";
    std::cin >> n2;

    std::cout << "Sum: " << n1 + n2 << std::endl;
    std::cout << "Difference: " << n1 - n2 << std::endl;

    if (n1 == n2) {
        std::cout << "The two numbers are equal." << std::endl;
    } else {
        std::cout << "The two numbers are not equal." << std::endl;
    }

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cout << std::endl;
    std::cout << "Question 2" << std::endl;
    Polynomial p1, p2;

    double_t value;

    std::cout << "Enter the first polynomial (ex: 3x^3 + 7x^2 - 2x + 8): ";
    std::cin >> p1;
    
    std::cout << "Enter the second polynomial (ex: 4x^2 + 6x - 1): ";
    std::cin >> p2;

    std::cout << "Enter the value to find the value of p1 (ex: 1): ";
    std::cin >> value;

    Polynomial::performance(p1, p2, value);

    // std::cout << std::endl;
    // std::cout << "Question 3" << std::endl;

    // load_file_context("smallSPMatrix.txt");
    
    return 0;
}
