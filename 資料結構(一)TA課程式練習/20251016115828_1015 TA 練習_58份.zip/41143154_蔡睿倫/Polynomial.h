#include <string>
#include <sstream>
#include <iostream>
#include <regex>
#include <memory>
#include <algorithm>
#include <cmath>
#include <chrono>

struct Term {
    int32_t exponent;
    double_t coefficient;
    
    Term() : exponent(0), coefficient(0.0) {}
    Term(int32_t exp, double_t coeff) : exponent(exp), coefficient(coeff) {}
};

class Polynomial {
private:
    std::unique_ptr<Term[]> terms;
    size_t capacity;
    size_t size;
    
    void expand_capacity() {
        size_t new_capacity = capacity == 0 ? 4 : capacity * 2;
        auto new_terms = std::make_unique<Term[]>(new_capacity);
        
        for (size_t i = 0; i < size; ++i) {
            new_terms[i] = std::move(terms[i]);
        }
        
        terms = std::move(new_terms);
        capacity = new_capacity;
    }
    
    size_t find_term(int32_t exponent) const {
        for (size_t i = 0; i < size; ++i) {
            if (terms[i].exponent == exponent) {
                return i;
            }
        }

        return size;
    }
    
    int32_t get_highest_exponent() const {
        if (size == 0) {
            return -1;
        }
        
        int32_t highest = terms[0].exponent;

        for (size_t i = 1; i < size; ++i) {
            highest = std::max(highest, terms[i].exponent);
        }

        return highest;
    }
    
    void remove_zero_terms() {
        size_t write_idx = 0;

        for (size_t read_idx = 0; read_idx < size; ++read_idx) {
            if (std::abs(terms[read_idx].coefficient) > 1e-10) {
                if (write_idx != read_idx) {
                    terms[write_idx] = std::move(terms[read_idx]);
                }
                ++write_idx;
            }
        }

        size = write_idx;
    }

public:
    Polynomial() : terms(nullptr), capacity(0), size(0) {}
    
    Polynomial(const Polynomial& other) : capacity(other.capacity), size(other.size) {
        if (capacity > 0) {
            terms = std::make_unique<Term[]>(capacity);

            for (size_t i = 0; i < size; ++i) {
                terms[i] = other.terms[i];
            }
            
        } else {
            terms = nullptr;
        }
    }
    
    Polynomial(Polynomial&& other) noexcept 
        : terms(std::move(other.terms)), capacity(other.capacity), size(other.size) {
        other.capacity = 0;
        other.size = 0;
    }
    
    Polynomial& operator=(const Polynomial& other) {
        if (this != &other) {
            capacity = other.capacity;
            size = other.size;
            
            if (capacity > 0) {
                terms = std::make_unique<Term[]>(capacity);
                for (size_t i = 0; i < size; ++i) {
                    terms[i] = other.terms[i];
                }
            } else {
                terms = nullptr;
            }
        }

        return *this;
    }
    
    Polynomial& operator=(Polynomial&& other) noexcept {
        if (this != &other) {
            terms = std::move(other.terms);
            capacity = other.capacity;
            size = other.size;
            
            other.capacity = 0;
            other.size = 0;
        }

        return *this;
    }
    
    ~Polynomial() = default;
    
    void add_term(int32_t exponent, double_t coefficient) {
        size_t existing_idx = find_term(exponent);
        
        if (existing_idx < size) {
            terms[existing_idx].coefficient += coefficient;
        } else {
            if (size >= capacity) {
                expand_capacity();
            }

            terms[size++] = Term(exponent, coefficient);
        }
        
        remove_zero_terms();
    }
    
    Polynomial operator+(const Polynomial& other) const {
        Polynomial result(*this);
        
        for (size_t i = 0; i < other.size; ++i) {
            result.add_term(other.terms[i].exponent, other.terms[i].coefficient);
        }
        
        return result;
    }
    
    Polynomial operator-(const Polynomial& other) const {
        Polynomial result(*this);
        
        for (size_t i = 0; i < other.size; ++i) {
            result.add_term(other.terms[i].exponent, -other.terms[i].coefficient);
        }
        
        return result;
    }
    
    Polynomial& operator+=(const Polynomial& other) {
        *this = *this + other;
        return *this;
    }
    
    Polynomial& operator-=(const Polynomial& other) {
        *this = *this - other;
        return *this;
    }
    
    Polynomial operator*(const Polynomial& other) const {
        Polynomial result;
        
        for (size_t i = 0; i < size; ++i) {
            for (size_t j = 0; j < other.size; ++j) {
                int32_t new_exponent = terms[i].exponent + other.terms[j].exponent;
                double_t new_coefficient = terms[i].coefficient * other.terms[j].coefficient;
                result.add_term(new_exponent, new_coefficient);
            }
        }
        
        return result;
    }
    
    Polynomial& operator*=(const Polynomial& other) {
        *this = *this * other;
        return *this;
    }
    
    std::string to_string() const {
        if (size == 0) {
            return "0";
        }
        
        std::ostringstream oss;
        bool first_term = true;
        
        for (int32_t exp = get_highest_exponent(); exp >= 0; --exp) {
            size_t term_idx = find_term(exp);

            if (term_idx < size) {
                double_t coeff = terms[term_idx].coefficient;
                
                if (std::abs(coeff) > 1e-10) {
                    if (!first_term) {
                        oss << (coeff > 0 ? " + " : " - ");
                    } else {
                        first_term = false;
                        if (coeff < 0) {
                            oss << "-";
                        }
                    }
                    
                    coeff = std::abs(coeff);
                    
                    if (exp == 0 || std::abs(coeff - 1.0) > 1e-10 || size == 1) {
                        if (std::abs(coeff - std::round(coeff)) < 1e-10) {
                            oss << static_cast<int>(std::round(coeff));
                        } else {
                            oss << coeff;
                        }
                    }
                    
                    if (exp > 0) {
                        oss << "x";
                        if (exp > 1) {
                            oss << "^" << exp;
                        }
                    }
                }
            }
        }
        
        for (size_t i = 0; i < size; ++i) {
            if (terms[i].exponent < 0) {
                double_t coeff = terms[i].coefficient;
                int32_t exp = terms[i].exponent;
                
                if (std::abs(coeff) > 1e-10) {
                    if (!first_term) {
                        oss << (coeff > 0 ? " + " : " - ");
                    } else {
                        first_term = false;
                        if (coeff < 0) {
                            oss << "-";
                        }
                    }
                    
                    coeff = std::abs(coeff);
                    
                    if (std::abs(coeff - 1.0) > 1e-10 || size == 1) {
                        if (std::abs(coeff - std::round(coeff)) < 1e-10) {
                            oss << static_cast<int>(std::round(coeff));
                        } else {
                            oss << coeff;
                        }
                    }
                    
                    oss << "x^" << exp;
                }
            }
        }
        
        return oss.str().empty() ? "0" : oss.str();
    }
    
    static Polynomial parse(const std::string& input) {
        Polynomial poly;
        
        std::string cleaned_input = input;
        cleaned_input.erase(std::remove_if(cleaned_input.begin(), cleaned_input.end(), ::isspace), cleaned_input.end());
        
        std::regex term_pattern(R"(([+-]?\d*\.?\d*)x(\^([+-]?\d+))?|([+-]?\d*\.?\d+))");
        std::sregex_iterator iter(cleaned_input.begin(), cleaned_input.end(), term_pattern);
        std::sregex_iterator end;
        
        while (iter != end) {
            std::smatch match = *iter;
            
            std::string coeff_str = match[1].str();
            std::string exp_str = match[3].str();
            std::string constant_str = match[4].str();
            
            double_t coefficient;
            int32_t exponent;
            
            if (!constant_str.empty()) {
                coefficient = std::stod(constant_str);
                exponent = 0;
            } else {
                if (coeff_str.empty() || coeff_str == "+") {
                    coefficient = 1.0;
                } else if (coeff_str == "-") {
                    coefficient = -1.0;
                } else {
                    coefficient = std::stod(coeff_str);
                }
                
                if (exp_str.empty()) {
                    exponent = 1;
                } else {
                    exponent = std::stoi(exp_str);
                }
            }
            
            poly.add_term(exponent, coefficient);
            ++iter;
        }
        
        return poly;
    }
    
    double_t evaluate(double_t x) const {
        double_t result = 0.0;

        for (size_t i = 0; i < size; ++i) {
            result += terms[i].coefficient * std::pow(x, terms[i].exponent);
        }
        return result;
    }
    
    size_t get_size() const { 
        return size; 
    }
    
    bool is_empty() const { 
        return size == 0; 
    }
    
    void clear() {
        size = 0;
    }
    
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& poly) {
        os << poly.to_string();
        return os;
    }
    
    friend std::istream& operator>>(std::istream& is, Polynomial& poly) {
        std::string input;

        std::getline(is, input);
        poly = Polynomial::parse(input);

        return is;
    }

    static void performance(Polynomial p1, Polynomial p2, double_t value)  {
        std::cout << "p1: " << p1 << std::endl;
        std::cout << "p2: " << p2 << std::endl;

        auto start = std::chrono::high_resolution_clock::now();
        Polynomial sum = p1 + p2;
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        std::cout << "sum: " << sum << std::endl;
        std::cout << "Computation time: " << duration.count() << " µs" << std::endl;

        start = std::chrono::high_resolution_clock::now();
        Polynomial diff = p1 - p2;
        end = std::chrono::high_resolution_clock::now();
        duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        std::cout << "diff: " << diff << std::endl;
        std::cout << "Computation time: " << duration.count() << " µs" << std::endl;

        start = std::chrono::high_resolution_clock::now();
        Polynomial mult = p1 * p2;
        end = std::chrono::high_resolution_clock::now();
        duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        std::cout << "mult: " << mult << std::endl;
        std::cout << "Computation time: " << duration.count() << " µs" << std::endl;

        start = std::chrono::high_resolution_clock::now();
        double_t result = p1.evaluate(value);
        end = std::chrono::high_resolution_clock::now();
        duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        std::cout << "p1 at x=" << value << ": " << result << std::endl;
        std::cout << "Computation time: " << duration.count() << " µs" << std::endl;

        std::cout << "Number of result items: "  
                    << "Sum: " << sum.get_size() 
                    << ", Diff: " << diff.get_size()
                    << ", Mult: " << mult.get_size()
                    << std::endl;
    }
};