#include <iostream>
#include <memory>
#include <algorithm>
#include <string>
#include <stdexcept>

class NatureNumber {
private:
    std::unique_ptr<int32_t[]> digits;
    size_t capacity;
    size_t size;

    void expand_capacity() {
        size_t new_capacity = capacity * 2;
        auto new_digits = std::make_unique<int32_t[]>(new_capacity);
        for (size_t i = 0; i < size; ++i)
            new_digits[i] = digits[i];
        digits = std::move(new_digits);
        capacity = new_capacity;
    }

public:
    NatureNumber(size_t initial_capacity = 10)
        : capacity(initial_capacity), size(0), digits(std::make_unique<int32_t[]>(initial_capacity)) {}

    void add_digit(int32_t digit) {
        if (size >= capacity) expand_capacity();
        digits[size++] = digit;
    }

    void clear() { size = 0; }

    size_t get_size() const { return size; }

    friend std::istream& operator>>(std::istream& is, NatureNumber& number) {
        std::string input;
        is >> input;
        number.clear();
        for (char ch : input) {
            if (isdigit(ch))
                number.add_digit(ch - '0');
            else
                throw std::invalid_argument("Invalid character");
        }
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        for (size_t i = 0; i < n.size; ++i)
            os << n.digits[i];
        return os;
    }

    bool operator==(const NatureNumber& other) const {
        if (size != other.size) return false;
        for (size_t i = 0; i < size; ++i)
            if (digits[i] != other.digits[i])
                return false;
        return true;
    }

    bool operator<(const NatureNumber& other) const {
        if (size != other.size) return size < other.size;
        for (size_t i = 0; i < size; ++i) {
            if (digits[i] < other.digits[i]) return true;
            if (digits[i] > other.digits[i]) return false;
        }
        return false;
    }

    bool operator>(const NatureNumber& other) const {
        return other < *this;
    }

    NatureNumber operator+(const NatureNumber& other) const {
        NatureNumber result;
        int32_t carry = 0;
        size_t i = size, j = other.size;

        while (i > 0 || j > 0 || carry) {
            int32_t sum = carry;
            if (i > 0) sum += digits[--i];
            if (j > 0) sum += other.digits[--j];
            result.add_digit(sum % 10);
            carry = sum / 10;
        }
        std::reverse(result.digits.get(), result.digits.get() + result.size);
        return result;
    }

    NatureNumber operator-(const NatureNumber& other) const {
        if (*this < other)
            throw std::invalid_argument("Subtraction would result in a negative number");

        NatureNumber result;
        int32_t borrow = 0;
        size_t i = size, j = other.size;

        while (i > 0) {
            int32_t diff = digits[--i] - borrow;
            if (j > 0) diff -= other.digits[--j];
            if (diff < 0) { diff += 10; borrow = 1; } else borrow = 0;
            result.add_digit(diff);
        }
        while (result.size > 1 && result.digits[result.size - 1] == 0)
            --result.size;
        std::reverse(result.digits.get(), result.digits.get() + result.size);
        return result;
    }

    NatureNumber operator*(const NatureNumber& other) const {
        NatureNumber result(size + other.size);
        for (size_t i = 0; i < result.capacity; ++i)
            result.add_digit(0);

        for (int32_t i = (int32_t)size - 1; i >= 0; --i) {
            int32_t carry = 0;
            for (int32_t j = (int32_t)other.size - 1; j >= 0; --j) {
                int32_t pos = i + j + 1;
                int32_t temp = result.digits[pos] + digits[i] * other.digits[j] + carry;
                result.digits[pos] = temp % 10;
                carry = temp / 10;
            }
            result.digits[i] += carry;
        }

        size_t start = 0;
        while (start < result.size - 1 && result.digits[start] == 0) ++start;

        if (start > 0) {
            for (size_t i = start; i < result.size; ++i)
                result.digits[i - start] = result.digits[i];
            result.size -= start;
        }
        return result;
    }
};