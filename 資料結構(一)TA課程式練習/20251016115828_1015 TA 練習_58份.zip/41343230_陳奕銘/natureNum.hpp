#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned int value; // �u���\�D�t���

public:
    // �w�]�غc�l
    NatureNumber() : value(0) {}

    // �a�Ѽƫغc�l
    NatureNumber(unsigned int v) : value(v) {}

    // ���o��
    unsigned int getValue() const { return value; }

    // ��J�B��l
    friend istream& operator>>(istream& in, NatureNumber& n) {
        in >> n.value;
        return in;
    }

    // ��X�B��l
    friend ostream& operator<<(ostream& out, const NatureNumber& n) {
        out << n.value;
        return out;
    }

    // �[�k�B��l
    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    // ��k�B��l�]�קK�t�ơ^
    NatureNumber operator-(const NatureNumber& other) const {
        if (this->value >= other.value)
            return NatureNumber(this->value - other.value);
        else
            return NatureNumber(0);
    }

    // ����B��l
    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    bool operator!=(const NatureNumber& other) const {
        return !(*this == other);
    }
};

#endif
