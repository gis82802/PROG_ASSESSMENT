#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms; // �x�s�h���������U��

public:
    Polynomial() {}

    // ��J�G��J�h�����]����J���ơA�A��J�C�����Y�ƻP���ơ^
    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "Enter number of terms: ";
        in >> n;

        p.terms.clear();
        for (int i = 0; i < n; ++i) {
            Term t;
            cout << "Enter coef and exp for term " << i + 1 << ": ";
            in >> t;
            p.terms.push_back(t);
        }
        return in;
    }

    // ��X�G�H�������ǦL�X�h����
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << "0";
            return out;
        }
        for (size_t i = 0; i < p.terms.size(); ++i) {
            if (i > 0 && p.terms[i].coef > 0)
                out << "+";
            out << p.terms[i];
        }
        return out;
    }

    // Add�G�h�����ۥ[
    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        size_t i = 0, j = 0;

        while (i < terms.size() && j < other.terms.size()) {
            if (terms[i].exp == other.terms[j].exp) {
                int sumCoef = terms[i].coef + other.terms[j].coef;
                if (sumCoef != 0)
                    result.terms.push_back(Term(sumCoef, terms[i].exp));
                i++; j++;
            }
            else if (terms[i].exp > other.terms[j].exp) {
                result.terms.push_back(terms[i]);
                i++;
            }
            else {
                result.terms.push_back(other.terms[j]);
                j++;
            }
        }

        // ��ѤU�����ɤW
        while (i < terms.size()) result.terms.push_back(terms[i++]);
        while (j < other.terms.size()) result.terms.push_back(other.terms[j++]);

        return result;
    }
};

#endif
