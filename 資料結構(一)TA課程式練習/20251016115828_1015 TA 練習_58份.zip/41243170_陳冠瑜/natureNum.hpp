#ifndef natureNum_hpp
#define	natureNum_hpp

#include<iostream>


class NatureNumber {


public:
	NatureNumber(int n = 0) {
		this->n = n;
	}
	//+
	NatureNumber operator+(const NatureNumber& other) const {
		return NatureNumber(n + other.n);
	}
	//-
	NatureNumber operator-(const NatureNumber& other) const {
		return NatureNumber(n - other.n);
	}
	//==
	bool operator==(const NatureNumber& other) const {
		return n == other.n;
	}
	//<<
	friend  std::ostream& operator<<(std::ostream& output, const NatureNumber& p) {
		output << p.n;
		return output;
	}
	//>>
	friend std::istream& operator>>(std::istream& input, NatureNumber& p) {
		input >> p.n;
		return input;
	}

private:
	int n;
};
#endif