#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"

using namespace std;

class Polynomial {
    vector<Term> ts; // 以指數「降冪」存，同冪已合併、無 0 項

    void normalize() {
        sort(ts.begin(), ts.end(), [](const Term& a, const Term& b){ return a.exp > b.exp; });
        vector<Term> merged;
        for (const auto& t : ts) {
            if (t.coef == 0) continue;
            if (!merged.empty() && merged.back().exp == t.exp) {
                merged.back().coef += t.coef;
                if (merged.back().coef == 0) merged.pop_back();
            } else merged.push_back(t);
        }
        ts.swap(merged);
        if (ts.empty()) ts.push_back(Term(0,0));
    }

public:
    Polynomial() { ts.push_back(Term(0,0)); }

    // 輸入
    friend istream& operator>>(istream& in, Polynomial& p) {
        int m; if (!(in >> m)) return in;
        p.ts.clear();
        for (int i = 0; i < m; ++i) {
            int c, e; in >> c >> e; if (e < 0) e = 0;
            p.ts.emplace_back(c, e);
        }
        p.normalize();
        return in;
        }

    // 輸出
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.ts.size() == 1 && p.ts[0].coef == 0 && p.ts[0].exp == 0) { out << 0; return out; }
        bool first = true;
        for (const auto& t : p.ts) {
            int c = t.coef, e = t.exp, absc = (c < 0 ? -c : c);
            if (first) {
                if (c < 0) out << '-';
                if (e == 0) out << absc;
                else { if (absc != 1) out << absc; out << 'x'; if (e != 1) out << '^' << e; }
                first = false;
            } else {
                out << (c < 0 ? '-' : '+');
                if (e == 0) out << absc;
                else { if (absc != 1) out << absc; out << 'x'; if (e != 1) out << '^' << e; }
            }
        }
        return out;
    }

    // a.Add(b) -> 傳回 a+b（新物件）
    Polynomial Add(const Polynomial& b) const {
        Polynomial r; r.ts.clear();
        size_t i = 0, j = 0;
        while (i < ts.size() && j < b.ts.size()) {
            if (ts[i].exp == b.ts[j].exp) {
                int c = ts[i].coef + b.ts[j].coef;
                if (c != 0) r.ts.emplace_back(c, ts[i].exp);
                ++i; ++j;
            } else if (ts[i].exp > b.ts[j].exp) {
                r.ts.push_back(ts[i++]);
            } else {
                r.ts.push_back(b.ts[j++]);
            }
        }
        while (i < ts.size()) r.ts.push_back(ts[i++]);
        while (j < b.ts.size()) r.ts.push_back(b.ts[j++]);
        if (r.ts.empty()) r.ts.push_back(Term(0,0));
        return r;
    }
};

#endif