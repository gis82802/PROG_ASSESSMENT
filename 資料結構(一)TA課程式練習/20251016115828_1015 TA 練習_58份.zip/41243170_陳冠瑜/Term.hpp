#ifndef Term_hpp
#define Term_hpp

#include <stdio.h>
#include <iostream>
class Polynomial;

class Term{
    friend std::ostream& operator<<(std::ostream& output,const Polynomial& p);
    friend std::istream& operator>>(std::istream& input,Polynomial& thePoly);
    friend Polynomial;
    private:
        float coef;
        int exp;
    public:
    Term(float c = 0, int e = 0) : coef(c), exp(e) {}
};
#endif