#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

class NatureNumber {
private:
    string digits;

    static string normalize(const string& s) {
        size_t i = 0;
        while (i < s.size() && s[i] == '0') i++;
        if (i == s.size()) return "0";
        return s.substr(i);
    }

public:
    NatureNumber() : digits("0") {}
    NatureNumber(const string& s) { digits = normalize(s); }
    NatureNumber(unsigned long long n) {
        if (n == 0) digits = "0";
        else {
            digits = "";
            while (n > 0) {
                digits.insert(digits.begin(), char('0' + (n % 10)));
                n /= 10;
            }
        }
    }

    friend istream& operator>>(istream& is, NatureNumber& n) {
        string s; is >> s;
        n.digits = normalize(s);
        return is;
    }

    friend ostream& operator<<(ostream& os, const NatureNumber& n) {
        os << n.digits;
        return os;
    }

    bool operator==(const NatureNumber& b) const {
        return digits == b.digits;
    }

    bool lessThan(const NatureNumber& b) const {
        if (digits.size() != b.digits.size())
            return digits.size() < b.digits.size();
        return digits < b.digits;
    }

    friend NatureNumber operator+(const NatureNumber& a, const NatureNumber& b) {
        string A = a.digits, B = b.digits;
        int i = A.size() - 1, j = B.size() - 1, carry = 0;
        string res;
        while (i >= 0 || j >= 0 || carry) {
            int da = (i >= 0 ? A[i--] - '0' : 0);
            int db = (j >= 0 ? B[j--] - '0' : 0);
            int sum = da + db + carry;
            carry = sum / 10;
            res.push_back('0' + (sum % 10));
        }
        reverse(res.begin(), res.end());
        return NatureNumber(res);
    }

    friend NatureNumber operator-(const NatureNumber& a, const NatureNumber& b) {
        if (a.lessThan(b)) return NatureNumber("0");
        string A = a.digits, B = b.digits;
        int i = A.size() - 1, j = B.size() - 1, borrow = 0;
        string res;
        while (i >= 0) {
            int da = (A[i] - '0') - borrow;
            int db = (j >= 0 ? B[j--] - '0' : 0);
            if (da < db) { da += 10; borrow = 1; }
            else borrow = 0;
            res.push_back('0' + (da - db));
            i--;
        }
        reverse(res.begin(), res.end());
        return NatureNumber(normalize(res));
    }
};

#endif
