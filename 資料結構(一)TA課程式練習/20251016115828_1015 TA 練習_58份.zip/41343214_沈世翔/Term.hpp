#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
public:
    int coefficient; 
    int exponent;   

    
    Term(int coef = 0, int exp = 0) : coefficient(coef), exponent(exp) {}

    friend istream& operator>>(istream& in, Term& t) {
        in >> t.coefficient >> t.exponent;
        return in;
    }

    friend ostream& operator<<(ostream& out, const Term& t) {
        out << t.coefficient << "x^" << t.exponent;
        return out;
    }
};

#endif
