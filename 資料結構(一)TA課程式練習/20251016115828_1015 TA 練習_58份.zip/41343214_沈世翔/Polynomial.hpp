#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>  
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms; 

public:
   
    void AddTerm(const Term& t) {
        for (auto& term : terms) {
            if (term.exponent == t.exponent) {
                term.coefficient += t.coefficient; 
                return;
            }
        }
        terms.push_back(t);  

        sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exponent > b.exponent; 
            });
    }

    
    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;  
        for (const auto& term : other.terms) {
            result.AddTerm(term);  
        }
        return result;
    }

    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "��J:";
        in >> n;
        for (int i = 0; i < n; ++i) {
            Term t;
            in >> t;
            p.AddTerm(t); 
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        for (size_t i = 0; i < p.terms.size(); ++i) {
            if (i > 0) out << " + "; 
            out << p.terms[i];
        }
        return out;
    }
};

#endif
