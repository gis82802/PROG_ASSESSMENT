#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned int value; 

public:
    NatureNumber() : value(0) {}
    NatureNumber(unsigned int v) : value(v) {}
    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value); 
    }
    NatureNumber operator-(const NatureNumber& other) const {
        if (this->value < other.value) {
            return NatureNumber(0); 
        }
        return NatureNumber(this->value - other.value);
    }
    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }
    friend istream& operator>>(istream& in, NatureNumber& nn) {
        in >> nn.value;
        return in;
    }
    friend ostream& operator<<(ostream& out, const NatureNumber& nn) {
        out << nn.value;
        return out;
    }
};
#endif
