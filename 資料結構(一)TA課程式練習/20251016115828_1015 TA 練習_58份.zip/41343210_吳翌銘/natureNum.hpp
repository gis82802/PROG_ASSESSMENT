#ifndef NATURENUMBER_HPP
#define NATURENUMBER_HPP

#include <iostream>

class NaturalNumber
{
private:
    int value;

public:
    NaturalNumber(int val = 0) : value(val) {}

    friend std::istream& operator >> (std::istream& is , NaturalNumber& n){
        is >> n.value;
        return is ;
    }

    friend std::ostream& operator << (std::ostream& os , const NaturalNumber& n){

        os << n.value;
        return os;
    }

    NaturalNumber operator+(const NaturalNumber& other) const{
        return NaturalNumber(value + other.value);
    }

    NaturalNumber operator-(const NaturalNumber& other) const {
        return NaturalNumber(value - other.value);
    }

    bool operator==(const NaturalNumber& other) const {
        return value == other.value;
    }


};

#endif // NATURENUMBER_HPP