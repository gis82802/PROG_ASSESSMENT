#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms; // �x�s�h�������C�@��

public:
    Polynomial() {}

    // �h�����ۥ[
    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        result.terms = this->terms;

        for (const auto& t : other.terms) {
            bool found = false;
            for (auto& r : result.terms) {
                if (r.getExp() == t.getExp()) {
                    r.setCoef(r.getCoef() + t.getCoef());
                    found = true;
                    break;
                }
            }
            if (!found) {
                result.terms.push_back(t);
            }
        }

        // �����Y�Ƭ�0����
        result.terms.erase(
            remove_if(result.terms.begin(), result.terms.end(),
                [](const Term& t) { return t.getCoef() == 0; }),
            result.terms.end()
        );

        // �̫��ƱƧǡ]�����^
        sort(result.terms.begin(), result.terms.end(),
            [](const Term& a, const Term& b) { return a.getExp() > b.getExp(); });

        return result;
    }

    // ��J�B��l
    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "Enter number of terms: ";
        in >> n;
        for (int i = 0; i < n; ++i) {
            float coef;
            int exp;
            cout << "Enter coefficient and exponent: ";
            in >> coef >> exp;
            Term t;
            t.setCoef(coef);
            t.setExp(exp);
            p.terms.push_back(t);
        }
        return in;
    }

    // ��X�B��l
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << 0;
            return out;
        }
        for (size_t i = 0; i < p.terms.size(); ++i) {
            const Term& t = p.terms[i];
            if (i > 0 && t.getCoef() > 0) out << "+";
            if (t.getExp() == 0)
                out << t.getCoef();
            else if (t.getExp() == 1)
                out << t.getCoef() << "x";
            else
                out << t.getCoef() << "x^" << t.getExp();
        }
        return out;
    }
};

#endif
