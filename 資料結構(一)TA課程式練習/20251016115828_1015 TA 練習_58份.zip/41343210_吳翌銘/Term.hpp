#ifndef TERM_HPP
#define TERM_HPP

class Term {
private:
    float coef;
    int exp;
public:
    Term() : coef(0), exp(0) {}
    Term(float c, int e) : coef(c), exp(e) {}

    // getter
    float getCoef() const { return coef; }
    int getExp() const { return exp; }

    // setter
    void setCoef(float c) { coef = c; }
    void setExp(int e) { exp = e; }
};

#endif
