#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP


#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;  // �h�����Ѧh�Ӷ��զ�

public:
    Polynomial() {}

    // �[�k�B��
    Polynomial Add(const Polynomial& other) const;

    // ��J�P��X
    friend istream& operator>>(istream& in, Polynomial& p);
    friend ostream& operator<<(ostream& out, const Polynomial& p);
};

#endif
