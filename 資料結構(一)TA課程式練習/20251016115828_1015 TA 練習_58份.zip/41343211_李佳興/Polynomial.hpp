#include"POLYNOMIAL01.hpp"
#include <algorithm>

// ��J�h����
istream& operator>>(istream& in, Polynomial& p) {
    int n;
    cout << "�п�J����: ";
    in >> n;
    p.terms.clear();
    for (int i = 0; i < n; ++i) {
        Term t;
        in >> t;
        p.terms.push_back(t);
    }
    return in;
}

// ��X�h����
ostream& operator<<(ostream& out, const Polynomial& p) {
    if (p.terms.empty()) {
        out << "0";
        return out;
    }

    for (size_t i = 0; i < p.terms.size(); ++i) {
        if (i > 0 && p.terms[i].coef >= 0)
            out << "+";
        out << p.terms[i];
    }
    return out;
}

// �h�����[�k
Polynomial Polynomial::Add(const Polynomial& other) const {
    Polynomial result;
    result.terms = terms;  // �ƻs�ثe���h����

    // �N other ���C�@���[�J
    for (auto& t : other.terms) {
        bool merged = false;
        for (auto& r : result.terms) {
            if (r.exp == t.exp) {
                r.coef += t.coef;
                merged = true;
                break;
            }
        }
        if (!merged) result.terms.push_back(t);
    }

    // �Ƨǡ]���ƥѤj��p�^
    sort(result.terms.begin(), result.terms.end(), [](Term a, Term b) {
        return a.exp > b.exp;
        });

    return result;
}
