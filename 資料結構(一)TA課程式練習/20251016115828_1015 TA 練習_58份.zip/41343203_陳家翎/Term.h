
#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
#include <stdexcept>
#include <cmath>

class Term {
private:
	double coeff; 
	int exp; 

public:

	Term(double c = 0.0, int e = 0) : coeff(c), exp(e) {}

	
	double getCoeff() const { return coeff; }
	int getExp() const { return exp; }
	void setCoeff(double c) { coeff = c; }
	void setExp(int e) { exp = e; }


	bool operator<(const Term& other) const {
		return exp > other.exp; 
	}

	bool operator==(const Term& other) const {
		return exp == other.exp;
	}

	Term operator+(const Term& other) const {
		if (exp != other.exp) {
			throw std::invalid_argument("Exponents must be equal for addition");
		}
		return Term(coeff + other.coeff, exp);
	}
};


inline std::istream& operator>>(std::istream& is, Term& term) {
	double coeff;
	int exp;

	if (is >> coeff >> exp) {
		term.setCoeff(coeff);
		term.setExp(exp);
	}

	return is;
}


inline std::ostream& operator<<(std::ostream& os, const Term& term) {
	double coeff = term.getCoeff();
	int exp = term.getExp();

	if (std::abs(coeff) < 1e-10) { 
		return os;
	}


	if (std::abs(coeff - 1.0) < 1e-10 && exp != 0) {
	
	}
	else if (std::abs(coeff + 1.0) < 1e-10 && exp != 0) {
		os << "-"; 
	}
	else {
		
		if (coeff == static_cast<int>(coeff)) {
			os << static_cast<int>(coeff);
		}
		else {
			os << coeff;
		}
	}

	
	if (exp > 0) {
		os << "x";
		if (exp > 1) {
			os << "^" << exp;
		}
	}
	else if (exp == 0) {
	
		if (std::abs(std::abs(coeff) - 1.0) < 1e-10) {
			
			os << std::abs(coeff);
		}
	}

	return os;
}

#endif
