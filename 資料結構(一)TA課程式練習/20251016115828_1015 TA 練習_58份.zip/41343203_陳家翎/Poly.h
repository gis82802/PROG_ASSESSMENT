#ifndef Poly_H
#define Poly_H

#include "Term.h"
#include <vector>
#include <algorithm>

class Polynomial {
private:
	std::vector<Term> terms;


	void simplify() {
		if (terms.empty()) return;

		
		std::sort(terms.begin(), terms.end());

	
		std::vector<Term> simplified;
		simplified.push_back(terms[0]);

		for (size_t i = 1; i < terms.size(); i++) {
			if (terms[i].getExp() == simplified.back().getExp()) {
				
				double newCoeff = simplified.back().getCoeff() + terms[i].getCoeff();
				simplified.back().setCoeff(newCoeff);
			}
			else {
				simplified.push_back(terms[i]);
			}
		}

		
		terms.clear();
		for (const auto& term : simplified) {
			if (term.getCoeff() != 0.0) {
				terms.push_back(term);
			}
		}
	}

public:

	Polynomial() = default;


	Polynomial Add(const Polynomial& other) const {
		Polynomial result;

	
		result.terms = this->terms;

		
		for (const auto& term : other.terms) {
			result.terms.push_back(term);
		}

	
		result.simplify();
		return result;
	}

	
	void clearTerms() { terms.clear(); }
	void addTerm(const Term& term) { terms.push_back(term); }
	const std::vector<Term>& getTerms() const { return terms; }

	
	void simplifyPolynomial() { simplify(); }
};


inline std::istream& operator>>(std::istream& is, Polynomial& poly) {
	int termCount;

	
	if (is >> termCount) {
		poly.clearTerms();

		
		if (termCount == 0) {
			return is;
		}

		for (int i = 0; i < termCount; i++) {
			Term term;
			if (is >> term) {
				
				if (term.getCoeff() != 0.0) {
					poly.addTerm(term);
				}
			}
		}

	
		poly.simplifyPolynomial();
	}

	return is;
}

inline std::ostream& operator<<(std::ostream& os, const Polynomial& poly) {
	const std::vector<Term>& terms = poly.getTerms();

	if (terms.empty()) {
		os << "0"; 
		return os;
	}

	bool firstTerm = true;
	for (const auto& term : terms) {

		if (!firstTerm && term.getCoeff() > 0) {
			os << "+";
		}

		os << term;
		firstTerm = false;
	}

	return os;
}

#endif