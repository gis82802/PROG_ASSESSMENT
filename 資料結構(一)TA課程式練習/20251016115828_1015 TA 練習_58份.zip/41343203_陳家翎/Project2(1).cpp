#include <iostream>
#include "Poly.h"
#include "Term.h"

using namespace std;

int main(int argc, const char* argv[]) {
	Polynomial a, b;


	cout << "input poly A" << endl;
	cin >> a;


	cout << "input poly B" << endl;
	cin >> b;


	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
	cout << "a+b=" << a.Add(b) << endl;

	return 0;
}