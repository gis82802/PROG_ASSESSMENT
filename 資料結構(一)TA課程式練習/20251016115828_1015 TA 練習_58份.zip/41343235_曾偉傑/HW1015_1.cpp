#include <iostream>
#include <cstdlib>
#include "natureNum.hpp"

using namespace std;

int main(void)
{
	NatureNumber a, b;
	NatureNumber* c;
	cin >> a;
	cin >> b;

	cout << a + b<<endl;
	cout << a - b << endl;
	if (a == b)
	{
		cout << "a==b" << endl;
	}
	else
	{
		cout << "a!=b" << endl;
	}
	return 0;
}