#include <iostream>
using namespace std;
class NatureNumber {
private:
    int value;

public:
    NatureNumber() : value(0) {}

    NatureNumber(int val) : value(val) {}

    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        return NatureNumber(this->value - other.value);
    }

    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    friend ostream& operator<<(ostream& os, const NatureNumber& obj) {
        os << obj.value;
        return os;
    }
    friend istream& operator>>(istream& is, NatureNumber& obj) {
        is >> obj.value;
        return is;
    }
};
