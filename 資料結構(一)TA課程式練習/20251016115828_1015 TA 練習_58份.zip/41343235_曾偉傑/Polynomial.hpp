#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include "Term.hpp"
#include <vector>
#include <algorithm>
#include <iostream>
#include <sstream>
using namespace std;
class Polynomial {
private:
   vector<Term> terms;

    void normalize() {
        if (terms.empty()) return;
        sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });
       vector<Term> tmp;
        tmp.reserve(terms.size());
        for (const auto& t : terms) {
            if (tmp.empty() || tmp.back().exp != t.exp) {
                tmp.push_back(t);
            }
            else {
                tmp.back().coeff += t.coeff;
            }
        }
        terms.clear();
        for (const auto& t : tmp) {
            if (t.coeff != 0) terms.push_back(t);
        }
    }

public:
    Polynomial() = default;

    Polynomial(const vector<Term>& t) : terms(t) { normalize(); }

    Polynomial Add(const Polynomial& other) const {
        Polynomial res;
        res.terms = terms;
        res.terms.insert(res.terms.end(), other.terms.begin(), other.terms.end());
        res.normalize();
        return res;
    }

    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        if (p.terms.empty()) {
            os << "0";
            return os;
        }
        bool first = true;
        for (const auto& t : p.terms) {
            if (!first) {
                if (t.coeff > 0) os << " + ";
                else os << " - ";
            }
            else {
                if (t.coeff < 0) os << "-";
            }
            long long abscoeff = t.coeff >= 0 ? t.coeff : -t.coeff;
            if (t.exp == 0) {
                os << abscoeff;
            }
            else if (t.exp == 1) {
                if (abscoeff != 1) os << abscoeff << "x";
                else os << "x";
            }
            else {
                if (abscoeff != 1) os << abscoeff << "x^" << t.exp;
                else os << "x^" << t.exp;
            }
            first = false;
        }
        return os;
    }

    friend istream& operator>>(istream& is, Polynomial& p) {
        p.terms.clear();
        int n;
        if (!(is >> n)) return is;
        if (n <= 0) {
            return is;
        }
        for (int i = 0; i < n; ++i) {
            long long coeff;
            unsigned int exp;
            if (!(is >> coeff >> exp)) {
                break;
            }
            p.terms.emplace_back(coeff, exp);
        }
        p.normalize();
        return is;
    }
};

#endif 
