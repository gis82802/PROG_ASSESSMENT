#include <iostream>
#include "Polynomial.hpp"
#include "Term.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    Polynomial a, b;
    cout << "Input poly A: " << endl;
    cin >> a;
    cout << "Input poly B: " << endl;
    cin >> b;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "a + b = " << (a + b) << endl;  
    
    return 0;
}