#pragma once
#include <algorithm>
#include <iostream>
#include <sstream>
#include <vector>
#include <cctype>
#include "Term.hpp"

using namespace std;

class Polynomial {
private:
    vector<Term> terms;

    void mergeLikeTerms() {
        if (terms.empty()) return;
        sort(terms.begin(), terms.end(), [](const Term &a, const Term &b) {
            return a.power > b.power;
        });

        vector<Term> merged;
        Term current = terms[0];
        for (size_t i = 1; i < terms.size(); ++i) {
            if (terms[i].power == current.power) {
                current.coeff += terms[i].coeff;
            } else {
                if (current.coeff != 0.0) merged.push_back(current);
                current = terms[i];
            }
        }
        if (current.coeff != 0.0) merged.push_back(current);
        terms = merged;
    }

    vector<Term> parseString(const string& input) {
        vector<Term> result;
        stringstream ss(input);
        string term;

        while (getline(ss, term, '+')) {
            term.erase(0, term.find_first_not_of(" \t"));
            term.erase(term.find_last_not_of(" \t") + 1);
            if (term.empty()) continue;

            double coeff = 1.0;
            int power = 0;

            if (term.find('x') == string::npos) {
                coeff = stod(term);
                power = 0;
            } else {
                size_t xPos = term.find('x');
                string coeffStr = term.substr(0, xPos);
                
                if (coeffStr.empty() || coeffStr == "-") {
                    coeff = coeffStr.empty() ? 1.0 : -1.0;
                } else {
                    coeff = stod(coeffStr);
                }

                size_t expPos = term.find('^', xPos);
                if (expPos != string::npos) {
                    power = stoi(term.substr(expPos + 1));
                } else {
                    power = 1;
                }
            }
            result.emplace_back(coeff, power);
        }
        return result;
    }
    
public:
    Polynomial() = default;

    friend istream &operator >>(istream &input, Polynomial &p) {
        string line;
        getline(cin, line);
        p.terms = p.parseString(line);
        p.mergeLikeTerms();
        return input;
    }

    friend ostream &operator <<(ostream &output, const Polynomial &p) {
        if (p.terms.empty()) {
            output << "0";
            return output;
        }

        for (size_t i = 0; i < p.terms.size(); ++i) {
            if (i > 0) output << " + ";
            
            double coeff = p.terms[i].coeff;
            int power = p.terms[i].power;
            
            if (power == 0) {
                output << coeff;
            } else if (power == 1) {
                if (coeff == 1.0) output << "x";
                else if (coeff == -1.0) output << "-x";
                else output << coeff << "x";
            } else {
                if (coeff == 1.0) output << "x^" << power;
                else if (coeff == -1.0) output << "-x^" << power;
                else output << coeff << "x^" << power;
            }
        }
        return output;
    }

    Polynomial operator+(const Polynomial &other) const {
        Polynomial result;
        for (const auto &t : terms) result.terms.emplace_back(t);
        for (const auto &t : other.terms) result.terms.emplace_back(t);
        result.mergeLikeTerms();
        return result;
    }
};