#ifndef NATURALNUMBER_HPP
#define NATURALNUMBER_HPP

#include <iostream>

using namespace std;

class naturalNumber {
    private:
        int value;

    public:
        naturalNumber(int v = 0): value(v) {}
        
        friend istream &operator >>(istream &input, naturalNumber & n) {
            int tmp;
            input >> tmp;
            n.value = tmp;
            return input;
        }

        friend ostream &operator <<(ostream &output, const naturalNumber & n) {
            output << n.value;
            return output;
        }

        naturalNumber operator+(const naturalNumber &other) const {
            return naturalNumber(value + other.value);
        }

        naturalNumber operator-(const naturalNumber &other) const {
            if ((value - other.value) < 0) return 0;
            return naturalNumber(value - other.value);
        }

        bool operator==(const naturalNumber &other) const {
            return value == other.value;
        }
};

#endif