#pragma once

struct Term
{
    double coeff;
    int power;

    Term (double c = 0, int p = 0): coeff(c), power(p) {}
};