#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

    void sortTerms() {
        sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });
    }

public:
    Polynomial() {}

    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        in >> n; 
        p.terms.clear();
        for (int i = 0; i < n; i++) {
            double c;
            int e;
            in >> c >> e;
            p.terms.emplace_back(c, e);
        }
        p.sortTerms();
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        for (size_t i = 0; i < p.terms.size(); i++) {
            double c = p.terms[i].coef;
            int e = p.terms[i].exp;

            if (e == 0) {
                out << c; 
            }
            else if (e == 1) {
                out << c << "x"; 
            }
            else {
                out << c << "x^" << e;
            }

            if (i != p.terms.size() - 1) out << " + ";
        }
        return out;
    }

    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        size_t i = 0, j = 0;
        while (i < terms.size() && j < other.terms.size()) {
            if (terms[i].exp == other.terms[j].exp) {
                double sumCoef = terms[i].coef + other.terms[j].coef;
                if (sumCoef != 0) result.terms.emplace_back(sumCoef, terms[i].exp);
                i++; j++;
            }
            else if (terms[i].exp > other.terms[j].exp) {
                result.terms.push_back(terms[i++]);
            }
            else {
                result.terms.push_back(other.terms[j++]);
            }
        }
        while (i < terms.size()) result.terms.push_back(terms[i++]);
        while (j < other.terms.size()) result.terms.push_back(other.terms[j++]);
        return result;
    }
};

#endif
