#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
#include <cmath>
using namespace std;

class NatureNumber {
private:
    long long value; 
      
public:
    NatureNumber(long long v = 0) : value(v) {}

    friend istream& operator>>(istream& in, NatureNumber& n) {
        in >> n.value;
        return in;
    }

    friend ostream& operator<<(ostream& out, const NatureNumber& n) {
        out << n.value;
        return out;
    }

    // +�B-
    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        return NatureNumber(value - other.value);
    }

    // ==�B!=
    bool operator==(const NatureNumber& other) const {
        return value == other.value;
    }

    bool operator!=(const NatureNumber& other) const {
        return value != other.value;
    }
};

#endif
