// Polynomial.hpp
#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.h"
using namespace std;

class Polynomial {
private:
    vector<Term> terms; // 儲存多項式的所有項

public:
    // 輸入運算子
    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "Enter number of terms: ";
        in >> n;
        p.terms.clear();
        for (int i = 0; i < n; i++) {
            Term t;
            cout << "term " << i + 1 << " (coef exp): ";
            in >> t;
            p.terms.push_back(t);
        }
        return in;
    }

    // 輸出運算子
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
    if (p.terms.empty()) {
        out << 0;
        return out;
    }
    for (size_t i = 0; i < p.terms.size(); i++) {
        double c = p.terms[i].coef;
        int e = p.terms[i].exp;

        // 處理第一項（不要印出多餘的 +）
        if (i == 0) {
            out << c << "x^" << e;
        } else {
            if (c >= 0 && e>1)
                out << " + " << c << "x^" << e;
            else if(c>=0 && e==1)
                out << " + " << c << "x";
            else if(c>=0 && e==0)
                out << " + " << c;
            else if(c<0 && e>1)
                out << " - " << -c << "x^" << e;
            else if(c<0 && e==1)
                out << " - " << -c << "x";
            else if(c<0 && e==0)
                out << " - " << -c;
            }
        }
        return out;
    }

    // 多項式相加
    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;

        for (const auto& t : other.terms) {
            bool merged = false;
            for (auto& rt : result.terms) {
                if (rt.exp == t.exp) {
                    rt.coef += t.coef;
                    merged = true;
                    break;
                }
            }
            if (!merged) result.terms.push_back(t);
        }

        // 按照指數由大到小排序
        sort(result.terms.begin(), result.terms.end(),[](const Term& a, const Term& b) { return a.exp > b.exp; });

        return result;
    }
};

#endif