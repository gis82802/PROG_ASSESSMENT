#ifndef NATURE_NUM_H
#define NATURE_NUM_H
#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
class natureNumber{
    private:
        unsigned long long value;//value>=0
    public:
    natureNumber(unsigned long long v=0):value(v){}//預設建構子
    //輸入運算子
    friend istream& operator>>(istream& in,natureNumber& n){
        in >> n.value;
        return in;
    }
    //輸出運算子
    friend ostream& operator<<(ostream& out,const natureNumber& n){
        out << n.value;
        return out;
    }
    //加法運算子
    natureNumber operator+(const natureNumber& other)const{
        return natureNumber(value + other.value);//回傳新物件
    }
    //減法運算子
    natureNumber operator- (const natureNumber& other)const{
        if(value >= other.value){
            return natureNumber(value - other.value);//回傳新物件
        }
        else{
            return natureNumber(0);//若結果為負數，回傳0
        }
    }
    //比較運算子
    bool operator==(const natureNumber& other)const{
        return value == other.value;
    }
    bool operator!=(const natureNumber& other)const{
        return !(*this == other);
    }
};
#endif // NATURE_NUM_H