#include<iostream>
#include"polynomial.h"
using namespace std;
int main() {
    Polynomial a, b;
    cout << "input poly a:" << endl;
    cin >> a;
    cout << "input poly b:" << endl;
    cin >> b;
    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "a+b=" <<a.Add(b)<< endl;
    return 0;
}