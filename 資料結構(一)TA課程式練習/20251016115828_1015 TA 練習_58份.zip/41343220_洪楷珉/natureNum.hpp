#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>


class NatureNumber {
private:
    
    int value;

public:
    
    NatureNumber() : value(0) {}

    
    NatureNumber(int val) {
        if (val >= 0) {
            value = val;
        }
        else {
            
            
            std::cerr << "Warning: Natural number cannot be negative. Setting to 0." << std::endl;
            value = 0;
        }
    }

    

    
    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    
    NatureNumber operator-(const NatureNumber& other) const {
        return NatureNumber(this->value - other.value);
    }

    
    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    
    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& num);
    friend std::istream& operator>>(std::istream& is, NatureNumber& num);
};


std::ostream& operator<<(std::ostream& os, const NatureNumber& num) {
    os << num.value;
    return os;
}


std::istream& operator>>(std::istream& is, NatureNumber& num) {
    int input_val;
    is >> input_val;
    if (input_val >= 0) {
        num.value = input_val;
    }
    else {
       
        std::cerr << "Warning: Input is negative. Storing as 0 for Natural Number." << std::endl;
        num.value = 0;
    }
    return is;
}

#endif 