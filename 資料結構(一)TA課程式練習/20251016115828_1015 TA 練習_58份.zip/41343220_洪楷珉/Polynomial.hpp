#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <algorithm> 
#include "Term.hpp"

class Polynomial {
public:
    
    Polynomial() {
        capacity = 2; 
        terms = 0;
        termArray = new Term[capacity];
    }

    
    ~Polynomial() {
        delete[] termArray;
    }

    
    Polynomial Add(const Polynomial& b) {
        Polynomial c;
        int aPos = 0, bPos = 0;

        while ((aPos < terms) && (bPos < b.terms)) {
            if (termArray[aPos].exp == b.termArray[bPos].exp) {
                float sum = termArray[aPos].coef + b.termArray[bPos].coef;
                if (sum != 0.0) {
                    c.NewTerm(sum, termArray[aPos].exp);
                }
                aPos++;
                bPos++;
            }
            else if (termArray[aPos].exp < b.termArray[bPos].exp) {
                c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
                bPos++;
            }
            else { 
                c.NewTerm(termArray[aPos].coef, termArray[aPos].exp);
                aPos++;
            }
        }

        
        for (; aPos < terms; aPos++) {
            c.NewTerm(termArray[aPos].coef, termArray[aPos].exp);
        }
        
        for (; bPos < b.terms; bPos++) {
            c.NewTerm(b.termArray[bPos].coef, b.termArray[bPos].exp);
        }

        return c;
    }

    
    void NewTerm(const float theCoeff, const int theExp) {
        if (terms == capacity) {
            capacity *= 2;
            Term* temp = new Term[capacity];
            std::copy(termArray, termArray + terms, temp);
            delete[] termArray;
            termArray = temp;
        }
        termArray[terms].coef = theCoeff;
        termArray[terms].exp = theExp;
        terms++;
    }

    
    friend std::ostream& operator<<(std::ostream&, const Polynomial&);
    friend std::istream& operator>>(std::istream&, Polynomial&);

private:
    Term* termArray; 
    int capacity;    
    int terms;       
};


std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
    if (p.terms == 0) {
        os << "0";
        return os;
    }
    for (int i = 0; i < p.terms; i++) {
        if (i > 0 && p.termArray[i].coef > 0) {
            os << "+";
        }
        os << p.termArray[i].coef << "x^" << p.termArray[i].exp;
        if (i < p.terms - 1) {
            os << " ";
        }
    }
    return os;
}


std::istream& operator>>(std::istream& is, Polynomial& p) {
    int num_terms;
    std::cout << "Enter number of non-zero terms: ";
    is >> num_terms;

    
    delete[] p.termArray;
    p.capacity = (num_terms > 0) ? num_terms : 1;
    p.terms = 0;
    p.termArray = new Term[p.capacity];

    std::cout << "Enter terms as 'coefficient exponent' pairs (in decreasing order of exponent):" << std::endl;
    for (int i = 0; i < num_terms; i++) {
        float c;
        int e;
        is >> c >> e;
        p.NewTerm(c, e);
    }
    return is;
}

#endif 