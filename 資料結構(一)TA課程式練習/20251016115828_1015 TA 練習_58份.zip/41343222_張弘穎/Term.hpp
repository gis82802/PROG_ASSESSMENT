#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
public:
    double coef; // 係數
    int exp;     // 指數

    Term(double c = 0, int e = 0) : coef(c), exp(e) {}

    friend ostream& operator<<(ostream& out, const Term& t) {
        if (t.exp == 0)
            out << t.coef;
        else if (t.exp == 1)
            out << t.coef << "x";
        else
            out << t.coef << "x^" << t.exp;
        return out;
    }
};

#endif
