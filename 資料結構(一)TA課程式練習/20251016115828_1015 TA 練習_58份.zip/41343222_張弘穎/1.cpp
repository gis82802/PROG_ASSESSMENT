#include<iostream>
#include "natureNum.hpp"
using namespace std;

int main() {
	NatureNumber a, b;
	NatureNumber* c;
	cin >> a;
	cin >> b;
	cout << a + b << endl;
	cout << a - b << endl;
	if (a == b) {
		cout << "a==b" << endl;
	}
	else {
		cout << "a!=b" << endl;
	}
}