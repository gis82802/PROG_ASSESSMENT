#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

    //  排序 + 合併同次項 + 移除係數為 0
    void simplify() {
        // 先依照指數由大到小排序
        sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });

        // 合併同次項
        vector<Term> merged;
        for (const auto& t : terms) {
            if (!merged.empty() && merged.back().exp == t.exp)
                merged.back().coef += t.coef;
            else
                merged.push_back(t);
        }

        // 移除係數為 0 的項
        terms.clear();
        for (const auto& t : merged)
            if (t.coef != 0)
                terms.push_back(t);
    }

public:
    // 一次輸入整行：例如「3 2  2 1  1 0」
    friend istream& operator>>(istream& in, Polynomial& p) {
        p.terms.clear();
        string line;
        //cout << "請輸入多項式（格式：係數 指數 ...），按 Enter 結束：" << endl;
        getline(in >> ws, line); // 讀入整行

        stringstream ss(line);
        double c;
        int e;
        while (ss >> c >> e) {
            p.terms.push_back(Term(c, e));
        }

        p.simplify(); // 自動整理
        return in;
    }

    // 輸出多項式
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << 0;
            return out;
        }

        for (size_t i = 0; i < p.terms.size(); i++) {
            if (i > 0 && p.terms[i].coef >= 0)
                out << "+";
            out << p.terms[i];
        }
        return out;
    }

    // 多項式相加
    Polynomial Add(const Polynomial& b) const {
        Polynomial result = *this;

        // 先把 b 的項目都加入
        for (const Term& tb : b.terms)
            result.terms.push_back(tb);

        // 再整理排序與合併
        result.simplify();
        return result;
    }
};

#endif
