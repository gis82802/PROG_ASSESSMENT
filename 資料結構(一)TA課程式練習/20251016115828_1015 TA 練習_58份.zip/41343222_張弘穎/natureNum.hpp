#include<iostream>
using namespace std;
class NatureNumber {
private:
	int number;
public:
	NatureNumber(int a = 0) {
		number = a;
	}
	NatureNumber operator+(const NatureNumber& other) {
		return NatureNumber(this->number + other.number);
	}
	NatureNumber operator-(const NatureNumber& other) {
		return NatureNumber(this->number - other.number);
	}
	bool operator==(const NatureNumber& other) {
		return number == other.number;
	}
	friend ostream& operator <<(ostream& os, const NatureNumber& all);
	friend istream& operator>>(istream& io, NatureNumber& all);
};
ostream& operator <<(ostream& os,const NatureNumber& all) {
	os << all.number;
	return os;
}
istream& operator>>(istream& io,NatureNumber& all) {//const 讓他可以改number值
	io >> all.number;
	return io;
}