#pragma once
#include<iostream>
#include<string>
#include<algorithm>

class NatureNum {
private:
	std::string val;

	void trimZero() {
		size_t p = val.find_first_not_of('0');
		if (p == std::string::npos)
			val = "0";
		else
			val = val.substr(p);
	}
	bool valid(const std::string& s) {
		if (s.empty())return false;
		for (char c : s) {
			if (!isdigit(c))return false;
		}
		return true;
	}
public:
	NatureNum():val("0"){}
	NatureNum(const std::string& s) {
		if (valid(s)) {
			val = s;
			trimZero();
		}
		else {
			val = "0";
		}
	}
	NatureNum operator + (const NatureNum & b)const {
		std::string res;
		int carry = 0;
		int i = (int)val.size() - 1;
		int j = (int)b.val.size() - 1;
		while (i >= 0 || j >= 0 || carry) {
			int sum = carry;
			if (i >= 0)sum += val[i--] - '0';
			if (j >= 0)sum += b.val[j--] - '0';

			res.push_back((sum % 10) + '0');
			carry = sum / 10;
		}
		std::reverse(res.begin(), res.end());
		return NatureNum(res);

	}
	NatureNum operator-(const NatureNum& b)const {
		if (*this < b)return NatureNum("0");

		std::string res;
		int borrow = 0;
		int i = (int)val.size() - 1;
		int j = (int)b.val.size() - 1;

		while (i >= 0) {
			int a = val[i--] - '0';
			int bb = (j >= 0) ? b.val[j--] - '0' : 0;
			a -= borrow;
			if (a < bb) {
				a += 10;
				borrow = 1;
			}
			else {
				borrow = 0;
			}
			res.push_back((a - bb) + '0');

		}
		std::reverse(res.begin(), res.end());
		return NatureNum(res);
	}
	bool operator==(const NatureNum& b)const {
		return val == b.val;
	}
	bool operator<(const NatureNum& b)const {
		if (val.size() != b.val.size())
			return val.size() < b.val.size();
		return val < b.val;
	}

	friend std::istream& operator>>(std::istream& is,NatureNum& n) {
		std::string in;
		is >> in;
		bool ok = true;
		for (char c : in) {
			if (!isdigit(c)) {
				ok = false;
				break;
			}
		}
		if (ok && !in.empty()) {
			n.val = in;
			n.trimZero();
		}
		else {
			n.val = "0";
		}
		return is;
	}
	friend std::ostream& operator<<(std::ostream& os, const NatureNum& n) {
		os << n.val;
		return os;
	}
};