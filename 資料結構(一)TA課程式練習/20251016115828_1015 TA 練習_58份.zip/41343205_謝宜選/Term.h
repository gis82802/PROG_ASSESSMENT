#pragma once
#include<iostream>

class Term {
public:
	int coef;
	int exp;

	Term(int c=0,int e=0):coef(c),exp(e){}

	bool operator==(const Term& t)const {
		return exp == t.exp;
	}

	bool operator<(const Term& t)const {
		return exp > t.exp;
	}

	friend std::ostream& operator<<(std::ostream& os, const Term& t) {
		if (t.exp == 0)
			os << t.coef;
		else if (t.exp == 1)
			os << t.coef << "x";
		else
			os << t.coef << "x^" << t.exp;
		return os;
	}
};