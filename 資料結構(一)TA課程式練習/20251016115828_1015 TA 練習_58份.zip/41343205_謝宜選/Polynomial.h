#pragma once
#include<iostream>
#include<vector>
#include<algorithm>
#include"Term.h"

class Polynomial {
private:
	std::vector<Term> terms;

	void simplify() {
		std::sort(terms.begin(), terms.end());
		std::vector<Term>result;
		for (auto& t : terms) {
			if (!result.empty() && result.back().exp == t.exp)
				result.back().coef += t.coef;
			else
				result.push_back(t);
		}
		terms = result;
	}
public:
	Polynomial() {}

	Polynomial Add(const Polynomial& other)const {
		Polynomial sum = *this;
		for (auto& t : other.terms)
			sum.terms.push_back(t);
		sum.simplify();
		return sum;
	}
	friend std::istream& operator>>(std::istream& is, Polynomial& p) {
		p.terms.clear();
		int n;
		std::cout << "Enter Number of Terms:";
		is >> n;
		for (int i = 0; i < n; i++) {
			int c, e;
			std::cout << "Term" << i + 1 << "(coef exp):";
			is >> c >> e;
			p.terms.push_back(Term(c, e));
		}
		p.simplify();
		return is;

	}
	friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
		if (p.terms.empty()) {
			os << "0";
			return os;
		}
		for (size_t i= 0; i < p.terms.size(); ++i) {
			if (i > 0 && p.terms[i].coef > 0)os << "+";
			os << p.terms[i];
		}
		return os;
	}
};