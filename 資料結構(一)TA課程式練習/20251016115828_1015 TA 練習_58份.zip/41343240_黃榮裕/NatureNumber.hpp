#ifndef NATURE_NUM_HPP
#define NATURE_NUM_HPP

#include <iostream>
using namespace std;

class NatureNumber
{
private:
    unsigned int value; // 自然數，不可為負

public:
    NatureNumber(unsigned int v = 0) : value(v) {}

    NatureNumber(const NatureNumber &other) = default;

    NatureNumber operator+(const NatureNumber &other) const
    {
        return NatureNumber(this->value + other.value);
    }

    NatureNumber operator-(const NatureNumber &other) const
    {
        if (this->value < other.value)
            return NatureNumber(0);
        return NatureNumber(this->value - other.value);
    }

    bool operator==(const NatureNumber &other) const
    {
        return this->value == other.value;
    }

    bool operator!=(const NatureNumber &other) const
    {
        return !(*this == other);
    }

    friend ostream &operator<<(ostream &os, const NatureNumber &n)
    {
        os << n.value;
        return os;
    }

    friend istream &operator>>(istream &is, NatureNumber &n)
    {
        int temp;
        is >> temp;
        if (temp < 0)
            temp = 0;
        n.value = static_cast<unsigned int>(temp);
        return is;
    }
};

#endif
