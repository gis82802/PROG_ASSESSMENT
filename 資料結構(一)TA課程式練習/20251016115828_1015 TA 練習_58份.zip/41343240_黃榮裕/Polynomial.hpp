#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include "Term.hpp"
using namespace std;

class Polynomial
{
private:
    static const int MAX_TERMS = 20; // 可視需求調整
    Term terms[MAX_TERMS];
    int termCount = 0;

    // 手動排序（降冪）
    void sortByExp()
    {
        for (int i = 0; i < termCount - 1; ++i)
        {
            for (int j = i + 1; j < termCount; ++j)
            {
                if (terms[i].exp < terms[j].exp)
                {
                    Term tmp = terms[i];
                    terms[i] = terms[j];
                    terms[j] = tmp;
                }
            }
        }
    }

    // 合併同次項
    void simplify()
    {
        sortByExp();
        int newCount = 0;
        for (int i = 0; i < termCount; ++i)
        {
            if (newCount > 0 && terms[i].exp == terms[newCount - 1].exp)
            {
                terms[newCount - 1].coef += terms[i].coef;
            }
            else
            {
                terms[newCount++] = terms[i];
            }
        }
        termCount = newCount;
    }

public:
    Polynomial() = default;

    // 多項式相加
    Polynomial Add(const Polynomial &other) const
    {
        Polynomial result;
        result.termCount = termCount + other.termCount;

        for (int i = 0; i < termCount; ++i)
            result.terms[i] = terms[i];

        for (int i = 0; i < other.termCount; ++i)
            result.terms[termCount + i] = other.terms[i];

        result.simplify();
        return result;
    }

    // 輸入格式
    friend istream &operator>>(istream &is, Polynomial &p)
    {
        cout << "number of terms: ";
        is >> p.termCount;
        if (p.termCount > MAX_TERMS)
            p.termCount = MAX_TERMS;

        for (int i = 0; i < p.termCount; i++)
        {
            cout << "term " << i + 1 << " (coef exp): ";
            is >> p.terms[i];
        }
        p.simplify();
        return is;
    }

    friend ostream &operator<<(ostream &os, const Polynomial &p)
    {
        if (p.termCount == 0)
        {
            os << 0;
            return os;
        }
        for (int i = 0; i < p.termCount; ++i)
        {
            if (i > 0 && p.terms[i].coef >= 0)
                os << "+";
            os << p.terms[i];
        }
        return os;
    }
};

#endif
