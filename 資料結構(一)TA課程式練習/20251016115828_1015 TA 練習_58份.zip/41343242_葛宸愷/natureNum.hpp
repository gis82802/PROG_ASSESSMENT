#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    int value; 

public:
    NatureNumber() : value(0) {}

    NatureNumber(int v) : value(v) {}

    friend istream& operator>>(istream& in, NatureNumber& num) {
        in >> num.value;
        return in;
    }

    friend ostream& operator<<(ostream& out, const NatureNumber& num) {
        out << num.value;
        return out;
    }

    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        return NatureNumber(this->value - other.value);
    }

    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    bool operator!=(const NatureNumber& other) const {
        return this->value != other.value;
    }

    int getValue() const { return value; }
};

#endif
