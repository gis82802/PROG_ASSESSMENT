#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
private:
    int coefficient;  
    int exponent;     

public:
    Term() : coefficient(0), exponent(0) {}

    Term(int coef, int exp) : coefficient(coef), exponent(exp) {}

    friend istream& operator>>(istream& in, Term& term) {
        in >> term.coefficient >> term.exponent;
        return in;
    }

    friend ostream& operator<<(ostream& out, const Term& term) {
        out << term.coefficient << "x^" << term.exponent;
        return out;
    }

    int getCoefficient() const { return coefficient; }

    int getExponent() const { return exponent; }

    Term operator+(const Term& other) const {
        if (this->exponent == other.exponent) {
            return Term(this->coefficient + other.coefficient, this->exponent);
        }
        return *this;
    }

    bool operator==(const Term& other) const {
        return this->exponent == other.exponent;
    }

    bool operator!=(const Term& other) const {
        return !(*this == other);
    }
};

#endif
