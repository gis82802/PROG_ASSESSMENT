#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP
#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
class Polynomial {
private:
    std::vector<Term> terms;

    void simplify() {
        if (terms.empty()) return;

        std::sort(terms.rbegin(), terms.rend());

        std::vector<Term> simplified_terms;
        if (!terms.empty()) {
            Term current = terms[0];
            for (size_t i = 1; i < terms.size(); ++i) {
                if (terms[i].exponent == current.exponent) {
                    current.coefficient += terms[i].coefficient;
                }
                else {
                    if (current.coefficient != 0.0) {
                        simplified_terms.push_back(current);
                    }
                    current = terms[i];
                }
            }
            if (current.coefficient != 0.0) {
                simplified_terms.push_back(current);
            }
        }
        terms = simplified_terms;
    }

public:
    Polynomial() {}

    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;

        for (const auto& term_b : other.terms) {
            result.terms.push_back(term_b);
        }

        result.simplify();

        return result;
    }

    friend std::istream& operator>>(std::istream& is, Polynomial& p) {
        p.terms.clear();
        int num_terms;

        std::cout << "Enter number of terms: ";
        if (!(is >> num_terms)) return is;

        std::cout << "Enter terms (coefficient exponent) " << num_terms << " times:" << std::endl;
        for (int i = 0; i < num_terms; ++i) {
            double c;
            int e;
            if (!(is >> c >> e)) {
                return is;
            }
            p.terms.emplace_back(c, e);
        }

        p.simplify();

        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        if (p.terms.empty()) {
            return os << "0";
        }

        bool first_term = true;
        for (const auto& term : p.terms) {
            if (term.coefficient == 0.0) continue;

            if (first_term) {
                if (term.coefficient < 0) {
                    os << term;
                }
                else {
                    if (std::abs(term.coefficient) != 1.0 || term.exponent == 0) {
                        os << term.coefficient;
                    }
                    else if (term.coefficient == -1.0) {
                        os << "-";
                    }

                    if (term.exponent > 1) {
                        os << "x^" << term.exponent;
                    }
                    else if (term.exponent == 1) {
                        os << "x";
                    }
                }
                first_term = false;
            }
            else {
                os << term;
            }
        }

        if (first_term) {
            return os << "0";
        }

        return os;
    }
};

#endif // POLYNOMIAL_HPP