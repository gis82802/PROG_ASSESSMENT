#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
#include <cmath>

class Term {
public:
    double coefficient;
    int exponent;

    Term(double coeff = 0.0, int exp = 0) : coefficient(coeff), exponent(exp) {}

    bool is_combinable(const Term& other) const {
        return exponent == other.exponent;
    }

    bool operator<(const Term& other) const {
        return exponent < other.exponent;
    }

    friend std::ostream& operator<<(std::ostream& os, const Term& t);
};

std::ostream& operator<<(std::ostream& os, const Term& t) {
    if (t.coefficient == 0.0) {
        return os;
    }

    if (t.coefficient > 0) {
        os << "+";
    }

    if (std::abs(t.coefficient) != 1.0 || t.exponent == 0) {
        os << t.coefficient;
    }
    else if (t.coefficient == -1.0) {
        os << "-";
    }

    if (t.exponent > 1) {
        os << "x^" << t.exponent;
    }
    else if (t.exponent == 1) {
        os << "x";
    }

    return os;
}

#endif // TERM_HPP