#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>

class NatureNumber {
private:
    int value;

public:
    NatureNumber() : value(1) {}

    NatureNumber(int val) {
        if (val >= 1) {
            value = val;
        }
        else {
            std::cerr << "Warning: Initial value " << val << " is not a nature number. Setting to 1." << std::endl;
            value = 1;
        }

    }

    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        return NatureNumber(this->value - other.value);
    }

    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    friend std::istream& operator>>(std::istream& is, NatureNumber& num) {
        int temp;
        if (is >> temp) {
            if (temp >= 1) {
                num.value = temp;
            }
            else {
                std::cerr << "Error: Input value " << temp << " is not a nature number. Value remains " << num.value << "." << std::endl;
            }
        }
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& num) {
        os << num.value;
        return os;
    }
};

#endif // NATURENUM_HPP