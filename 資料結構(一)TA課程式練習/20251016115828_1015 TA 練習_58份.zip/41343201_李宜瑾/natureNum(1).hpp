#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
#include <algorithm>

class NatureNumber {
private:
    int value;

public:
    NatureNumber() : value(1) {}

    NatureNumber(int v) {
        value = v;
    }

    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        int result = this->value - other.value;
        int final_value = std::max(0, result);
        return NatureNumber(final_value);
    }

    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }

    friend std::istream& operator>>(std::istream& is, NatureNumber& obj) {
        int input_val;
        is >> input_val;

        if (input_val >= 0) {
            obj.value = input_val;
        }
        else {
            std::cout << "Warning: Input must be >= 0. Setting to 0." << std::endl;
            obj.value = 0;
        }

        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& obj) {
        os << obj.value;
        return os;
    }
};

#endif // NATURENUM_HPP