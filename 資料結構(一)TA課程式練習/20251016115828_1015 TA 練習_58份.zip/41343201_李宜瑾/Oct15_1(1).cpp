#include <iostream>
#include "natureNum.hpp"
using namespace std;

int main() {
    NatureNumber a, b;
    NatureNumber* c;

    cout << "��J�Ĥ@�Ӧ۵M�� (a): ";
    cin >> a;

    cout << "��J�ĤG�Ӧ۵M�� (b): ";
    cin >> b;

    cout << "a+b=" << a + b << endl;
    cout << "a-b=" << a - b << endl;

    if (a == b) {
        cout << "a==b" << endl;
    }
    else {
        cout << "a!=b" << endl;
    }

    return 0;
}