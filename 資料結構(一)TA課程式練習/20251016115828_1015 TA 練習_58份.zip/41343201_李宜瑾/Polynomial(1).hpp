#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include "Term.hpp" 

const double EPSILON = 1e-9;

class Polynomial {
private:
    std::vector<Term> terms;
    void simplify() {
        if (terms.empty()) return;
        std::sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });
        std::vector<Term> newTerms;
        if (!terms.empty()) {
            Term current = terms[0];
            for (size_t i = 1; i < terms.size(); ++i) {
                if (terms[i].exp == current.exp) {
                    current.coeff += terms[i].coeff;
                }
                else {
                    newTerms.push_back(current);
                    current = terms[i];
                }
            }
            newTerms.push_back(current);
        }
        terms = std::move(newTerms);
        terms.erase(
            std::remove_if(terms.begin(), terms.end(), [](const Term& t) {
                return std::abs(t.coeff) < EPSILON;
                }),
            terms.end()
        );
    }

public:
    Polynomial() {}
    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        result.terms.reserve(this->terms.size() + other.terms.size());

        result.terms.insert(result.terms.end(), this->terms.begin(), this->terms.end());
        result.terms.insert(result.terms.end(), other.terms.begin(), other.terms.end());

        result.simplify();

        return result;
    }
    friend std::istream& operator>>(std::istream& is, Polynomial& p);
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p);
};
std::istream& operator>>(std::istream& is, Polynomial& p) {
    p.terms.clear();
    int numTerms;
    double coeff;
    int exp;
    std::cout << "�п�J�����ƶq: ";
    if (!(is >> numTerms)) return is;

    for (int i = 0; i < numTerms; ++i) {
        std::cout << "��J�� " << i + 1 << " �� (�Y�� ����): ";
        if (!(is >> coeff >> exp)) return is;
        p.terms.push_back(Term(coeff, exp));
    }

    p.simplify();
    return is;
}

std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
    if (p.terms.empty()) {
        os << "0";
        return os;
    }

    bool isFirst = true;

    for (const auto& term : p.terms) {
        if (std::abs(term.coeff) < EPSILON) {
            continue; 
        }
        if (term.coeff > 0) {
            if (!isFirst) {
                os << " + "; 
            }
        }
        else {
            if (isFirst) {
                os << "-";
            }
            else {
                os << " - ";
            }
        }

        double absCoeff = std::abs(term.coeff);
        bool isInteger = std::abs(absCoeff - std::round(absCoeff)) < EPSILON;

        if (term.exp == 0 || std::abs(absCoeff - 1.0) > EPSILON) {
            if (isInteger) {
                os << (long long)std::round(absCoeff);
            }
            else {
                os << absCoeff; 
            }
        }
        if (term.exp > 0) {
            os << "x";
            if (term.exp > 1) {
                os << "^" << term.exp;
            }
        }
        else if (term.exp == 0 && std::abs(absCoeff - 1.0) < EPSILON) {
            os << "1";
        }

        isFirst = false;
    }
    return os;
}

#endif 