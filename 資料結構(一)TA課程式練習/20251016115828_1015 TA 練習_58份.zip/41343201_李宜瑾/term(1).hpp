#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
#include <cmath>

class Term {
public:
    double coeff;
    int exp;
    Term(double c = 0.0, int e = 0) : coeff(c), exp(e) {}
};
#endif 
