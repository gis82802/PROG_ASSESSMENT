#pragma once
#include <iostream>
using namespace std;

class NatureNumber {
private:
	unsigned int value;
public:
	NatureNumber() : value(0) {}
	NatureNumber(unsigned int v) : value(v) {}

	friend istream& operator>>(istream& is, NatureNumber& n) {
		int temp;
		is >> temp;
		if (temp < 0) temp = 0; 
		n.value = static_cast<unsigned int>(temp);
		return is;
	}

	friend ostream& operator<<(ostream& os, const NatureNumber& n) {
		os << n.value;
		return os;
	}

	friend NatureNumber operator+(const NatureNumber& a, const NatureNumber& b) {
		return NatureNumber(a.value + b.value);
	}

	friend NatureNumber operator-(const NatureNumber& a, const NatureNumber& b) {
		if (a.value < b.value) return NatureNumber(0);
		return NatureNumber(a.value - b.value);
	}

	friend bool operator==(const NatureNumber& a, const NatureNumber& b) {
		return a.value == b.value;
	}
	friend bool operator!=(const NatureNumber& a, const NatureNumber& b) {
		return !(a == b);
	}
};