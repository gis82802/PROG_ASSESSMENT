#include <iostream>
#include "Polynomial.hpp"
#include "Term.hpp"

using namespace std;

int main() {
    Polynomial a, b;

    cout << "input poly A " << endl;
    cin >> a;

    cout << "input poly B " << endl;
    cin >> b;

    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "a+b=" << a.Add(b) << endl;

    return 0;
}
