#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

public:
    // ��J�h����
    friend istream& operator>>(istream& in, Polynomial& p) {
        p.terms.clear();
        int n;
        cout << "��J���ơG";
        in >> n;
        for (int i = 0; i < n; i++) {
            Term t;
            cout << "��J�� " << i + 1 << " �����Y�ƻP����G";
            in >> t.coef >> t.exp;

            // �X�֦P����
            bool found = false;
            for (auto &x : p.terms) {
                if (x.exp == t.exp) {
                    x.coef += t.coef;
                    found = true;
                    break;
                }
            }
            if (!found) p.terms.push_back(t);
        }
        return in;
    }

    // ��X�h����
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        for (int i = 0; i < p.terms.size(); i++) {
            int c = p.terms[i].coef;
            int e = p.terms[i].exp;
            if (i > 0 && c > 0) out << "+";

            if (e == 0)
                out << c;
            else if (c == 1)
                out << "x";
            else if (c == -1)
                out << "-x";
            else
                out << c << "x";

            if (e > 1) out << "^" << e;
        }
        return out;
    }

    // �[�k
    Polynomial Add(const Polynomial& b) const {
        Polynomial r = *this;
        for (auto tb : b.terms) {
            bool found = false;
            for (auto &ta : r.terms) {
                if (ta.exp == tb.exp) {
                    ta.coef += tb.coef;
                    found = true;
                    break;
                }
            }
            if (!found) r.terms.push_back(tb);
        }
        return r;
    }
};

#endif


