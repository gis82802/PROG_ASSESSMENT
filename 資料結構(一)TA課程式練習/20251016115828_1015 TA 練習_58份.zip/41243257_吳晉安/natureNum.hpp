// natureNum.hpp
#include <iostream>
using namespace std;

class NatureNumber {
private:
    int value;

public:
    NatureNumber(int v = 0) { value = (v >= 0) ? v : 0; }

    // ��J��X
    friend istream& operator>>(istream& in, NatureNumber& n) {
        in >> n.value;
        if (n.value < 0) n.value = 0;
        return in;
    }
    friend ostream& operator<<(ostream& out, const NatureNumber& n) {
        out << n.value;
        return out;
    }

    // �[��
    friend NatureNumber operator+(const NatureNumber& a, const NatureNumber& b) {
        return NatureNumber(a.value + b.value);
    }
    friend NatureNumber operator-(const NatureNumber& a, const NatureNumber& b) {
        return NatureNumber((a.value - b.value >= 0) ? a.value - b.value : 0);
    }

    // ���
    friend bool operator==(const NatureNumber& a, const NatureNumber& b) {
        return a.value == b.value;
    }
};

