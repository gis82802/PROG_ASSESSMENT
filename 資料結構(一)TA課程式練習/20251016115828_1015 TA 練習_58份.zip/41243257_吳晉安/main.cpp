#include <iostream>
#include "Polynomial.hpp"
using namespace std;

int main() {
    Polynomial a, b;
    cout << "��J�h���� a�G" << endl;
    cin >> a;

    cout << "��J�h���� b�G" << endl;
    cin >> b;

    cout << "a = " << a << endl;
    cout << "b = " << b << endl;

    cout << "a + b = " << a.Add(b) << endl;

    return 0;
}

