#ifndef natureNum_hpp
#define natureNum_hpp

#include <iostream>
using namespace std;

class NatureNumber {
private:
    int num;

public:
    NatureNumber() { num = 0; }

    friend istream& operator>>(istream& in, NatureNumber& a) {
        in >> a.num;
        // �T�O��J���D�t��
        if (a.num < 0) {
            a.num = 0;
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, NatureNumber a) {
        out << a.num;
        return out;
    }

    NatureNumber operator+(NatureNumber b) {
        NatureNumber c;
        c.num = num + b.num;
        return c;
    }

    NatureNumber operator-(NatureNumber b) {
        NatureNumber c;
        c.num = num - b.num;
        // �����G���t�ɡA��^ 0�]�۵M�Ƥ��ର�t�^
        if (c.num < 0) {
            c.num = 0;
        }
        return c;
    }

    bool operator==(NatureNumber b) {
        return num == b.num;
    }
};

#endif