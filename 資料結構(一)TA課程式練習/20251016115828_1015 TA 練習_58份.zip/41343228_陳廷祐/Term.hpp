#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
public:
    double coeff;  // �Y��
    int exp;       // ����

    // �غc�l
    Term(double c = 0.0, int e = 0) : coeff(c), exp(e) {}

    // ����B��l�]������Ƨǡ^
    bool operator<(const Term& other) const {
        return exp > other.exp;  // �����Ƨ�
    }

    // ��X�B��l
    friend ostream& operator<<(ostream& os, const Term& t) {
        if (t.coeff == 0) return os;

        if (t.exp == 0) {
            os << t.coeff;
        }
        else if (t.exp == 1) {
            if (t.coeff == 1) {
                os << "x";
            }
            else if (t.coeff == -1) {
                os << "-x";
            }
            else {
                os << t.coeff << "x";
            }
        }
        else {
            if (t.coeff == 1) {
                os << "x^" << t.exp;
            }
            else if (t.coeff == -1) {
                os << "-x^" << t.exp;
            }
            else {
                os << t.coeff << "x^" << t.exp;
            }
        }
        return os;
    }
};

#endif