#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
#include <limits>

class NatureNumber {
public:
    using value_type = unsigned long long;

    NatureNumber() noexcept : val(0) {}
    explicit NatureNumber(value_type v) noexcept : val(v) {}

    NatureNumber(const NatureNumber&) = default;
    NatureNumber(NatureNumber&&) = default;
    NatureNumber& operator=(const NatureNumber&) = default;
    NatureNumber& operator=(NatureNumber&&) = default;

    NatureNumber operator+(const NatureNumber& other) const noexcept {
        value_type a = val, b = other.val;
        if (a > std::numeric_limits<value_type>::max() - b) {
            return NatureNumber(std::numeric_limits<value_type>::max());
        }
        return NatureNumber(a + b);
    }

    NatureNumber operator-(const NatureNumber& other) const noexcept {
        if (val <= other.val) return NatureNumber(0);
        return NatureNumber(val - other.val);
    }

    bool operator==(const NatureNumber& other) const noexcept {
        return val == other.val;
    }
    bool operator!=(const NatureNumber& other) const noexcept {
        return !(*this == other);
    }

    value_type value() const noexcept { return val; }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        os << n.val;
        return os;
    }

    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
        long long tmp;
        if (!(is >> tmp)) {
            n.val = 0;
            return is;
        }
        if (tmp < 0) n.val = 0;
        else n.val = static_cast<value_type>(tmp);
        return is;
    }

private:
    value_type val;
};

#endif
