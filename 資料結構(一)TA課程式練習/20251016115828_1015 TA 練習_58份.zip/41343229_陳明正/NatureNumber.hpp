#pragma once
#include <iostream>

class NatureNumber {
public:
    using value_type = unsigned long long;

    NatureNumber() : v_(0) {}
    explicit NatureNumber(value_type v) : v_(v) {}
    explicit NatureNumber(long long v) : v_(v < 0 ? 0ULL : static_cast<value_type>(v)) {}
    NatureNumber operator+(const NatureNumber& rhs) const {
        return NatureNumber(v_ + rhs.v_);
    }
    NatureNumber operator-(const NatureNumber& rhs) const {
        return NatureNumber(v_ >= rhs.v_ ? v_ - rhs.v_ : 0ULL);
    }

    bool operator==(const NatureNumber& rhs) const { return v_ == rhs.v_; }
    bool operator!=(const NatureNumber& rhs) const { return v_ != rhs.v_; }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        return os << n.v_;
    }
    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
        long long tmp;
        if (is >> tmp) {
            if (tmp < 0) tmp = 0;
            n.v_ = static_cast<value_type>(tmp);
        }
        return is;
    }

private:
    value_type v_;
};
