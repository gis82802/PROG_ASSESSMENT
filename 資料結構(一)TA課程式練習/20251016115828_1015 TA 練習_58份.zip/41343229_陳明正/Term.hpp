#pragma once
struct Term {
    long long coef;
    int       exp;
    Term(long long c = 0, int e = 0) : coef(c), exp(e) {}
};