#pragma once
#include <map>
#include <iostream>

class Polynomial {
public:
    Polynomial() = default;

    Polynomial Add(const Polynomial& rhs) const {
        Polynomial res = *this;
        for (const auto& kv : rhs.poly_) res.poly_[kv.first] += kv.second;
        res.shrink();
        return res;
    }

    friend std::istream& operator>>(std::istream& is, Polynomial& p) {
        p.poly_.clear();
        int t;
        if (!(is >> t)) return is;
        for (int i = 0; i < t; ++i) {
            long long c; int e;
            is >> c >> e;
            p.poly_[e] += c;
        }
        p.shrink();
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        if (p.poly_.empty()) { os << 0; return os; }

        bool first = true;
        for (auto it = p.poly_.rbegin(); it != p.poly_.rend(); ++it) {
            long long c = it->second;
            int e = it->first;
            if (c == 0) continue;

            if (first) {
                if (c < 0) { os << '-'; c = -c; }
            }
            else {
                os << (c < 0 ? " - " : " + ");
                if (c < 0) c = -c;
            }

            if (e == 0) {
                os << c;
            }
            else {
                if (c != 1) os << c;
                os << "x";
                if (e != 1) os << "^" << e;
            }
            first = false;
        }
        if (first) os << 0;
        return os;
    }

private:
    std::map<int, long long> poly_;
    void shrink() {
        for (auto it = poly_.begin(); it != poly_.end(); )
            if (it->second == 0) it = poly_.erase(it);
            else ++it;
    }
};