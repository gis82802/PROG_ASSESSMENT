#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>

class Term {
public:
    int coefficient;
    int exponent;

    Term() : coefficient(0), exponent(0) {}

    Term(int coeff, int exp) : coefficient(coeff), exponent(exp) {}
    friend std::ostream& operator<<(std::ostream& os, const Term& t) {
        if (t.coefficient == 0) return os;

        if (t.exponent == 0) {
            os << t.coefficient;
        }
        else {
            if (t.coefficient != 1 && t.coefficient != -1) {
                os << t.coefficient;
            }
            else if (t.coefficient == -1) {
                os << "-";
            }
            os << "x";
            if (t.exponent != 1) {
                os << "^" << t.exponent;
            }
        }
        return os;
    }
};

#endif