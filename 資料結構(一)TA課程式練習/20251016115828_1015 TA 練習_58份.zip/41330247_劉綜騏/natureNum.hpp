#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

class NatureNumber {
private:
    std::vector<int> d;

    void normalize() {
        while (!d.empty() && d.back() == 0) d.pop_back();
    }

public:
    NatureNumber() { }

    explicit NatureNumber(const std::string& s) {
        for (int i = (int)s.size() - 1; i >= 0; --i) {
            d.push_back(s[i] - '0');
        }
        normalize();
    }
    NatureNumber operator+(const NatureNumber& other) const {
        NatureNumber res;
        const std::vector<int>& a = d;
        const std::vector<int>& b = other.d;
        int n = std::max(a.size(), b.size());
        res.d.resize(n);
        int carry = 0;
        for (int i = 0; i < n; ++i) {
            int av = (i < (int)a.size() ? a[i] : 0);
            int bv = (i < (int)b.size() ? b[i] : 0);
            int s = av + bv + carry;
            res.d[i] = s % 10;
            carry = s / 10;
        }
        while (carry) {
            res.d.push_back(carry % 10);
            carry /= 10;
        }
        res.normalize();
        return res;
    }

    NatureNumber operator-(const NatureNumber& other) const {
        if (*this < other) {
            return NatureNumber();
        }
        NatureNumber res;
        const std::vector<int>& a = d;
        const std::vector<int>& b = other.d;
        res.d.resize(a.size());
        int borrow = 0;
        for (size_t i = 0; i < a.size(); ++i) {
            int av = a[i];
            int bv = (i < b.size() ? b[i] : 0);
            int diff = av - bv - borrow;
            if (diff < 0) {
                diff += 10;
                borrow = 1;
            }
            else {
                borrow = 0;
            }
            res.d[i] = diff;
        }
        res.normalize();
        return res;
    }

    bool operator==(const NatureNumber& other) const {
        std::vector<int> a = d;
        std::vector<int> b = other.d;
        return a == b;
    }
    bool operator!=(const NatureNumber& other) const { return !(*this == other); }

    bool operator<(const NatureNumber& other) const {
        const std::vector<int>& a = d;
        const std::vector<int>& b = other.d;
        if (a.size() != b.size()) return a.size() < b.size();
        for (int i = (int)a.size() - 1; i >= 0; --i) {
            if (a[i] != b[i]) return a[i] < b[i];
        }
        return false;
    }

    friend std::istream& operator>>(std::istream& is, NatureNumber& nnum) {
        std::string s;

        if (!(is >> s)) return is;
        std::string digits;
        for (char ch : s) {
            if (std::isdigit(static_cast<unsigned char>(ch))) digits.push_back(ch);
            else {
 
                is.setstate(std::ios::failbit);
                return is;
            }
        }
        size_t pos = 0;
        while (pos < digits.size() && digits[pos] == '0') ++pos;
        if (pos == digits.size()) {
            nnum.d.clear();
        }
        else {
            nnum.d.clear();
            for (int i = (int)digits.size() - 1; i >= (int)pos; --i) nnum.d.push_back(digits[i] - '0');
        }
        return is;
    }

    // stream output
    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& nnum) {
        if (nnum.d.empty()) {
            os << '0';
            return os;
        }
        for (int i = (int)nnum.d.size() - 1; i >= 0; --i) os << char('0' + nnum.d[i]);
        return os;
    }
};

#endif 
