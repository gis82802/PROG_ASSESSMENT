#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include "Term.hpp"

class Polynomial {
private:
    std::vector<Term> terms;

    void simplify() {
        if (terms.empty()) return;

        std::map<int, int> combined_terms;
        for (const auto& term : terms) {
            combined_terms[term.exponent] += term.coefficient;
        }

        terms.clear();

        for (auto it = combined_terms.rbegin(); it != combined_terms.rend(); ++it) {
            int exponent = it->first;
            int coefficient = it->second;

            if (coefficient != 0) {
                terms.push_back(Term(coefficient, exponent));
            }
        }
    }

public:
    Polynomial() {}

    friend std::istream& operator>>(std::istream& is, Polynomial& p) {
        p.terms.clear();
        int num_terms;

        std::cout << "Enter number of terms: ";
        if (!(is >> num_terms)) return is;

        for (int i = 0; i < num_terms; ++i) {
            int coeff, exp;
            std::cout << "Enter coefficient and exponent for term " << i + 1 << " (coeff exp): ";
            if (!(is >> coeff >> exp)) return is;
            if (coeff != 0) {
                p.terms.push_back(Term(coeff, exp));
            }
        }
        p.simplify();
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const Polynomial& p) {
        bool first_term = true;
        bool all_zero = true;

        for (const auto& term : p.terms) {
            if (term.coefficient != 0) {
                all_zero = false;

                if (!first_term) {
                    if (term.coefficient > 0) {
                        os << " + ";
                    }
                    else {
                        os << " ";
                    }
                }
                else if (term.coefficient < 0) {

                }

                os << term;
                first_term = false;
            }
        }

        if (all_zero) {
            os << "0";
        }
        return os;
    }

    Polynomial Add(const Polynomial& other) const {
        Polynomial result;

        result.terms = this->terms;
        result.terms.insert(result.terms.end(), other.terms.begin(), other.terms.end());

        result.simplify();

        return result;
    }
};

#endif // POLYNOMIAL_HPP