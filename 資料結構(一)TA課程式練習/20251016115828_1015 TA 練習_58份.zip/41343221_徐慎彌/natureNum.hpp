#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
#include <stdexcept>

class NatureNumber {
private:
    unsigned long long value; 

public:

    NatureNumber(unsigned long long v = 0) : value(v) {}


    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(value + other.value);
    }

    NatureNumber operator-(const NatureNumber& other) const {
        if (value < other.value)
            throw std::underflow_error("���ର�t");
        return NatureNumber(value - other.value);
    }

    bool operator==(const NatureNumber& other) const {
        return value == other.value;
    }

    bool operator!=(const NatureNumber& other) const {
        return value != other.value;
    }

    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
        long long tmp;
        if (is >> tmp) {
            if (tmp < 0)
                throw std::invalid_argument("�D�t���");
            n.value = static_cast<unsigned long long>(tmp);
        }
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        os << n.value;
        return os;
    }
};

#endif
