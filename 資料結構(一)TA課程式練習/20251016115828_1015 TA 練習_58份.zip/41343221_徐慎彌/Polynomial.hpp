#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

    void simplify() {
        if (terms.empty()) return;
        sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });

        vector<Term> result;
        result.push_back(terms[0]);
        for (size_t i = 1; i < terms.size(); ++i) {
            if (terms[i].exp == result.back().exp)
                result.back().coef += terms[i].coef;
            else
                result.push_back(terms[i]);
        }

        terms.clear();
        for (auto& t : result)
            if (t.coef != 0) terms.push_back(t);
    }

public:
    Polynomial() {}

    Polynomial Add(const Polynomial& b) const {
        Polynomial result = *this;
        for (auto& t : b.terms) {
            result.terms.push_back(t);
        }
        result.simplify();
        return result;
    }

    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "���� ";
        in >> n;
        p.terms.clear();
        for (int i = 0; i < n; i++) {
            Term t;
            cout << "�Y�� ���� ";
            in >> t;
            p.terms.push_back(t);
        }
        p.simplify();
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << 0;
            return out;
        }

        for (size_t i = 0; i < p.terms.size(); ++i) {
            const Term& t = p.terms[i];
            if (i > 0 && t.coef >= 0) out << "+";
            out << t;
        }
        return out;
    }
};

#endif
