#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    int value;  // �x�s�۵M�ƭ�

public:
    // �غc�l
    NatureNumber(int v = 0) : value(v) {}

    // ��J
    friend istream& operator>>(istream& in, NatureNumber& n) {
        in >> n.value;
        return in;
    }

    // ��X
    friend ostream& operator<<(ostream& out, const NatureNumber& n) {
        out << n.value;
        return out;
    }

    // �[�k
    NatureNumber operator+(const NatureNumber& n) const {
        return NatureNumber(value + n.value);
    }

    // ��k
    NatureNumber operator-(const NatureNumber& n) const {
        return NatureNumber(value - n.value);
    }

    // �۵����
    bool operator==(const NatureNumber& n) const {
        return value == n.value;
    }
};

#endif

