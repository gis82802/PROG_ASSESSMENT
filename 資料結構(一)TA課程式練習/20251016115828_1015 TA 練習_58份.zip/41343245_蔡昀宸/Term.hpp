#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
public:
    int coef; // �Y��
    int exp;  // ����

    Term(int c = 0, int e = 0) : coef(c), exp(e) {}

    // ��J�涵���A�Ҧp: 3 2 �N�� 3x^2
    friend istream& operator>>(istream& in, Term& t) {
        in >> t.coef >> t.exp;
        return in;
    }

    // ��X�涵���A�ھڦ���M�w�榡
    friend ostream& operator<<(ostream& out, const Term& t) {
        if (t.exp == 0) {               // �`�ƶ�
            out << t.coef;
        }
        else if (t.exp == 1) {        // �@����
            if (t.coef == 1) out << "x";
            else if (t.coef == -1) out << "-x";
            else out << t.coef << "x";
        }
        else {                        // �G���H�W
            if (t.coef == 1) out << "x^" << t.exp;
            else if (t.coef == -1) out << "-x^" << t.exp;
            else out << t.coef << "x^" << t.exp;
        }
        return out;
    }
};

#endif
