#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

public:
    Polynomial() {}

    // ��J�h����
    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "Number of terms: ";
        in >> n;
        p.terms.clear();
        for (int i = 0; i < n; i++) {
            Term t;
            in >> t;
            p.terms.push_back(t);
        }
        return in;
    }

    // ��X�h����
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << 0;
            return out;
        }

        for (size_t i = 0; i < p.terms.size(); i++) {
            const Term& t = p.terms[i];

            // �B�z���t��
            if (i > 0) {
                if (t.coef > 0) out << "+";
            }

            out << t;
        }
        return out;
    }

    // �h�����[�k
    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        result.terms = terms;

        for (auto& t : other.terms) {
            bool found = false;
            for (auto& r : result.terms) {
                if (r.exp == t.exp) {
                    r.coef += t.coef;
                    found = true;
                    break;
                }
            }
            if (!found) result.terms.push_back(t);
        }

        // �����Y�Ƭ� 0 ����
        vector<Term> cleaned;
        for (auto& t : result.terms) {
            if (t.coef != 0) cleaned.push_back(t);
        }
        result.terms = cleaned;

        // ������Ѥj��p�Ƨ�
        sort(result.terms.begin(), result.terms.end(), [](Term a, Term b) {
            return a.exp > b.exp;
            });

        return result;
    }
};

#endif
