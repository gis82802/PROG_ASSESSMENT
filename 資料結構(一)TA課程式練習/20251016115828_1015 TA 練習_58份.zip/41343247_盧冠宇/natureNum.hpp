#include <iostream>
using namespace std;

class NatureNumber {
private:
	int num = 0;
public:
	NatureNumber(){}
	~NatureNumber(){}
	friend istream& operator>>(istream& os,NatureNumber& r) {
		cin >> r.num;
		return os;
	}
	friend int operator+(const NatureNumber& s1, const NatureNumber& s2) {
		return s1.num + s2.num;
	}
	friend int operator-(const NatureNumber& s1, const NatureNumber& s2) {
		if (s1.num - s2.num < 0) { return 0; }
		return s1.num - s2.num;
	}
	bool operator==(const NatureNumber& r) const {
		return (this->num == r.num);
	}
};