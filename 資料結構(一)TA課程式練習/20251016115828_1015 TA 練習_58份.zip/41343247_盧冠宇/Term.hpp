#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>

class Term {
public:
    int coefficient;
    int exponent;

    Term(int coef = 0, int exp = 0) : coefficient(coef), exponent(exp) {}

    friend std::istream& operator>>(std::istream& in, Term& term) {
        std::cout << "��J�Y�ƩM����: ";
        in >> term.coefficient >> term.exponent;
        return in;
    }

    friend std::ostream& operator<<(std::ostream& out, const Term& term) {
        if (term.exponent == 0) { out << term.coefficient;
        }
        else{
            out << term.coefficient << "x^" << term.exponent;
        }
        return out;
    }

    bool operator==(const Term& other) const {
        return this->exponent == other.exponent;
    }

    Term operator+(const Term& other) const {
        if (this->exponent == other.exponent) {
            return Term(this->coefficient + other.coefficient, this->exponent);
        }
        return *this;
    }
};

#endif