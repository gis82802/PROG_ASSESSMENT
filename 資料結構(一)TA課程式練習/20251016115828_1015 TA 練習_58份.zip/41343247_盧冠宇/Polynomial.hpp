using namespace std;
#include <iostream>
#include <vector>
#include "Term.hpp"

class Polynomial {
public:
    vector<Term> terms;

    friend istream& operator>>(istream& in, Polynomial& poly) {
        int n;
        cout << "���X��terms: ";
        in >> n;
        poly.terms.resize(n);
        for (int i = 0; i < n; ++i) {
            in >> poly.terms[i];
        }
        return in;
    }

    friend std::ostream& operator<<(std::ostream& out, const Polynomial& poly) {
        size_t i = 0;
        for (const auto& term : poly.terms) {
            if (i == poly.terms.size() - 1 ) {
                out << term;
            }
            else {
                out << term << "+";
            }
            i++;
        }
        return out;
    }

    Polynomial Add(const Polynomial& other) {
        Polynomial result;

        for (const auto& term : this->terms) {
            result.terms.push_back(term);
        }

        for (const auto& termB : other.terms) {
            bool found = false;
            for (auto& termA : result.terms) {
                if (termA.exponent == termB.exponent) {
                    termA.coefficient += termB.coefficient;
                    found = true;
                    break;
                }
            }

            if (!found) {
                result.terms.push_back(termB);
            }
        }

        return result;
    }
};