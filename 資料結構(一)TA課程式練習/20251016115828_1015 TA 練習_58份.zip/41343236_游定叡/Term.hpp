#ifndef TERM_HPP
#define TERM_HPP

class Term {
public:
    double coef;  // coefficient
    int exp;      // exponent

    // Default constructor
    Term() : coef(0), exp(0) {}

    // Parameterized constructor
    Term(double c, int e) : coef(c), exp(e) {}
};

#endif // TERM_HPP