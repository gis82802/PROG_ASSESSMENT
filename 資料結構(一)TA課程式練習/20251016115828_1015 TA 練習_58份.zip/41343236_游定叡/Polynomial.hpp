#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include "Term.hpp"
#include <iostream>
#include <vector>
#include <algorithm>

class Polynomial {
private:
    std::vector<Term> terms;

    void simplify() {
        if (terms.empty()) return;

        // Sort by exponent in descending order
        std::sort(terms.begin(), terms.end(),
            [](const Term& a, const Term& b) {
                return a.exp > b.exp;
            });

        // Combine like terms
        std::vector<Term> simplified;
        for (const auto& term : terms) {
            if (simplified.empty() || simplified.back().exp != term.exp) {
                simplified.push_back(term);
            }
            else {
                simplified.back().coef += term.coef;
            }
        }

        // Remove zero coefficients
        simplified.erase(
            std::remove_if(simplified.begin(), simplified.end(),
                [](const Term& t) { return t.coef == 0; }),
            simplified.end()
        );

        terms = simplified;
    }

public:
    Polynomial() {}

    // Add a polynomial to this one
    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        result.terms = this->terms;
        result.terms.insert(result.terms.end(),
            other.terms.begin(),
            other.terms.end());
        result.simplify();
        return result;
    }

    // Input operator
    friend std::istream& operator>>(std::istream& in, Polynomial& poly) {
        poly.terms.clear();
        int numTerms;
        in >> numTerms;

        for (int i = 0; i < numTerms; i++) {
            Term t;
            in >> t.coef >> t.exp;
            if (t.coef != 0) {
                poly.terms.push_back(t);
            }
        }

        poly.simplify();
        return in;
    }

    // Output operator
    friend std::ostream& operator<<(std::ostream& out, const Polynomial& poly) {
        if (poly.terms.empty()) {
            out << "0";
            return out;
        }

        for (size_t i = 0; i < poly.terms.size(); i++) {
            if (i > 0 && poly.terms[i].coef > 0) {
                out << "+";
            }

            if (poly.terms[i].exp == 0) {
                out << poly.terms[i].coef;
            }
            else if (poly.terms[i].exp == 1) {
                if (poly.terms[i].coef == 1) {
                    out << "x";
                }
                else if (poly.terms[i].coef == -1) {
                    out << "-x";
                }
                else {
                    out << poly.terms[i].coef << "x";
                }
            }
            else {
                if (poly.terms[i].coef == 1) {
                    out << "x^" << poly.terms[i].exp;
                }
                else if (poly.terms[i].coef == -1) {
                    out << "-x^" << poly.terms[i].exp;
                }
                else {
                    out << poly.terms[i].coef << "x^" << poly.terms[i].exp;
                }
            }
        }

        return out;
    }
};

#endif // POLYNOMIAL_HPP