#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
// #include <cmath> // �]�����A�ϥ� abs(), �ҥH�i�H����

using namespace std;

class NatureNumber {
    friend ostream& operator<<(ostream& os, const NatureNumber& num);
    friend istream& operator>>(istream& is, NatureNumber& num);

private:
    int value;

public:
    NatureNumber() : value(0) {}

    NatureNumber(int val) {
        if (val < 0) {
            value = 0;
        }
        else {
            value = val;
        }
    }

    NatureNumber operator+(const NatureNumber& other) const {
        return NatureNumber(this->value + other.value);
    }

    // ===== vvvvv �o�̤w��^��l�޿� vvvvv =====
    // ������k�B��l (-)
    // �p�G���G���t�A�h��^ 0
    NatureNumber operator-(const NatureNumber& other) const {
        int result = this->value - other.value;
        if (result < 0) {
            return NatureNumber(0); // �� a < b�A���G�� 0
        }
        return NatureNumber(result);
    }
    // ===== ^^^^^ �o�̤w��^��l�޿� ^^^^^ =====

    bool operator==(const NatureNumber& other) const {
        return this->value == other.value;
    }
};

ostream& operator<<(ostream& os, const NatureNumber& num) {
    os << num.value;
    return os;
}

istream& operator>>(istream& is, NatureNumber& num) {
    int input_val;
    is >> input_val;
    if (input_val < 0) {
        num.value = 0;
    }
    else {
        num.value = input_val;
    }
    return is;
}

#endif // NATURENUM_HPP