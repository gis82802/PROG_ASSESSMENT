#include <iostream>
using namespace std;

class Term {
public:
    int coef;  // 係數
    int exp;   // 指數

    Term(int c = 0, int e = 0) : coef(c), exp(e) {}

    // 讀入：一組 (coef exp)
    friend istream& operator>>(istream& in, Term& t) {
        in >> t.coef >> t.exp;
        return in;
    }

    // 輸出：簡單格式
    friend ostream& operator<<(ostream& out, const Term& t) {
        if (t.exp == 0)          out << t.coef;
        else if (t.exp == 1)     out << t.coef << "x";
        else                     out << t.coef << "x^" << t.exp;
        return out;
    }
};
