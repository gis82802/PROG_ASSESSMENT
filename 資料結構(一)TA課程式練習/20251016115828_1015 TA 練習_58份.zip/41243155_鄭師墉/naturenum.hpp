#include<ioapiset.h>
using namespace std;

class NatureNumber {
public:
    unsigned long long val;   // 用long long
    NatureNumber(unsigned long long v=0) : val(v) {}

    // 加法與減法
    NatureNumber operator+(const NatureNumber& rhs) const {
        return NatureNumber(val + rhs.val);
    }
    NatureNumber operator-(const NatureNumber& rhs) const {
        return NatureNumber(val - rhs.val);
    }

    // 比較
    bool operator==(const NatureNumber& rhs) const {
        return val == rhs.val;
    }

    // 輸入輸出
    friend istream& operator>>(istream& in, NatureNumber& x) {
        in >> x.val;
        return in;
    }
    friend ostream& operator<<(ostream& out, const NatureNumber& x) {
        out << x.val;
        return out;
    }
};