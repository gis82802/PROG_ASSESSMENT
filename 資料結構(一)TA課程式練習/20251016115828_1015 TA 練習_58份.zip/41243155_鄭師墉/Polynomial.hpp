#include <iostream>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
public:
    vector<Term> terms;

    // 輸入：先讀 n，接著 n 組 (coef exp)
    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "Enter the number of terms: ";
        in >> n;
        p.terms.clear();
        for (int i = 0; i < n; ++i) {
            cout << "Enter coefficient and exponent for term " << (i+1) << ": ";
            Term t;
            in >> t;
            if (t.coef != 0) p.terms.push_back(t);
        }
        return in;
    }


    // 輸出
    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) { out << 0; return out; }
        for (size_t i=0; i<p.terms.size(); ++i) {
            if (i>0 && p.terms[i].coef > 0) out << '+';
            out << p.terms[i];
        }
        return out;
    }

    // A + B：同次項合併，沒有就附加；最後移除 0 項
    Polynomial Add(const Polynomial& b) const {
        Polynomial res;
        res.terms = terms;
        for (size_t i=0; i<b.terms.size(); ++i) {
            Term tb = b.terms[i];
            bool merged = false;
            for (size_t j=0; j<res.terms.size(); ++j) {
                if (res.terms[j].exp == tb.exp) {
                    res.terms[j].coef += tb.coef;
                    merged = true;
                    break;
                }
            }
            if (!merged) res.terms.push_back(tb);
        }

        // 移除係數為 0 的項
        vector<Term> kept;
        for (size_t i=0; i<res.terms.size(); ++i)
            if (res.terms[i].coef != 0) kept.push_back(res.terms[i]);
        res.terms = kept;
        return res;
    }
};