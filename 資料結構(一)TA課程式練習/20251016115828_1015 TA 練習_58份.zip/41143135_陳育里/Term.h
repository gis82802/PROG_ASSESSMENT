#ifndef TERM_H
#define TERM_H

#include <iostream>
using namespace std;

class Term {
public:
    double a;
    int b;    

    Term(double coef = 0, int exp = 0) : a(coef), b(exp) {}

    friend istream& operator>>(istream& in, Term& t) {
        in >> t.a >> t.b;
        return in;
    }

    friend ostream& operator<<(ostream& out, const Term& t) {
        if (t.a == 0) return out;
        if (t.b == 0) out << t.a;
        else if (t.b == 1) {
            if (t.a == 1) out << "x";
            else if (t.a == -1) out << "-x";
            else out << t.a << "x";
        } else {
            if (t.a == 1) out << "x^" << t.b;
            else if (t.a == -1) out << "-x^" << t.b;
            else out << t.a << "x^" << t.b;
        }
        return out;
    }
};

#endif
