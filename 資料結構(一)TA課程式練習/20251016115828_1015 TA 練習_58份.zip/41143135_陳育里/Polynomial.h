#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include <iostream>
#include "Term.h"
using namespace std;

class Polynomial {
private:
    Term* terms;
    int size;

public:
    Polynomial() : terms(NULL), size(0) {}

    Polynomial(const Polynomial& other) {
        size = other.size;
        terms = (size > 0) ? new Term[size] : NULL;
        for (int i = 0; i < size; ++i)
            terms[i] = other.terms[i];
    }

    ~Polynomial() {
        delete[] terms;
    }

    Polynomial& operator=(const Polynomial& other) {
        if (this != &other) {
            delete[] terms;
            size = other.size;
            terms = (size > 0) ? new Term[size] : NULL;
            for (int i = 0; i < size; ++i)
                terms[i] = other.terms[i];
        }
        return *this;
    }

    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        for (int i = 0; i < size; ++i) {
            bool found = false;
            for (int j = 0; j < result.size; ++j) {
                if (result.terms[j].b == terms[i].b) {
                    result.terms[j].a += terms[i].a;
                    found = true;
                    break;
                }
            }
            if (!found) {
                ++result.size;
                Term* newArr = new Term[result.size];
                for (int k = 0; k < result.size - 1; ++k)
                    newArr[k] = result.terms[k];
                newArr[result.size - 1] = terms[i];
                delete[] result.terms;
                result.terms = newArr;
            }
        }
        for (int i = 0; i < other.size; ++i) {
            bool found = false;
            for (int j = 0; j < result.size; ++j) {
                if (result.terms[j].b == other.terms[i].b) {
                    result.terms[j].a += other.terms[i].a;
                    found = true;
                    break;
                }
            }
            if (!found) {
                ++result.size;
                Term* newArr = new Term[result.size];
                for (int k = 0; k < result.size - 1; ++k)
                    newArr[k] = result.terms[k];
                newArr[result.size - 1] = other.terms[i];
                delete[] result.terms;
                result.terms = newArr;
            }
        }
        return result;
    }

    friend istream& operator>>(istream& in, Polynomial& p) {
        delete[] p.terms;
        p.terms = NULL;
        p.size = 0;

        cout << "��J�Y�ƻP���� (��J 0 0 ����):\n";
        while (true) {
            Term t;
            cout << "��J�Y�ƩM�����: ";
            in >> t;
            if (t.a == 0 && t.b == 0) break;
            ++p.size;
            Term* newArr = new Term[p.size];
            for (int i = 0; i < p.size - 1; ++i)
                newArr[i] = p.terms[i];
            newArr[p.size - 1] = t;
            delete[] p.terms;
            p.terms = newArr;
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.size == 0) {
            out << "0";
            return out;
        }

        for (int i = 0; i < p.size; ++i) {
            const Term& t = p.terms[i];
            if (t.a == 0) continue;

            if (i > 0) {
                if (t.a > 0) out << " + ";
                else out << " - ";
            } else if (t.a < 0) {
                out << "-";
            }

            Term temp = t;
            if (temp.a < 0) temp.a = -temp.a;
            out << temp;
        }

        return out;
    }
};

#endif

