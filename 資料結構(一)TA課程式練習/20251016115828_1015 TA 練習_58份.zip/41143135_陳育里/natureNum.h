#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned int value;

public:
    NatureNumber(unsigned int v = 0) {
        value = v;
    }

    friend istream& operator>>(istream& in, NatureNumber& n) {
        int temp;
        in >> temp;
        if (temp < 0) {
            cout << "�۵M�Ƥ��i���t�A�H�אּ����" << endl;
            n.value = 0;
        } else {
            n.value = static_cast<unsigned int>(temp);
        }
        return in; 
    }

    friend ostream& operator<<(ostream& out, const NatureNumber& n) {
        out << n.value;
        return out;
    }

    NatureNumber operator+(const NatureNumber& rhs) const {
        return NatureNumber(this->value + rhs.value);
    }

    NatureNumber operator-(const NatureNumber& rhs) const {
        if (this->value < rhs.value)
            return NatureNumber(0);
        else
    		return NatureNumber(this->value - rhs.value);
    }

    bool operator==(const NatureNumber& rhs) const {
        return this->value == rhs.value;
    }
};


