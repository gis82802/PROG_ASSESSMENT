#include <iostream>
#include "nqtureNum.hpp"
using namespace std;

int main() {
    NatureNumber a, b;
    NatureNumber* c;

    // input two nature numbers and store them in two NatureNumber objects a,b
    cout << "input  A " << endl;
    cin >> a;
    cout << "input  B " << endl;
    cin >> b;
    cout << "a + b = " << a + b << endl;
    cout << "a - b = " << a - b << endl;

    if (a == b) {
        cout << "a==b" << endl;
    }
    else {
        cout << "a!=b" << endl;
    }

    return 0;
}
