#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

struct Term {
    double coef; // �Y��
    int exp;     // ����
    Term(double c = 0, int e = 0) : coef(c), exp(e) {}
};

#endif
