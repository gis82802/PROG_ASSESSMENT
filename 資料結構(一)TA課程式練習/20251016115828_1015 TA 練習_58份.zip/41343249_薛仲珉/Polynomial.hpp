#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms; // �x�s�h�������U��

public:
    Polynomial();

    // ��J��X�B��l
    friend istream& operator>>(istream& in, Polynomial& p);
    friend ostream& operator<<(ostream& out, const Polynomial& p);

    // �[�k
    Polynomial Add(const Polynomial& rhs) const;
};

#endif
