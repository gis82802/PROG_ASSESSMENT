#ifndef NATURENUM_HPP
#define NATURENUM_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    unsigned int value; // �u���\�۵M�� (>=0)
public:
    NatureNumber();                 // �w�]�غc�l
    NatureNumber(unsigned int v);   // ���w��Ȫ��غc�l
    NatureNumber(const NatureNumber& n); // �ƻs�غc�l

    // ��J��X�B��l
    friend istream& operator>>(istream& in, NatureNumber& n);
    friend ostream& operator<<(ostream& out, const NatureNumber& n);

    // �B��l�h��
    NatureNumber operator+(const NatureNumber& rhs) const;
    NatureNumber operator-(const NatureNumber& rhs) const;
    bool operator==(const NatureNumber& rhs) const;
    bool operator!=(const NatureNumber& rhs) const;
};

#endif
