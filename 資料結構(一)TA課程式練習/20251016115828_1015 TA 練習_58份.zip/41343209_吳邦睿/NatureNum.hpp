#ifndef NATURENUMBER_HPP
#define NATURENUMBER_HPP

#include <iostream>
using namespace std;

class NatureNumber {
private:
    int value;

public:
    NatureNumber(int v = 0) : value(v) {}

    friend istream& operator>>(istream& in, NatureNumber& n) {
        in >> n.value;
        return in;
    }

    friend ostream& operator<<(ostream& out, const NatureNumber& n) {
        out << n.value;
        return out;
    }

    NatureNumber operator+(const NatureNumber& rhs) const {
        return NatureNumber(value + rhs.value);
    }

    NatureNumber operator-(const NatureNumber& rhs) const {
        return NatureNumber(value - rhs.value);
    }

    bool operator==(const NatureNumber& rhs) const {
        return value == rhs.value;
    }

    bool operator!=(const NatureNumber& rhs) const {
        return value != rhs.value;
    }
};

#endif
