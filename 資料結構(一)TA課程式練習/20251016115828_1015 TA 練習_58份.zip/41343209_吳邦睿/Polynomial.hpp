#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

public:
    Polynomial() {}


    friend istream& operator>>(istream& in, Polynomial& p) {
        int n;
        cout << "�п�J����: ";
        in >> n;
        p.terms.clear();
        for (int i = 0; i < n; i++) {
            Term t;
            cout << "��J�� " << i + 1 << " �����Y�ƻP����: ";
            in >> t.coef >> t.exp;
            p.terms.push_back(t);
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& p) {
        if (p.terms.empty()) {
            out << "0";
            return out;
        }

        for (int i = 0; i < (int)p.terms.size(); i++) {
            out << p.terms[i].coef << "x^" << p.terms[i].exp;
            if (i != p.terms.size() - 1) out << " + ";
        }
        return out;
    }

    Polynomial Add(const Polynomial& other) const {
        Polynomial result;
        result.terms = terms;

        for (auto& t : other.terms) {
            bool found = false;
            for (auto& r : result.terms) {
                if (r.exp == t.exp) {
                    r.coef += t.coef;
                    found = true;
                    break;
                }
            }
            if (!found) {
                result.terms.push_back(t);
            }
        }

        return result;
    }
};

#endif
