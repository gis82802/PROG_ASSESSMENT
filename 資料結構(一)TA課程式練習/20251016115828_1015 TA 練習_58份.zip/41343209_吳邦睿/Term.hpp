#pragma once
#ifndef TERM_HPP
#define TERM_HPP

struct Term {
    int coef; 
    int exp;  
};

#endif
