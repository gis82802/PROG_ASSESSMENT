#ifndef NATURE_NUMBER_HPP
#define NATURE_NUMBER_HPP

#include <iostream>
#include <string>
#include <stdexcept>
#include <limits>
#include <cctype>

class NatureNumber {
public:
    using value_type = unsigned long long;

private:
    value_type value_;

public:
  
    NatureNumber() noexcept : value_(0) {}
    NatureNumber(int v) {
        if (v < 0) throw std::invalid_argument("NatureNumber must be non-negative");
        value_ = static_cast<value_type>(v);
    }
    NatureNumber(long long v) {
        if (v < 0) throw std::invalid_argument("NatureNumber must be non-negative");
        value_ = static_cast<value_type>(v);
    }
    explicit NatureNumber(value_type v) noexcept : value_(v) {}


    NatureNumber(const NatureNumber&) noexcept = default;
    NatureNumber(NatureNumber&&) noexcept = default;
    NatureNumber& operator=(const NatureNumber&) noexcept = default;
    NatureNumber& operator=(NatureNumber&&) noexcept = default;

    
    value_type value() const noexcept { return value_; }

 
    friend NatureNumber operator+(const NatureNumber& a, const NatureNumber& b) noexcept {
       
        return NatureNumber(a.value_ + b.value_);
    }
    friend NatureNumber operator-(const NatureNumber& a, const NatureNumber& b) {
        if (a.value_ < b.value_) throw std::underflow_error("Result would be negative (NatureNumber)");
        return NatureNumber(a.value_ - b.value_);
    }
    friend NatureNumber operator*(const NatureNumber& a, const NatureNumber& b) noexcept {
        return NatureNumber(a.value_ * b.value_);
    }
    friend NatureNumber operator/(const NatureNumber& a, const NatureNumber& b) {
        if (b.value_ == 0) throw std::domain_error("Division by zero");
        return NatureNumber(a.value_ / b.value_);
    }
    friend NatureNumber operator%(const NatureNumber& a, const NatureNumber& b) {
        if (b.value_ == 0) throw std::domain_error("Modulo by zero");
        return NatureNumber(a.value_ % b.value_);
    }

   
    NatureNumber& operator+=(const NatureNumber& other) noexcept { value_ += other.value_; return *this; }
    NatureNumber& operator-=(const NatureNumber& other) {
        if (value_ < other.value_) throw std::underflow_error("Result would be negative (NatureNumber)");
        value_ -= other.value_; return *this;
    }
    NatureNumber& operator*=(const NatureNumber& other) noexcept { value_ *= other.value_; return *this; }
    NatureNumber& operator/=(const NatureNumber& other) {
        if (other.value_ == 0) throw std::domain_error("Division by zero");
        value_ /= other.value_; return *this;
    }
    NatureNumber& operator%=(const NatureNumber& other) {
        if (other.value_ == 0) throw std::domain_error("Modulo by zero");
        value_ %= other.value_; return *this;
    }

    friend bool operator==(const NatureNumber& a, const NatureNumber& b) noexcept { return a.value_ == b.value_; }
    friend bool operator!=(const NatureNumber& a, const NatureNumber& b) noexcept { return a.value_ != b.value_; }
    friend bool operator<(const NatureNumber& a, const NatureNumber& b) noexcept { return a.value_ < b.value_; }
    friend bool operator<=(const NatureNumber& a, const NatureNumber& b) noexcept { return a.value_ <= b.value_; }
    friend bool operator>(const NatureNumber& a, const NatureNumber& b) noexcept { return a.value_ > b.value_; }
    friend bool operator>=(const NatureNumber& a, const NatureNumber& b) noexcept { return a.value_ >= b.value_; }

    
    friend std::ostream& operator<<(std::ostream& os, const NatureNumber& n) {
        os << n.value_;
        return os;
    }


    friend std::istream& operator>>(std::istream& is, NatureNumber& n) {
      
        std::string token;
        if (!(is >> token)) return is; 
        
        for (char c : token) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                
                is.setstate(std::ios::failbit);
                return is;
            }
        }
        
        try {
            
            unsigned long long v = 0;
          
            for (char c : token) {
                unsigned int d = static_cast<unsigned int>(c - '0');
                
                if (v > (std::numeric_limits<unsigned long long>::max() - d) / 10ULL) {
                    
                    is.setstate(std::ios::failbit);
                    return is;
                }
                v = v * 10ULL + d;
            }
            n.value_ = v;
        }
        catch (...) {
            is.setstate(std::ios::failbit);
            return is;
        }
        return is;
    }

    
    std::string to_string() const {
        return std::to_string(value_);
    }

    
    explicit operator unsigned long long() const noexcept { return value_; }
    explicit operator unsigned int() const noexcept { return static_cast<unsigned int>(value_); }

}; 

#endif 
