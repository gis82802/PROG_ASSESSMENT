#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <vector>
#include <algorithm>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms; 

   
    void simplify() {
        
        sort(terms.begin(), terms.end(), [](const Term& a, const Term& b) {
            return a.exp > b.exp;
            });
        
        vector<Term> result;
        for (const auto& t : terms) {
            if (!result.empty() && result.back().exp == t.exp) {
                result.back().coef += t.coef;
            }
            else {
                result.push_back(t);
            }
        }
       
        terms.clear();
        for (auto& t : result) {
            if (t.coef != 0) terms.push_back(t);
        }
    }

public:
    Polynomial() {}

  
    friend istream& operator>>(istream& is, Polynomial& p) {
        int n;
        cout << "Enter number of terms: ";
        is >> n;
        p.terms.clear();
        for (int i = 0; i < n; ++i) {
            Term t;
            cout << "Enter coef and exp for term " << i + 1 << ": ";
            is >> t;
            p.terms.push_back(t);
        }
        p.simplify();
        return is;
    }

    
    friend ostream& operator<<(ostream& os, const Polynomial& p) {
        if (p.terms.empty()) {
            os << 0;
            return os;
        }
        for (size_t i = 0; i < p.terms.size(); ++i) {
            if (i > 0 && p.terms[i].coef > 0) os << "+";
            os << p.terms[i];
        }
        return os;
    }

   
    Polynomial Add(const Polynomial& other) const {
        Polynomial result = *this;
        for (auto& t : other.terms) {
            result.terms.push_back(t);
        }
        result.simplify();
        return result;
    }
};

#endif
