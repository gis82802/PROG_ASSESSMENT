#ifndef TERM_HPP
#define TERM_HPP

#include <iostream>
using namespace std;

class Term {
public:
    int coef;   
    int exp; 

    Term(int c = 0, int e = 0) : coef(c), exp(e) {}

   
    friend istream& operator>>(istream& is, Term& t) {
        is >> t.coef >> t.exp;
        return is;
    }

    
    friend ostream& operator<<(ostream& os, const Term& t) {
        if (t.coef == 0) return os;
        if (t.exp == 0)
            os << t.coef;
        else if (t.exp == 1)
            os << t.coef << "x";
        else
            os << t.coef << "x^" << t.exp;
        return os;
    }
};

#endif
