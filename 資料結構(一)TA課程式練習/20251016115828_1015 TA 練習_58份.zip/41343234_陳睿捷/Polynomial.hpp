#ifndef POLYNOMIAL_HPP
#define POLYNOMIAL_HPP

#include <iostream>
#include <algorithm>
#include <vector>
#include "Term.hpp"
using namespace std;

class Polynomial {
private:
    vector<Term> terms;

public:
    Polynomial() {}

    friend istream& operator>>(istream& in, Polynomial& poly) {
        int n;
        in >> n;
        for (int i = 0; i < n; ++i) {
            Term term;
            in >> term;
            poly.terms.push_back(term);
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, const Polynomial& poly) {
        for (size_t i = 0; i < poly.terms.size(); ++i) {
            if (i != 0 && poly.terms[i].getCoefficient() > 0) {
                out << " + ";
            }
            out << poly.terms[i];
        }
        return out;
    }


    Polynomial Add(const Polynomial& other) const {
        Polynomial result;


        vector<Term> combined = this->terms;
        combined.insert(combined.end(), other.terms.begin(), other.terms.end());


        sort(combined.begin(), combined.end(), [](const Term& a, const Term& b) {
            return a.getExponent() > b.getExponent();
            });

        for (size_t i = 0; i < combined.size(); ++i) {
            if (i + 1 < combined.size() && combined[i].getExponent() == combined[i + 1].getExponent()) {
                combined[i + 1] = combined[i + 1] + combined[i];
            }
            else {
                result.terms.push_back(combined[i]);
            }
        }

        return result;
    }
};

#endif