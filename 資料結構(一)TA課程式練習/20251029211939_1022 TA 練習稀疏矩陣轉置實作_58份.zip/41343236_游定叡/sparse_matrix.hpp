#ifndef SPARSE_MATRIX_HPP
#define SPARSE_MATRIX_HPP

#include <iostream>
#include <iomanip> 
using namespace std;

class MatrixTerm {
private:
    int row, col, value;

public:
    // �w�]�غc�l
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}

    friend class SparseMatrix;

    friend SparseMatrix* createMatrixFromInput();
};


class SparseMatrix {
private:
    MatrixTerm* terms;
    int numRows, numCols, numTerms; 
    int maxTerms; 

public:
    

    // �غc�l
    SparseMatrix(int r, int c, int t);

    // �Ѻc�l
    ~SparseMatrix();

    //²����m
    SparseMatrix simpleTranspose() const;

    //�ֳt��m
    SparseMatrix fastTranspose() const;

    // �L�X�}���x�}
    void print() const; 

   
    friend SparseMatrix* createMatrixFromInput();
};

// ���U�禡���쫬�ŧi
SparseMatrix* createMatrixFromInput();

#endif 