#include <iostream>
#include "sparse_matrix.hpp" 

// �غc�l
SparseMatrix::SparseMatrix(int r, int c, int t)
    : numRows(r), numCols(c), numTerms(t) {

    maxTerms = numTerms + 1;
    terms = new MatrixTerm[maxTerms];
    terms[0] = MatrixTerm(r, c, t); // terms[0] �x�s����
}

// �Ѻc�l
SparseMatrix::~SparseMatrix() {
    delete[] terms;
}

// ��k�@�G²����m
SparseMatrix SparseMatrix::simpleTranspose() const {
    SparseMatrix b(numCols, numRows, numTerms);

    if (numTerms == 0) {
        return b;
    }

    int currentBIndex = 1;
    for (int c = 0; c < numCols; c++) {
        for (int i = 1; i <= numTerms; i++) {
            if (terms[i].col == c) {
                b.terms[currentBIndex].row = terms[i].col;
                b.terms[currentBIndex].col = terms[i].row;
                b.terms[currentBIndex].value = terms[i].value;
                currentBIndex++;
            }
        }
    }
    return b;
}

// ��k�G�G�ֳt��m
SparseMatrix SparseMatrix::fastTranspose() const {
    SparseMatrix b(numCols, numRows, numTerms);

    if (numTerms == 0) {
        return b;
    }

    int* rowTerms = new int[numCols];
    int* startingPos = new int[numCols];

    for (int i = 0; i < numCols; i++) {
        rowTerms[i] = 0;
    }
    for (int i = 1; i <= numTerms; i++) {
        rowTerms[terms[i].col]++;
    }
    startingPos[0] = 1;
    for (int i = 1; i < numCols; i++) {
        startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];
    }
    for (int i = 1; i <= numTerms; i++) {
        int j = terms[i].col;
        int pos = startingPos[j];
        b.terms[pos].row = terms[i].col;
        b.terms[pos].col = terms[i].row;
        b.terms[pos].value = terms[i].value;
        startingPos[j]++;
    }
    delete[] rowTerms;
    delete[] startingPos;

    return b;
}

// �L�X�x�}
void SparseMatrix::print() const {

    cout << "  (�x�}��T: " << terms[0].row << "x" << terms[0].col
        << ", �@ " << terms[0].value << " �ӫD�s��)" << endl;

    //�]�w���a�k
    cout << right; 

    //��Ƽ��Y
    cout << setw(8) << "Row" << setw(8) << "Col" << setw(8) << "Value" << endl;
    cout << "------------------------" << endl;

    //�L�X���
    for (int i = 1; i <= numTerms; i++) { // �j��q 1 �}�l (���L terms[0])
        cout << setw(8) << terms[i].row
            << setw(8) << terms[i].col
            << setw(8) << terms[i].value << endl;
    }
}

SparseMatrix* createMatrixFromInput() {
    int d, k;
    cout << "�п�J�x�}���C��d: ";
    cin >> d;
    cout << "�п�J�x�}�����k: ";
    cin >> k;

    if (d >= 15 || k >= 15) {
        cout << "���~" << endl;
        return nullptr;
    }

    int tempMatrix[15][15];
    int nonZeroCount = 0;

    cout << "�п�J " << d << "x" << k << " �x�}�����e (�H�ť�����j):" << endl;
    for (int i = 0; i < d; i++) {
        for (int j = 0; j < k; j++) {
            cin >> tempMatrix[i][j];
            if (tempMatrix[i][j] != 0) {
                nonZeroCount++;
            }
        }
    }

    SparseMatrix* matrix = new SparseMatrix(d, k, nonZeroCount);

    int currentTermIndex = 1;
    for (int i = 0; i < d; i++) {
        for (int j = 0; j < k; j++) {
            if (tempMatrix[i][j] != 0) {
                matrix->terms[currentTermIndex].row = i;
                matrix->terms[currentTermIndex].col = j;
                matrix->terms[currentTermIndex].value = tempMatrix[i][j];
                currentTermIndex++;
            }
        }
    }
    return matrix;
}

int main() {
    SparseMatrix* originalMatrix = createMatrixFromInput();

    if (originalMatrix == nullptr) {
        return 1;
    }

    cout << "\n��l�}���x�} (��²���ܪk) ---" << endl;
    originalMatrix->print();

    cout << "\n��k�@�GSimple Transpose (²����m) ---" << endl;
    SparseMatrix simpleTransposed = originalMatrix->simpleTranspose();
    simpleTransposed.print();

    cout << "\n��k�G�GFast Transpose (�ֳt��m) ---" << endl;
    SparseMatrix fastTransposed = originalMatrix->fastTranspose();
    fastTransposed.print();

    delete originalMatrix;

    return 0;
}