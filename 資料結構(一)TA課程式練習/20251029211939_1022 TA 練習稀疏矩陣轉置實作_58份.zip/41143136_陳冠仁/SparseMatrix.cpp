﻿#include "SparseMatrix.hpp"

void SparseMatrix::input() {
    cout << "請輸入矩陣的列數與行數: ";
    cin >> rows >> cols;
    cout << "請輸入矩陣的非零項數量: ";
    cin >> terms;

    for (int i = 0; i < terms; i++) {
        int r, c, v;
        cout << "請輸入第 " << i + 1 << " 個非零項 (列 行 值): ";
        cin >> r >> c >> v;
        elements[i].set(r, c, v);
    }
}

void SparseMatrix::print() const {
    cout << "列\t行\t值\n";
    for (int i = 0; i < terms; i++) {
        cout << elements[i].getRow() << "\t"
            << elements[i].getCol() << "\t"
            << elements[i].getValue() << "\n";
    }
}

SparseMatrix SparseMatrix::transpose() const {
    SparseMatrix b(cols, rows, terms);
    int bindex = 0;

    for (int col = 0; col < cols; col++) {
        for (int i = 0; i < terms; i++) {
            if (elements[i].getCol() == col) {
                b.elements[bindex++].set(
                    elements[i].getCol(),
                    elements[i].getRow(),
                    elements[i].getValue());
            }
        }
    }
    return b;
}

SparseMatrix SparseMatrix::fastTranspose() const {
    SparseMatrix b(cols, rows, terms);
    int* rowTerms = new int[cols]();
    int* startingPos = new int[cols]();

    for (int i = 0; i < terms; i++)
        rowTerms[elements[i].getCol()]++;

    startingPos[0] = 0;
    for (int i = 1; i < cols; i++)
        startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

    for (int i = 0; i < terms; i++) {
        int j = elements[i].getCol();
        int pos = startingPos[j]++;
        b.elements[pos].set(elements[i].getCol(), elements[i].getRow(), elements[i].getValue());
    }

    delete[] rowTerms;
    delete[] startingPos;
    return b;
}

// ✅ 將 main() 放在這裡
int main() {
    SparseMatrix sm;
    sm.input();

    cout << "\n原始稀疏矩陣:\n";
    sm.print();

    cout << "\n轉置後矩陣 (一般法):\n";
    SparseMatrix t1 = sm.transpose();
    t1.print();

    cout << "\n轉置後矩陣 (快速法):\n";
    SparseMatrix t2 = sm.fastTranspose();
    t2.print();

    return 0;
}
