#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
using namespace std;

class MatrixTerm {
private:
    int row, col;
    int value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0)
        : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void set(int r, int c, int v) {
        row = r;
        col = c;
        value = v;
    }

    void print() const {
        cout << "(" << row << ", " << col << ", " << value << ") ";
    }
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm elements[225]; // 15x15 �̤j 225

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t) {}

    void input();
    void print() const;
    SparseMatrix transpose() const;       // �@����m�k
    SparseMatrix fastTranspose() const;   // �ֳt��m�k
};

#endif
