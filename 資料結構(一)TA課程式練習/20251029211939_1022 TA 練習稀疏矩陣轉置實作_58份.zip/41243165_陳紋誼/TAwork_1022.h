#ifndef TAWORK_1022_H
#define TAWORK_1022_H

#include <iostream>
using namespace std;

class SparseMatrix;

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row, col, value;
};

class SparseMatrix {
private:
    int rows, cols;      // �C�ơB���
    int terms;           // �D�s���Ӽ�
    int capacity;        // smArray �e�q
    MatrixTerm* smArray; // �j�p�� capacity

    void reserve(int cap) {
        delete[] smArray;
        capacity = cap;
        smArray = (capacity > 0 ? new MatrixTerm[capacity] : nullptr);
    }

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t), capacity(0), smArray(nullptr) {
        reserve(t);
    }
    ~SparseMatrix() { delete[] smArray; }

    void readFromUser() {
        cout << "�п�J�x�}�j�p d k�]�� < 15�^�G";
        cin >> rows >> cols;
        cout << "�п�J�D�s���Ӽ� terms�G";
        cin >> terms;

        if (rows <= 0 || cols <= 0 || rows >= 15 || cols >= 15) {
            cout << "�ؤo���X�k�A���� 0<d,k<15\n";
            exit(0);
        }
        if (terms < 0 || terms > rows * cols) {
            cout << "terms �W�X�d��\n";
            exit(0);
        }

        reserve(terms);
        cout << "�Ш̧ǿ�J " << terms
            << " ���Grow col value�]���� 0-based�A��ĳ�� row �A col ���W�^\n";
        for (int i = 0; i < terms; ++i) {
            int r, c, v;  cin >> r >> c >> v;
            if (r < 0 || r >= rows || c < 0 || c >= cols) {
                cout << "���޶W�X�d��\n";
                exit(0);
            }
            smArray[i].row = r;
            smArray[i].col = c;
            smArray[i].value = v;
        }
    }

    void print(const char* title) const {
        cout << "== " << title << " ==\n";
        cout << "rows=" << rows << ", cols=" << cols << ", terms=" << terms << "\n";
        cout << "idx   row  col  value\n";
        for (int i = 0; i < terms; ++i) {
            cout << "[" << i << "]   "
                << smArray[i].row << "    "
                << smArray[i].col << "    "
                << smArray[i].value << "\n";
        }
    }

    // ������m
    SparseMatrix Transpose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int currentB = 0;
            for (int c = 0; c < cols; ++c) {
                for (int i = 0; i < terms; ++i) {
                    if (smArray[i].col == c) {
                        b.smArray[currentB].row = c;
                        b.smArray[currentB].col = smArray[i].row;
                        b.smArray[currentB].value = smArray[i].value;
                        ++currentB;
                    }
                }
            }
        }
        return b;
    }

    // �ֳt��m
    SparseMatrix FastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];

            for (int j = 0; j < cols; ++j) rowSize[j] = 0;

            for (int i = 0; i < terms; ++i)
                ++rowSize[smArray[i].col];

            rowStart[0] = 0;
            for (int j = 1; j < cols; ++j)
                rowStart[j] = rowStart[j - 1] + rowSize[j - 1];

            // �̧ǩ�J���T��m
            for (int i = 0; i < terms; ++i) {
                int j = smArray[i].col;
                int pos = rowStart[j]++;       // �� j ���U�@�ӥi�Φ�m
                b.smArray[pos].row = j;
                b.smArray[pos].col = smArray[i].row;
                b.smArray[pos].value = smArray[i].value;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};

#endif
