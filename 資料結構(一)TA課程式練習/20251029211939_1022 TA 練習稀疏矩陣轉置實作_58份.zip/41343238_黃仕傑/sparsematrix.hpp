#ifndef SPARSEMTRX_HPP
#define SPARSEMTRX_HPP

const int MAX_TERMS = 200;

class SparseMatrix;

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row;
    int col;
    int value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[MAX_TERMS];

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0);

    void Read();
    void Print();
    SparseMatrix Transpose();
    SparseMatrix FastTranspose();
};

#endif // SPARSEMTRX_HPP
