#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
#include <iomanip>
#include <algorithm>
using namespace std;

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row, col, value;
};

class SparseMatrix {
private:
    int rows, cols, terms, capacity;
    MatrixTerm* smArray;

public:
    // �غc�l
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t), capacity(t) {
        smArray = (t > 0) ? new MatrixTerm[t] : nullptr;
    }

    // �Ѻc�l
    ~SparseMatrix() {
        delete[] smArray;
    }

    // ��J�}���x�}
    void input() {
        cout << "�п�J�x�}���� (rows cols): ";
        cin >> rows >> cols;
        cout << "�п�J�D�s�����Ӽ�: ";
        cin >> terms;
        capacity = terms;
        smArray = new MatrixTerm[terms];
        cout << "�̧ǿ�J�C�ӫD�s�� (row col value):" << endl;
        for (int i = 0; i < terms; i++) {
            cin >> smArray[i].row >> smArray[i].col >> smArray[i].value;
        }
    }

    // �L�X
    void print(const string& title = "") const {
        if (!title.empty())
            cout << "\n" << title << ":\n";
        cout << "row\tcol\tvalue\n";
        for (int i = 0; i < terms; i++) {
            cout << smArray[i].row << "\t" << smArray[i].col << "\t" << smArray[i].value << endl;
        }
    }

    // �@����m
    SparseMatrix Transpose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int currentB = 0;
            for (int c = 0; c < cols; c++) {
                for (int i = 0; i < terms; i++) {
                    if (smArray[i].col == c) {
                        b.smArray[currentB].row = smArray[i].col;
                        b.smArray[currentB].col = smArray[i].row;
                        b.smArray[currentB].value = smArray[i].value;
                        currentB++;
                    }
                }
            }
        }
        return b;
    }

    // �ֳt��m
    SparseMatrix FastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];
            fill(rowSize, rowSize + cols, 0);

            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].col]++;

            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].col]++;
                b.smArray[j].row = smArray[i].col;
                b.smArray[j].col = smArray[i].row;
                b.smArray[j].value = smArray[i].value;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};

#endif
