#ifndef SPARSEMATRIX_H
#define SPARSEMATRIX_H

#include <iostream>
using namespace std;

class MatrixTerm {
private:
    int row;
    int col;
    int value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0)
        : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void set(int r, int c, int v) {
        row = r;
        col = c;
        value = v;
    }

    void print() const {
        cout << "(" << row << ", " << col << ", " << value << ")";
    }
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm data[225];  

public:
    SparseMatrix(int r = 0, int c = 0) : rows(r), cols(c), terms(0) {}

    void inputFullMatrix();
    void display() const;
    SparseMatrix simpleTranspose() const;
    SparseMatrix fastTranspose() const;
};

#endif
