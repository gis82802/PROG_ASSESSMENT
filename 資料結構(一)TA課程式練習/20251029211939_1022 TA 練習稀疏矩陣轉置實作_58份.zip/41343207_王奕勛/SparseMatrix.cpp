#include "SparseMatrix.hpp"

void SparseMatrix::inputFullMatrix() {
    cout << "��J�x�}�j�p (�C ��): ";
    cin >> rows >> cols;

    cout << "�Ш̧ǿ�J�x�}���e (�@ " << rows * cols << " �Ӥ���):\n";
    terms = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int v;
            cin >> v;
            if (v != 0) {
                data[terms++].set(i, j, v);
            }
        }
    }
}

void SparseMatrix::display() const {
    cout << "�x�}�j�p: " << rows << "x" << cols << ", �D�s��: " << terms << endl;
    cout << "(row, col, value)\n";
    for (int i = 0; i < terms; i++) {
        data[i].print();
        cout << endl;
    }
}

SparseMatrix SparseMatrix::simpleTranspose() const {
    SparseMatrix trans(cols, rows);
    trans.terms = terms;
    int q = 0;
    for (int c = 0; c < cols; c++) {
        for (int i = 0; i < terms; i++) {
            if (data[i].getCol() == c) {
                trans.data[q++].set(data[i].getCol(), data[i].getRow(), data[i].getValue());
            }
        }
    }
    return trans;
}

SparseMatrix SparseMatrix::fastTranspose() const {
    SparseMatrix trans(cols, rows);
    trans.terms = terms;
    if (terms > 0) {
        int* rowSize = new int[cols] {0};
        int* rowStart = new int[cols] {0};

        for (int i = 0; i < terms; i++)
            rowSize[data[i].getCol()]++;

        rowStart[0] = 0;
        for (int i = 1; i < cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for (int i = 0; i < terms; i++) {
            int j = data[i].getCol();
            int k = rowStart[j]++;
            trans.data[k].set(data[i].getCol(), data[i].getRow(), data[i].getValue());
        }

        delete[] rowSize;
        delete[] rowStart;
    }
    return trans;
}
