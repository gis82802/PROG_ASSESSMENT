#include <iostream>
using namespace std;

#define MAX_TERMS 225  // �̤j 15x15

class MatrixTerm {
private:
    int row, col, value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0)
        : row(r), col(c), value(v) {}

    void set(int r, int c, int v) {
        row = r; col = c; value = v;
    }

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[MAX_TERMS];

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t) {}

    // �q����x�}��J
    void readFullMatrix() {
        cout << "��J�x�}���C�ƻP��� (�Ҧp 5 5)�G";
        cin >> rows >> cols;
        terms = 0;

        cout << "�п�J�x�}���e"<< "�G\n";
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int val;
                cin >> val;
                if (val != 0) {
                    smArray[terms++].set(i, j, val);
                }
            }
        }
    }

    void printMatrix() const {
        cout << "row col value\n";
        for (int i = 0; i < terms; i++) {
            cout << smArray[i].getRow() << " "
                << smArray[i].getCol() << " "
                << smArray[i].getValue() << "\n";
        }
        cout << endl;
    }

    // ---------- �@����m ----------
    SparseMatrix transpose() const {
        SparseMatrix b(cols, rows, terms);
        int currentb = 0;

        for (int col = 0; col < cols; col++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].getCol() == col) {
                    b.smArray[currentb++].set(
                        smArray[i].getCol(),
                        smArray[i].getRow(),
                        smArray[i].getValue()
                    );
                }
            }
        }
        return b;
    }

    // ---------- �ֳt��m ----------
    SparseMatrix fastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];

            for (int i = 0; i < cols; i++)
                rowSize[i] = 0;

            // �p��C�@�榳�h�֫D�s����
            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].getCol()]++;

            // �p��C�@��b��m�x�}���_�l��m
            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            // ��J��m�᪺���T��m
            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].getCol()]++;
                b.smArray[j].set(
                    smArray[i].getCol(),
                    smArray[i].getRow(),
                    smArray[i].getValue()
                );
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};