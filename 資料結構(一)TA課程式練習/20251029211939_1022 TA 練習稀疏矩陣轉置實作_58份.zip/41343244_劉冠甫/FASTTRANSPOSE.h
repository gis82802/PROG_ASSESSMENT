#ifndef FASTTRANSPOSE_H
#define FASTTRANSPOSE_H

#include "Transpose.h"
#include <vector>
using namespace std;

inline SparseMatrix FastTranspose(const SparseMatrix& src) {
    SparseMatrix b(src.cols, src.rows);
    if (src.terms == 0) return b;

    b.smArray.resize(src.terms);
    vector<int> colCounts(src.cols, 0);
    for (int i = 0; i < src.terms; ++i)
        ++colCounts[src.smArray[i].col];

    vector<int> startPos(src.cols, 0);
    startPos[0] = 0;
    for (int c = 1; c < src.cols; ++c)
        startPos[c] = startPos[c - 1] + colCounts[c - 1];

    for (int i = 0; i < src.terms; ++i) {
        int c = src.smArray[i].col;
        int pos = startPos[c]++;
        b.smArray[pos].row = src.smArray[i].col;
        b.smArray[pos].col = src.smArray[i].row;
        b.smArray[pos].value = src.smArray[i].value;
    }

    b.terms = src.terms;
    return b;
}

#endif