#ifndef TRANSPOSE_H
#define TRANSPOSE_H

#include <iostream>
#include <vector>
using namespace std;

struct MatrixTerm {
    int row;
    int col;
    int value;
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}
};

class SparseMatrix {
public:
    int rows;
    int cols;
    int terms;
    vector<MatrixTerm> smArray;

    SparseMatrix(int r = 0, int c = 0) : rows(r), cols(c), terms(0) {}

    void addTerm(int r, int c, int v) {
        if (v == 0) return;
        smArray.emplace_back(r, c, v);
        terms = (int)smArray.size();
    }

    SparseMatrix Transpose() const {
        SparseMatrix b(cols, rows);
        if (terms == 0) return b;
        for (int c = 0; c < cols; ++c)
            for (int i = 0; i < terms; ++i)
                if (smArray[i].col == c)
                    b.smArray.emplace_back(smArray[i].col, smArray[i].row, smArray[i].value);
        b.terms = (int)b.smArray.size();
        return b;
    }

    void printSparse(const string& title = "") const {
        if (!title.empty()) cout << title << "\n";
        cout << "rows=" << rows << ", cols=" << cols << ", terms=" << terms << "\n";
        cout << "Index\trow\tcol\tvalue\n";
        for (int i = 0; i < terms; ++i)
            cout << i << "\t" << smArray[i].row << "\t" << smArray[i].col << "\t" << smArray[i].value << "\n";
        cout << "\n";
    }
};

#endif