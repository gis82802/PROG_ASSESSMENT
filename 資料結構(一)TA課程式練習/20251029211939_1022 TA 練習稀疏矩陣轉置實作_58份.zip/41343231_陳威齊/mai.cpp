#include <iostream>

using namespace std;

const int MAX_TERMS = 200;

class SparseMatrix;

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row;
    int col;
    int value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[MAX_TERMS];

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0) : rows(r), cols(c), terms(t) {}

    void Read() {
        cout << "�п�J " << terms << " �ӫD�s���� (row col value):" << endl;
        for (int i = 0; i < terms; i++) {
            cin >> smArray[i].row >> smArray[i].col >> smArray[i].value;
        }
    }

    void Print() {
        cout << "rows = " << rows << ", cols = " << cols << ", terms = " << terms << endl;
        for (int i = 0; i < terms; i++) {
            cout << "smArray[" << i << "]: "
                << smArray[i].row << " "
                << smArray[i].col << " "
                << smArray[i].value << endl;
        }
    }

    SparseMatrix Transpose() {
        SparseMatrix b(cols, rows, terms);

        if (terms > 0) {
            int currentB = 0;
            for (int c = 0; c < cols; c++) {
                for (int i = 0; i < terms; i++) {
                    if (smArray[i].col == c) {
                        b.smArray[currentB].row = smArray[i].col;
                        b.smArray[currentB].col = smArray[i].row;
                        b.smArray[currentB].value = smArray[i].value;
                        currentB++;
                    }
                }
            }
        }
        return b;
    }

    SparseMatrix FastTranspose() {
        SparseMatrix b(cols, rows, terms);

        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];

            for (int i = 0; i < cols; i++) {
                rowSize[i] = 0;
            }

            for (int i = 0; i < terms; i++) {
                rowSize[smArray[i].col]++;
            }

            rowStart[0] = 0;
            for (int i = 1; i < cols; i++) {
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];
            }

            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].col];
                b.smArray[j].row = smArray[i].col;
                b.smArray[j].col = smArray[i].row;
                b.smArray[j].value = smArray[i].value;
                rowStart[smArray[i].col]++;
            }

            delete[] rowSize;
            delete[] rowStart;
        }

        return b;
    }
};

int main() {
    int d, k, t;
    cout << "�п�J�x�}�� (d)rows, (k)cols, (t)terms (d, k < 15):" << endl;
    cin >> d >> k >> t;

    if (d >= 15 || k >= 15) {
        cout << "d �M k �����p�� 15" << endl;
        return 1;
    }
    if (t > d * k || t > MAX_TERMS) {
        cout << "terms �ƶq���X�k" << endl;
        return 1;
    }

    SparseMatrix a(d, k, t);
    a.Read();

    cout << "\n--- ��l�}���x�} (a) ---" << endl;
    a.Print();

    cout << "\n--- �@����m (Transpose) ���G (b) ---" << endl;
    SparseMatrix b = a.Transpose();
    b.Print();

    cout << "\n--- �ֳt��m (FastTranspose) ���G (c) ---" << endl;
    SparseMatrix c = a.FastTranspose();
    c.Print();
    system("pause");
    return 0;
}