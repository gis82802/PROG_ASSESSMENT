#include <iostream>
#include <vector>
using namespace std;


class MatrixTerm {
private:
    int row;
    int col;
    int value;
public:
    MatrixTerm() : row(0), col(0), value(0) {}
    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void setRow(int r) { row = r; }
    void setCol(int c) { col = c; }
    void setValue(int v) { value = v; }
};


void printSparseMatrix(const vector<MatrixTerm>& terms) {
    cout << "row\tcol\tvalue\n";
    for (const auto& t : terms) {
        cout << t.getRow() << "\t" << t.getCol() << "\t" << t.getValue() << "\n";
    }
}


vector<MatrixTerm> simpleTranspose(const vector<MatrixTerm>& terms) {
    vector<MatrixTerm> transposed;
    for (const auto& t : terms) {
        transposed.push_back(MatrixTerm(t.getCol(), t.getRow(), t.getValue()));
    }
    return transposed;
}


vector<MatrixTerm> fastTranspose(const vector<MatrixTerm>& terms, int d, int k) {
    vector<MatrixTerm> transposed(terms.size());
    if (terms.size() == 0) return transposed;

    int numTerms = terms.size();
    int* rowSize = new int[k]();  
    int* rowStart = new int[k](); 

    
    for (int i = 0; i < numTerms; i++) {
        rowSize[terms[i].getCol()]++;
    }

    
    rowStart[0] = 0;
    for (int i = 1; i < k; i++) {
        rowStart[i] = rowStart[i - 1] + rowSize[i - 1];
    }

    
    for (int i = 0; i < numTerms; i++) {
        int col = terms[i].getCol();
        int pos = rowStart[col]++;
        transposed[pos] = MatrixTerm(col, terms[i].getRow(), terms[i].getValue());
    }

    delete[] rowSize;
    delete[] rowStart;
    return transposed;
}

int main() {
    int d, k;
    cout << "��J�x�}�j�p d x k (d,k < 15): ";
    cin >> d >> k;

    vector<MatrixTerm> sparseMatrix;
    cout << "��J�x�}�G\n";
    for (int i = 0; i < d; i++) {
        for (int j = 0; j < k; j++) {
            int val;
            cin >> val;
            if (val != 0) {
                sparseMatrix.push_back(MatrixTerm(i, j, val));
            }
        }
    }

    cout << "\n��l�x�}:\n";
    printSparseMatrix(sparseMatrix);

    
    vector<MatrixTerm> simpleT = simpleTranspose(sparseMatrix);
    cout << "\n�@����m:\n";
    printSparseMatrix(simpleT);

    
    vector<MatrixTerm> fastT = fastTranspose(sparseMatrix, d, k);
    cout << "\n�ֳt��m:\n";
    printSparseMatrix(fastT);

    return 0;
}
