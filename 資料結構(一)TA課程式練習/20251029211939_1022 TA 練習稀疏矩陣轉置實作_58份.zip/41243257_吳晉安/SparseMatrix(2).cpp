#include <iostream>
#include "SparseMatrix.hpp"
using namespace std;

// �C�L�}���x�}
void printSparse(MatrixTerm a[], int terms, int rows, int cols) {
    cout << "row\tcol\tvalue\n";
    cout << "-----------------\n";
   
    for (int i = 0; i < terms; i++)
        cout << a[i].getRow() << "\t" << a[i].getCol() << "\t" << a[i].getValue() << "\n";
    cout << endl;
}

//�@����m�k
void simpleTranspose(MatrixTerm a[], MatrixTerm b[], int rows, int cols, int terms) {
    int currentb = 0;
    for (int c = 0; c < cols; c++) {
        for (int i = 0; i < terms; i++) {
            if (a[i].getCol() == c)
                b[currentb++].setTerm(a[i].getCol(), a[i].getRow(), a[i].getValue());
        }
    }
}

// �ֳt��m�k
void fastTranspose(MatrixTerm a[], MatrixTerm b[], int rows, int cols, int terms) {
    int *rowSize = new int[cols];
    int *rowStart = new int[cols];

    for (int i = 0; i < cols; i++) rowSize[i] = 0;

    // �p��C��D�s�����ƶq
    for (int i = 0; i < terms; i++)
        rowSize[a[i].getCol()]++;

    // �p��_�l��m
    rowStart[0] = 0;
    for (int i = 1; i < cols; i++)
        rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

    // ��J���T��m
    for (int i = 0; i < terms; i++) {
        int j = rowStart[a[i].getCol()]++;
        b[j].setTerm(a[i].getCol(), a[i].getRow(), a[i].getValue());
    }

    delete[] rowSize;
    delete[] rowStart;
}

// �D�{��
int main() {
    int d, k;
    cout << "��J�x�}���C�� d �P��� k (<15): ";
    cin >> d >> k;

    int mat[15][15];
    cout << "�п�J�x�}���e�]�� 0 �N���ŭȡ^:\n";
    for (int i = 0; i < d; i++)
        for (int j = 0; j < k; j++)
            cin >> mat[i][j];

    // �ন�T����
    MatrixTerm a[100];
    int terms = 0;
    for (int i = 0; i < d; i++)
        for (int j = 0; j < k; j++)
            if (mat[i][j] != 0)
                a[terms++].setTerm(i, j, mat[i][j]);

    cout << "\n��}���x�}�]�T���ժ��ܡ^:\n";
    printSparse(a, terms, d, k);

    MatrixTerm b1[100], b2[100];

    simpleTranspose(a, b1, d, k, terms);
    cout << "�@����m���G:\n";
    printSparse(b1, terms, k, d);

    fastTranspose(a, b2, d, k, terms);
    cout << "�ֳt��m���G:\n";
    printSparse(b2, terms, k, d);

    return 0;
}

