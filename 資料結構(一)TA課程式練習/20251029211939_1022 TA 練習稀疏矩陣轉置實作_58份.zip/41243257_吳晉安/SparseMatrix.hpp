#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
using namespace std;

// �T���յ��c�w�q
struct MatrixTerm {
private:
    int row, col, value;
public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}
    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }
    void setTerm(int r, int c, int v) { row = r; col = c; value = v; }
};

// �禡�ŧi
void printSparse(MatrixTerm a[], int terms, int rows, int cols);
void simpleTranspose(MatrixTerm a[], MatrixTerm b[], int rows, int cols, int terms);
void fastTranspose(MatrixTerm a[], MatrixTerm b[], int rows, int cols, int terms);

#endif

