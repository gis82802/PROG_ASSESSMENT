
#ifndef SPARSE_MATRIX_HPP
#define SPARSE_MATRIX_HPP

#include <iostream>
using namespace std;

struct MatrixTerm {
    int row;
    int col;
    int value;
};

class SparseMatrix {
private:
    MatrixTerm terms[225];
    int rows, cols, termsCount;

public:
    SparseMatrix(int r = 0, int c = 0) : rows(r), cols(c), termsCount(0) {}

    void input();
    void print() const;
    SparseMatrix transpose() const;
    SparseMatrix fastTranspose() const;
};


void SparseMatrix::input() {
    cout << "�п�J�x�}�j�p (d k)�G";
    cin >> rows >> cols;

    cout << "�п�J�D�s���ƶq�G";
    cin >> termsCount;

    cout << "�Ш̧ǿ�J�C�@���� [�C �� ��]�]���ޱq0�}�l�^\n";
    for (int i = 0; i < termsCount; i++) {
        cin >> terms[i].row >> terms[i].col >> terms[i].value;
    }
}


void SparseMatrix::print() const {
    cout << "�C\t��\t��\n";
    for (int i = 0; i < termsCount; i++) {
        cout << terms[i].row << "\t" << terms[i].col << "\t" << terms[i].value << "\n";
    }
}

SparseMatrix SparseMatrix::transpose() const {
    SparseMatrix result(cols, rows);
    result.termsCount = termsCount;

    int idx = 0;
    for (int c = 0; c < cols; c++) {
        for (int i = 0; i < termsCount; i++) {
            if (terms[i].col == c) {
                result.terms[idx].row = terms[i].col;
                result.terms[idx].col = terms[i].row;
                result.terms[idx].value = terms[i].value;
                idx++;
            }
        }
    }
    return result;
}


SparseMatrix SparseMatrix::fastTranspose() const {
    SparseMatrix result(cols, rows);
    result.termsCount = termsCount;

    int* rowSize = new int[cols] {0};
    int* rowStart = new int[cols] {0};

   
    for (int i = 0; i < termsCount; i++)
        rowSize[terms[i].col]++;

   
    rowStart[0] = 0;
    for (int i = 1; i < cols; i++)
        rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

    
    for (int i = 0; i < termsCount; i++) {
        int j = rowStart[terms[i].col]++;
        result.terms[j].row = terms[i].col;
        result.terms[j].col = terms[i].row;
        result.terms[j].value = terms[i].value;
    }

    delete[] rowSize;
    delete[] rowStart;
    return result;
}

#endif
