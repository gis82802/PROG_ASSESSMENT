#include <iostream>
using namespace std;

class MatrixTerm {
private:
    int row;
    int col;
    int value;
public:
    MatrixTerm() : row(0), col(0), value(0) {}
    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void set(int r, int c, int v) {
        row = r;
        col = c;
        value = v;
    }

    void print() const {
        cout << "(" << row << ", " << col << ", " << value << ")\n";
    }
};

void simpleTranspose(MatrixTerm a[], MatrixTerm b[], int rows, int cols, int terms) {
    b[0].set(cols, rows, terms);
    if (terms > 0) {
        int currentb = 1;
        for (int col = 0; col < cols; col++) {
            for (int i = 1; i <= terms; i++) {
                if (a[i].getCol() == col) {
                    b[currentb].set(a[i].getCol(), a[i].getRow(), a[i].getValue());
                    currentb++;
                }
            }
        }
    }
}

void fastTranspose(MatrixTerm a[], MatrixTerm b[], int rows, int cols, int terms) {
    b[0].set(cols, rows, terms);
    if (terms > 0) {
        int* rowSize = new int[cols]();
        int* rowStart = new int[cols];

        for (int i = 1; i <= terms; i++)
            rowSize[a[i].getCol()]++;

        rowStart[0] = 1;
        for (int i = 1; i < cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for (int i = 1; i <= terms; i++) {
            int j = rowStart[a[i].getCol()]++;
            b[j].set(a[i].getCol(), a[i].getRow(), a[i].getValue());
        }

        delete[] rowSize;
        delete[] rowStart;
    }
}

void printSparse(MatrixTerm a[]) {
    int terms = a[0].getValue();
    cout << "(rows=" << a[0].getRow() << ", cols=" << a[0].getCol()
        << ", terms=" << terms << ")\n";
    for (int i = 1; i <= terms; i++) {
        a[i].print();
    }
    cout << endl;
}
