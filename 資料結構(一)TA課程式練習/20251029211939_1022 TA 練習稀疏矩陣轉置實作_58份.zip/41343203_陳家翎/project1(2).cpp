#include <iostream>
#include <vector>
using namespace std;

class Term {
private:
    int r;
    int c;
    int v;
public:
    Term() : r(0), c(0), v(0) {}
    Term(int r, int c, int v) : r(r), c(c), v(v) {}

    int getR() const { return r; }
    int getC() const { return c; }
    int getV() const { return v; }
    void setR(int r) { r = r; }
    void setC(int c) { c = c; }
    void setV(int v) { v = v; }
};


void print(const vector<Term>& terms) {
    cout << "row\tcol\tvalue\n";
    for (const auto& t : terms) {
        cout << t.getR() << "\t" << t.getC() << "\t" << t.getV() << "\n";
    }
}


vector<Term> ST(const vector<Term>& terms) {
    vector<Term> STM;
    for (const auto& t : terms) {
        STM.push_back(Term(t.getC(), t.getR(), t.getV()));
    }
    return STM;
}


vector<Term> FT(const vector<Term>& terms, int d, int k) {
    vector<Term> FTM(terms.size());
    if (terms.size() == 0) 
        return FTM;

    int numTerms = terms.size();
    int* rowSize = new int[k]();  
    int* rowStart = new int[k](); 

    for (int i = 0; i < numTerms; i++) {
        rowSize[terms[i].getC()]++;
    }

    rowStart[0] = 0;
    for (int i = 1; i < k; i++) {
        rowStart[i] = rowStart[i - 1] + rowSize[i - 1];
    }

    for (int i = 0; i < numTerms; i++) {
        int col = terms[i].getC();
        int pos = rowStart[col]++;
        FTM[pos] = Term(col, terms[i].getR(), terms[i].getV());
    }

    delete[] rowSize;
    delete[] rowStart;
    return FTM;
}

int main() {
    int d, k;
    cout << "�x�}�j�p: ";
    cin >> d >> k;

    vector<Term> Matrix;
    cout << "�x�}�����G\n";
    for (int i = 0; i < d; i++) {
        for (int j = 0; j < k; j++) {
            int val;
            cin >> val;
            if (val != 0) {
                Matrix.push_back(Term(i, j, val));
            }
        }
    }

    cout << "\n��m�e:\n";
    print(Matrix);


    vector<Term> STM = ST(Matrix);
    cout << "\n�@����m:\n";
    print(STM);

    vector<Term> FTM = FT(Matrix, d, k);
    cout << "\n�ֳt��m:\n";
    print(FTM);

    return 0;
}
