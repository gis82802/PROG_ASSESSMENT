#include <iostream>
#include <vector>
#include <algorithm>
class MatrixTerm {
public:
    int row, col, value;

    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}


    void print() const {
        std::cout << "(" << row << ", " << col << ", " << value << ")" << std::endl;
    }
};


class SparseMatrix {
private:
    int d, k;
    std::vector<MatrixTerm> terms;

public:
    SparseMatrix(int rows, int cols) : d(rows), k(cols) {}


    void addTerm(int row, int col, int value) {
        if (value != 0) {
            terms.push_back(MatrixTerm(row, col, value));
        }
    }

    void printMatrix() const {
        std::cout << "�x�}���e (��, �C, ��)�G" << std::endl;
        for (const auto& term : terms) {
            term.print();
        }
    }


    SparseMatrix transposeCSR() const {
        SparseMatrix transposed(k, d);
        for (const auto& term : terms) {
            transposed.addTerm(term.col, term.row, term.value);
        }
        return transposed;
    }


    SparseMatrix transposeCSC() const {
        SparseMatrix transposed(k, d);
        for (const auto& term : terms) {
            transposed.addTerm(term.col, term.row, term.value);
        }
        return transposed;
    }
};