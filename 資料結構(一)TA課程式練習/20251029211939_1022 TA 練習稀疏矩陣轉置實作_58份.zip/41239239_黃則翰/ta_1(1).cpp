#include "SparseMatrix.h"

void inputMatrix(SparseMatrix &m) {
    cout << "Enter rows and cols: ";
    cin >> m.rows >> m.cols;
    m.terms = 0;
    cout << "Enter matrix (" << m.rows << "x" << m.cols << "):\n";

    for (int i = 0; i < m.rows; i++) {
        for (int j = 0; j < m.cols; j++) {
            int val;
            cin >> val;
            if (val != 0) {
                m.data[m.terms].row = i;
                m.data[m.terms].col = j;
                m.data[m.terms].value = val;
                m.terms++;
            }
        }
    }
}

void printMatrix(const SparseMatrix &m) {
    cout << "Row\tCol\tValue\n";
    for (int i = 0; i < m.terms; i++) {
        cout << m.data[i].row << "\t"
             << m.data[i].col << "\t"
             << m.data[i].value << endl;
    }
}

// 一般轉置
SparseMatrix transpose(const SparseMatrix &a) {
    SparseMatrix b;
    b.rows = a.cols;
    b.cols = a.rows;
    b.terms = a.terms;
    int index = 0;

    for (int c = 0; c < a.cols; c++) {
        for (int i = 0; i < a.terms; i++) {
            if (a.data[i].col == c) {
                b.data[index].row = a.data[i].col;
                b.data[index].col = a.data[i].row;
                b.data[index].value = a.data[i].value;
                index++;
            }
        }
    }
    return b;
}

// 快速轉置
SparseMatrix fastTranspose(const SparseMatrix &a) {
    SparseMatrix b;
    b.rows = a.cols;
    b.cols = a.rows;
    b.terms = a.terms;

    int rowTerms[MAX_TERMS] = {0};
    int startingPos[MAX_TERMS] = {0};

    for (int i = 0; i < a.terms; i++)
        rowTerms[a.data[i].col]++;

    startingPos[0] = 0;
    for (int i = 1; i < a.cols; i++)
        startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

    for (int i = 0; i < a.terms; i++) {
        int col = a.data[i].col;
        int pos = startingPos[col]++;
        b.data[pos].row = a.data[i].col;
        b.data[pos].col = a.data[i].row;
        b.data[pos].value = a.data[i].value;
    }

    return b;
}

int main() {
    SparseMatrix A;
    inputMatrix(A);

    cout << "\nOriginal Sparse Matrix:\n";
    printMatrix(A);

    SparseMatrix B = transpose(A);
    cout << "\nNormal Transpose:\n";
    printMatrix(B);

    SparseMatrix C = fastTranspose(A);
    cout << "\nFast Transpose:\n";
    printMatrix(C);

    return 0;
}
