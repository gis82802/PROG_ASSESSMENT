#ifndef MATRIXTERM_H
#define MATRIXTERM_H

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row;
    int col;
    int value;
};

#endif
