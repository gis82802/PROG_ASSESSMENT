#ifndef SPARSEMATRIX_H
#define SPARSEMATRIX_H

#include <iostream>
using namespace std;

#define MAX_TERMS 100

// 結構表示稀疏矩陣中的一個非零元素
struct MatrixTerm {
    int row;
    int col;
    int value;
};

// 稀疏矩陣結構
struct SparseMatrix {
    int rows;      // 矩陣的列數
    int cols;      // 矩陣的行數
    int terms;     // 非零元素數量
    MatrixTerm data[MAX_TERMS];
};

// 輸入矩陣
void inputMatrix(SparseMatrix &m);

// 以課本三元組(triplet)方式輸出
void printMatrix(const SparseMatrix &m);

// 一般轉置
SparseMatrix transpose(const SparseMatrix &a);

// 快速轉置
SparseMatrix fastTranspose(const SparseMatrix &a);

#endif
