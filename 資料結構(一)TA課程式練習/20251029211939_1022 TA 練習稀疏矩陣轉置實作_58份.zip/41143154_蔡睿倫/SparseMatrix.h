#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <iomanip>

struct MatrixItem {
    int32_t row;
    int32_t col;
    int32_t value;

    MatrixItem(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void setRow(int r) { row = r; }
    void setCol(int c) { col = c; }
    void setValue(int v) { value = v; }

    void print() const {
        std::cout << "(" << std::setw(2) << row
                  << ", " << std::setw(2) << col
                  << ", " << std::setw(2) << value << ")" << std::endl;
    }
};

class SparseMatrix {
private:
    std::unique_ptr<MatrixItem[]> items;
    int32_t args_rows, args_cols, args_item;
    std::vector<std::vector<int32_t>> args_matrix;
    
public:
    SparseMatrix(int32_t rows, int32_t cols, const std::vector<std::vector<int32_t>>& matrix)
        : args_rows(rows), args_cols(cols), args_matrix(matrix), args_item(0),
          items(std::make_unique<MatrixItem[]>(rows * cols))
    {}

    void read_matrix() {
        for (int32_t row = 0; row < args_rows; ++row) {
            for (int32_t col = 0; col < args_cols; ++col) {
                int32_t int_matrix = args_matrix[row][col];
                if (int_matrix != 0) {
                    MatrixItem item{};
                    item.row = row;
                    item.col = col;
                    item.value = int_matrix;
                    items[args_item++] = item;
                }
            }
        }
    }

    void general_transpose() {
        auto transpose = std::make_unique<SparseMatrix>(args_cols, args_rows, args_matrix);
        int32_t position = 0;
        for (int32_t row = 0; row < args_cols; ++row) {
            for (int32_t item = 0; item < args_item; ++item) {
                if (items[item].col == row) {
                    transpose->items[position].row = items[item].col;
                    transpose->items[position].value = items[item].value;
                    transpose->items[position].col = items[item].row;
                    ++position;
                }
            }
        }
        transpose->print_original_matrix(args_item);
        transpose->print_result_matrix(args_item);
    }

    void fast_transpose() {
        auto transpose = std::make_unique<SparseMatrix>(args_cols, args_rows, args_matrix);
        std::vector<int32_t> col_count(args_cols, 0);
        std::vector<int32_t> col_pointer(args_cols, 0);

        for (int32_t i = 0; i < args_item; ++i) {
            ++col_count[items[i].col];
        }
        col_pointer[0] = 0;
        for (int32_t i = 1; i < args_cols; ++i) {
            col_pointer[i] = col_pointer[i - 1] + col_count[i - 1];
        }
        for (int32_t i = 0; i < args_item; ++i) {
            int32_t j = items[i].col;
            int32_t t = col_pointer[j];
            transpose->items[t].col = items[i].row;
            transpose->items[t].value = items[i].value;
            transpose->items[t].row = items[i].col;
            ++col_pointer[j];
        }
        transpose->print_original_matrix(args_item);
        transpose->print_result_matrix(args_item);
    }

    void print_original_matrix(int32_t non_zero_item) const {
        std::cout << "before matrix..." << std::endl;
        std::cout << "(" << std::setw(2) << args_cols 
                  << " ," << std::setw(2) << args_rows 
                  << " ," << std::setw(2) << non_zero_item 
                  << ")" << std::endl << std::endl;

        for (int32_t i = 0; i < args_cols; ++i) {
            for (int32_t j = 0; j < args_rows; ++j) {
                int32_t value = args_matrix[i][j];
                if (value != 0) {
                    std::cout << "(" << std::setw(2) << i 
                              << " ," << std::setw(2) << j 
                              << " ," << std::setw(2) << value 
                              << ")" << std::endl;
                }
            }
        }
        std::cout << std::endl;
    }

    void print_result_matrix(int32_t non_zero_item) const {
        int32_t position = 0;
        std::cout << "after matrix..." << std::endl;

        std::cout << "(" << std::setw(2) << args_rows 
                  << " ," << std::setw(2) << args_cols 
                  << " ," << std::setw(2) << non_zero_item 
                  << ")" << std::endl << std::endl;

        for (int32_t i = 0; i < args_rows; ++i) {
            for (int32_t j = 0; j < args_cols; ++j) {
                if (position < non_zero_item && items[position].row == i && items[position].col == j) {
                    items[position].print();
                    ++position;
                }
            }
        }
        std::cout << std::endl;
    }
};
