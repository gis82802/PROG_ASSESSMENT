#ifndef SPARSEMATRIX_H
#define SPARSEMATRIX_H

#include <iostream>
#include <algorithm>
using namespace std;

#define MAX_TERMS 225

class MatrixTerm {
private:
    int row, col, value;
public:
    MatrixTerm() : row(0), col(0), value(0) {}
    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}
    friend class SparseMatrix;
};


class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[MAX_TERMS];
public:
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t) {}

    void input() {
        cout << "�п�J�x�}���C�ƻP��� (d k)�G";
        cin >> rows >> cols;
        cout << "�п�J�D�s�����ƶq�G";
        cin >> terms;
        cout << "�Ш̧ǿ�J (row col value)�G\n";
        for (int i = 0; i < terms; i++) {
            int r, c, v;
            cin >> r >> c >> v;
            smArray[i] = MatrixTerm(r, c, v);
        }
    }

    void print() const {
        cout << " row  col  value\n";
        for (int i = 0; i < terms; i++) {
            cout << "  " << smArray[i].row << "    "
                << smArray[i].col << "    "
                << smArray[i].value << "\n";
        }
        cout << endl;
    }

    SparseMatrix simpleTranspose() const {
        SparseMatrix b(cols, rows, terms);
        int currentB = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].col == c) {
                    b.smArray[currentB++] = MatrixTerm(
                        smArray[i].col,
                        smArray[i].row,
                        smArray[i].value);
                }
            }
        }
        return b;
    }

    SparseMatrix fastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];

            fill(rowSize, rowSize + cols, 0);

            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].col]++;

            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].col];
                b.smArray[j].row = smArray[i].col;
                b.smArray[j].col = smArray[i].row;
                b.smArray[j].value = smArray[i].value;
                rowStart[smArray[i].col]++;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};

#endif