#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct MatrixTerm {
    int row, col;
    int value;
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[225]; // �A�Ω� 15x15 �H�����x�}
public:
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t) {
    }

    void inputMatrix() {
        cout << "��J�x�}�j�p (rows cols): ";
        cin >> rows >> cols;
        cout << "��J�D�s���� terms: ";
        cin >> terms;

        cout << "�Ш̧ǿ�J�C�ӫD�s�� (row col value):\n";
        for (int i = 0; i < terms; i++) {
            cin >> smArray[i].row >> smArray[i].col >> smArray[i].value;
        }
    }

    void display(const string& title) const {
        cout << "\n" << title << " (row col value):\n";
        for (int i = 0; i < terms; i++) {
            cout << setw(4) << smArray[i].row
                << setw(6) << smArray[i].col
                << setw(8) << smArray[i].value << "\n";
        }
    }

    // �@����m O(rows*cols*terms)
    SparseMatrix Transpose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int currentB = 0;
            for (int c = 0; c < cols; c++) {
                for (int i = 0; i < terms; i++) {
                    if (smArray[i].col == c) {
                        b.smArray[currentB].row = c;
                        b.smArray[currentB].col = smArray[i].row;
                        b.smArray[currentB].value = smArray[i].value;
                        currentB++;
                    }
                }
            }
        }
        return b;
    }

    // �ֳt��m O(cols + terms)
    SparseMatrix FastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[cols]();
            int* rowStart = new int[cols]();

            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].col]++;

            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].col]++;
                b.smArray[j].row = smArray[i].col;
                b.smArray[j].col = smArray[i].row;
                b.smArray[j].value = smArray[i].value;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};

#endif