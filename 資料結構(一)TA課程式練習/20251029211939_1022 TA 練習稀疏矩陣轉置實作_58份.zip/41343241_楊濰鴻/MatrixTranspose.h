#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
struct Triple{
    int row,col,value;
};
class MatrixTranspose{
    private:
    int rows,cols,terms;
    Triple *SmArray;
    public:
    MatrixTranspose(int r,int c){
        rows = r;
        cols = c;
        terms = 0;
        SmArray = new Triple[225];
    }
    ~MatrixTranspose(){
        delete[] SmArray;
    }
    void input(){
        /*cout<<"輸入非零項數目:"<<endl;
        cin>>terms;
        if(SmArray != nullptr) delete[] SmArray;
        SmArray = new Triple[terms];*/
        int r,c,value;
        cout<<"輸入非零項(row,col,value):"<<endl;
        cin>>r>>c>>value;
        while(r!=-1 && c!=-1 && value!=-1){
            SmArray[terms].row = r;
            SmArray[terms].col=c;
            SmArray[terms].value = value;
            terms++;
            cin>>r>>c>>value;
        }
    }
    void output() const{
        cout<<"Row\tCol\tValue"<<endl;
        for(int i=0;i<terms;i++){
            cout<<SmArray[i].row<<"\t"
            <<SmArray[i].col<<"\t"
            <<SmArray[i].value<<endl;
        }
    }
    MatrixTranspose transpose() const{
        MatrixTranspose result(cols,rows);
        result.terms = terms;
        if(terms>0){
            int *rowSize = new int[cols];
            int *rowStart = new int[cols];
            for(int i=0;i<cols;i++){
                rowSize[i] = 0;
                rowStart[i] = 0;
            }
            for(int i=0;i<terms;i++){
                rowSize[SmArray[i].col]++;
            }
            rowStart[0] = 0;
            for(int i=1;i<cols;i++){
                rowStart[i] = rowStart[i-1] + rowSize[i-1];//前一行的非零項數目加上前一行的起始位置
            }
            for(int i=0;i<terms;i++){
                int change = rowStart[SmArray[i].col]++;
                result.SmArray[change].row = SmArray[i].col;
                result.SmArray[change].col = SmArray[i].row;
                result.SmArray[change].value = SmArray[i].value;
            }
            delete[] rowSize;
            delete[] rowStart;
        }
        return result;
    }
};