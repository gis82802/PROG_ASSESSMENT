#include<iostream>
#include<vector>
#include<algorithm>
#include"MatrixTranspose.h"
using namespace std;
int main(){
    int r,c;
    cout<<"請輸入矩陣非零行、列、總數(r,c)"<<endl;
    cin>>r>>c;
    if(r>=15 || c>=15){
        cout<<"無法接受大於15*15的矩陣"<<endl;
        return 0;
    }
    MatrixTranspose sm(r,c);
    sm.input();//輸入非零項
    cout<<"原矩陣"<<endl;
    sm.output();//輸出原矩陣
    MatrixTranspose transpose = sm.transpose();//轉置矩陣
    cout<<"轉置後矩陣"<<endl;
    transpose.output();//輸出轉置後矩陣
    return 0;
}