#include<bits/stdc++.h>
#include "matrixTerm.hpp"
using namespace std;

// row 列 column 行 [列][行]

int main()
{
    int d, k;
    cin>>d>>k;
    SparseMatrix in(k, d, d*k);
    for(int i=0;i<k;i++)
        for(int j=0;j<d;j++)
        {
            int val; 
            cin>>val;
            if(val) in.addSmTerm(i, j, val);
        }
    cout << endl;

    in.print();

    cout << "=== Transpose ===" << endl;
    SparseMatrix out1 = in.Transpose();
    out1.print();

    cout << "=== FastTranspose ===" << endl;
    SparseMatrix out2 = in.FastTranspose();
    out2.print();

    return 0;
}