#include<bits/stdc++.h>
#include "matrixTerm.hpp"
using namespace std;

SparseMatrix SparseMatrix::Transpose()
{
    SparseMatrix b(cols, rows, terms);
    if(terms > 0)
    {
        int currentB = 0;
        for(int c=0;c<cols;c++)
        {
            for(int i=0;i<terms;i++)
            {
                if(smAry[i].col == c)
                {
                    b.smAry[currentB].row = c;
                    b.smAry[currentB].col = smAry[i].row;
                    b.smAry[currentB++].value = smAry[i].value;
                }
            }
        }
    }
    b.terms = terms;
    return b;
}

SparseMatrix SparseMatrix::FastTranspose()
{
    SparseMatrix b(cols, rows, terms);
    if(terms > 0)
    {
        int *rowSize = new int[cols];
        int *rowStart = new int[cols];
        fill(rowSize, rowSize + cols, 0);
        for(int i=0;i<terms;i++) rowSize[smAry[i].col]++;
        
        rowStart[0] = 0;
        for(int i=1;i<cols;i++)  rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for(int i=0;i<terms;i++)
        {
            int j = rowStart[smAry[i].col];
            b.smAry[j].row = smAry[i].col;
            b.smAry[j].col = smAry[i].row;
            b.smAry[j].value = smAry[i].value;
            rowStart[smAry[i].col]++;
        }

        delete rowSize; delete rowStart;
    }
    b.terms = terms;
    return b;
}

void SparseMatrix::addSmTerm(int r, int c, int v)
{
    if(terms==capacity)
    {
        capacity*=2;
        MatrixTerm *tmp = new MatrixTerm[capacity];
        copy(smAry, smAry + terms, tmp);
        delete [] smAry;
        smAry = tmp;
    }
    smAry[terms].row = r;
    smAry[terms].col = c;
    smAry[terms++].value = v;
}

void SparseMatrix::print()
{
    cout << "rows=" << rows << ", cols=" << cols << ", terms=" << terms << endl;
    cout << "\n\t Row\tCol\tValue\n";
    for(int i=0;i<terms;i++) 
        cout << "smAry[" << i << "] " << smAry[i].row << '\t' << smAry[i].col << '\t' << smAry[i].value << endl;
    cout << endl;
}