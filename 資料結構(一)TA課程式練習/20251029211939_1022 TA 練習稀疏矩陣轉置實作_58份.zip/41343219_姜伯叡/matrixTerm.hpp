#ifndef _MATRIXTERM_HPP
#define _MATRIXTERM_HPP

class MatrixTerm{
    friend class SparseMatrix;
    private:
        int row, col, value;
};

class SparseMatrix{
    private:
        int rows, cols, terms, capacity;
        MatrixTerm *smAry;
    public:
        SparseMatrix(int r, int c, int t) {
            rows = r;
            cols = c;
            terms = 0;
            capacity = t;
            smAry = new MatrixTerm[t];
        };
        void addSmTerm(int r, int c, int v);
        void print();
        SparseMatrix Transpose();
        SparseMatrix FastTranspose();
};

#endif