#include "SparseMatrix.hpp"
/*
0 1 2
1 1 3
2 3 4
3 3 5
4 1 2
4 4 6
*/
SparseMatrix::SparseMatrix(int r, int c, int t) {
    rows = r;
    cols = c;
    terms = t;
    smArray = (t > 0) ? new MatrixTerm[t] : nullptr;
}

SparseMatrix::~SparseMatrix() {
    delete[] smArray;
}

void SparseMatrix::Input() {
    cout << "�п�J�D�s���� : ";
    cin >> terms;

    if (smArray) delete[] smArray;
    smArray = new MatrixTerm[terms];

    cout << "�Ш̧ǿ�J (row col value):\n";
    int count = 0;

    for (int i = 0; i < terms; i++) {
        int r, c, v;
        cin >> r >> c >> v;

        if (r >= rows || c >= cols || r < 0 || c < 0) {
            cout << "error\n";
            continue;
        }

        smArray[count].row = r;
        smArray[count].col = c;
        smArray[count].value = v;
        count++;
    }

    terms = count;
}

void SparseMatrix::Print() {
    if (terms == 0) {
        cout << "(�ůx�})\n";
        return;
    }

    cout << left << setw(10) << "Row" << setw(10) << "Col" << setw(10) << "Value" << endl;
    for (int i = 0; i < terms; i++)
        cout << setw(10) << smArray[i].row
        << setw(10) << smArray[i].col
        << setw(10) << smArray[i].value << endl;
}

SparseMatrix SparseMatrix::Transpose() {
    SparseMatrix b(cols, rows, terms);
    if (terms > 0) {
        int currentB = 0;
        for (int c = 0; c < cols; c++)
            for (int i = 0; i < terms; i++)
                if (smArray[i].col == c) {
                    b.smArray[currentB].row = c;
                    b.smArray[currentB].col = smArray[i].row;
                    b.smArray[currentB++].value = smArray[i].value;
                }
    }
    return b;
}

SparseMatrix SparseMatrix::FastTranspose() {
    SparseMatrix b(cols, rows, terms);
    if (terms > 0) {
        int* rowSize = new int[cols]();
        int* rowStart = new int[cols]();

        fill(rowSize, rowSize + cols, 0);
        for (int i = 0; i < terms; i++)
            rowSize[smArray[i].col]++;

        rowStart[0] = 0;
        for (int i = 1; i < cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for (int i = 0; i < terms; i++) {
            int colIndex = smArray[i].col;
            int j = rowStart[colIndex];
            b.smArray[j].row = colIndex;
            b.smArray[j].col = smArray[i].row;
            b.smArray[j].value = smArray[i].value;
            rowStart[colIndex]++;
        }

        delete[] rowSize;
        delete[] rowStart;
    }
    return b;
}

int main() {
    int r, c;
    cout << "�C�B��: ";
    cin >> r >> c;

    cout << "\n=== ��J�}���x�} ===\n";
    SparseMatrix a(r, c, 0);
    a.Input();

    cout << "\n��l�x�}:\n";
    a.Print();

    cout << "\n=== Transpose ===\n";
    SparseMatrix b = a.Transpose();
    b.Print();

    cout << "\n=== FastTranspose ===\n";
    SparseMatrix c_fast = a.FastTranspose();
    c_fast.Print();

    system("pause");
    return 0;
}
