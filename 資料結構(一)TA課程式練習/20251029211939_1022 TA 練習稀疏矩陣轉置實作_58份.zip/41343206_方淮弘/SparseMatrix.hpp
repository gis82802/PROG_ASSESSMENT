#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row, col, value;
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm* smArray;

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0);
    ~SparseMatrix();

    void Input();
    void Print();
    SparseMatrix Transpose();
    SparseMatrix FastTranspose();
};

#endif
