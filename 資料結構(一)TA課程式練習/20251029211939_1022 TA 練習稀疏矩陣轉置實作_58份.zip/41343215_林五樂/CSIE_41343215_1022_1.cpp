#include "CSIE_41343215_1022_1.hpp"
#include <vector>
#include <iostream>
using namespace std;
SparseMatrix::SparseMatrix(int r, int c) {
    this->rows = r;
    this->cols = c;
    this->term_count = 0;
}
void SparseMatrix::addTerm(int r, int c, int v) {
    if (v != 0) {
        terms.push_back(MatrixTerm(r, c, v));
        term_count++;
    }
}
void SparseMatrix::print(const string& title) const {
    cout << title << "\n";
    cout << "rows: " << rows << "  cols: " << cols << "  terms: " << term_count << "\n";
    for (int i = 0; i < term_count; ++i) {
        cout << "a[" << i << "]: ";
        terms[i].print();
        cout << "\n";
    }
    cout << "\n\n";
}
SparseMatrix SparseMatrix::simpleTranspose() const {
    SparseMatrix B(cols, rows);
    if (term_count == 0) return B;
    for (int c = 0; c < cols; ++c) for (int i = 0; i < term_count; ++i)if (terms[i].getCol() == c) B.addTerm(terms[i].getCol(), terms[i].getRow(), terms[i].getValue());
    return B;
}
SparseMatrix SparseMatrix::fastTranspose() const {
    SparseMatrix B(cols, rows);
    if (term_count == 0) return B;
    B.terms.resize(term_count);
    B.term_count = term_count;
    vector<int> col_count(cols, 0);
    vector<int> starting_pos(cols, 0);
    for (int i = 0; i < term_count; ++i) col_count[terms[i].getCol()]++;
    starting_pos[0] = 0; 
    for (int c = 1; c < cols; ++c)starting_pos[c] = starting_pos[c - 1] + col_count[c - 1];
    for (int i = 0; i < term_count; ++i) {
        int c = terms[i].getCol();
        int pos = starting_pos[c];
        B.terms[pos].set(terms[i].getCol(), terms[i].getRow(), terms[i].getValue());
        starting_pos[c]++;
    }
    return B;
}
int main() {
    int d, k;
    cout << "��J�x�}d*k ";
    cin >> d >> k;
    if (d >= 15 || k >= 15 || d <= 0 || k <= 0) {
        cout << "error\n";
        return 1;
    }
    SparseMatrix A(d, k);
    cout << "��J " << d << "*" << k << " �x�}���e \n";
    for (int i = 0; i < d; ++i) {
        for (int j = 0; j < k; ++j) {
            int value;
            cin >> value;
            A.addTerm(i, j, value);
        }
    }
    A.print("\n��l�x�}");
    SparseMatrix B_simple = A.simpleTranspose();
    B_simple.print("²����m");
    SparseMatrix B_fast = A.fastTranspose();
    B_fast.print("�ֳt��m");
}