#include <iostream>
#include "MatrixTerm.hpp"
using namespace std;
int main()
{
    int rows, cols, terms;
    cout << "Enter number of rows, columns(rows,columns<15): " << endl;
    cin >> rows >> cols;
    if (rows > 15 || cols > 15)
    {
        cout << "Rows and Columns should be less than 15." << endl;
        return 0;
    }
    SparseMatrix a = a.input(rows, cols);
    SparseMatrix b = a.Transpose();
    cout << "Original Matrix:" << endl;
    a.print();
    cout << "Transpose completed." << endl;
    b.print();
    SparseMatrix c = a.FastTranspose();
    cout << "Fast Transpose completed." << endl;
    c.print();
    return 0;
}