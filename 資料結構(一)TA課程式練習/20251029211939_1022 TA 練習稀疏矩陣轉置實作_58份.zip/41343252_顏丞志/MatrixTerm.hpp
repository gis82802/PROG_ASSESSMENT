#include <iostream>
using namespace std;
class MatrixTerm
{
    friend class SparseMatrix;

private:
    int row;
    int col;
    int value;
};
class SparseMatrix
{
private:
    int rows;
    int cols;
    int terms;
    MatrixTerm *smArray;

public:
    SparseMatrix Transpose();
    SparseMatrix FastTranspose();
    SparseMatrix input(int r, int c)
    {
        rows = r;
        cols = c;
        terms = 0;
        int m[r][c];
        for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                cout << "Enter element at position (" << i << "," << j << "): ";
                cin >> m[i][j];
                if (m[i][j] != 0)
                {
                    terms++;
                }
            }
        }
        int term = 0;
        smArray = new MatrixTerm[terms];
        for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                if (m[i][j] != 0)
                {
                    smArray[term].row = i;
                    smArray[term].col = j;
                    smArray[term].value = m[i][j];
                    term++;
                }
            }
        }
    }
    SparseMatrix(int r, int c, int t)
    {
        rows = r;
        cols = c;
        terms = t;
        smArray = new MatrixTerm[terms];
    }
    void print()
    {
        cout << "Row:" << rows << " Column:" << cols << "Value:" << terms << endl;
        for (int i = 0; i < terms; i++)
        {
            cout << smArray[i].row << "\t" << smArray[i].col << "\t" << smArray[i].value << endl;
        }
    }
};
SparseMatrix SparseMatrix::Transpose()
{
    SparseMatrix b(cols, rows, terms);
    if (terms > 0)
    {
        int currentB = 0;
        for (int i = 0; i < cols; i++)
        {
            for (int j = 0; j < terms; j++)
            {
                if (smArray[j].col == i)
                {
                    b.smArray[currentB].row = i;
                    b.smArray[currentB].col = smArray[j].row;
                    b.smArray[currentB].value = smArray[j].value;
                    currentB++;
                }
            }
        }
    }
    return b;
}
SparseMatrix SparseMatrix::FastTranspose()
{
    SparseMatrix b(cols, rows, terms);
    if (terms > 0)
    {
        int *rowSize = new int[cols];
        int *rowStart = new int[cols];
        for (int i = 0; i < cols; i++)
            rowSize[i] = 0;
        for (int i = 0; i < terms; i++)
            rowSize[smArray[i].col]++;
        rowStart[0] = 0;
        for (int i = 1; i < cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];
        for (int i = 0; i < terms; i++)
        {
            int j = rowStart[smArray[i].col]++;
            b.smArray[j].row = smArray[i].col;
            b.smArray[j].col = smArray[i].row;
            b.smArray[j].value = smArray[i].value;
        }
        delete[] rowSize;
        delete[] rowStart;
    }
    return b;
}