#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include "MatrixTerm.hpp"
#include <iostream>
#include <iomanip>
#include <algorithm>
using namespace std;

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm* smArray;

public:
    // �غc�l
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t)
    {
        smArray = new MatrixTerm[terms + 1]; // +1 �� header
    }

    // �Ѻc�l
    ~SparseMatrix() {
        delete[] smArray;
    }

    // ��J
    void input() {
        cout << "�п�J�x�}����ƻP�C�� (d k): ";
        cin >> rows >> cols;
        cout << "�п�J�D�s�������Ӽ�: ";
        cin >> terms;

        delete[] smArray; // �����ӪŶ�
        smArray = new MatrixTerm[terms + 1];

        smArray[0].setRow(rows);
        smArray[0].setCol(cols);
        smArray[0].setValue(terms);

        cout << "�Ш̧ǿ�J�C�ӫD�s���� (row col value):\n";
        for (int i = 1; i <= terms; i++) {
            int r, c, v;
            cin >> r >> c >> v;
            smArray[i].setRow(r);
            smArray[i].setCol(c);
            smArray[i].setValue(v);
        }
    }

    // ��X
    void print(const string& title = "�}���x�}���e") const {
        cout << "\n" << title << " (row, col, value):\n";
        for (int i = 0; i <= terms; i++) {
            cout << "smArray[" << i << "]" << setw(3) << smArray[i].getRow() << " "
                << setw(3) << smArray[i].getCol() << " "
                << setw(3) << smArray[i].getValue() << "\n";
        }
    }

    // �@����m
    SparseMatrix Transpose() const {
        SparseMatrix b(cols, rows, terms);
        b.smArray[0].setRow(cols);
        b.smArray[0].setCol(rows);
        b.smArray[0].setValue(terms);

        if (terms > 0) {
            int currentB = 1; // �q 1 �}�l�s�D�s����
            for (int c = 0; c < cols; c++) {
                for (int i = 1; i <= terms; i++) {
                    if (smArray[i].getCol() == c) {
                        b.smArray[currentB].setRow(smArray[i].getCol());
                        b.smArray[currentB].setCol(smArray[i].getRow());
                        b.smArray[currentB].setValue(smArray[i].getValue());
                        currentB++;
                    }
                }
            }
        }
        return b;
    }

    // �ֳt��m
    SparseMatrix FastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        b.smArray[0].setRow(cols);
        b.smArray[0].setCol(rows);
        b.smArray[0].setValue(terms);

        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];
            fill(rowSize, rowSize + cols, 0);

            for (int i = 1; i <= terms; i++)
                rowSize[smArray[i].getCol()]++;

            rowStart[0] = 1; // �q 1 �}�l�s��
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 1; i <= terms; i++) {
                int j = rowStart[smArray[i].getCol()]++;
                b.smArray[j].setRow(smArray[i].getCol());
                b.smArray[j].setCol(smArray[i].getRow());
                b.smArray[j].setValue(smArray[i].getValue());
            }

            delete[] rowSize;
            delete[] rowStart;
        }

        return b;
    }
};

#endif
