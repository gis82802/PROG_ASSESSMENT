#ifndef MATRIXTERM_HPP
#define MATRIXTERM_HPP

class MatrixTerm {
private:
    int row;
    int col;
    int value;
public:
    MatrixTerm(int r = 0, int c = 0, int v = 0)
        : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void setRow(int r) { row = r; }
    void setCol(int c) { col = c; }
    void setValue(int v) { value = v; }
};

#endif
