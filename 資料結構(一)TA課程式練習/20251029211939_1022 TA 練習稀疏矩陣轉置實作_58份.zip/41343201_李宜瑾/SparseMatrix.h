// SparseMatrix.h

#ifndef SPARSEMATRIX_H
#define SPARSEMATRIX_H

#include <iostream>

#define MAX_SIZE 15
#define MAX_TERMS 225

struct MatrixTerm {
    int row;
    int col;
    int value;
};

struct SparseMatrix {
    int rows;
    int cols;
    int terms;
    MatrixTerm data[MAX_TERMS];
};

void printSparseMatrix(const SparseMatrix& m);
SparseMatrix simpleTranspose(const SparseMatrix& a);
SparseMatrix fastTranspose(const SparseMatrix& a);
SparseMatrix inputDenseMatrix();

#endif // SPARSEMATRIX_H