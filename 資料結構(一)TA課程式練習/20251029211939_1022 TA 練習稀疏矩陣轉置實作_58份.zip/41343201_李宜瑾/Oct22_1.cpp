#include "SparseMatrix.h"
#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

void printSparseMatrix(const SparseMatrix& m) {
    cout << setw(4) << "row" << setw(6) << "col" << setw(8) << "value" << endl;

    for (int i = 0; i < m.terms; i++) {
        cout << setw(4) << m.data[i].row
            << setw(6) << m.data[i].col
            << setw(8) << m.data[i].value << "\n";
    }
}

SparseMatrix simpleTranspose(const SparseMatrix& a) {
    SparseMatrix b;
    b.rows = a.cols;
    b.cols = a.rows;
    b.terms = a.terms;

    if (a.terms == 0) return b;

    int bIndex = 0;
    for (int col = 0; col < a.cols; col++) {
        for (int i = 0; i < a.terms; i++) {
            if (a.data[i].col == col) {
                b.data[bIndex].row = a.data[i].col;
                b.data[bIndex].col = a.data[i].row;
                b.data[bIndex].value = a.data[i].value;
                bIndex++;
            }
        }
    }
    return b;
}

SparseMatrix fastTranspose(const SparseMatrix& a) {
    SparseMatrix b;
    b.rows = a.cols;
    b.cols = a.rows;
    b.terms = a.terms;

    if (a.terms > 0) {
        int rowSize[MAX_SIZE] = { 0 };
        int rowStart[MAX_SIZE] = { 0 };

        for (int i = 0; i < a.terms; i++)
            rowSize[a.data[i].col]++;

        rowStart[0] = 0;
        for (int i = 1; i < a.cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for (int i = 0; i < a.terms; i++) {
            int j = rowStart[a.data[i].col]++;
            b.data[j].row = a.data[i].col;
            b.data[j].col = a.data[i].row;
            b.data[j].value = a.data[i].value;
        }
    }
    return b;
}

SparseMatrix inputDenseMatrix() {
    SparseMatrix m;
    cout << "��J�x�}���C�ƻP��� (d k, d, k < 15): ";
    if (!(cin >> m.rows >> m.cols)) return m;

    if (m.rows >= MAX_SIZE || m.cols >= MAX_SIZE || m.rows <= 0 || m.cols <= 0) {
        cerr << "���~: �x�}�j�p���ŦX�n�D (1 <= d, k < 15)�C" << endl;
        m.rows = 0; m.cols = 0; m.terms = 0;
        return m;
    }

    m.terms = 0;
    cout << "�̧ǿ�J�x�}���e:\n";
    for (int i = 0; i < m.rows; i++) {
        for (int j = 0; j < m.cols; j++) {
            int val;
            if (!(cin >> val)) return m;

            if (val != 0) {
                if (m.terms >= MAX_TERMS) {
                    cerr << "ĵ�i: �D�s�����L�h�A�w���������J�C" << endl;
                    return m;
                }
                m.data[m.terms].row = i;
                m.data[m.terms].col = j;
                m.data[m.terms].value = val;
                m.terms++;
            }
        }
    }
    return m;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    cout << "�}���x�}��m\n";
    SparseMatrix a = inputDenseMatrix();

    if (a.rows == 0 || a.cols == 0) return 1;
    cout << "\n��l�}���x�}:\n";
    printSparseMatrix(a);

    SparseMatrix b1 = simpleTranspose(a);
    cout << "\n²����m:\n";
    printSparseMatrix(b1);

    SparseMatrix b2 = fastTranspose(a);
    cout << "\n�ֳt��m:\n";
    printSparseMatrix(b2);

    return 0;
}