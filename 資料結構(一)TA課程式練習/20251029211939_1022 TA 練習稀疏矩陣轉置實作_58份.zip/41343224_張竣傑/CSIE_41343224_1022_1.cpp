#include "CSIE_41343224_1022_1.h"
#include <iostream>

using namespace std;

int main() {
    SparseMatrix a;
    cout << "輸入稀疏矩陣" << endl;
    a.readMatrix();

    cout << "\n原始" << endl;
    a.printMatrix();

    cout << "\n一般轉置" << endl;
    SparseMatrix b = a.transpose();
    b.printMatrix();

    cout << "\n快速轉置" << endl;
    SparseMatrix c = a.fastTranspose();
    c.printMatrix();

    return 0;
}
