#ifndef CSIE_41343224_1022_1_H
#define CSIE_41343224_1022_1_H

#include <iostream>
using namespace std;


class MatrixTerm {
private:
    int row, col;
    int value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0)
        : row(r), col(c), value(v) {}

    friend class SparseMatrix;
};

class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[16];

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0);
    void readMatrix();
    void printMatrix();
    SparseMatrix transpose();
    SparseMatrix fastTranspose();
};

#endif
