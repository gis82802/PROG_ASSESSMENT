    #include "CSIE_41343224_1022_1.h"
    #include <iostream>

    using namespace std;

    SparseMatrix::SparseMatrix(int r, int c, int t)
        : rows(r), cols(c), terms(t) {}

    void SparseMatrix::readMatrix() {
        cout << "請輸入矩陣的行(row)數與列(column)數 (<15)：";
        cin >> rows >> cols;
        cout << "輸入矩陣內容（" << rows << "x" << cols << "）：" << endl;
        terms = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int val;
                cin >> val;
                if (val != 0) {
                    smArray[terms++] = MatrixTerm(i, j, val);
                }
            }
        }
    }

    void SparseMatrix::printMatrix(){
        cout << "Row\tCol\tValue" << endl;
        for (int i = 0; i < terms; i++) {
            cout << smArray[i].row << "\t"
                << smArray[i].col << "\t"
                << smArray[i].value << endl;
        }
    }

    SparseMatrix SparseMatrix::transpose(){
        SparseMatrix b(cols, rows, terms);
        int currentb = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].col == c) {
                    b.smArray[currentb++] = MatrixTerm(smArray[i].col, smArray[i].row, smArray[i].value);
                }
            }
        }
        return b;
    }

    SparseMatrix SparseMatrix::fastTranspose(){
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int rowSize[cols] = {0};
            int rowStart[cols] = {0};

            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].col]++;

            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].col]++;
                b.smArray[j] = MatrixTerm(smArray[i].col, smArray[i].row, smArray[i].value);
            }
        }
        return b;
    }
