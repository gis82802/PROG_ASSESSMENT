// SparseMatrix.hpp
#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include "MatrixTerm.hpp"
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
#include <iomanip>

std::vector<std::vector<int>> inputMatrix(int d, int k) {
    std::vector<std::vector<int>> matrix(d, std::vector<int>(k));
    std::cout << "請輸入 " << d << " x " << k << " 的矩陣，每行用空格分隔：" << std::endl;
    for (int i = 0; i < d; ++i) {
        for (int j = 0; j < k; ++j) {
            std::cin >> matrix[i][j];
        }
    }
    return matrix;
}

std::vector<MatrixTerm> matrixToSparse(const std::vector<std::vector<int>>& matrix) {
    int d = matrix.size();
    int k = matrix[0].size();
    std::vector<MatrixTerm> sparse;
    for (int i = 0; i < d; ++i) {
        for (int j = 0; j < k; ++j) {
            if (matrix[i][j] != 0) {
                sparse.emplace_back(i, j, matrix[i][j]);
            }
        }
    }
    return sparse;
}

void printSparse(const std::vector<MatrixTerm>& sparse, const std::string& title) {
    std::cout << "\n" << title << ":" << std::endl;
    if (sparse.empty()) {
        std::cout << "空矩陣" << std::endl;
    } else {
        for (const auto& term : sparse) {
            term.print();
            std::cout << " ";
        }
        std::cout << std::endl;
    }
}

std::vector<MatrixTerm> transposeSimple(const std::vector<MatrixTerm>& sparse) {
    std::vector<MatrixTerm> transposed;
    for (const auto& t : sparse) {
        transposed.emplace_back(t.col, t.row, t.value);
    }
    std::sort(transposed.begin(), transposed.end(), [](const MatrixTerm& a, const MatrixTerm& b) {
        if (a.row != b.row) return a.row < b.row;
        return a.col < b.col;
    });
    return transposed;
}

std::vector<MatrixTerm> transposeFast(const std::vector<MatrixTerm>& sparse) {
    if (sparse.empty()) {
        return {};
    }

    int numTerms = sparse.size();
    int origCols = 0;
    for (const auto& t : sparse) {
        origCols = std::max(origCols, t.col + 1);
    }

    std::vector<int> colCounts(origCols, 0);
    for (const auto& t : sparse) {
        ++colCounts[t.col];
    }

    std::vector<int> startPos(origCols, 0);
    int pos = 0;
    for (int i = 0; i < origCols; ++i) {
        startPos[i] = pos;
        pos += colCounts[i];
    }

    std::vector<MatrixTerm> transposed(numTerms);
    std::vector<int> currentPos = startPos;

    for (const auto& t : sparse) {
        int col = t.col;
        int idx = currentPos[col]++;
        transposed[idx] = MatrixTerm(col, t.row, t.value);
    }

    return transposed;
}

#endif