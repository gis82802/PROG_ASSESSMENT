// MatrixTerm.hpp
#ifndef MATRIXTERM_HPP
#define MATRIXTERM_HPP

#include <iostream>

struct MatrixTerm {
    int row;
    int col;
    int value;

    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}

    void print() const {
        std::cout << "(" << row << ", " << col << ", " << value << ")";
    }
};

#endif