#include <iostream>
using namespace std;

class MatrixTerm
{
private:
    int row, col, value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}
    int r() const { return row; }
    int c() const { return col; }
    int v() const { return value; }
    void set(int r, int c, int v)
    {
        row = r;
        col = c;
        value = v;
    }
};

void print(MatrixTerm a[], string name) // print矩陣
{
    cout << name << ":\n";
    for (int i = 0; i <= a[0].v(); i++)
        cout << "a[" << i << "] " << a[i].r() << " " << a[i].c() << " " << a[i].v() << "\n";
    cout << "\n";
}

void build(MatrixTerm a[], int m[15][15], int d, int k) // 壓縮矩陣
{
    int t = 1;
    for (int i = 0; i < d; i++)
        for (int j = 0; j < k; j++)
            if (m[i][j] != 0)
                a[t++].set(i, j, m[i][j]);
    a[0].set(d, k, t - 1);
}

void simple(MatrixTerm a[], MatrixTerm b[]) // 簡單轉置
{
    int r = a[0].r(), c = a[0].c(), t = a[0].v();
    b[0].set(c, r, t);
    int q = 1;
    for (int col = 0; col < c; col++)
        for (int i = 1; i <= t; i++)
            if (a[i].c() == col)
                b[q++].set(a[i].c(), a[i].r(), a[i].v());
}

void fast(MatrixTerm a[], MatrixTerm b[]) // 快速轉置
{
    int r = a[0].r(), c = a[0].c(), t = a[0].v();
    b[0].set(c, r, t);
    int count[15] = {0}, start[15] = {0};
    for (int i = 1; i <= t; i++)
        count[a[i].c()]++;
    start[0] = 1;
    for (int i = 1; i < c; i++)
        start[i] = start[i - 1] + count[i - 1];
    for (int i = 1; i <= t; i++)
    {
        int pos = start[a[i].c()]++;
        b[pos].set(a[i].c(), a[i].r(), a[i].v());
    }
}

int main()
{
    int d, k;
    cout << "Enter d k (<15): ";
    cin >> d >> k;
    int m[15][15];
    cout << "Enter matrix:\n";
    for (int i = 0; i < d; i++)
        for (int j = 0; j < k; j++)
            cin >> m[i][j];
    cout << "\n";

    MatrixTerm a[230], b1[230], b2[230]; // 15 × 15 = 225

    build(a, m, d, k);
    print(a, "Original (compressed)");

    simple(a, b1);
    print(b1, "Simple Transpose");

    fast(a, b2);
    print(b2, "Fast Transpose");
}
