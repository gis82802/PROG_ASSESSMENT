#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <vector>
#include <iostream>
#include <iomanip>  

class MatrixTerm {
private:
    int row;    
    int col;  
    int value;  

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void setRow(int r) { row = r; }
    void setCol(int c) { col = c; }
    void setValue(int v) { value = v; }
};

class SparseMatrix {
private:
    int d;  
    int k;  
    std::vector<MatrixTerm> terms;

public:
    SparseMatrix(int rows, int cols) : d(rows), k(cols) {}

    void inputMatrix();       
    void printMatrix() const; 
    SparseMatrix transpose1() const;
    SparseMatrix transpose2() const; 
};

void SparseMatrix::inputMatrix() {
    std::cout << "�п�J�}���x�}�����e�]�C��@�Ӧ�C���ƭȡA�Ů���j�^�G\n";
    for (int i = 0; i < d; ++i) {
        for (int j = 0; j < k; ++j) {
            int value;
            std::cin >> value;
            if (value != 0) {
                terms.push_back(MatrixTerm(i, j, value));  
            }
        }
    }
}

void SparseMatrix::printMatrix() const {
    std::cout << "�}���x�}���e�G\n";
    std::cout << "��  �C  �ƭ�\n";

 
    for (const auto& term : terms) {
        std::cout << std::setw(3) << term.getRow() << " "
            << std::setw(3) << term.getCol() << " "
            << std::setw(3) << term.getValue() << "\n";
    }
}

SparseMatrix SparseMatrix::transpose1() const {
    SparseMatrix transposed(k, d);  

    for (const auto& term : terms) {
        transposed.terms.push_back(MatrixTerm(term.getCol(), term.getRow(), term.getValue()));
    }

    return transposed;
}

SparseMatrix SparseMatrix::transpose2() const {
    SparseMatrix transposed(k, d);

    std::vector<int> count(k, 0);
    std::vector<int> startingPosition(k, 0);

    for (const auto& term : terms) {
        ++count[term.getCol()];
    }

    startingPosition[0] = 0;
    for (int i = 1; i < k; ++i) {
        startingPosition[i] = startingPosition[i - 1] + count[i - 1];
    }

    for (const auto& term : terms) {
        int position = startingPosition[term.getCol()]++;
        transposed.terms.push_back(MatrixTerm(term.getCol(), term.getRow(), term.getValue()));
    }

    return transposed;
}

#endif
