#include <iostream>
using namespace std;

#define MAX_TERMS 225  // 15x15 = 225

class MatrixTerm {
public:
    int row, col, value;
};

class SparseMatrix {
public:
    int rows, cols, terms;
    MatrixTerm smArray[MAX_TERMS];

    // ��J
    void input() {
        cout << "��J�x�}�C�� (d < 15): ";
        cin >> rows;
        cout << "��J�x�}��� (k < 15): ";
        cin >> cols;
        cout << "��J�D�s�����ƶq: ";
        cin >> terms;

        cout << "�п�J " << terms << " �ӫD�s���� (�� �C ��)�A�C��@��:\n";
        for (int i = 0; i < terms; i++) {
            cin >> smArray[i].row >> smArray[i].col >> smArray[i].value;
        }
    }

    // �L�X�x�}
    void print(const string& title) const {
        cout << endl << title << endl;
        for (int i = 0; i < terms; i++) {
            cout << "(" << smArray[i].row << ", " << smArray[i].col << ", " << smArray[i].value << ")" << endl;
        }
    }

    // ²����m�k
    SparseMatrix simpleTranspose() const {
        SparseMatrix b;
        b.rows = cols;
        b.cols = rows;
        b.terms = terms;

        int currentB = 0;
        for (int col = 0; col < cols; col++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].col == col) {
                    b.smArray[currentB].row = smArray[i].col;
                    b.smArray[currentB].col = smArray[i].row;
                    b.smArray[currentB].value = smArray[i].value;
                    currentB++;
                }
            }
        }
        return b;
    }

    // �ֳt��m�k
    SparseMatrix fastTranspose() const {
        SparseMatrix b;
        b.rows = cols;
        b.cols = rows;
        b.terms = terms;

        if (terms > 0) {
            int* colCount = new int[cols];
            int* colStart = new int[cols];

            for (int i = 0; i < cols; i++) colCount[i] = 0;

            for (int i = 0; i < terms; i++)
                colCount[smArray[i].col]++;

            colStart[0] = 0;
            for (int i = 1; i < cols; i++)
                colStart[i] = colStart[i - 1] + colCount[i - 1];

            for (int i = 0; i < terms; i++) {
                int pos = colStart[smArray[i].col]++;
                b.smArray[pos].row = smArray[i].col;
                b.smArray[pos].col = smArray[i].row;
                b.smArray[pos].value = smArray[i].value;
            }

            delete[] colCount;
            delete[] colStart;
        }
        return b;
    }
};

int main() {
    SparseMatrix A;
    A.input();

    A.print("��}���x�}:");

    SparseMatrix B1 = A.simpleTranspose();
    B1.print("²����m���G:");

    SparseMatrix B2 = A.fastTranspose();
    B2.print("�ֳt��m���G:");

    return 0;
}
