#include <iostream>
#include <vector>
#include "SparseMatrix.hpp"
using namespace std;

int main() {
    int rows, cols;
    cout << "�Д��c�Д�: ";
    cin >> rows >> cols;

    vector<vector<int>> matrix(rows, vector<int>(cols));
    cout << "��ꇃ��� ��(" << rows << "x" << cols << "):\n";
    for (int i = 0; i < rows; ++i)
        for (int j = 0; j < cols; ++j)
            cin >> matrix[i][j];

    cout << "\n=== ԭʼ��� ===\n";
    for (auto& row : matrix) {
        for (auto val : row)
            cout << val << " ";
        cout << endl;
    }

    SparseMatrix sm;
    sm.fromDense(matrix);

    cout << "\n=== ϡ���� ===\n";
    sm.show();

    cout << "\n=== �D�� ===\n";
    SparseMatrix normalT = sm.transpose();
    normalT.show();

    //cout << "\n=== �����D�� ===\n";
    //SparseMatrix fastT = sm.fastTranspose();
    //fastT.show();

    return 0;
}
