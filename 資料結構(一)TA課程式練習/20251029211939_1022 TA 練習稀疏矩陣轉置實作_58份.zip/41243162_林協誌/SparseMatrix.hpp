#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
#include <vector>
using namespace std;

struct Term {
    int row;
    int col;
    int value;
};

class SparseMatrix {
private:
    int rows, cols;
    vector<Term> smArray; // ��������

public:
    SparseMatrix(int r = 0, int c = 0) : rows(r), cols(c) {}

    // ��һ�����D�Q��ϡ����
    void fromDense(const vector<vector<int>>& matrix) {
        smArray.clear();
        rows = matrix.size();
        cols = matrix[0].size();

        for (int i = 0; i < rows; ++i)
            for (int j = 0; j < cols; ++j)
                if (matrix[i][j] != 0)
                    smArray.push_back({ i, j, matrix[i][j] });
    }

    // �@ʾϡ���ꇃ���
    void show() const {
        cout << "ϡ���ꇹ��� " << rows << "x" << cols
            << "������헔� = " << smArray.size() << endl;
        for (auto& t : smArray)
            cout << "(" << t.row << ", " << t.col << ", " << t.value << ")\n";
    }

    // һ���D��
    SparseMatrix transpose() const {
        SparseMatrix result(cols, rows);
        for (int c = 0; c < cols; ++c) {
            for (auto& t : smArray)
                if (t.col == c)
                    result.smArray.push_back({ t.col, t.row, t.value });
        }
        return result;
    }

    // �����D��
    SparseMatrix fastTranspose() const {
        SparseMatrix result(cols, rows);
        int numTerms = smArray.size();
        if (numTerms == 0) return result;

        vector<int> rowTerms(cols, 0);
        vector<int> startingPos(cols, 0);

        for (auto& t : smArray)
            rowTerms[t.col]++;

        startingPos[0] = 0;
        for (int i = 1; i < cols; ++i)
            startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

        result.smArray.resize(numTerms);
        for (auto& t : smArray) {
            int pos = startingPos[t.col]++;
            result.smArray[pos] = { t.col, t.row, t.value };
        }

        return result;
    }
};

#endif
