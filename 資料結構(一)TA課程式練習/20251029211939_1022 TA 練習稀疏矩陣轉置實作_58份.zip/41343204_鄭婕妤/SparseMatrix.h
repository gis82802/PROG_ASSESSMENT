#ifndef SPARSEMATRIX_H
#define SPARSEMATRIX_H

const int MAX_TERMS = 100;
const int MAX_SIZE = 15;

struct MatrixTerm {
    int row;
    int col;
    int value;
};

struct SparseMatrix {
    int rows;
    int cols;
    int terms;
    MatrixTerm data[MAX_TERMS];
};

void printSparseMatrix(const SparseMatrix& m);
SparseMatrix simpleTranspose(const SparseMatrix& a);
SparseMatrix fastTranspose(const SparseMatrix& a);
SparseMatrix inputDenseMatrix();

#endif

