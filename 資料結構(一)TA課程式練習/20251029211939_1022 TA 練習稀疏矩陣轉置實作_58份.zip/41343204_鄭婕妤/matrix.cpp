#include <iostream>
#include "SparseMatrix.h"
using namespace std;


void printSparseMatrix(const SparseMatrix& m) {
    cout << "row\tcol\tvalue\n";
    for (int i = 0; i < m.terms; i++) {
        cout << m.data[i].row << "\t"
            << m.data[i].col << "\t"
            << m.data[i].value << "\n";
    }
}

SparseMatrix simpleTranspose(const SparseMatrix& a) {
    SparseMatrix b;
    b.rows = a.cols;
    b.cols = a.rows;
    b.terms = a.terms;

    int bIndex = 0;
    for (int col = 0; col < a.cols; col++) {
        for (int i = 0; i < a.terms; i++) {
            if (a.data[i].col == col) {
                b.data[bIndex].row = a.data[i].col;
                b.data[bIndex].col = a.data[i].row;
                b.data[bIndex].value = a.data[i].value;
                bIndex++;
            }
        }
    }
    return b;
}

SparseMatrix fastTranspose(const SparseMatrix& a) {
    SparseMatrix b;
    b.rows = a.cols;
    b.cols = a.rows;
    b.terms = a.terms;

    if (a.terms > 0) {
        int rowSize[MAX_SIZE] = { 0 };
        int rowStart[MAX_SIZE] = { 0 };

        for (int i = 0; i < a.terms; i++)
            rowSize[a.data[i].col]++;

        rowStart[0] = 0;
        for (int i = 1; i < a.cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for (int i = 0; i < a.terms; i++) {
            int j = rowStart[a.data[i].col]++;
            b.data[j].row = a.data[i].col;
            b.data[j].col = a.data[i].row;
            b.data[j].value = a.data[i].value;
        }
    }
    return b;
}

SparseMatrix inputDenseMatrix() {
    SparseMatrix m;
    cout << "��J�x�}���C�ƻP���: ";
    cin >> m.rows >> m.cols;

    m.terms = 0;
    cout << "�̧ǿ�J�x�}���e(" << m.rows << "x" << m.cols << "):\n";
    for (int i = 0; i < m.rows; i++) {
        for (int j = 0; j < m.cols; j++) {
            int val;
            cin >> val;
            if (val != 0) {
                m.data[m.terms].row = i;
                m.data[m.terms].col = j;
                m.data[m.terms].value = val;
                m.terms++;
            }
        }
    }
    return m;
}



int main() {
    SparseMatrix a = inputDenseMatrix();

    cout << "\n=== ��l�}���x�} ===\n";
    printSparseMatrix(a);

    SparseMatrix b1 = simpleTranspose(a);
    cout << "\n=== ²����m���G ===\n";
    printSparseMatrix(b1);

    SparseMatrix b2 = fastTranspose(a);
    cout << "\n=== �ֳt��m���G ===\n";
    printSparseMatrix(b2);

    return 0;
}
