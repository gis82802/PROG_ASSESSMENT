#ifndef FAST_TRANSPOSE_HPP
#define FAST_TRANSPOSE_HPP

#include <iostream>
#include <vector>
using namespace std;

struct Triple {
    int row, col;
    double val;
    Triple(int r = 0, int c = 0, double v = 0.0) : row(r), col(c), val(v) {}
};

class SparseMatrix {
public:
    int rows, cols;
    vector<Triple> terms;

    SparseMatrix(int r = 0, int c = 0) : rows(r), cols(c) {}

    void add_term(int r, int c, double v) {
        if (v != 0.0)
            terms.emplace_back(r, c, v);
    }

    SparseMatrix fast_transpose() const {
        SparseMatrix T(cols, rows);
        int numTerms = terms.size();
        if (numTerms == 0) return T;

        vector<int> colCount(cols, 0);
        for (auto& t : terms)
            colCount[t.col]++;

        vector<int> startPos(cols, 0);
        for (int i = 1; i < cols; i++)
            startPos[i] = startPos[i - 1] + colCount[i - 1];

        T.terms.resize(numTerms);
        for (auto& t : terms) {
            int pos = startPos[t.col]++;
            T.terms[pos] = Triple(t.col, t.row, t.val);
        }
        return T;
    }

    void print_triples(const string& title) const {
        cout << title << "\n";
        cout << "rows: " << rows << "  cols: " << cols
            << "  terms: " << terms.size() << "\n";
        for (size_t i = 0; i < terms.size(); i++) {
            cout << "a[" << i << "]: ("
                << terms[i].row << ", "
                << terms[i].col << ", "
                << terms[i].val << ")\n";
        }
        cout << "\n";
    }
};

#endif
