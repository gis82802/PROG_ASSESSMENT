#ifndef HW_H
#define HW_H

#include<iostream>
#include<vector>
#include<iomanip>

using namespace std;
class MT {
private:
	int row;
	int col;
	int value;

public:
	MT(int r=0,int c=0,int v=0):row(r),col(c),value(v){}

	int GR() const { return row; }
	int GC() const { return col; }
	int GV() const { return value; }

	void SV(int v) { value = v; }

	void print() const {
		cout << "(" << row << "," << col << "," << value << ")";
	}
	
};

class SM {
private:
	int rows;
	int cols;
	int terms;
	vector<MT> elements;

public:
	SM(int r = 0, int c = 0) :rows(r), cols(c), terms(0) {}

	void input() {
		cout << "��J�x�}��,�C:";
		cin >> rows >> cols;

		if (rows >= 15 || cols >= 15) {
			cout << "���~!" << endl;
			return;
		}

		cout << "��J�x�}����" << endl;
		int temp;
		terms = 0;
		elements.clear();

		for (int i = 0; i < rows; i++) {
			for (int j=0; j < cols; j++) {
				cin >> temp;
				if (temp != 0) {
					elements.push_back(MT(i, j, temp));
					terms++;
				}
			}
		}
	}

	SM ST() const {
		SM result(cols, rows);
		result.terms = terms;
		result.elements.resize(terms);

		int current = 0;
		for (int j = 0; j < cols; j++) {
			for (int i=0; i < terms; i++) {
				if (elements[i].GC()==j) {
					result.elements[current] = MT(j, elements[i].GR(), elements[i].GV());
					current++;
				}
			}
		}

		return result;
	}

	SM FT()const {
		SM result(cols, rows);
		result.terms = terms;
		result.elements.resize(terms);

		vector<int>CC(cols, 0);
		for (int i = 0; i < terms; i++) {
			CC[elements[i].GC()]++;
		}

		vector<int>SP(cols, 0);
		for (int j = 1; j < cols; j++) {
			SP[j] = SP[j - 1] + CC[j - 1];
		}

		for (int i = 0; i < terms; i++) {
			int j = elements[i].GC();
			int pos = SP[j];
			result.elements[pos] = MT(j, elements[i].GR(), elements[i].GV());
			SP[j]++;
		}

		return result;
	}

	void PF() const {
		vector<vector<int>>FM(rows, vector<int>(cols, 0));

		for (int i = 0; i < terms; i++) {
			int r = elements[i].GR();
			int c = elements[i].GC();
			int v = elements[i].GV();
			FM[r][c] = v;
		}
	
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				cout << setw(2) << FM[i][j]<<" ";
			}
			cout << endl;
		}
	}


	void PC()const {
		cout << "��²����:" << endl;
		for (int i = 0; i < terms; i++) {
			elements[i].print();
			if (i < terms - 1)cout << ", ";
		}
		cout << endl;
	}
	int GRS() const { return rows; }
	int GCS() const { return cols; }
	int GTS() const { return terms; }
};
#endif

