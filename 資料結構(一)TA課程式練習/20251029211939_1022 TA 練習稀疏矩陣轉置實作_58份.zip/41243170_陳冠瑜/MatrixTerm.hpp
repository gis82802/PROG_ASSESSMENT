﻿#ifndef MATRIXTERM_HPP
#define MATRIXTERM_HPP

#include <iostream>
#include <vector>

class SparseMatrix;

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row, col, value;

public:
    MatrixTerm() : row(0), col(0), value(0) {}
    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}
};

class SparseMatrix {
public:
    SparseMatrix(int r, int c, int t);
    ~SparseMatrix();

    SparseMatrix Transpose();
    SparseMatrix FastTranspose();
    void Print() const;

    void SetTerm(int index, int r, int c, int v);

private:
    int rows, cols, terms, capacity;
    MatrixTerm* smArray;
};

#endif // MATRIXTERM_HPP
