﻿#include <iostream>
#include <vector>
#include <stdexcept>
#include "MatrixTerm.hpp"

using namespace std;

// === 建構子 ===
SparseMatrix::SparseMatrix(int r, int c, int t)
    : rows(r), cols(c), terms(t), capacity(max(1, t))
{
    smArray = new MatrixTerm[capacity];
}

// === 解構子 ===
SparseMatrix::~SparseMatrix() {
    delete[] smArray;
}

// === 一般轉置 ===
SparseMatrix SparseMatrix::Transpose() {
    SparseMatrix b(cols, rows, terms);
    if (terms > 0) {
        int currentB = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].col == c) {
                    b.smArray[currentB].row = c;
                    b.smArray[currentB].col = smArray[i].row;
                    b.smArray[currentB++].value = smArray[i].value;
                }
            }
        }
    }
    return b;
}

// === 快速轉置 ===
SparseMatrix SparseMatrix::FastTranspose() {
    SparseMatrix b(cols, rows, terms);
    if (terms > 0) {
        int* rowSize = new int[cols];
        int* rowStart = new int[cols];

        fill(rowSize, rowSize + cols, 0);
        for (int i = 0; i < terms; i++) rowSize[smArray[i].col]++;

        rowStart[0] = 0;
        for (int i = 1; i < cols; i++)
            rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

        for (int i = 0; i < terms; i++) {
            int j = rowStart[smArray[i].col];
            b.smArray[j].row = smArray[i].col;
            b.smArray[j].col = smArray[i].row;
            b.smArray[j].value = smArray[i].value;
            rowStart[smArray[i].col]++;
        }
        delete[] rowSize;
        delete[] rowStart;
    }
    return b;
}

// === 列印矩陣 ===
void SparseMatrix::Print() const {
    cout << "Row\tCol\tValue" << endl;
    for (int i = 0; i < terms; i++) {
        cout << smArray[i].row << "\t" << smArray[i].col << "\t" << smArray[i].value << endl;
    }
}

void SparseMatrix::SetTerm(int index, int r, int c, int v) {
    if (index < 0 || index >= capacity) {
        throw out_of_range("Index out of range in SetTerm()");
    }
    smArray[index] = MatrixTerm(r, c, v);
}


// === 主程式：輸入一個矩陣並顯示結果 ===
int main() {
    int rows, cols, terms;

    cout << "請輸入矩陣的行數、列數與非零元素數量: ";
    cin >> rows >> cols >> terms;

    SparseMatrix mat(rows, cols, terms);

    cout << "請依序輸入每個非零元素 (row col value):" << endl;
    for (int i = 0; i < terms; i++) {
        int r, c, v;
        cout << "[" << i + 1 << "] ";
        cin >> r >> c >> v;
        mat.SetTerm(i, r, c, v); 
    }

    cout << "\n輸入的矩陣為：" << endl;
    mat.Print();

    SparseMatrix trans = mat.Transpose();
    cout << "\n一般轉置矩陣為：" << endl;
    trans.Print();

    SparseMatrix fasttrans = mat.FastTranspose();
    cout << "\n快速轉置矩陣為：" << endl;
    fasttrans.Print();

    return 0;
}

