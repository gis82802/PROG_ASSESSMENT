#ifndef SPARSEMATRIX_H
#define SPARSEMATRIX_H

#include <iostream>
#include <iomanip>
using namespace std;

const int MAX_TERMS = 225; // �̦h 15x15

struct MatrixTerm {
    int row;
    int col;
    int value;
};

class SparseMatrix {
private:
    int rows;   // �`�C��
    int cols;   // �`���
    int terms;  // �D�s���ؼ�
    MatrixTerm data[MAX_TERMS];

public:
    SparseMatrix() : rows(0), cols(0), terms(0) {}

    void inputMatrix();
    void printMatrix() const;

    SparseMatrix simpleTranspose() const;
    SparseMatrix fastTranspose() const;
};

void SparseMatrix::inputMatrix() {
    cout << "��J�x�}���C�� d (<15): ";
    cin >> rows;
    cout << "��J�x�}����� k (<15): ";
    cin >> cols;

    cout << "�п�J�x�}���e�]0 ���ܪŭȡ^:\n";
    int val;
    terms = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cin >> val;
            if (val != 0) {
                data[terms].row = i;
                data[terms].col = j;
                data[terms].value = val;
                terms++;
            }
        }
    }
}

void SparseMatrix::printMatrix() const {
    cout << "rows = " << rows << ", cols = " << cols
        << ", terms = " << terms << "\n";
    cout << setw(6) << "Row" << setw(6) << "Col" << setw(8) << "Value\n";
    cout << "---------------------------\n";
    for (int i = 0; i < terms; i++) {
        cout << setw(6) << data[i].row
            << setw(6) << data[i].col
            << setw(8) << data[i].value << "\n";
    }
    cout << endl;
}

SparseMatrix SparseMatrix::simpleTranspose() const {
    SparseMatrix b;
    b.rows = cols;
    b.cols = rows;
    b.terms = terms;

    if (terms > 0) {
        int currentB = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (data[i].col == c) {
                    b.data[currentB].row = data[i].col;
                    b.data[currentB].col = data[i].row;
                    b.data[currentB].value = data[i].value;
                    currentB++;
                }
            }
        }
    }
    return b;
}

SparseMatrix SparseMatrix::fastTranspose() const {
    SparseMatrix b;
    b.rows = cols;
    b.cols = rows;
    b.terms = terms;

    if (terms > 0) {
        int rowTerms[15] = { 0 };
        int startingPos[15] = { 0 };

        for (int i = 0; i < terms; i++)
            rowTerms[data[i].col]++;

        startingPos[0] = 0;
        for (int i = 1; i < cols; i++)
            startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

        for (int i = 0; i < terms; i++) {
            int j = startingPos[data[i].col]++;
            b.data[j].row = data[i].col;
            b.data[j].col = data[i].row;
            b.data[j].value = data[i].value;
        }
    }
    return b;
}

#endif
