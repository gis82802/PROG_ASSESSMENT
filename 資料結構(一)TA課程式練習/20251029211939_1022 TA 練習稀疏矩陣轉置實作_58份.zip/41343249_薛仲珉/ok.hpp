#include <iostream>
using namespace std;

// ---------------------------
// ���O�GMatrixTerm�]�x�s�@�ӫD�s���^
// ---------------------------
class MatrixTerm {
private:
    int row;    // ��s��
    int col;    // �C�s��
    int value;  // �ƭ�

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) {
        row = r; col = c; value = v;
    }

    void setRow(int r) { row = r; }
    void setCol(int c) { col = c; }
    void setValue(int v) { value = v; }

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void print() const {
        cout << "(" << row << ", " << col << ", " << value << ")";
    }
};

// ---------------------------
// ���O�GSparseMatrix�]�}���x�}�^
// ---------------------------
class SparseMatrix {
private:
    int rows;     // �`���
    int cols;     // �`�C��
    int terms;    // �D�s���ƶq
    MatrixTerm smArray[100]; // �D�s���}�C

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0) {
        rows = r;
        cols = c;
        terms = t;
    }

    void setMatrix(int r, int c, int t) {
        rows = r;
        cols = c;
        terms = t;
    }

    void setTerm(int index, int r, int c, int v) {
        smArray[index].setRow(r);
        smArray[index].setCol(c);
        smArray[index].setValue(v);
    }

    void showMatrix() const {
        cout << "\n(row, col, value):" << endl;
        for (int i = 0; i < terms; i++) {
            smArray[i].print();
            cout << endl;
        }
    }

    // ---------------------------
    // (1) �@����m�k slowTranspose
    // ---------------------------
    void slowTranspose(SparseMatrix& b) const {
        b.rows = cols;
        b.cols = rows;
        b.terms = terms;
        int index = 0;

        for (int c = 0; c < cols; c++) {     // ���y�C�@��
            for (int i = 0; i < terms; i++) { // ���y�Ҧ��D�s��
                if (smArray[i].getCol() == c) {
                    b.smArray[index].setRow(smArray[i].getCol());
                    b.smArray[index].setCol(smArray[i].getRow());
                    b.smArray[index].setValue(smArray[i].getValue());
                    index++;
                }
            }
        }
    }

    // ---------------------------
    // (2) �ֳt��m�k fastTranspose
    // ---------------------------
    void fastTranspose(SparseMatrix& b) const {
        int rowSize[100];
        int rowStart[100];

        b.rows = cols;
        b.cols = rows;
        b.terms = terms;

        if (terms > 0) {
            // Step 1�G�έp�C��D�s���ƶq
            for (int i = 0; i < cols; i++)
                rowSize[i] = 0;
            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].getCol()]++;

            cout << "\n[rowSize] �U��D�s���ƶq:" << endl;
            for (int i = 0; i < cols; i++)
                cout << "col " << i << ": " << rowSize[i] << endl;

            // Step 2�G�p����m��C�C�_�l��m
            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            cout << "\n[rowStart] �U����m��_�l����:" << endl;
            for (int i = 0; i < cols; i++)
                cout << "col " << i << " �� �_�l��m " << rowStart[i] << endl;

            // Step 3�G��J��m�x�}
            for (int i = 0; i < terms; i++) {
                int j = smArray[i].getCol();
                int index = rowStart[j];

                b.smArray[index].setRow(smArray[i].getCol());
                b.smArray[index].setCol(smArray[i].getRow());
                b.smArray[index].setValue(smArray[i].getValue());

                rowStart[j]++; // �ʺA��s
            }
        }
    }
};
