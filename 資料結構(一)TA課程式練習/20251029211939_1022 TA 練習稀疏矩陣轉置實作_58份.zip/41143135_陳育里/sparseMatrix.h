#include <iostream>
#include <algorithm>

using namespace std;
class MatrixTerm {
private:
    int row, col, value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0)
        : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }
    void set(int r, int c, int v) { row = r; col = c; value = v; }
};

class SparseMatrix {
private:
    int rows, cols, terms;
    int capacity;
    MatrixTerm* smArray;

public:
    SparseMatrix(int R = 0, int C = 0, int t = 0)
        : rows(R), cols(C), terms(0) {
        capacity = (t > 0 ? t : 1);
        smArray = new MatrixTerm[capacity];
    }

    ~SparseMatrix() { delete[] smArray; }

    void addTerm(int r, int c, int v) {
        if (v == 0) return;
        if (terms == capacity) {
            capacity *= 2;
            MatrixTerm* temp = new MatrixTerm[capacity];
            copy(smArray, smArray + terms, temp);
            delete[] smArray;
            smArray = temp;
        }
        smArray[terms++].set(r, c, v);
    }

    void print() const {
        cout << "(row, col, value)" << endl;
        for (int i = 0; i < terms; i++) {
            cout << "(" << smArray[i].getRow() << ", "
                 << smArray[i].getCol() << ", "
                 << smArray[i].getValue() << ")" << endl;
        }
    }

    SparseMatrix transpose() const {
        SparseMatrix b(cols, rows, terms);
        int currentB = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].getCol() == c) {
                    b.smArray[currentB++].set(
                        smArray[i].getCol(),
                        smArray[i].getRow(),
                        smArray[i].getValue()
                    );
                }
            }
        }
        b.terms = terms;
        return b;
    }

    SparseMatrix transposeFast() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[cols];
            int* rowStart = new int[cols];
			for (int i = 0; i < cols; i++) {
                rowSize[i] = 0;
                rowStart[i] = 0;
            }
            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].getCol()]++;

            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = rowStart[smArray[i].getCol()]++;
                b.smArray[j].set(
                    smArray[i].getCol(),
                    smArray[i].getRow(),
                    smArray[i].getValue()
                );
            }
            b.terms = terms;
            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};
