#include <iostream>
#include "sparseMatrix.h" 
using namespace std;

int main() {
    int d, k;
    cout << "�п�J�x�}���C�ƻP��� (d k)�G";
    cin >> d >> k;

    SparseMatrix A(d, k);

    cout << "�п�J�x�}�G" << endl;
    for (int i = 0; i < d; i++) {
        for (int j = 0; j < k; j++) {
            int val;
            cin >> val;
            if (val != 0)
                A.addTerm(i, j, val);
        }
    }

    cout << "\n��x�}" << endl;
    A.print();

    SparseMatrix B = A.transpose();
    cout << "\n�C�t��m�x�}" << endl;
    B.print();

    SparseMatrix C = A.transposeFast();
    cout << "\n�ֳt��m�x�}" << endl;
    C.print();

    return 0;
}

