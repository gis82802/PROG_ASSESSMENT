#include "SparseMatrix.hpp"

MatrixTerm::MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}
int MatrixTerm::getRow() const { return row; }
int MatrixTerm::getCol() const { return col; }
int MatrixTerm::getValue() const { return value; }
void MatrixTerm::set(int r, int c, int v)
{
    row = r;
    col = c;
    value = v;
}
void MatrixTerm::print() const { cout << "(" << row << "," << col << "," << value << ") "; }

void SparseMatrix::read()
{
    cin >> rows >> cols >> terms;
    for (int i = 0; i < terms; i++)
    {
        int r, c, v;
        cin >> r >> c >> v;
        data[i].set(r, c, v);
    }
}

void SparseMatrix::print() const
{
    for (int i = 0; i < terms; i++)
        data[i].print();
    cout << endl;
}

void SparseMatrix::printFullMatrix() const
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            int val = 0;
            for (int k = 0; k < terms; k++)
                if (data[k].getRow() == i && data[k].getCol() == j)
                {
                    val = data[k].getValue();
                    break;
                }
            cout << val << "\t";
        }
        cout << endl;
    }
}

SparseMatrix SparseMatrix::Transpose() const
{
    SparseMatrix t;
    t.rows = cols;
    t.cols = rows;
    t.terms = terms;
    int idx = 0;
    for (int c = 0; c < cols; c++)
        for (int i = 0; i < terms; i++)
            if (data[i].getCol() == c)
                t.data[idx++].set(data[i].getCol(), data[i].getRow(), data[i].getValue());
    return t;
}

SparseMatrix SparseMatrix::fastTranspose() const
{
    SparseMatrix t;
    t.rows = cols;
    t.cols = rows;
    t.terms = terms;
    int rowCount[15] = {0}, startPos[15] = {0};

    for (int i = 0; i < terms; i++)
        rowCount[data[i].getCol()]++;

    for (int i = 1; i < cols; i++)
        startPos[i] = startPos[i - 1] + rowCount[i - 1];

    for (int i = 0; i < terms; i++)
    {
        int j = startPos[data[i].getCol()]++;
        t.data[j].set(data[i].getCol(), data[i].getRow(), data[i].getValue());
    }
    return t;
}

int main()
{
    SparseMatrix A;
    A.read();

    cout << "原矩陣（稀疏形式）: ";
    A.print();
    cout << "原矩陣（矩陣圖）:" << endl;
    A.printFullMatrix();

    SparseMatrix B = A.Transpose();
    cout << "一般轉置（稀疏形式）: ";
    B.print();
    cout << "一般轉置（矩陣圖）:" << endl;
    B.printFullMatrix();

    SparseMatrix C = A.fastTranspose();
    cout << "快速轉置（稀疏形式）: ";
    C.print();
    cout << "快速轉置（矩陣圖）:" << endl;
    C.printFullMatrix();

    return 0;
}
