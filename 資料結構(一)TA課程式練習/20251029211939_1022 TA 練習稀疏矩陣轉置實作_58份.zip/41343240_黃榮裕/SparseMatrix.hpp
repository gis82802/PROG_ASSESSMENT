#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
using namespace std;

class MatrixTerm
{
private:
    int row, col, value;

public:
    MatrixTerm(int r = 0, int c = 0, int v = 0);
    int getRow() const;
    int getCol() const;
    int getValue() const;
    void set(int r, int c, int v);
    void print() const;
};

class SparseMatrix
{
private:
    int rows, cols, terms;
    MatrixTerm data[225];

public:
    void read();
    void print() const;
    void printFullMatrix() const;
    SparseMatrix Transpose() const;
    SparseMatrix fastTranspose() const;
};

#endif
