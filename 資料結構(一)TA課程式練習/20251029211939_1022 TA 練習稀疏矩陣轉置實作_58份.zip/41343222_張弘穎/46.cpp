#include<iostream>
#include"798.hpp"
using namespace std;

int main() {
	MatrixTerm A;
	A.input();
	cout << "轉置前的稀疏矩陣：" << endl;
	A.print();
	cout << "=== 簡單轉置結果 ===\n";
	MatrixTerm B = A.simpleTranspose();
	B.print();
	cout << "=== 快速轉置結果 ===\n";
	MatrixTerm C = A.fastTranspose();
	C.print();
}