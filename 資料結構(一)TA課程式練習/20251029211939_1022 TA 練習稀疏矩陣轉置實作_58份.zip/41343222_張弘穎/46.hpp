#include<iostream>
using namespace std;
#include <iostream>
using namespace std;

struct number {
    int rows, columns, value;
};

class MatrixTerm {
private:
    int rows, columns, terms;
    number data[225];

public:
    MatrixTerm(int a = 0, int b = 0, int c = 0) : rows(a), columns(b), terms(c) {}

    void input() {
        cout << "請輸入有幾列 行" << endl;
        cin >> rows >> columns;
        terms = 0;
        for (int a = 0; a < rows; a++) {
            for (int b = 0; b < columns; b++) {
                int p = 0;
                cin >> p;
                if (p != 0) {
                    data[terms].value = p;
                    data[terms].rows = a;
                    data[terms].columns = b;
                    terms++;
                }
            }
        }
    }

    void print() const {
        cout << "[0]" << rows << " " << columns << " " << terms << endl;
        for (int a = 0; a < terms; a++) {
            cout << "[" << a + 1 << "]"
                << data[a].rows << " " << data[a].columns << " " << data[a].value << endl;
        }
    }

    MatrixTerm simpleTranspose() const {
        MatrixTerm result(columns, rows, terms);
        int g = 0;
        for (int a = 0; a < columns; a++) {
            for (int b = 0; b < terms; b++) {
                if (data[b].columns == a + 1) { // 注意：原程式 columns 從 1 開始
                    result.data[g].rows = data[b].columns;
                    result.data[g].columns = data[b].rows;
                    result.data[g].value = data[b].value;
                    g++;
                }
            }
        }
        return result;
    }

    MatrixTerm fastTranspose() const {
        MatrixTerm result(columns, rows, terms);
        if (terms > 0) {
            int* rowSize = new int[columns](); // 各欄非零項個數
            int* rowStart = new int[columns];  // 每欄起始位置

            for (int i = 0; i < terms; i++)
                rowSize[data[i].columns - 1]++;

            rowStart[0] = 0;
            for (int i = 1; i < columns; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = rowStart[data[i].columns - 1]++;
                result.data[j].rows = data[i].columns;
                result.data[j].columns = data[i].rows;
                result.data[j].value = data[i].value;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return result;
    }
};
