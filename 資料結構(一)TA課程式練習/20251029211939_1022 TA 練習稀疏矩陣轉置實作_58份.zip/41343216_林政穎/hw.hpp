#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
using namespace std;

struct MatrixTerm {
    int row;    // �C�s��
    int col;    // ��s��
    int value;  // �ƭ�
};

class SparseMatrix {
private:
    MatrixTerm terms[225];  // �̦h 15x15
    int rows, cols, termsCount;

public:
    SparseMatrix() : rows(0), cols(0), termsCount(0) {}

    void inputMatrix() {
        cout << "�п�J�x�}���C�� (d < 15)�G";
        cin >> rows;
        cout << "�п�J�x�}����� (k < 15)�G";
        cin >> cols;
        cout << "�п�J�D�s���ơG";
        cin >> termsCount;

        for (int i = 0; i < termsCount; i++) {
            cout << "�п�J�� " << i + 1 << " �ӫD�s���� (�C �� ��)�G";
            cin >> terms[i].row >> terms[i].col >> terms[i].value;
        }
    }

    void printMatrix() const {
        cout << "\n�C  ��  ��\n";
        for (int i = 0; i < termsCount; i++) {
            cout << terms[i].row << "   " << terms[i].col << "   " << terms[i].value << endl;
        }
    }

    // ��k�@�G�@����m
    SparseMatrix transposeSlow() const {
        SparseMatrix trans;
        trans.rows = cols;
        trans.cols = rows;
        trans.termsCount = termsCount;

        int index = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < termsCount; i++) {
                if (terms[i].col == c) {
                    trans.terms[index].row = terms[i].col;
                    trans.terms[index].col = terms[i].row;
                    trans.terms[index].value = terms[i].value;
                    index++;
                }
            }
        }
        return trans;
    }

    // ��k�G�G�ֳt��m
    SparseMatrix transposeFast() const {
        SparseMatrix trans;
        trans.rows = cols;
        trans.cols = rows;
        trans.termsCount = termsCount;

        if (termsCount > 0) {
            int* rowSize = new int[cols]();
            int* rowStart = new int[cols]();

            for (int i = 0; i < termsCount; i++)
                rowSize[terms[i].col]++;

            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            for (int i = 0; i < termsCount; i++) {
                int j = rowStart[terms[i].col]++;
                trans.terms[j].row = terms[i].col;
                trans.terms[j].col = terms[i].row;
                trans.terms[j].value = terms[i].value;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return trans;
    }
};

#endif
#pragma once
