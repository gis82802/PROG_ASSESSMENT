#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
using namespace std;

#define MAX_TERMS 225 // 15x15 �̤j������

// ===================== MatrixTerm ���O =====================
class MatrixTerm {
private:
    int row, col;
    int value;
public:
    MatrixTerm() : row(0), col(0), value(0) {}
    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}

    void set(int r, int c, int v) { row = r; col = c; value = v; }
    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void print() const {
        cout << "(" << row << ", " << col << ", " << value << ") ";
    }
};

// ===================== SparseMatrix ���O =====================
class SparseMatrix {
private:
    int rows, cols, terms;
    MatrixTerm smArray[MAX_TERMS];
public:
    SparseMatrix(int r = 0, int c = 0, int t = 0)
        : rows(r), cols(c), terms(t) {}

    // ��J�x�}���
    void readMatrix() {
        cout << "��J�x�}�j�p d k�G";
        cin >> rows >> cols;
        cout << "�п�J�x�}���e�]�@ " << rows << "x" << cols << "�^�G" << endl;
        terms = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int val;
                cin >> val;
                if (val != 0) {
                    smArray[terms++].set(i, j, val);
                }
            }
        }
    }

    // �L�X�}���x�}���e
    void printMatrix() const {
        cout << "rows=" << rows << ", cols=" << cols << ", terms=" << terms << endl;
        cout << "row\tcol\tvalue" << endl;
        for (int i = 0; i < terms; i++) {
            cout << smArray[i].getRow() << "\t"
                << smArray[i].getCol() << "\t"
                << smArray[i].getValue() << endl;
        }
    }

    // ��k�@�G²����m
    SparseMatrix simpleTranspose() const {
        SparseMatrix b(cols, rows, terms);
        int currentB = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].getCol() == c) {
                    b.smArray[currentB++].set(smArray[i].getCol(), smArray[i].getRow(), smArray[i].getValue());
                }
            }
        }
        return b;
    }

    // ��k�G�G�ֳt��m
    SparseMatrix fastTranspose() const {
        SparseMatrix b(cols, rows, terms);
        if (terms > 0) {
            int* rowTerms = new int[cols];
            int* startingPos = new int[cols];

            for (int i = 0; i < cols; i++)
                rowTerms[i] = 0;

            for (int i = 0; i < terms; i++)
                rowTerms[smArray[i].getCol()]++;

            startingPos[0] = 0;
            for (int i = 1; i < cols; i++)
                startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

            for (int i = 0; i < terms; i++) {
                int j = startingPos[smArray[i].getCol()]++;
                b.smArray[j].set(smArray[i].getCol(), smArray[i].getRow(), smArray[i].getValue());
            }

            delete[] rowTerms;
            delete[] startingPos;
        }
        return b;
    }

};

#endif
