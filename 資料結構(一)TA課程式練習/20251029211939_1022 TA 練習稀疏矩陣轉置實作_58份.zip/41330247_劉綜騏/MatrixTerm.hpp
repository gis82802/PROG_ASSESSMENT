#ifndef MATRIXTERM_HPP
#define MATRIXTERM_HPP

class MatrixTerm {
    friend class SparseMatrix;
private:
    int row, col;
    int value;
public:
    MatrixTerm(int r = 0, int c = 0, int v = 0) : row(r), col(c), value(v) {}
};

#endif
