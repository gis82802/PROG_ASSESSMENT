#include <iostream>
#include "SparseMatrix.hpp"
using namespace std;

int main() {
    SparseMatrix m;
    m.input();

    cout << "\n��l�}���x�}�G\n";
    m.output();

    cout << "\n²�����G\n";
    SparseMatrix t1 = m.transpose();
    t1.output();

    cout << "\n�ֳt����G\n";
    SparseMatrix t2 = m.fastTranspose();
    t2.output();

    return 0;
}
