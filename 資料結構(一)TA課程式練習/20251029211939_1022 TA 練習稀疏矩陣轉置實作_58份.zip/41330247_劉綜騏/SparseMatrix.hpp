#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
#include <vector>
#include "MatrixTerm.hpp"
using namespace std;

class SparseMatrix {
private:
    int rows, cols, terms;      
    vector<MatrixTerm> smArray; 

public:
    SparseMatrix(int r = 0, int c = 0, int t = 0) : rows(r), cols(c), terms(t) {}

    void input() {
        cout << "�п�J�x�}�j�p�]�C�ƻP��ơ^�G";
        cin >> rows >> cols;

        cout << "�п�J�x�}���e�G" << endl;
        smArray.clear();

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int v;
                cin >> v;
                if (v != 0) {
                    smArray.push_back(MatrixTerm(i, j, v)); 
                }
            }
        }

        terms = smArray.size(); 
    }

    void output() const {
        cout << "��\t�C\t��\n";
        for (auto& t : smArray) {
            cout << t.row << "\t" << t.col << "\t" << t.value << "\n";
        }
    }

    SparseMatrix transpose() const {
        SparseMatrix result(cols, rows, terms);
        int idx = 0;
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].col == c) {
                    result.smArray.push_back(MatrixTerm(c, smArray[i].row, smArray[i].value));
                }
            }
        }
        result.terms = result.smArray.size();
        return result;
    }

    SparseMatrix fastTranspose() const {
        SparseMatrix result(cols, rows, terms);
        if (terms > 0) {
            vector<int> rowTerms(cols, 0);
            vector<int> startingPos(cols, 0);

            for (int i = 0; i < terms; i++)
                rowTerms[smArray[i].col]++;

            startingPos[0] = 0;
            for (int i = 1; i < cols; i++)
                startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];

            result.smArray.resize(terms);
            for (int i = 0; i < terms; i++) {
                int j = startingPos[smArray[i].col]++;
                result.smArray[j] = MatrixTerm(smArray[i].col, smArray[i].row, smArray[i].value);
            }
        }
        return result;
    }
};

#endif
