#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

#include <iostream>
#include <vector>
using namespace std;

// ================= MatrixTerm ���O =================
class MatrixTerm {
private:
    int row;
    int col;
    int value;
public:
    MatrixTerm() : row(0), col(0), value(0) {}
    MatrixTerm(int r, int c, int v) : row(r), col(c), value(v) {}

    int getRow() const { return row; }
    int getCol() const { return col; }
    int getValue() const { return value; }

    void setRow(int r) { row = r; }
    void setCol(int c) { col = c; }
    void setValue(int v) { value = v; }
};

// ================= SparseMatrix ���O =================
class SparseMatrix {
private:
    int rows;
    int cols;
    int terms;
public:
    vector<MatrixTerm> smArray;

    SparseMatrix(int r = 0, int c = 0, int t = 0) : rows(r), cols(c), terms(0) {}

    void inputMatrix() {
        cout << "�п�J�x�}���� (" << rows << "x" << cols << ")�G" << endl;
        int val;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cin >> val;
                if (val != 0) {
                    smArray.push_back(MatrixTerm(i, j, val));
                    terms++;
                }
            }
        }
    }

    void printSparse() const {
        cout << "�C\t��\t��" << endl;
        for (int i = 0; i < terms; i++)
            cout << smArray[i].getRow() << "\t"
            << smArray[i].getCol() << "\t"
            << smArray[i].getValue() << endl;
    }

    int getRows() const { return rows; }
    int getCols() const { return cols; }
    int getTerms() const { return terms; }
    void setTerms(int t) { terms = t; }

    // �@����m
    SparseMatrix Transpose() const {
        SparseMatrix b(cols, rows);
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < terms; i++) {
                if (smArray[i].getCol() == c) {
                    b.smArray.push_back(MatrixTerm(c, smArray[i].getRow(), smArray[i].getValue()));
                    b.setTerms(b.getTerms() + 1);
                }
            }
        }
        return b;
    }

    // �ֳt��m
    SparseMatrix FastTranspose() const {
        SparseMatrix b(cols, rows);
        if (terms > 0) {
            int* rowSize = new int[cols] {0};
            int* rowStart = new int[cols] {0};

            // �p��C�@�C���X�ӫD�s����
            for (int i = 0; i < terms; i++)
                rowSize[smArray[i].getCol()]++;

            // �p��C�@�C���_�l��m
            rowStart[0] = 0;
            for (int i = 1; i < cols; i++)
                rowStart[i] = rowStart[i - 1] + rowSize[i - 1];

            // �վ� b.smArray �j�p
            b.smArray.resize(terms);
            b.setTerms(terms);

            // ��m�L�{
            for (int i = 0; i < terms; i++) {
                int col = smArray[i].getCol();
                int pos = rowStart[col];
                b.smArray[pos].setRow(col);
                b.smArray[pos].setCol(smArray[i].getRow());
                b.smArray[pos].setValue(smArray[i].getValue());
                rowStart[col]++;
            }

            delete[] rowSize;
            delete[] rowStart;
        }
        return b;
    }
};

#endif
