#include <iostream>
using namespace std;

template <class T>
class MyStack
{
    T *data;
    int cap, topIndex;

public:
    MyStack(int c = 2) : cap(c), topIndex(-1) { data = new T[cap]; }
    ~MyStack() { delete[] data; }

    void push(T x)
    {
        if (topIndex + 1 >= cap)
        {
            cout << "Expand capacity: " << cap << " -> " << cap * 2 << endl;
            T *newData = new T[cap * 2];
            for (int i = 0; i <= topIndex; i++)
                newData[i] = data[i];
            delete[] data;
            data = newData;
            cap *= 2;
        }
        data[++topIndex] = x;
    }

    void pop()
    {
        if (topIndex >= 0)
            topIndex--;
    }

    T top() { return data[topIndex]; }
    bool empty() { return topIndex < 0; }

    void print()
    {
        cout << "Stack (bottom -> top): ";
        for (int i = 0; i <= topIndex; i++)
            cout << data[i] << " ";
        cout << endl;
    }
};

int main()
{
    MyStack<int> intStk;       // store int values
    MyStack<double> doubleStk; // store double values

    intStk.push(12);
    intStk.push(34);
    intStk.push(56); // triggers expansion

    doubleStk.push(1);
    doubleStk.push(2.3);
    doubleStk.push(4.5);
    doubleStk.push(6.7); // triggers expansion
    intStk.print();
    doubleStk.print();
}
