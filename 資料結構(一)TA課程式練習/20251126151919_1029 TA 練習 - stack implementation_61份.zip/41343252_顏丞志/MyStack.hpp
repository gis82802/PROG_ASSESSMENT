#include <iostream>
using namespace std;
template <class T>
class MyStack
{
private:
    T *arr;
    int capacity;
    int top;
    void ChangeSize1D(T *&a, int oldSize, int newSize)
    {
        if (newSize < 0)
            throw "New size must be >= 0";
        T *temp = new T[newSize];
        int number = min(oldSize, newSize);
        copy(a, a + number, temp);
        delete[] a;
        a = temp;
    }

public:
    MyStack(int size = 10);
    bool IsEmpty() const;
    T &Top() const;
    void Push(const T &item);
    void Pop();
};
template <class T>
MyStack<T>::MyStack(int size) : capacity(size)
{
    if (capacity < 1)
        throw "Stack capacity must be > 0";
    arr = new T[capacity];
    top = -1;
}
template <class T>
inline bool MyStack<T>::IsEmpty() const
{
    return top == -1;
}
template <class T>
inline T &MyStack<T>::Top() const
{
    if (IsEmpty())
        throw "Stack is empty";
    return arr[top];
}
template <class T>
inline void MyStack<T>::Push(const T &item)
{
    if (top == capacity - 1)
    {
        cout << "�e�q�ܬ� " << 2 * capacity << endl;
        ChangeSize1D(arr, capacity, 2 * capacity);
        capacity *= 2;
    }
    arr[++top] = item;
}
template <class T>
void MyStack<T>::Pop()
{
    if (IsEmpty())
        throw "Stack is empty. Cannot delete.";
    arr[top--].~T();
}