#include "MyStack.h"

int main(void) {
	MyStack<int> intStk;
	MyStack<double> doubleStk;

	intStk.push(12);
	doubleStk.push(2.3);
	intStk.push(13);
	intStk.push(14);
	doubleStk.push(3.4);
	doubleStk.push(4.5);
	intStk.push(15);
	intStk.push(16);
	doubleStk.push(5.6);
	doubleStk.push(6.7);

	cout << "\nintStk����X���e�O: ";
	while (!intStk.emp()) {
		cout << intStk.pop() << ' ';
	}

	cout << "\ndoubleStk����X���e�O: ";
	while (!doubleStk.emp()) {
		cout<<doubleStk.pop()<<' ';
	}
	return 0;
}
