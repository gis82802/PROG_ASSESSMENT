#include <iostream>
#include <typeinfo>
using namespace std;

template<class T>
class MyStack {
private:
    T* data;
    int cap, top;

public:
    void resetsize() {
        int newcap = cap * 2;
        T* newdata = new T[newcap];
        for (int n = 0; n < cap; n++) {
            newdata[n] = data[n];
        }
        delete[] data;
        data = newdata;
        cap = newcap;
        cout <<"MyStack<"<<typeid(T).name()<<"> ���Ŷ�2���A�ܦ� " << cap << endl;
    }

    MyStack(int incap = 1) {
        cap = incap;
        data = new T[cap];
        top = -1;
    }

    ~MyStack() {
        delete[] data;
    }

    void push(T nu) {
        if (top + 1 >= cap) {
            resetsize();
        }
        data[++top] = nu;
    }

    T pop() {
        return data[top--];
    }

    bool emp() {
        return top == -1;
    }
};
