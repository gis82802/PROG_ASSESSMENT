// MyStack.h
#ifndef MYSTACK_H
#define MYSTACK_H

#include <iostream>
#include <vector>
#include <typeinfo>
using namespace std;

template <typename T>
class MyStack {
private:
    vector<T> data;
    int capacity;
    string typeName;

    void resize() {
        int oldCapacity = capacity;
        capacity = (capacity == 0) ? 4 : capacity * 2;
        data.reserve(capacity);

        cout << "MyStack<" << typeName << "> ���Ŷ�2���A�ܦ� " << capacity << endl;
    }

public:
    MyStack() : capacity(0) {
        typeName = typeid(T).name();
        resize();  // ��l�e�q 4
    }

    void push(const T& value) {
        if (data.size() == data.capacity()) {
            resize();  // Ĳ�o�X�e + �L�T��
        }
        data.push_back(value);
    }

    T pop() {
        if (data.empty()) throw runtime_error("Stack empty");
        T value = data.back();
        data.pop_back();
        return value;
    }

    bool isEmpty() const { return data.empty(); }
    int size() const { return data.size(); }
};

#endif