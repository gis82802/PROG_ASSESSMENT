#include <iostream>
using namespace std;

template <typename T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void expandCapacity() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];
        for (int i = 0; i <= topIndex; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
        cout << "�e�q�w�X�R�� " << capacity << "�I" << endl;
    }

public:
    MyStack(int initialCapacity = 2) {
        capacity = initialCapacity;
        data = new T[capacity];
        topIndex = -1;
    }

    ~MyStack() {
        delete[] data;
    }

    void push(const T& value) {
        if (topIndex + 1 >= capacity) {
            expandCapacity();
        }
        data[++topIndex] = value;
    }

    T pop() {
        if (topIndex < 0) {
            throw runtime_error("���|���šA�L�k�u�X�I");
        }
        return data[topIndex--];
    }

    T top() const {
        if (topIndex < 0) {
            throw runtime_error("���|���šA�L�k�d�ݳ��ݤ����I");
        }
        return data[topIndex];
    }

    bool empty() const {
        return topIndex == -1;
    }

    int size() const {
        return topIndex + 1;
    }
};

