#include <iostream>
#include "MyStack.h"
using namespace std;

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;
    intStk.push(12);
    doubleStk.push(2.3);

    for (int i = 1; i < 20; i++) {
        intStk.push(i);
        doubleStk.push(i*0.2);
    }

    intStk.print();
    doubleStk.print();

    for (int i = 0; i < 3; i++) {
        intStk.pop();
        doubleStk.pop();
    }

    intStk.print();
    doubleStk.print();

    return 0;
}
