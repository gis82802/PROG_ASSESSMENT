#ifndef MYSTACK_H
#define MYSTACK_H

#include <iostream>
using namespace std;

template <class T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void resize() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];
        for (int i = 0; i < capacity; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
        cout << "[�t�ΰT��] Stack �e�q�w�۰��X�R�� " << capacity << endl;
    }

public:
    MyStack(int initCap = 2) {
        capacity = initCap;
        data = new T[capacity];
        topIndex = -1;
    }

    ~MyStack() {
        delete[] data;
    }

    void push(const T& value) {
        if (topIndex + 1 >= capacity) {
            resize();
        }
        data[++topIndex] = value;
    }

    void pop() {
        if (isEmpty()) {
            cout << "[ĵ�i] Stack ���šA�L�k pop�C\n";
            return;
        }
        topIndex--;
    }

    T top() const {
        if (isEmpty()) {
            throw out_of_range("Stack ���šA�L�k���o top�C");
        }
        return data[topIndex];
    }

    bool isEmpty() const {
        return topIndex == -1;
    }

    int size() const {
        return topIndex + 1;
    }
};

#endif
