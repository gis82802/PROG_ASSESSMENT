#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
using namespace std;

template <typename T>
class MyStack {
private:
    T* arr;
    int capacity;
    int topIndex;

    void expandCapacity() {
        int newCapacity = capacity * 2;
        T* newArr = new T[newCapacity];
        for (int i = 0; i <= topIndex; i++) {
            newArr[i] = arr[i];
        }
        delete[] arr;
        arr = newArr;
        capacity = newCapacity;
        cout << "�e�q�w�X�R�� " << capacity << endl;
    }

public:
    MyStack(int initialCapacity = 4) {
        capacity = initialCapacity;
        arr = new T[capacity];
        topIndex = -1;
    }

    ~MyStack() {
        delete[] arr;
    }

    void push(const T& value) {
        if (topIndex + 1 >= capacity) {
            expandCapacity();
        }
        arr[++topIndex] = value;
    }

    T pop() {
        if (topIndex < 0) {
            throw runtime_error("���|����");
        }
        return arr[topIndex--];
    }

    bool empty() const {
        return topIndex == -1;
    }

    int size() const {
        return topIndex + 1;
    }
};

#endif
