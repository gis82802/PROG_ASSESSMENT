#include <iostream>
#include "MyStack.hpp"
using namespace std;

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << "push int 12, double 2.3" << endl;
    intStk.push(12);
    doubleStk.push(2.3);

    cout << "intStk pop: " << intStk.pop() << endl;
    cout << "doubleStk pop: " << doubleStk.pop() << endl;

    cout << "\n�۰��X�R intStk" << endl;
    for (int i = 1; i <= 10; i++) {  
        cout << "push int: " << i * 12 << endl;
        intStk.push(i * 12);
    }
    cout << "�� LIFO pop intStk: ";
    while (!intStk.empty()) {
        cout << intStk.pop() << " ";
    }
    cout << endl;

    cout << "\n�۰��X�R doubleStk" << endl;
    for (int i = 1; i <= 10; i++) {  
        double value = i * 2.3;
        cout << "push double: " << value << endl;
        doubleStk.push(value);
    }
    cout << "�� LIFO pop doubleStk: ";
    while (!doubleStk.empty()) {
        cout << doubleStk.pop() << " ";
    }
    cout << endl;

    return 0;
}


