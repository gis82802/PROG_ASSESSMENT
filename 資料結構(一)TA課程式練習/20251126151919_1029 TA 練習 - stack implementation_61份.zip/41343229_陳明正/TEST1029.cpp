#include "hw.hpp"
using namespace std;

int main() {
    cout << "=== hw: MyStack demo (auto-resize prints message) ===\n\n";

 
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << "Push single elements first:\n";
    intStk.push(12);           
    doubleStk.push(2.3);       

    intStk.print("intStk after pushing 12:");
    doubleStk.print("doubleStk after pushing 2.3:");

    cout << "\n--- Now push more values with for-loop to trigger resizing ---\n\n";

    for (int i = 0; i < 12; ++i) {
        int val = 100 + i;
        cout << "Pushing int " << val << " ... ";
        intStk.push(val);
        cout << "(size=" << intStk.size() << ", capacity=" << intStk.capacity() << ")\n";
    }

    cout << "\nAfter loop, intStk content:\n";
    intStk.print();

    for (int i = 0; i < 8; ++i) {
        double dv = 3.14 + i * 0.5;
        cout << "Pushing double " << dv << " ... ";
        doubleStk.push(dv);
        cout << "(size=" << doubleStk.size() << ", capacity=" << doubleStk.capacity() << ")\n";
    }

    cout << "\nAfter loop, doubleStk content:\n";
    doubleStk.print();

    cout << "\n--- Demonstrate popping (LIFO) without destroying other stacks' values ---\n\n";
    cout << "Pop top 5 elements from intStk:\n";
    for (int i = 0; i < 5 && !intStk.empty(); ++i) {
        cout << " pop -> " << intStk.top() << "\n";
        intStk.pop();
    }
    cout << "intStk now:\n";
    intStk.print();

    cout << "\nFull demo finished.\n";
    return 0;
}