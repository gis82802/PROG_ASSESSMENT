#include <iostream>
#include <vector>
using namespace std;


template <typename T>
class MyStack {
private:
	vector<T> data;
	size_t lastCapacity;

public:
	MyStack() : lastCapacity(0) {}

	void push(const T& value) {
		size_t before = data.capacity();
		data.push_back(value);
		size_t after = data.capacity();
		if (after != before) {
			
			cout << "�e�q " << before << " �W�[�� " << after << endl;
		}
	}

	bool isEmpty() const { return data.empty(); }

	void printStack() const {
		cout << "[ ";
		for (size_t i = 0; i < data.size(); ++i) {
			cout << data[i];
			if (i != data.size() - 1) cout << " ";
		}
		cout << " ]" << endl;
	}
	void printStacka() const {
		cout << "[ ";
		for (size_t i =1 ; i < data.size(); ++i) {
			cout << data[i];
			if (i != data.size() - 1) cout << " ";
		}
		cout << " ]" << endl;
	}
};


int main() {
	MyStack<int> intStk;
	MyStack<double> doubleStk;

	
	intStk.push(12);
	intStk.printStack();

	doubleStk.push(2.3);
	doubleStk.printStack();

	
	for (int i = 0; i <= 10; ++i) {
		intStk.push(12 + i);
		doubleStk.push(2.3 + i * 0.2);
	}

	cout << endl;
	intStk.printStacka();
	cout << endl;
	doubleStk.printStacka();

	return 0;
}
