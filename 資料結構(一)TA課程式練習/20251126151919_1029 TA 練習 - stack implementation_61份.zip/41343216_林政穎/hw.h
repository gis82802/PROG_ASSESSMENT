#ifndef HW_H
#define HW_H

#include <iostream>
#include <stdexcept>
#include <initializer_list>
#include <utility> // move, forward
#include <type_traits>

using namespace std;

template<typename T>
class MyStack {
public:
    MyStack() : _data(nullptr), _cap(0), _sz(0) { reserve(4); }

    explicit MyStack(size_t reserve_cap) : _data(nullptr), _cap(0), _sz(0) {
        reserve(reserve_cap);
    }

    MyStack(initializer_list<T> init) : _data(nullptr), _cap(0), _sz(0) {
        reserve(init.size());
        for (const T& v : init) push(v);
    }

    // copy ctor
    MyStack(const MyStack& other) : _data(nullptr), _cap(0), _sz(0) {
        reserve(other._sz);
        for (size_t i = 0; i < other._sz; ++i)
            new(&_data[i]) T(other._data[i]);
        _sz = other._sz;
    }

    // move ctor
    MyStack(MyStack&& other) noexcept
        : _data(other._data), _cap(other._cap), _sz(other._sz) {
        other._data = nullptr; other._cap = 0; other._sz = 0;
    }

    // copy assign
    MyStack& operator=(const MyStack& other) {
        if (this == &other) return *this;
        clear();
        reserve(other._sz);
        for (size_t i = 0; i < other._sz; ++i)
            new(&_data[i]) T(other._data[i]);
        _sz = other._sz;
        return *this;
    }

    // move assign
    MyStack& operator=(MyStack&& other) noexcept {
        if (this == &other) return *this;
        destroy_buffer();
        _data = other._data; _cap = other._cap; _sz = other._sz;
        other._data = nullptr; other._cap = 0; other._sz = 0;
        return *this;
    }

    ~MyStack() { destroy_buffer(); }

    // push (copy)
    void push(const T& value) {
        ensure_capacity_for_push();
        new(&_data[_sz]) T(value);
        ++_sz;
    }

    // push (move)
    void push(T&& value) {
        ensure_capacity_for_push();
        new(&_data[_sz]) T(move(value));
        ++_sz;
    }

    template<typename... Args>
    void emplace(Args&&... args) {
        ensure_capacity_for_push();
        new(&_data[_sz]) T(forward<Args>(args)...);
        ++_sz;
    }

    void pop() {
        if (empty()) throw out_of_range("pop() on empty stack");
        --_sz;
        _data[_sz].~T();
    }

    T& top() {
        if (empty()) throw out_of_range("top() on empty stack");
        return _data[_sz - 1];
    }

    const T& top() const {
        if (empty()) throw out_of_range("top() on empty stack");
        return _data[_sz - 1];
    }

    bool empty() const noexcept { return _sz == 0; }
    size_t size() const noexcept { return _sz; }
    size_t capacity() const noexcept { return _cap; }

    // explicit reserve (will print if capacity increases)
    void reserve(size_t new_cap) {
        if (new_cap <= _cap) return;
        cout << "[MyStack] Resizing capacity: " << _cap << " -> " << new_cap << endl;
        T* new_buf = static_cast<T*>(::operator new(sizeof(T) * new_cap));
        for (size_t i = 0; i < _sz; ++i) {
            new(&new_buf[i]) T(move(_data[i]));
            _data[i].~T();
        }
        ::operator delete(_data);
        _data = new_buf;
        _cap = new_cap;
    }

    // �C�X���|���e�]�q top -> bottom�^�A���|���� stack ����
    void print(const string& label = "") const {
        if (!label.empty()) cout << label << "\n";
        cout << "Top -> Bottom (size=" << _sz << ", capacity=" << _cap << "): ";
        if (_sz == 0) {
            cout << "[empty]\n";
            return;
        }
        // �� top �� bottom �C�X
        for (size_t i = 0; i < _sz; ++i) {
            size_t idx = _sz - 1 - i;
            // ��X�����]�Y T �O�r���r��ξ�ơB�B�I�ƩΤ䴩 operator<< �������^
            cout << _data[idx];
            if (i + 1 < _sz) cout << " | ";
        }
        cout << "\n";
    }

private:
    T* _data;
    size_t _cap;
    size_t _sz;

    void ensure_capacity_for_push() {
        if (_sz >= _cap) {
            size_t new_cap = (_cap == 0) ? 4 : (_cap * 2);
            reserve(new_cap);
        }
    }

    void clear() noexcept {
        while (_sz) {
            --_sz;
            _data[_sz].~T();
        }
    }

    void destroy_buffer() noexcept {
        if (!_data) return;
        for (size_t i = 0; i < _sz; ++i) _data[i].~T();
        ::operator delete(_data);
        _data = nullptr; _cap = 0; _sz = 0;
    }
};

#endif // HW_H
#pragma once
