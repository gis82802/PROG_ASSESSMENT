#include <iostream>
#include "MyStack.hpp"

int main() {

    MyStack<int> intStk;
    std::cout << "Demonstrating MyStack<int>:" << std::endl;
    intStk.push(12);
    std::cout << "Pushed 12 to intStk. Size: " << intStk.size() << std::endl;


    intStk.push(5);
    intStk.push(8);
    intStk.push(1);
    intStk.push(9);

    for (int i = 1; i <= 8; ++i) {
        intStk.push(10 + i * 2);
    }
    std::cout << "After pushing multiple value, size: " << intStk.size() << std::endl;

    intStk.sort();
    intStk.print();

    MyStack<double> doubleStk;
    std::cout << "\nDemonstrating MyStack<double>:" << std::endl;
    doubleStk.push(2.3);
    std::cout << "Pushed 2.3 to doubleStk. Size: " << doubleStk.size() << std::endl;


    doubleStk.push(1.5);
    doubleStk.push(4.7);
    doubleStk.push(0.9);

    for (int i = 1; i <= 8; ++i) {
        doubleStk.push(static_cast<double>(i) * 0.5 + 3.0);
    }
    std::cout << "After pushing multiple values, size: " << doubleStk.size() << std::endl;

    doubleStk.sort();
    doubleStk.print();

    return 0;
}