#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <vector>
#include <stdexcept>
#include <iostream>
#include <algorithm>

template <typename T>
class MyStack {
private:
    std::vector<T> stk;
    size_t capacity;

public:
    MyStack() : capacity(10) {
        stk.reserve(capacity);
    }

    void push(const T& value) {
        if (stk.size() == capacity) {
            size_t new_capacity = capacity * 2;
            stk.reserve(new_capacity);
            std::cout << "Resizing stack capacity from " << capacity << " to " << new_capacity << std::endl;
            capacity = new_capacity;
        }
        stk.push_back(value);
    }

    T pop() {
        if (stk.empty()) {
            throw std::runtime_error("Stack is empty");
        }
        T top_val = stk.back();
        stk.pop_back();
        return top_val;
    }

    T top() const {
        if (stk.empty()) {
            throw std::runtime_error("Stack is empty");
        }
        return stk.back();
    }

    bool empty() const {
        return stk.empty();
    }

    size_t size() const {
        return stk.size();
    }

    void sort() {
        if (!stk.empty()) {
            std::sort(stk.begin(), stk.end());
            std::cout << "Stack sorted in ascending order." << std::endl;
        }
    }

    void print() const {
        std::cout << "Stack content (bottom to top): ";
        for (const auto& item : stk) {
            std::cout << item << " ";
        }
        std::cout << std::endl;
    }
};

#endif // MYSTACK_HPP