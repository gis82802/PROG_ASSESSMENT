#include "MyStack.hpp"
#include <algorithm> 
using namespace std;

template <class T>
void ChangeSizeID(T*& a, const int oldsize, const int newsize) {
    if (newsize < 0)
        throw "New length must be > 0";

    cout << "capacity " << oldsize << " is increased to " << newsize << endl;

    T* temp = new T[newsize];
    int num = min(oldsize, newsize);
    copy(a, a + num, temp);
    delete[] a;
    a = temp;
}

template <class T>
MyStack<T>::MyStack(int stackcapacity) : capacity(stackcapacity) {
    if (capacity < 1)
        throw "stack capacity must be > 0";

    stack = new T[capacity];
    top = -1;
}

template <class T>
bool MyStack<T>::IsEmpty() const {
    return top == -1;
}

template <class T>
T& MyStack<T>::Top() const {
    if (IsEmpty())
        throw "stack is empty";
    return stack[top];
}

template <class T>
void MyStack<T>::Push(const T& item) {
    if (top == capacity - 1) { 
        ChangeSizeID(stack, capacity, capacity * 2);
        capacity *= 2;
    }
    stack[++top] = item;
}

template <class T>
void MyStack<T>::Pop() {
    if (IsEmpty())
        throw "Stack is empty. Cannot pop.";
    top--;
}

template <class T>
void MyStack<T>::Print() {
    cout << "[Stack contents] ";
    for (int i = 0; i <= top; i++)
        cout << stack[i] << " ";
    cout << endl;
}


int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << "---- Push single element ----" << endl;
    intStk.Push(12);
    doubleStk.Push(2.3);
    intStk.Print();
    doubleStk.Print();

    cout << "\n---- Push multiple elements to trigger expansion ----" << endl;
    for (int i = 0; i < 20; i++) {
        intStk.Push(i);
        doubleStk.Push(i * 0.4);
    }

    intStk.Print();
    intStk.Pop(); intStk.Pop(); intStk.Pop();
    intStk.Print();

    doubleStk.Print();
    doubleStk.Pop(); doubleStk.Pop();
    doubleStk.Print();

    return 0;
}