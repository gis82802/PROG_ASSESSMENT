#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
using namespace std;

template <class T>
class MyStack {
public:
    MyStack(int stackcapacity = 4); 
    bool IsEmpty() const;           // 檢查是否為空
    T& Top() const;                 
    void Push(const T& item);       // 推入新元素
    void Pop();                   
    void Print();                  

private:
    T* stack;       // 指向堆疊的陣列
    int top;        // 指向堆疊頂端
    int capacity;   // 目前容量
};

template <class T>
void ChangeSizeID(T*& a, const int oldsize, const int newsize);

#endif
