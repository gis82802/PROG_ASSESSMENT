#ifndef MYSTACK_HPP
#define MYSTACK_HPP
#include <iostream>
#include <algorithm>
using namespace std;

template <class T>
void changeSize1D(T*& a, const int oldSize, const int newSize) {
    if (newSize < oldSize) {
        return;
    }
    cout << "�®e�q= " << oldSize << " �X�i��" << newSize << endl;
    T* temp = new T[newSize];
    for (int i = 0; i < oldSize; i++) {
        temp[i] = a[i];
    }
    if (a != NULL ){
        delete [] a;
    }
    a = temp;
}

template <class T>
class MyStack {
private:
    T *array;
    int capacity;
    int top;

public:
    MyStack(int initialCapacity = 4) : capacity(initialCapacity), top(-1) {
        if (initialCapacity < 1) capacity = 1;
        array = new T[capacity];
    }

    ~MyStack() {
        delete [] array;
    }

    bool isEmpty() const {
        return top == -1;
    }

    int getCapacity() const {
        return capacity;
    }

    int size() const {
        return top + 1;
    }

    void push(const T& x) {
        if (top == capacity - 1) {
            int newCapacity = capacity * 2;
            changeSize1D(array, capacity, newCapacity);
            capacity = newCapacity;
        }
        top++;
        array[top] = x;
    }

    void pop() {
        if (isEmpty()) {
            throw "���|���šA�L�k���X���";
        }
        top--;
    }

    T& getTop() {
        if (isEmpty()) {
             throw "���|���šA�L�̤W�h����";
        }
        return array[top];
    }
};

#endif 

