#include <iostream>
#include <stdexcept>
#include <typeinfo>
#include <utility>  


template <typename T>
class MyStack {
private:
    T* data_;
    size_t n_;
    size_t cap_;

    void ensureCapacity(size_t need) {
        if (need <= cap_) return;
        size_t old = cap_;
        cap_ = (cap_ == 0 ? 2 : cap_ * 2);
        while (cap_ < need) cap_ *= 2;

        T* nd = new T[cap_];
        for (size_t i = 0; i < n_; ++i) nd[i] = std::move(data_[i]);
        delete[] data_;
        data_ = nd;

        std::cout << "[MyStack<" << typeid(T).name() << ">] capacity grow "
            << old << " -> " << cap_ << " (size=" << n_ << ")\n";
    }
public:
    MyStack() : data_(nullptr), n_(0), cap_(0) {}
    ~MyStack() { delete[] data_; }

    // Rule of Five
    MyStack(const MyStack& other) : data_(nullptr), n_(other.n_), cap_(other.cap_) {
        if (cap_) {
            data_ = new T[cap_];
            for (size_t i = 0; i < n_; ++i) data_[i] = other.data_[i];
        }
    }
    MyStack(MyStack&& other) noexcept : data_(other.data_), n_(other.n_), cap_(other.cap_) {
        other.data_ = nullptr; other.n_ = other.cap_ = 0;
    }
    MyStack& operator=(MyStack other) { swap(other); return *this; }

    void swap(MyStack& o) noexcept {
        std::swap(data_, o.data_);
        std::swap(n_, o.n_);
        std::swap(cap_, o.cap_);
    }

    // �򥻾ާ@
    void push(const T& value) {
        ensureCapacity(n_ + 1);
        data_[n_++] = value;
    }
    void push(T&& value) {
        ensureCapacity(n_ + 1);
        data_[n_++] = std::move(value);
    }
    void pop() {
        if (empty()) throw std::out_of_range("pop from empty MyStack");
        --n_;
    }
    T& top() {
        if (empty()) throw std::out_of_range("top from empty MyStack");
        return data_[n_ - 1];
    }
    const T& top() const {
        if (empty()) throw std::out_of_range("top from empty MyStack");
        return data_[n_ - 1];
    }

    bool   empty()    const { return n_ == 0; }
    size_t size()     const { return n_; }
    size_t capacity() const { return cap_; }


};
