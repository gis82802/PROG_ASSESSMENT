#include <iostream>
#include <stdexcept>
#include <typeinfo>
#include <utility>   // std::move

// =======================
//  Template class MyStack
// =======================
template <typename T>
class MyStack {
public:
    MyStack() : arr_(nullptr), n_(0), cap_(0) {}
    ~MyStack() { delete[] arr_; }

    // �`����
    MyStack(const MyStack& o) : arr_(nullptr), n_(o.n_), cap_(o.cap_) {
        if (cap_ > 0) {
            arr_ = new T[cap_];
            for (int i = 0; i < n_; ++i) arr_[i] = o.arr_[i];
        }
    }
    MyStack& operator=(const MyStack& o) {
        if (this == &o) return *this;
        T* nd = (o.cap_ > 0 ? new T[o.cap_] : nullptr);
        for (int i = 0; i < o.n_; ++i) nd[i] = o.arr_[i];
        delete[] arr_;
        arr_ = nd;
        n_ = o.n_;
        cap_ = o.cap_;
        return *this;
    }

    // ����
    MyStack(MyStack&& o) noexcept : arr_(o.arr_), n_(o.n_), cap_(o.cap_) {
        o.arr_ = nullptr; o.n_ = 0; o.cap_ = 0;
    }
    MyStack& operator=(MyStack&& o) noexcept {
        if (this == &o) return *this;
        delete[] arr_;
        arr_ = o.arr_; n_ = o.n_; cap_ = o.cap_;
        o.arr_ = nullptr; o.n_ = 0; o.cap_ = 0;
        return *this;
    }

    // �򥻾ާ@
    bool empty()  const { return n_ == 0; }
    int  size()   const { return n_; }
    int  capacity() const { return cap_; }

    void push(const T& v) { ensure(n_ + 1); arr_[n_++] = v; }
    void push(T&& v) { ensure(n_ + 1); arr_[n_++] = std::move(v); }

    void pop() {
        if (empty()) throw std::out_of_range("pop from empty MyStack");
        --n_;
    }
    T& top() {
        if (empty()) throw std::out_of_range("top from empty MyStack");
        return arr_[n_ - 1];
    }
    const T& top() const {
        if (empty()) throw std::out_of_range("top from empty MyStack");
        return arr_[n_ - 1];
    }

private:
    T* arr_;
    int n_;
    int cap_;

    void ensure(int need) {
        if (need <= cap_) return;
        int old = cap_;
        int newcap = (cap_ <= 0 ? 2 : cap_);
        while (newcap < need) {
            if (newcap > 1000000000 / 2)
                throw std::length_error("MyStack capacity overflow (int)");
            newcap *= 2;
        }
        T* nd = new T[newcap];
        for (int i = 0; i < n_; ++i) nd[i] = std::move(arr_[i]);
        delete[] arr_;
        arr_ = nd;
        cap_ = newcap;

        std::cout << "[MyStack<" << typeid(T).name()
            << ">] capacity grow " << old << " -> " << cap_
            << " (size=" << n_ << ")\n";
    }
};

// �C�X���|�G�� top -> bottom�]�έȶǻ��ƥ��A���}�a����|�^
template <typename T>
void listStack(MyStack<T> s) {
    std::cout << "[top] ";
    while (!s.empty()) {
        std::cout << s.top() << " ";
        s.pop();
    }
    std::cout << "[bottom]\n";
}

