#include "senser.hpp"
int main() {
    MyStack<int>    intStk;
    MyStack<double> doubleStk;

    // 1) ���U�ۥu push �@��
    intStk.push(12);
    
    doubleStk.push(2.3);

    for (int i = 0; i < 20; ++i) {
        intStk.push(100 + i);          
        doubleStk.push(3.0 + i * 0.1); 
    }

    std::cout << "\nintStk contents:   ";
    listStack(intStk);

    std::cout << "doubleStk contents: ";
    listStack(doubleStk);

    return 0;
}
