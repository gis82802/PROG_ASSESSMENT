﻿#ifndef MYSTACK_HPP
#define MYSTACK_HPP
#include <iostream>
using namespace std;
template <class T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;
    void resize() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];

        for (int i = 0; i < topIndex; i++)
            newData[i] = data[i];
        delete[] data;
        data = newData;
        cout << "capacity " << capacity << " is increased to " << newCapacity << endl;
        capacity = newCapacity;
    }
public:
    MyStack(int initSize = 4) {
        capacity = initSize;
        data = new T[capacity];
        topIndex = 0;
    }
    ~MyStack() {
        delete[] data;
    }
    void push(const T& value) {
        if (topIndex >= capacity)
            resize();
        data[topIndex++] = value;
    }
    T pop() {
        if (topIndex == 0)
            throw runtime_error("Stack is empty!");
        return data[--topIndex];
    }
    bool isEmpty() const {
        return topIndex == 0;
    }
    int size() const {
        return topIndex;
    }
    void print() const {
        for (int i = 0; i < topIndex; i++)
            cout << data[i] << " ";
        cout << endl;
    }
};
#endif
