﻿#include <iostream>
#include "MyStack.hpp"
using namespace std;

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;
    intStk.push(12);
    doubleStk.push(2.3);
    // 放入 20 筆資料（觸發多次擴充）
    for (int i = 1; i < 20; i++) {
        intStk.push(i);
        doubleStk.push(i * 0.2);
    }
    // 印出所有資料（第一次）
    intStk.print();
    doubleStk.print();
    // 將最後三個數字 POP 掉（各 POP 三次）
    for (int i = 0; i < 3; i++) {
        intStk.pop();
        doubleStk.pop();
    }
    // 再印一次（第二次，應該只剩下 17 筆）
    intStk.print();
    doubleStk.print();

    return 0;
}
