﻿#include <iostream>
using namespace std;

template <typename T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void expandCapacity() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];
        for (int i = 0; i <= topIndex; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
        cout << "容量已擴充至 " << capacity << "！" << endl;
    }

public:
    MyStack(int initialCapacity = 2) {
        capacity = initialCapacity;
        data = new T[capacity];
        topIndex = -1;
    }

    ~MyStack() {
        delete[] data;
    }

    void push(const T& value) {
        if (topIndex + 1 >= capacity) {
            expandCapacity();
        }
        data[++topIndex] = value;
    }

    T pop() {
        if (topIndex < 0) {
            throw runtime_error("堆疊為空，無法彈出！");
        }
        return data[topIndex--];
    }

    T top() const {
        if (topIndex < 0) {
            throw runtime_error("堆疊為空，無法查看頂端元素！");
        }
        return data[topIndex];
    }

    bool empty() const {
        return topIndex == -1;
    }

    int size() const {
        return topIndex + 1;
    }
};