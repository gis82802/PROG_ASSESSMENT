#ifndef CSIE_41343215_1029_1
#define CSIE_41343215_1029_1
#include <iostream>
#include <stdexcept>
#include <algorithm>
using namespace std;
template <class T>
void ChangeSize1D(T*& a, const int oldSize, const int newSize) {
	if (newSize < 0) throw runtime_error("New length must be >= 0");
	cout << "capacity " << oldSize << " is increased to " << newSize << endl;
	T* temp = new T[newSize];
	int number = min(oldSize, newSize);
	for (int i = 0; i < number; i++) temp[i] = a[i];
	delete[] a;
	a = temp;
}
template <class T>
class MyStack {
public:
	MyStack(int stackCapacity = 4);
	~MyStack();
	bool IsEmpty() const;
	T& Top() const;
	void Push(const T& item);
	void Pop();
	void print();
private:
	T* stack;
	int top;
	int capacity;
};
template <class T>
MyStack<T>::MyStack(int stackCapacity) : capacity(stackCapacity) {
	if (capacity < 1) throw runtime_error("Stack capacity must be > 0");
	stack = new T[capacity];
	top = -1;
}
template <class T>
MyStack<T>::~MyStack() {
	delete[] stack;
}
template <class T>
bool MyStack<T>::IsEmpty() const {
	return top == -1;
}
template <class T>
T& MyStack<T>::Top() const {
	if (IsEmpty()) throw out_of_range("Stack is empty. Cannot access Top.");
	return stack[top];
}
template <class T>
void MyStack<T>::Push(const T& item) {
	if (top == capacity - 1) {
		ChangeSize1D(stack, capacity, 2 * capacity);
		capacity *= 2;
	}
	stack[++top] = item;
}
template <class T>
void MyStack<T>::Pop() {
	if (IsEmpty()) throw out_of_range("Stack is empty. cannot delete.");
	stack[top--].~T();
}
template <class T>
void MyStack<T>::print() {
	if (IsEmpty()) {
		cout << endl;
		return;
	}
	for (int i = 0; i < top + 1; i++) cout << stack[i] << " ";
	cout << endl;
}
#endif