#include <iostream>
#include "CSIE_41343215_1029_1.hpp"
using namespace std;
int main(int argc, const char* argv[]) {
    MyStack<int> intStk;
    MyStack<double> doubleStk;
    intStk.Push(12);
    doubleStk.Push(2.3);
    for (int i = 1; i < 20; i++) {
        int j = i * 10 + 12;
        double k = i * 0.2 + 2.3;
        intStk.Push(j);
        doubleStk.Push(k);
    }
    cout << "\n" << endl;
    cout << "intStk full content: ";
    intStk.print();
    cout << "doubleStk full content: ";
    doubleStk.print();
    cout << "\n" << endl;
    if (!intStk.IsEmpty()) {
        cout << "�̤W�h " << intStk.Top() << endl;
        intStk.Pop();
        cout << "pop�� " << intStk.Top() << endl;
    }
    if (!intStk.IsEmpty()) {
        cout << "�̤W�h " << intStk.Top() << endl;
        intStk.Pop();
        cout << "pop�� " << intStk.Top() << endl;
    }
    if (!intStk.IsEmpty()) {
        cout << "�̤W�h " << intStk.Top() << endl;
        intStk.Pop();
        cout << "pop�� " << intStk.Top() << endl;
    }
    cout << "\n" << endl;
    if (!doubleStk.IsEmpty()) {
        cout << "�̤W�h " << doubleStk.Top() << endl;
        doubleStk.Pop();
        cout << "pop�� " << doubleStk.Top() << endl;
    }
    if (!doubleStk.IsEmpty()) {
        cout << "�̤W�h " << doubleStk.Top() << endl;
        doubleStk.Pop();
        cout << "pop�� " << doubleStk.Top() << endl;
    }
    cout << "\n--- Final ---" << endl;
    cout << "intStk final content: ";
    intStk.print();
    cout << "doubleStk final content: ";
    doubleStk.print();
}