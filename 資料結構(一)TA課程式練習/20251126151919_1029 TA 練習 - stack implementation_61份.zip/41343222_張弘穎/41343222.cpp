#include<iostream>
#include "Mystack.hpp"
using namespace std;
int main() {
	MyStack<int> intStk(4);
	int e = 12;
	for (int r = 1; r <= 18; r++) {
		intStk.push(e);
		e += 5;
	}
	intStk.print();
	for (int i = 0; i < 18; i++) {
		intStk.pop();
		intStk.popPrint();
	}
	MyStack<double> doubleStk(4);
	double x = 2.3;
	for (int r = 1; r <= 12; r++) {
		doubleStk.push(x);
		x += 1.2;
	}
	doubleStk.print();
	for (int i = 0; i < 12; i++) {
		doubleStk.pop();
		doubleStk.popPrint();
	}
}