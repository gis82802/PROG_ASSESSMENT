#include<iostream>
using namespace std;
template <class T>
class MyStack {
private:
	T* data;
	int capacity;
	int top = -1;
	void bigsize() {
		int newCapacity = capacity * 2;
		T* newData = new T[newCapacity];
		for (int y = 0; y <= top; y++) {
			newData[y] = data[y];
		}
		cout << "capacity " << capacity << "is increased to" << newCapacity << endl;
		delete[] data;
		data = newData;
		capacity = newCapacity;
	}
public:
	bool isFull() {
		return(top == capacity - 1);
	}
	bool isEmpty() {
		return(top == -1);
	}
	void push(T& it) {
		if (isFull())bigsize();
		data[++top] = it;
	}
	MyStack(int a = 4) {
		capacity = a;
		data = new T[capacity];
		top = -1;
	}
	~MyStack() {
		delete[] data;
	}
	T pop() {
		if (isEmpty()) {
			cout << "堆疊是空的，無法POP" << endl;
			return T();
		}
		return data[top--];
	}
	void print() {
		if (isEmpty()) {
			cout << "空的" << endl;
		}
		else {
			cout << "Stack:";
			for (int i = 0; i <= top; i++) {
				cout << data[i] << " ";
			}
			cout << endl;
		}
	}
	void popPrint() {
		cout << "這次POP的是" << data[top+1]<<endl;
	}
};