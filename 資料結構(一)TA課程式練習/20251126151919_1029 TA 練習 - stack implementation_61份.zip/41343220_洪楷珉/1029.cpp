#include "1029.hpp"
int main(void)
{
    MyStack<int> instack;
    MyStack<float> flstack;
    int a[7] = {63,45,36,89,87,45,147};
    double b[7] = { 1.2,3.6,6.9,8.5,12.1 };
    instack.push(12);
    flstack.push(2.3);
    for (int i = 0; i < 6; i++)
    {
        instack.push(a[i]);
        flstack.push(b[i]);
    }
    std::cout << "���|���e: ";
    instack.print();
    std::cout << "\n";
    flstack.print();

    instack.pop();
    flstack.pop();
    std::cout << "�u�X�@�Ӥ����᪺���e: ";
    std::cout << "\n";
    instack.print();
    
    flstack.print();
    return 0;
}