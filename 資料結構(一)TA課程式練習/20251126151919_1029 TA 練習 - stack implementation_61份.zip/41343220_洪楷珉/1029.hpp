#ifndef STACK_HPP
#define STACK_HPP
#include <iostream>
#include <algorithm> 


template <class T>
class MyStack {
public:
    MyStack(int stackCapacity = 4);   
    ~MyStack();                    

    T& top() const;                   
    bool isEmpty() const;             
    void pop();                       
    void push(const T& item);         
    void print() const;              

private:
    T* stackArray;                    
    int topIndex;                     
    int capacity;                    

    void changeSize(T*& a, const int oldSize, const int newSize);  
};


template <class T>
MyStack<T>::MyStack(int stackCapacity) {
    capacity = stackCapacity;
    stackArray = new T[capacity];      
    topIndex = -1;                     
}


template <class T>
MyStack<T>::~MyStack() {
    delete[] stackArray;             
}

template <class T>
bool MyStack<T>::isEmpty() const {
    return topIndex == -1;            
}


template <class T>
T& MyStack<T>::top() const {
    if (isEmpty()) {
        throw std::out_of_range("���|����!");  
    }
    return stackArray[topIndex];       
}


template <class T>
void MyStack<T>::push(const T& item) {
    if (topIndex == capacity - 1) {    
        changeSize(stackArray, capacity, capacity * 2);  
        capacity *= 2;
    }
    stackArray[++topIndex] = item;    
}


template <class T>
void MyStack<T>::pop() {
    if (isEmpty()) {
        throw std::out_of_range("���|����!�L�k�u�X�����C");  
    }
    --topIndex;  
}


template <class T>
void MyStack<T>::print() const {
    if (isEmpty()) {
        std::cout << "���|����!" << std::endl;
        return;
    }
    for (int i = topIndex; i >= 0; --i) {
        std::cout << stackArray[i] << " ";  
    }
    std::cout << std::endl;
}


template <class T>
void MyStack<T>::changeSize(T*& a, const int oldSize, const int newSize) {
    if (newSize < 0) {
        throw std::invalid_argument("�s�j�p��?�j�󵥩�0");
    }
    //printf("��j�s��");
    T* temp = new T[newSize];                      
    int num = std::min(oldSize, newSize);           
    std::copy(a, a + num, temp);  
    std::cout << "�O�����j��"<<newSize<<"\n";
    delete[] a;                                   
    a = temp;    
    
}

#endif
