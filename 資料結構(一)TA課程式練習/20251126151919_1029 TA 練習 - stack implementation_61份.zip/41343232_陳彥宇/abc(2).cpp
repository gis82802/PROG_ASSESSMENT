#include "MyStack.h"
using namespace std;

int main() {
   
    Stack<int> intStack;
    for (int i = 12; i <= 40; i++) {
        intStack.Push(i);
    }
    cout << "\n=== Integer Stack ===" << endl;
    intStack.Print();

    
    cout << "\nPop all integers:" << endl;
    while (!intStack.IsEmpty()) {
        intStack.Pop();
    }

    
    Stack<double> doubleStack;
    for (double d = 2.3; d <= 40.0; d += 2.3) {
        doubleStack.Push(d);
    }
    cout << "\n=== Double Stack ===" << endl;
    doubleStack.Print();

    cout << "\nPop some doubles:" << endl;
    for (int i = 0; i < 5; ++i) { 
        doubleStack.Pop();
    }

    cout << "\nRemaining double stack:" << endl;
    doubleStack.Print();

    return 0;
}
