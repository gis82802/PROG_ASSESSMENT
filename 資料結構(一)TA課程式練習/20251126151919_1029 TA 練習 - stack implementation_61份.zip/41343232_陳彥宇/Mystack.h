#ifndef Stack_hpp
#define Stack_hpp

#include <iostream>
#include <algorithm>
#include <stdexcept>


template <class T>
void ChangeSize1D(T*& a, const int oldSize, const int newSize) {
    if (newSize < 0) throw std::length_error("New length must be >= 0");
    if (newSize == oldSize) return;

    if (newSize > oldSize) {
        std::cout << "capacity " << oldSize << " is increased to " << newSize << std::endl;
    }

    T* temp = new T[newSize];
    int number = std::min(oldSize, newSize);
    for (int i = 0; i < number; ++i) temp[i] = a[i];
    delete[] a;
    a = temp;
}


template <class T>
class Stack {
public:
    Stack(int stackCapacity = 4);
    ~Stack();

    bool IsEmpty() const;
    T& Top() const;
    void Push(const T& item);
    T Pop();                  
    void Print() const;

private:
    T* stack;
    int topIndex;
    int capacity;
};

template <class T>
Stack<T>::Stack(int stackCapacity) : capacity(stackCapacity), topIndex(-1) {
    if (capacity < 1) throw std::length_error("Stack capacity must be > 0");
    stack = new T[capacity];
}

template <class T>
Stack<T>::~Stack() {
    delete[] stack;
}

template <class T>
bool Stack<T>::IsEmpty() const {
    return topIndex == -1;
}

template <class T>
T& Stack<T>::Top() const {
    if (IsEmpty()) throw std::out_of_range("Stack is empty");
    return const_cast<T&>(stack[topIndex]);
}

template <class T>
void Stack<T>::Push(const T& item) {
    if (topIndex + 1 == capacity) {
        int newCap = capacity * 2;
        ChangeSize1D(stack, capacity, newCap);
        capacity = newCap;
    }
    stack[++topIndex] = item;
}

template <class T>
T Stack<T>::Pop() {
    if (IsEmpty()) throw std::out_of_range("Pop on empty stack");
    T poppedValue = stack[topIndex--];  
    std::cout << "Popped value: " << poppedValue << std::endl;
    return poppedValue;
}

template <class T>
void Stack<T>::Print() const {
    if (IsEmpty()) {
        std::cout << "(empty)" << std::endl;
        return;
    }
    std::cout << "Stack (bottom -> top): ";
    for (int i = 0; i <= topIndex; ++i) {
        std::cout << stack[i];
        if (i != topIndex) std::cout << " ";
    }
    std::cout << std::endl;
}

#endif
