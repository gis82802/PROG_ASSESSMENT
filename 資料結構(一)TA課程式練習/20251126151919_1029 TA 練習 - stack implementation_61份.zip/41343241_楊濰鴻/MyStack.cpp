#include"Mystack2.h"
#include<iostream>
using namespace std;
int main(int args, const char* argv[]){
    MyStack<int> intStk;
    MyStack<double> doubleStk;
    intStk.Push(12);  
    doubleStk.Push(2.3);
    for(int i=0;i<20;i++){
        intStk.Push(i);
        doubleStk.Push(i*0.2);
    }
    intStk.Print();
    doubleStk.Print();

    intStk.Pop(); intStk.Pop(); intStk.Pop();
    doubleStk.Pop(); doubleStk.Pop();
    intStk.Print();
    doubleStk.Print();
    return 0;

}