#ifndef Stack_h
#define Stack_h
#include<stdio.h>
template <class T>
class MyStack{
    public:
    MyStack(int stackcapacity = 4);
    bool IsEmpty() const;
    T& Top() const;
    void Push(const T& item);
    void Pop();
    void Print();
    private:
    T* stack;
    int top;
    int capacity;

};
#endif
