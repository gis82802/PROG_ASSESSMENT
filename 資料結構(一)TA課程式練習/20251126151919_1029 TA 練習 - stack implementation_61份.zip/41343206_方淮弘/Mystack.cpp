#include <iostream>
#include "MyStack.hpp"
using namespace std;

int main(int argc, const char* argv[]) {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    intStk.Push(12);     
    doubleStk.Push(2.3); 

    intStk.Print();
    doubleStk.Print();

    intStk.Pop(); intStk.Pop();
    doubleStk.Pop(); doubleStk.Pop();

    intStk.Print();
    doubleStk.Print();

    system("pause");
    return 0;
}
