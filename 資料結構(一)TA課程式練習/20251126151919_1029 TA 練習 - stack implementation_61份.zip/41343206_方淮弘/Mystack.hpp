#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
#include <algorithm>
using namespace std;

template <class T>
class MyStack {
private:
    T* stack;
    int top;
    int capacity;

    void ChangeSize1D(T*& a, const int oldSize, const int newSize) {
        if (newSize < 0) throw "New length must be >= 0";
        cout << "capacity " << oldSize << " is increased to " << newSize << endl;
        T* temp = new T[newSize];
        int number = min(oldSize, newSize);
        copy(a, a + number, temp);
        delete[] a;
        a = temp;
    }

public:
    MyStack(int stackCapacity = 4) : capacity(stackCapacity) {
        if (capacity < 1) throw "Stack capacity must be > 0";
        stack = new T[capacity];
        top = -1;
    }

    ~MyStack() {
        delete[] stack;
    }

    bool IsEmpty() const {
        return top == -1;
    }

    T& Top() const {
        if (IsEmpty()) throw "Stack is empty";
        return stack[top];
    }

    void Push(int count) {
        cout << "--- int ---" << endl;
        for (int i = 0; i < count; ++i) {
            if (top == capacity - 1) {
                ChangeSize1D(stack, capacity, 2 * capacity);
                capacity *= 2;
            }
            stack[++top] = i;
        }
    }


    void Push(double endValue) {
        cout << "--- double ---" << endl;
        int count = static_cast<int>(endValue * 10);
        for (int i = 0; i < count; ++i) {
            if (top == capacity - 1) {
                ChangeSize1D(stack, capacity, 2 * capacity);
                capacity *= 2;
            }
            stack[++top] = i * 0.1;
        }
    }

    void Pop() {
        if (IsEmpty()) throw "Stack is empty, cannot delete.";
        stack[top--].~T();
    }

    void Print() {
        for (int i = 0; i < top + 1; i++) {
            if (i != 0 && i % 20 == 0)
                cout << stack[i] << endl;
            else
                cout << stack[i] << " ";
        }
        cout << endl;
    }
};

#endif
