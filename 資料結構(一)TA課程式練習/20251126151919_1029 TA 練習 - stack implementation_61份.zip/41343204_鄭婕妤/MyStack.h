#ifndef MyStack_H
#define MyStack_H

#include <iostream>

template <typename T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void resize() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];
        for (int i = 0; i < capacity; i++)
            newData[i] = data[i];
        delete[] data;
        data = newData;
        capacity = newCapacity;
        std::cout << "Resizing stack to capacity " << newCapacity << std::endl;
    }

public:
    MyStack() {
        capacity = 2;
        data = new T[capacity];
        topIndex = -1;
    }

    ~MyStack() {
        delete[] data;
    }

    void push(T value) {
        if (topIndex + 1 == capacity)
            resize();
        data[++topIndex] = value;
    }

    T pop() {
        return data[topIndex--];
    }

    bool isEmpty() {
        return topIndex == -1;
    }
};

#endif
