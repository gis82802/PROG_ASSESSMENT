#include "MyStack.h"

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    intStk.push(1);
    intStk.push(2);
    intStk.push(3);
    intStk.push(4);
    intStk.push(5);
    intStk.push(6);
    intStk.push(7);
    intStk.push(8);
    intStk.push(9);

    doubleStk.push(1.3);
    doubleStk.push(4.9);
    doubleStk.push(6.7);
    doubleStk.push(8.0);
    doubleStk.push(3.7);

    while (!intStk.isEmpty())
        std::cout << "Popped from intStk: " << intStk.pop() << std::endl;

    while (!doubleStk.isEmpty())
        std::cout << "Popped from doubleStk: " << doubleStk.pop() << std::endl;

    return 0;
}
