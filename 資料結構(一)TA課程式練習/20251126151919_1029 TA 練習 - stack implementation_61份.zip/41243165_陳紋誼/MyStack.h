#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>

using namespace std;

template <class T>
class MyStack {
public:
    MyStack(int stackCapacity = 4);
    bool IsEmpty() const;
    T& Top() const;
    void Push(const T& item);
    void Pop();
    void print() const;
    int Size() const { return top + 1; }
    int Capacity() const { return capacity; }

private:
    T* stack;
    int top;
    int capacity;
};

// �ʺA�վ� 1D �}�C�j�p
template <class T>
void ChangeSize1D(T*& a, const int oldSize, const int newSize);

#endif // MYSTACK_HPP