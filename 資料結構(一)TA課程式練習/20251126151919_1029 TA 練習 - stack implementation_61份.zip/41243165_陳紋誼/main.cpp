#include "MyStack.h"
#include "MyStack.cpp"
#include <iostream>

using namespace std;

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    intStk.Push(12);
    doubleStk.Push(2.3);

    for (int i = 0; i < 19; ++i) {
        intStk.Push(i);
        doubleStk.Push(i * 0.2);
    }

    cout << endl;
    intStk.print();
    doubleStk.print();

    for (int i = 0; i < 3; ++i) {
        intStk.Pop();
    }
        
    for (int i = 0; i < 3; ++i) {
        doubleStk.Pop();
    }
        
    intStk.print();
    doubleStk.print();
    cout << "intStk size = " << intStk.Size() << ", capacity = " << intStk.Capacity() << endl;
    cout << "doubleStk size = " << doubleStk.Size() << ", capacity = " << doubleStk.Capacity() << endl;

    return 0;
}