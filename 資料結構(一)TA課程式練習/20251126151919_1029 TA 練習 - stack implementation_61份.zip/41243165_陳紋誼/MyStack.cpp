#include "MyStack.h"
#include <algorithm>
#include <iostream>
using namespace std;

template <class T>
void ChangeSize1D(T*& a, const int oldSize, const int newSize) {
    if (newSize < 0) throw "New length must be >= 0";
    cout << "capacity " << oldSize << " is increased to " << newSize << "\n";
    T* temp = new T[newSize];
    int number = min(oldSize, newSize);
    copy(a, a + number, temp);
    delete[] a;
    a = temp;
}

template <class T>
MyStack<T>::MyStack(int stackCapacity) : stack(nullptr), top(-1), capacity(stackCapacity) {
    if (capacity < 1) throw "Stack capacity must be > 0";
    stack = new T[capacity];
}

template <class T>
inline bool MyStack<T>::IsEmpty() const { 
    return top == -1;
}

template <class T>
inline T& MyStack<T>::Top() const {
    if (IsEmpty()) throw "Stack is empty";
    return stack[top];
}

template <class T>
void MyStack<T>::Push(const T& x) {
    if (top == capacity - 1) {
        ChangeSize1D(stack, capacity, 2 * capacity);
        capacity *= 2;
    }
    stack[++top] = x;
}

template <class T>
void MyStack<T>::Pop() {
    if (IsEmpty()) throw "Stack is empty, cannot delete.";
    stack[top--].~T();
}

template <class T>
void MyStack<T>::print() const {
    for (int i = 0; i <= top; ++i) {
        if (i != 0 && i % 20 == 0) {
            cout << stack[i] << endl;
        }
        else {
            cout << stack[i] << " ";
        }
    }
    cout << endl;
}