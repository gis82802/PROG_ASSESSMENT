#include "MyStack.hpp"

int main() {
	MyStack<int> intStk;
	MyStack<float> floatStk;
	intStk.push(12);
	floatStk.push(2.3);
	for (int i = 0; i < 10; i++) {
		intStk.push(i);
		floatStk.push(0.2*i);
	}
	intStk.print();
	floatStk.print();
}