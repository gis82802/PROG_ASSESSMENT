// MyStack.hpp

#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
using namespace std;

template <class T>
class MyStack {
private:
    int top, size;
    T* stack;

public:
    // Constructor with an optional initial size (default 4)
    MyStack(int Initialize = 4) {
        size = Initialize;
        top = -1;
        stack = new T[size];
    }

    // Check the size of the stack and expand if needed
    void CheckSize(T*& stack, int& top, int& size) {
        size *= 2;  // Double the size
        T* bustack = new T[size];  // New temporary stack

        for (int i = 0; i <= top; i++) {
            bustack[i] = stack[i];  // Copy old stack into new stack
        }

        delete[] stack;  // Delete old stack
        stack = bustack;  // Assign new stack
        cout << "Stack size increased from " << size / 2 << " to " << size << "." << endl;
    }

    // Push a new item onto the stack
    void push(T data) {
        top++;
        if (top == size) {
            CheckSize(stack, top, size);  // Expand stack if needed
        }
        stack[top] = data;
    }

    // Pop the top item from the stack
    void pop() {
        if (top == -1) {
            throw "Stack is empty";  // Throw exception if stack is empty
        }
        top--;  // Just decrease top (no need to explicitly call destructor)
    }

    // Print the contents of the stack
    void print() {
        for (int i = 0; i <= top; i++) {
            if (i != 0 && i % 20 == 0) cout << endl;  // Print every 20 items in new line
            cout << stack[i] << " ";
        }
        cout << endl;  // Print newline at the end
    }

    // Destructor to release allocated memory
    ~MyStack() {
        delete[] stack;
    }
};

#endif // MYSTACK_HPP
