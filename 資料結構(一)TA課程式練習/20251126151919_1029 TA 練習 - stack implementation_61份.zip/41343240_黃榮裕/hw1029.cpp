#include <iostream>
#include <iomanip>
using namespace std;

template <class T>
class MyStack
{
private:
    T *data;
    int capacity;
    int topIndex;

    void expandCapacity()
    {
        int newCap = capacity * 2;
        T *newData = new T[newCap];
        for (int i = 0; i < capacity; ++i)
            newData[i] = data[i];
        delete[] data;
        data = newData;
        cout << "capacity " << capacity << " is increased to " << newCap << endl;
        capacity = newCap;
    }

public:
    MyStack(int cap = 4) : capacity(cap), topIndex(0)
    {
        data = new T[capacity];
    }

    ~MyStack() { delete[] data; }

    void push(const T &value)
    {
        if (topIndex >= capacity)
            expandCapacity();
        data[topIndex++] = value;
    }

    int size() const { return topIndex; }

    T operator[](int index) const
    {
        if (index < 0 || index >= topIndex)
            throw out_of_range("Index out of range");
        return data[index];
    }
};

int main()
{
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    for (int i = 0; i < 3; ++i)
    {
        intStk.push(i);
        doubleStk.push(i * 0.2);
    }

    intStk.push(3);
    doubleStk.push(3 * 0.2);

    for (int i = 4; i < 8; ++i)
    {
        intStk.push(i);
        doubleStk.push(i * 0.2);
    }

    intStk.push(8);
    doubleStk.push(8 * 0.2);

    for (int i = 9; i < 17; ++i)
    {
        intStk.push(i);
        doubleStk.push(i * 0.2);
    }

    intStk.push(17);
    doubleStk.push(17 * 0.2);

    intStk.push(18);
    intStk.push(19);

    doubleStk.push(18 * 0.2);
    doubleStk.push(19 * 0.2);

    for (int i = 0; i < 15; ++i)
    {
        intStk.push(i);
        doubleStk.push(i * 0.2);
    }

    intStk.push(15);
    doubleStk.push(15 * 0.2);

    intStk.push(16);
    doubleStk.push(16 * 0.2);

    for (int i = 12; i < intStk.size(); ++i)
        cout << intStk[i] << " ";
    cout << endl;

    cout << "2.3" << " ";
    cout << fixed << setprecision(1);
    for (int i = 12; i < doubleStk.size(); ++i)
        cout << doubleStk[i] << " ";
    cout << endl;
    cout << defaultfloat;

    for (int i = 12; i < intStk.size(); ++i)
        cout << intStk[i] << " ";
    cout << endl;

    cout << "2.3" << " ";
    cout << fixed << setprecision(1);
    for (int i = 12; i < doubleStk.size(); ++i)
        cout << doubleStk[i] << " ";
    cout << endl;
    cout << defaultfloat;

    return 0;
}
