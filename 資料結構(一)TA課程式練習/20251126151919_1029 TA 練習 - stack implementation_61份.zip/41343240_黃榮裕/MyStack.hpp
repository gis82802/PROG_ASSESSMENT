#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
#include <stdexcept>
using namespace std;

template <class T>
class MyStack
{
private:
    T *data;
    int capacity;
    int topIndex;

    void expandCapacity()
    {
        int newCap = capacity * 2;
        T *newData = new T[newCap];
        for (int i = 0; i < capacity; ++i)
            newData[i] = data[i];
        delete[] data;
        data = newData;
        cout << "capacity " << capacity << " is increased to " << newCap << endl;
        capacity = newCap;
    }

public:
    MyStack(int cap = 4) : capacity(cap), topIndex(0)
    {
        data = new T[capacity];
    }

    ~MyStack() { delete[] data; }

    void push(const T &value)
    {
        if (topIndex >= capacity)
            expandCapacity();
        data[topIndex++] = value;
    }

    int size() const { return topIndex; }

    T operator[](int index) const
    {
        if (index < 0 || index >= topIndex)
            throw out_of_range("Index out of range");
        return data[index];
    }
};

#endif
