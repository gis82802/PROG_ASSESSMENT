#pragma once
#ifndef pj_H
#define pj_H
#include <iostream>
using namespace std;

template <class T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void resize() {
        int newCapacity = capacity *2;
        T* newData = new T[newCapacity];

        
        for (int i = 0; i < topIndex; ++i) {
            newData[i] = data[i];
        }
        cout << "�q" << capacity ;
        delete[] data;
        data = newData;
        capacity = newCapacity;
        cout << "�X�R�� " << newCapacity << endl;
        
    }

public:

    MyStack(int initialCapacity = 2)
        : capacity(initialCapacity), topIndex(0) {
        data = new T[capacity];
    }


    ~MyStack() {
        delete[] data;
    }

    void push(const T& value) {
        if (topIndex == capacity) {
            resize();
        }
        data[topIndex++] = value;
    }

    void pop() {
        if (isEmpty()) {
            cout << "�S�����\n";
            return;
        }
        --topIndex;
    }

    T top() const {
        if (isEmpty()) {
            throw runtime_error("�S�����");
        }
        return data[topIndex - 1];
    }

    bool isEmpty() const {
        return topIndex == 0;
    }

    int size() const {
        return topIndex;
    }
    void print()const {
        if (isEmpty()) {
            cout << "�S�����";
            return;
        }
        cout << "���|:";
        for (int i = 0; i< topIndex ; ++i) {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};
#endif
