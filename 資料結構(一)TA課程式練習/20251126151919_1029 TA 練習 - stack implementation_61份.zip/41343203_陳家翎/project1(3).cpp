#include <iostream>
#include "pj.H"

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << "int ���|\n";
    intStk.push(12);
    intStk.print();
    cout << "\ndouble ���|\n";
    doubleStk.push(2.3);
    doubleStk.print();
    cout << "\n" ;

    for (int i = 1; i <= 10; i++) {
        intStk.push(i);
    }
    intStk.print();
    for (int i = 11; i  >=0; i--) {
      intStk.pop();
    }
    for (double j = 1; j <=10; j++) {
        doubleStk.push(0.1*j+2.3);
    }
    doubleStk.print();

    return 0;
}
