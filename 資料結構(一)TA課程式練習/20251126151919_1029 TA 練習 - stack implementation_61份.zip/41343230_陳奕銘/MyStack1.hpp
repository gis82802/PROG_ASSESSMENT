#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>

template <typename T>
class MyStack {
private:
    T* stack;
    int top;
    int capacity;

    void resize() {
        int newCapacity = capacity * 2;
        std::cout << "�e�q�w�X�R�� " << newCapacity << "!" << std::endl;

        T* newStack = new T[newCapacity];
        for (int i = 0; i <= top; ++i) {
            newStack[i] = stack[i];
        }
        delete[] stack;
        stack = newStack;
        capacity = newCapacity;
    }

public:
    MyStack() {
        capacity = 2;
        stack = new T[capacity];
        top = -1;
    }

    ~MyStack() {
        delete[] stack;
    }

    bool isEmpty() {
        return (top == -1);
    }

    void push(T item) {
        if (top + 1 == capacity) {
            resize();
        }
        top++;
        stack[top] = item;
    }

    T pop() {
        if (isEmpty()) {
            std::cerr << "���~�G���ձq�Ű��|�� pop ��ơI" << std::endl;
            return T();
        }
        return stack[top--];
    }
};

#endif // MYSTACK_HPP