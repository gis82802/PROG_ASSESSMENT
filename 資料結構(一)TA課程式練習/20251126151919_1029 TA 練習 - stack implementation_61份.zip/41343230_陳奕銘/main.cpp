#include <iostream>
#include "MyStack1.hpp"

using namespace std;

int main() {

    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << ">>> �����J�򥻸�ơG" << endl;

    for (int i = 0; i < 20; ++i) {
        intStk.push(i);
    }

    doubleStk.push(2.3);
    for (double d = 0.5; d <= 19.5; d += 1.0) {
        doubleStk.push(d);
    }

    cout << endl;
    cout << ">>> �̫���|���e�G=========" << endl;

    cout << "int ���| (�q���쩳)�G";
    while (!intStk.isEmpty()) {
        cout << intStk.pop() << " ";
    }
    cout << endl;

    cout << "double ���| (�q���쩳)�G";
    while (!doubleStk.isEmpty()) {
        cout << doubleStk.pop() << " ";
    }
    cout << endl;

    return 0;
}