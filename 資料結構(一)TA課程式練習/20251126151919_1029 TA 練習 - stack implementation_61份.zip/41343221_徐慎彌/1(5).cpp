#include <iostream>
#include "MyStack.hpp"
#include <iomanip>

using namespace std;

template <typename T>
void printStackElements(const MyStack<T>& stk) {
    cout << std::fixed << std::setprecision(1);
    for (int i = 0; i < stk.size(); ++i) {
        cout << stk.get_data_at(i) << " ";
    }
    cout << endl;
}

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    intStk.push(12);
    doubleStk.push(2.3);

    cout << "Int Stack: ";
    printStackElements(intStk);
    cout << "Double Stack: ";
    printStackElements(doubleStk);
    cout << endl;

    for (int i = 1; i <= 10; ++i) {
        intStk.push(12 + i);
        doubleStk.push(2.3 + i * 0.5);
    }

    cout << "\nInt Stack after resize: ";
    printStackElements(intStk);

    cout << "Double Stack after resize: ";
    printStackElements(doubleStk);


    intStk.pop();
    doubleStk.pop();

    cout << "Int Stack after one pop: ";
    printStackElements(intStk);

    cout << "Double Stack after one pop: ";
    printStackElements(doubleStk);

    return 0;
}
