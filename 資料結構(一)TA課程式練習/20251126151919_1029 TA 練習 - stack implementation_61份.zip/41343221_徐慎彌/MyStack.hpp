#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
#include <stdexcept>

template <typename T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void resize() {
        int oldCapacity = capacity;
        int newCapacity = capacity * 2;

        std::cout << "capacity " << oldCapacity
            << " is increased to " << newCapacity << std::endl;

        T* newData = new T[newCapacity];
        for (int i = 0; i < capacity; ++i)
            newData[i] = data[i];

        delete[] data;
        data = newData;
        capacity = newCapacity;
    }

public:
    MyStack(int initialCapacity = 4)
        : capacity(initialCapacity), topIndex(0) {
        data = new T[initialCapacity];
    }

    ~MyStack() {
        delete[] data;
    }

    void push(const T& value) {
        if (topIndex >= capacity)
            resize();
        data[topIndex++] = value;
    }

    void pop() {
        if (!isEmpty())
            --topIndex;
        else
            std::cout << "Stack is empty. Cannot pop." << std::endl;
    }

    T top() const {
        if (!isEmpty())
            return data[topIndex - 1];
        throw std::out_of_range("Stack is empty");
    }

    bool isEmpty() const {
        return topIndex == 0;
    }

    int size() const {
        return topIndex;
    }

    T get_data_at(int index) const {
        if (index >= 0 && index < topIndex)
            return data[index];
        throw std::out_of_range("Index out of bounds");
    }
};

#endif
