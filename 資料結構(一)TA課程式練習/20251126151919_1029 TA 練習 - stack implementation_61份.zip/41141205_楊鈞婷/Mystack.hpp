#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
#include <iomanip>  // ����B�I�ƿ�X
using namespace std;

template <typename T>
class MyStack {
private:
    T* data;
    int capacity;
    int top;

    void expand(); // �۰��X�R�e�q

public:
    MyStack();
    ~MyStack();

    void push(const T& value);
    void pop();
    T peek();

    bool isEmpty();
    bool isFull();

    void print();   // �L�X�ثe�Ҧ�����
};

#endif
