﻿#include <iostream>
#include "MyStack.hpp"
using namespace std;

int main() {

    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << "=== 整數堆疊 ===" << endl;
    intStk.push(12);  // 題目要求
    for (int i = 2; i <= 12; i++)
        intStk.push(i * 10);   // 其他數值

    cout << "\n=== 浮點數堆疊 ===" << endl;
    doubleStk.push(2.3);  // 題目要求
    for (int i = 2; i <= 12; i++)
        doubleStk.push(i * 1.1);  // 其他數值

    cout << "\n=== 整數堆疊最後所有內容 ===" << endl;
    intStk.print();

    cout << "=== 浮點數堆疊最後所有內容 ===" << endl;
    doubleStk.print();

    return 0;
}
