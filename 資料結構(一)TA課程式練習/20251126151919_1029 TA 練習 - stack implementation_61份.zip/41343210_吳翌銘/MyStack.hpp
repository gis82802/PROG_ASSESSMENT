#include <iostream>
using namespace std;
template <typename T>
class MyStack {
private:
    T* data;          // 儲存資料的動態陣列
    int capacity;     // 目前容量
    int topIndex;     // 栈頂索引

    void expandCapacity() {
        int newCapacity = capacity * 2;  // 容量加倍
        T* newData = new T[newCapacity];
        for (int i = 0; i <= topIndex; ++i) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
        cout << "容量不足，自動擴充至 " << capacity << "!" << endl;
    }

public:
    MyStack(int initCapacity = 2) { // 預設容量為2
        capacity = initCapacity;
        data = new T[capacity];
        topIndex = -1;
    }

    ~MyStack() {
        delete[] data;
    }

    void push(T value) {
        if (topIndex + 1 >= capacity) {
            expandCapacity();
        }
        data[++topIndex] = value;
    }

    T pop() {
        if (topIndex < 0) {
            throw runtime_error("Stack is empty!");
        }
        return data[topIndex--];
    }

    bool isEmpty() const {
        return topIndex < 0;
    }

    int size() const {
        return topIndex + 1;
    }
};