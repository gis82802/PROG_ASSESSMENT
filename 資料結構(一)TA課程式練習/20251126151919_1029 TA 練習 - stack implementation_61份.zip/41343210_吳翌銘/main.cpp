#include <iostream>
#include "MyStack.hpp"
using namespace std;


int main() {
    // 儲存 int 資料
    MyStack<int> intStk;
    intStk.push(12);
    intStk.push(34);
    intStk.push(56);  // 這裡會觸發擴充容量

    while (!intStk.isEmpty()) {
        cout << "int stack pop: " << intStk.pop() << endl;
    }

    // 儲存 double 資料
    MyStack<double> doubleStk;
    doubleStk.push(2.3);
    doubleStk.push(4.5);
    doubleStk.push(6.7);  // 這裡也會觸發擴充容量

    while (!doubleStk.isEmpty()) {
        cout << "double stack pop: " << doubleStk.pop() << endl;
    }

    return 0;
}
