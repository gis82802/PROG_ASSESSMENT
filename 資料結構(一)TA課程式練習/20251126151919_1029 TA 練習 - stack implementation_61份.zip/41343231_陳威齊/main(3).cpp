#include <iostream>
#include "MyStack.h"
using namespace std;

int main() {
    MyStack<int> intStack(4);
    MyStack<double> doubleStack(4);

    cout << "Initial capacity of intStack: " << intStack.getCapacity() << endl;
    cout << "Initial capacity of doubleStack: " << doubleStack.getCapacity() << endl;

    cout << "\n--- Start pushing elements into stacks ---" << endl;

    for (int i = 0; i < 10; i++) {
        cout << "\n[Iteration " << i + 1 << "]" << endl;
        intStack.push((i + 1) * 2);        // ���J���
        doubleStack.push((i + 1) * 1.1);   // ���J�B�I��
    }

    for (int i = 0; i < 2; i++) {
        intStack.pop();
        doubleStack.pop();
    }

    cout << "\n--- Integer Stack after pop ---" << endl;
    intStack.printStack();

    cout << "--- Double Stack after pop ---" << endl;
    doubleStack.printStack();

    cout << "\n--- Final Stack States ---" << endl;
    cout << "intStack capacity: " << intStack.getCapacity() << endl;
    intStack.printStack();

    cout << "doubleStack capacity: " << doubleStack.getCapacity() << endl;
    doubleStack.printStack();

    return 0;
}
