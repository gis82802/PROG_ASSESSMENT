﻿#ifndef MYSTACK_H
#define MYSTACK_H

#include <iostream>
using namespace std;

template <class T>
class MyStack {
private:
    T* stackArray;
    int top;
    int capacity;

    // ✅ 擴充容量的函式
    void expandCapacity() {
        int oldCapacity = capacity;
        capacity *= 2; // 擴充為原本的兩倍
        T* newArray = new T[capacity];

        // 複製舊資料
        for (int i = 0; i <= top; i++) {
            newArray[i] = stackArray[i];
        }

        delete[] stackArray;
        stackArray = newArray;

        cout << " Stack capacity increased from " << oldCapacity
            << " to " << capacity << endl;
    }

public:
    MyStack(int size = 4) { // 預設容量 4
        capacity = size;
        stackArray = new T[capacity];
        top = -1;
    }

    ~MyStack() {
        delete[] stackArray;
    }

    void push(T value) {
        // 滿了就擴充容量
        if (top == capacity - 1) {
            expandCapacity();
        }

        stackArray[++top] = value;
        cout << "Pushed value: " << value << endl;
    }

    void pop() {
        if (isEmpty()) {
            cout << "Stack underflow!" << endl;
            return;
        }
        cout << "Popped value: " << stackArray[top] << endl;
        top--;
    }

    T peek() const {
        if (isEmpty()) {
            cout << "Stack is empty!" << endl;
            return T();
        }
        return stackArray[top];
    }

    bool isEmpty() const {
        return top == -1;
    }

    void printStack() const {
        if (isEmpty()) {
            cout << "Stack is empty!" << endl;
            return;
        }
        cout << "Stack elements: ";
        for (int i = 0; i <= top; i++) {
            cout << stackArray[i] << " ";
        }
        cout << endl;
    }

    int getCapacity() const {
        return capacity;
    }
};

#endif
