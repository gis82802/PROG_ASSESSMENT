#include <iostream>
#include <stdexcept>
#include "stack1.h" 
using namespace std;

int main() {
    MyStack<int> mystack(2);
    cout << "��l�e�q: " << mystack.GetCapacity() << endl;
    mystack.Push(12);
    for (int i = 1; i <= 20; i++) {
        mystack.Push(i*1);
    }
    cout << "���|��������: ";
    mystack.PrintStack(); 

    MyStack<double> mystackdouble(2);
    cout << "\n��l�e�q: " << mystackdouble.GetCapacity() << endl;
    mystackdouble.Push(2.3);
    for (int i = 0; i < 60; i++) {
        mystackdouble.Push(i*2);
    }
    cout << "���|��������: ";
    mystackdouble.PrintStack(); 

    return 0;
}



