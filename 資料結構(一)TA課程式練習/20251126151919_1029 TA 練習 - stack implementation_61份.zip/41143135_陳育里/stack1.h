#include <iostream>
#include <stdexcept>
using namespace std;

template <typename T>
class MyStack {
private:
    T* arr;
    int capacity;
    int top;

public:
    MyStack(int initialCapacity) {
        capacity = initialCapacity;
        arr = new T[capacity];
        top = -1;
    }

    ~MyStack() {
        delete[] arr;
    }

    int GetCapacity() {
        return capacity;
    }

    void Push(T value) {
        if (top + 1 == capacity) {
            // �X�R���|�e�q
            capacity *= 2;
            T* newArr = new T[capacity];
            for (int i = 0; i <= top; i++) {
                newArr[i] = arr[i];
            }
            delete[] arr;
            arr = newArr;
            cout << "���|�e�q�X�R��: " << capacity << endl;
        }
        arr[++top] = value;
    }

    void Pop() {
        if (top >= 0) {
            top--;
        }
    }

    T Top() {
        if (top >= 0) {
            return arr[top];
        }
        throw out_of_range("���|����");
    }

    void PrintStack() {
        cout << "[";
        for (int i = 0; i <= top; i++) {
            cout << arr[i];
            if (i < top) {
                cout << ", ";
            }
        }
        cout << "]" << endl;
    }
};


