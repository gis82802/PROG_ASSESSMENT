#include "Stack.hpp"
#include<iostream>

int main()
{
    try {
        MyStack<int> intStk;   // 儲存 int 形態資料
        MyStack<double> doubleStk;  // 儲存 double 形態資料

        intStk.push(12);
        doubleStk.push(2.3);

        for(int i=0;i<20;i++)
        {
            intStk.push(i);
            doubleStk.push(i*0.2);
        }

        intStk.print();
        doubleStk.print();

        intStk.pop(); intStk.pop(); intStk.pop();
        doubleStk.pop(); doubleStk.pop(); 

        intStk.print();
        doubleStk.print();
    } catch (const char* msg){
        std::cout << msg << std::endl;
    }

    return 0;
}