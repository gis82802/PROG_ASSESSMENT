#include "Stack.hpp"
#include<bits/stdc++.h>
using namespace std;

template <class T>
void ChangeSize1D(T*& a, const int oldSize, const int newSize)
{
    if(newSize < 0) throw "New length must be >= 0";

    cout << "capacity " << oldSize << " is incressed to " << newSize << endl;
    T* tmp = new T[newSize];
    int num = min(oldSize, newSize);
    copy(a, a + num, tmp);
    delete [] a;
    a = tmp;
}

template <class T>
MyStack<T>::MyStack(int stackCapacity):capacity(stackCapacity)
{
    if(capacity < 1) throw "Stack capacity must be > 0";

    stack = new T[capacity];
    top = -1;
}

template <class T>
inline bool MyStack<T>::IsEmpty() const { return top == -1; }

template <class T>
inline T& MyStack<T>::Top() const 
{
    if(IsEmpty()) throw "Stack is empty";
    return stack[top];
}

template <class T>
void MyStack<T>::push(const T& x) 
{
    if(top == capacity - 1)
    {
        ChangeSize1D(stack, capacity, 2*capacity);
        capacity *= 2;
    }
    stack[++top]=x;
} 

template  <class T>
void MyStack<T>::pop()
{
    if(IsEmpty()) throw "Stack is empty. cannot delete. ";
    stack[top--].~T();
} 

template <class T>
void MyStack<T>::print()
{
    for(int i=0;i<top;i++)
    {
        if(i != 0 && i%20 == 0)
            cout << stack[i] << endl;
        else
            cout << stack[i] << ", ";
    }
    cout << endl;
}