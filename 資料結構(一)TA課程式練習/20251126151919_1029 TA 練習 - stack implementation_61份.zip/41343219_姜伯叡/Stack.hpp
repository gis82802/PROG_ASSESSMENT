#ifndef Stack_hpp
#define Stack_hpp
#include<iostream>

template <class T>
class MyStack{
    private:
        T* stack;
        int top;
        int capacity;
    public:
        MyStack(int stackCapacity=4);
        bool IsEmpty() const;
        T& Top() const;
        void push(const T& item);
        void pop();
        void print();
};

#endif