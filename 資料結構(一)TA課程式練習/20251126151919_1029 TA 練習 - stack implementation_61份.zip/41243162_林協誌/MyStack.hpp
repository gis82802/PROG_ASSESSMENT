﻿#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
#include <stdexcept>
using namespace std;

// ======== 樣板類別 MyStack ========
template <class T>
class MyStack {
private:
    T* data;          // 儲存資料的陣列
    int capacity;     // 容量
    int topIndex;     // 指向頂端元素索引

    // 自動擴充容量
    void resize() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];
        for (int i = 0; i <= topIndex; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
        cout << " Stack 容量自動擴充至 " << capacity << endl;
    }

public:
    // 建構子
    MyStack(int initCap = 2) {
        if (initCap <= 0) initCap = 2;
        capacity = initCap;
        data = new T[capacity];
        topIndex = -1;
    }

    // 解構子
    ~MyStack() {
        delete[] data;
    }

    // push: 放入元素
    void push(const T& value) {
        if (topIndex + 1 == capacity)
            resize();
        data[++topIndex] = value;
        cout << " push(" << value << ") 成功 (目前大小: "
            << size() << "/" << capacity << ")" << endl;
    }

    // pop: 移除頂端元素
    void pop() {
        if (isEmpty()) {
            cout << "Stack 為空，無法 pop！" << endl;
            return;
        }
        cout << "已移除頂端元素：" << data[topIndex--] << endl;
    }

    // top: 回傳頂端元素
    T top() const {
        if (isEmpty())
            throw out_of_range("Stack 為空！");
        return data[topIndex];
    }

    // 判斷是否為空
    bool isEmpty() const {
        return topIndex == -1;
    }

    // 堆疊大小
    int size() const {
        return topIndex + 1;
    }

    // 印出堆疊內容
    void print() const {
        cout << "[堆疊內容] (頂端→底部): ";
        for (int i = topIndex; i >= 0; i--)
            cout << data[i] << " ";
        cout << endl;
    }
};

#endif
