#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
using namespace std;

template <typename T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;

    void resize();

public:
    MyStack(int initialCapacity = 2);
    ~MyStack();

    void push(const T& value);
    void pop();
    T top() const;
    bool isEmpty() const;
    int size() const;
};

// ======================
// �˪O���O��@
// ======================

template <typename T>
MyStack<T>::MyStack(int initialCapacity)
    : capacity(initialCapacity), topIndex(0) {
    data = new T[capacity];
}

template <typename T>
MyStack<T>::~MyStack() {
    delete[] data;
}

template <typename T>
void MyStack<T>::resize() {
    int newCapacity = capacity * 2;
    T* newData = new T[newCapacity];

    for (int i = 0; i < topIndex; ++i) {
        newData[i] = data[i];
    }

    delete[] data;
    data = newData;
    capacity = newCapacity;

    cout << ">> �e�q�����A�۰��X�R�� " << capacity << endl;
}

template <typename T>
void MyStack<T>::push(const T& value) {
    if (topIndex >= capacity) {
        resize();
    }
    data[topIndex++] = value;
}

template <typename T>
void MyStack<T>::pop() {
    if (isEmpty()) {
        cout << ">> ���~�G���|���šA�L�k pop�C\n";
        return;
    }
    --topIndex;
}

template <typename T>
T MyStack<T>::top() const {
    if (isEmpty()) {
        cout << ">> ���~�G���|���šA�L�k���o���ݤ����C\n";
        exit(1);
    }
    return data[topIndex - 1];
}

template <typename T>
bool MyStack<T>::isEmpty() const {
    return topIndex == 0;
}

template <typename T>
int MyStack<T>::size() const {
    return topIndex;
}

#endif
