#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
#include <stdexcept>
using namespace std; 

template <class T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;


    void expandCapacity() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];
        for (int i = 0; i < capacity; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        cout << "capacity " << capacity << " is increased to " << newCapacity << endl;
        capacity = newCapacity;
    }

public:

    MyStack(int initCap = 4) {
        capacity = initCap;
        data = new T[capacity];
        topIndex = 0;
    }


    ~MyStack() {
        delete[] data;
    }


    void push(T value) {
        if (topIndex >= capacity) {
            expandCapacity();
        }
        data[topIndex++] = value;
    }


    T pop() {
        if (topIndex == 0) {
            throw out_of_range("Stack is empty!");
        }
        return data[--topIndex];
    }


    bool empty() const {
        return topIndex == 0;
    }


    int size() const {
        return topIndex;
    }


    void print() const {
        for (int i = 0; i < topIndex; i++) {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};
#endif
