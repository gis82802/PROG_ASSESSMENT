#include <iostream>
#include "MyStack.hpp"
using namespace std;

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    
    for (int i = 0; i < 20; i++) {
        intStk.push(12 + i);          
        doubleStk.push(2.3 + i * 0.2);
    }

    
    cout << "intStk: ";
    intStk.print();
    cout << "doubleStk: ";
    doubleStk.print();

    return 0;
}
