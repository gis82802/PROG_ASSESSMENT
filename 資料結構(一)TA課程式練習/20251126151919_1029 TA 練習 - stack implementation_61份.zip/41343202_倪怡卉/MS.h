#ifndef MS_H
#define MS_H

#include <iostream>
#include <vector>

template <typename T>
class MS {
private:
    T* data;
    int capacity;
    int topIndex;

    void resize(int newCapacity) {
        std::cout << "�վ���|�e�q�q " << capacity << " �� " << newCapacity << std::endl;
        T* newData = new T[newCapacity];
        for (int i = 0; i <= topIndex; ++i) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
    }

public:
    MS() : capacity(2), topIndex(-1) {
        data = new T[capacity];
        std::cout << "�إ߰��|�A��l�e�q: " << capacity << std::endl;
    }

    ~MS() {
        delete[] data;
    }

    void push(const T& value) {
        if (topIndex + 1 >= capacity) {
            resize(capacity * 2);
        }
        data[++topIndex] = value;
        std::cout << "�[�J����: " << value << "�A�ثe�j�p: " << (topIndex + 1) << std::endl;
    }

    void pop() {
        if (topIndex < 0) return;
        std::cout << "��������: " << data[topIndex] << std::endl;
        --topIndex;
    }

    T& top() {
        return data[topIndex];
    }

    bool empty() const {
        return topIndex == -1;
    }

    int size() const {
        return topIndex + 1;
    }

    int getCapacity() const {
        return capacity;
    }

    // �s�W�G������|���e�]�q�����쩳���^
    std::vector<T> getContent() const {
        std::vector<T> content;
        for (int i = topIndex; i >= 0; --i) {
            content.push_back(data[i]);
        }
        return content;
    }
};

#endif
