#include "MyStack1.h"

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    cout << "=== ���� int ���A Stack ===\n";
    intStk.push(12);
     intStk.print();       

    intStk.push(20);
    intStk.push(30);
    intStk.push(75);
    intStk.push(46);


    intStk.print();       


    cout << "\n=== ���� double ���A Stack ===\n";
    doubleStk.push(2.3);
    doubleStk.print();
    
    doubleStk.push(2.2);
    doubleStk.push(3.3);
        doubleStk.push(4.3);
    doubleStk.push(5.6);
    doubleStk.push(9.8);
  
    doubleStk.print();    

    return 0;
}

