#ifndef MYSTACK_H
#define MYSTACK_H

#include <iostream>
using namespace std;

template <class T>
class MyStack {
private:
    T* data;
    int capacity;
    int topIndex;


    void resize() {
        int newCapacity = capacity * 2;
        T* newData = new T[newCapacity];

        for (int i = 0; i < topIndex; i++)
            newData[i] = data[i];

        delete[] data;
        data = newData;
        capacity = newCapacity;

        cout << "[�t�ΰT��] Stack �e�q�w�۰��X�R�� " << capacity << "�C\n";
    }

public:

    MyStack(int initialCapacity = 2) {
        capacity = initialCapacity;
        data = new T[capacity];
        topIndex = 0;
    }


    ~MyStack() {
        delete[] data;
    }


    void push(const T& value) {
        if (topIndex == capacity)
            resize();
        data[topIndex++] = value;
    }


    void pop() {
        if (isEmpty()) {
            cout << "Stack ���šA�L�k pop�C\n";
            return;
        }
        cout << "�u�X�����G" << data[topIndex - 1] << endl;
        topIndex--;
    }


    T top() const {
        if (isEmpty()) {
            cout << "Stack ���šA�L���ݤ����A�^�ǹw�]�ȡC\n";
            return T();
        }
        return data[topIndex - 1];
    }


    bool isEmpty() const {
        return topIndex == 0;
    }


    int size() const {
        return topIndex;
    }

    void print() const {
        if (isEmpty()) {
            cout << "[Stack ����]\n";
            return;
        }

        cout << "Stack ���e (�ѩ��쳻): ";
        for (int i = 0; i < topIndex; i++) {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};

#endif

