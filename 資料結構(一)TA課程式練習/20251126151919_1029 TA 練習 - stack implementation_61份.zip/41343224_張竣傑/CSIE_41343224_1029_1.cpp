#include <iostream>
#include "CSIE_41343224_1029_1.hpp"
using namespace std;

int main() {
    MyStack<int> intStk;
    MyStack<double> doubleStk;

    intStk.Push(12);  
    doubleStk.Push(2.3);
    intStk.Print();
    doubleStk.Print();

    for(int i = 0 ; i <= 20 ; i++){
    intStk.Push(i);
    doubleStk.Push(i*0.2);
    }
    
    intStk.Print();
    doubleStk.Print();

    return 0;
}
