#ifndef CSIE_41343224_1029_1_H
#define CSIE_41343224_1029_1_H

#include <iostream>
using namespace std;

template <class T>
class MyStack{
    public:
        MyStack(int stackCapacity = 4);
        bool IsEmpty() const;
        T& Top() const;
        void Push(const T& item);
        void Pop();
        void Print();
    private:
        T* stack;
        int top;
        int capacity;
};
template <class T>
void  changeSize(T*& stack, const int oldSize, const int newSize){
    if (newSize <0) throw "大小不可小於0";

    cout<<"大小從 "<<oldSize<<"增加為 "<<newSize<<endl;
    T* temp = new T[newSize];
    int n = min(oldSize,newSize);
    copy(stack, stack+n, temp);
    delete[] stack;
    stack = temp; 
}

template <class T>
MyStack<T>::MyStack(int stackCapacity){
    capacity = stackCapacity;
    top = -1;
    if(capacity <0)throw "大小不可小於0";
    stack = new T[capacity];
}

template <class T>
inline bool MyStack<T>::IsEmpty() const{return top == -1;}

template <class T>
inline T& MyStack<T>::Top() const{
    if(IsEmpty())throw "此堆疊是空的";
    return stack[top];
}

template <class T>
void MyStack<T>::Push(const T& item) {
    if (top == capacity - 1) {
        changeSize(stack, capacity, capacity * 2);
        capacity *= 2;
    }
    stack[++top] = item;
}

template <class T>
void MyStack<T>::Pop() {
    if (IsEmpty())throw "此堆疊是空的";
    stack[top--].~T();
}

template <class T>
void MyStack<T>::Print() {
    cout << "[ ";
    for (int i = 0; i <= top; i++)
        cout << stack[i] << " ";
    cout << "]" << endl;
}

#endif