
#include <iostream>
#include"bdd.hpp"
using namespace std;



// ===== 主程式 =====
int main() {
    cout << "int 測試 " << endl;
    MyStack<int> intStk;
    intStk.push(12);
    intStk.push(34);
    intStk.push(56);   // 這裡會觸發自動擴充

    intStk.printStack();//輸出現在的資料

    cout << "堆疊頂端: " << intStk.top() << endl;
    intStk.pop();
    cout << "彈出後頂端: " << intStk.top() << endl;

    cout << "\ndouble 測試 " << endl;
    MyStack<double> doubleStk;
    doubleStk.push(2.3);
    doubleStk.push(4.56);
    doubleStk.printStack();//輸出現在的資料

    doubleStk.push(7.89);   // 同樣會觸發擴充


    doubleStk.printStack();//輸出現在的資料


    cout << "堆疊頂端: " << doubleStk.top() << endl;
    doubleStk.pop();
    cout << "彈出後頂端: " << doubleStk.top() << endl;

    MyStack<int> testStk;
    testStk.push(1);
    testStk.push(2);
    testStk.push(3);// 這裡會觸發自動擴充


    testStk.printStack();//輸出現在的資料






    //測試用
    int a = 0;
    cin >> a;
    testStk.push(a);

    testStk.printStack();


    cout << "堆疊頂端: " << testStk.top() << endl;
    testStk.pop();
    cout << "彈出後頂端: " << testStk.top() << endl;




    return 0;
}
