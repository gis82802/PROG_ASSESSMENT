
#include <iostream>
using namespace std;


// ===== 樣板類別 MyStack =====
template <class T>
class MyStack {
private:
    T* arr;          // 動態陣列
    int datasizeStk;    // 容量
    int topV;    // 指向堆疊頂端位置

    // 動態擴充容量
    void resize(int newCapacity) {
        cout << " 容量不足，進行擴充：從 " << datasizeStk << " 到 " << newCapacity << endl;
        T* newArr = new T[newCapacity];
        for (int i = 0; i < datasizeStk; i++)
            newArr[i] = arr[i];
        delete[] arr;
        arr = newArr;
        datasizeStk = newCapacity;
    }

public:
    
   
    // 建構子
    MyStack(int cap = 2) {
        datasizeStk = cap;
        arr = new T[datasizeStk];
        topV = 0;
    }

    // 解構子
    ~MyStack() {
        delete[] arr;
    }

    // 推入元素
    void push(const T& value) {
        if (topV == datasizeStk)
            resize(datasizeStk * 2);   // 自動擴充
        arr[topV++] = value;
    }

    // 彈出元素
    void pop() {
        if (isEmpty()) {
            cout << "堆疊為空，無法 pop！" << endl;
            return;
        }
        topV--;
    }

    // 取得堆疊頂端
    T top() const {
        if (isEmpty()) {
            cout << "堆疊為空！" << endl;
            return T(); // 傳回型態預設值
        }
        return arr[topV - 1];
    }

    // 判斷是否為空
    bool isEmpty() const {
        return topV == 0;
    }

    // 目前大小
    int size() const {
        return topV;
    }
    void printStack() const {
        if (isEmpty()) {
            cout << "（堆疊目前是空的）" << endl;
            return;
        }

        cout << "堆疊內容（由頂端 到 底部）：" << endl;
        for (int i = topV - 1; i >= 0; i--) {
            cout << "│ " << arr[i] << " │" << endl;
        }
        cout << "───────" << endl;
    }
};