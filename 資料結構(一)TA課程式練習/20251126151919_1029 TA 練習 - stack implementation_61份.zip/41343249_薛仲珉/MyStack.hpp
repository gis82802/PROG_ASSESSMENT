#ifndef MYSTACK_HPP
#define MYSTACK_HPP

#include <iostream>
using namespace std;

template <class T>
class MyStack {
private:
    T* data; // �ʺA�}�C
    int capacity; // �e�q
    int topIndex; // ���V���|���ݤ���������

    // �۰��X�R�e�q
    void resize() {
        int cap = capacity;
        int newCap = capacity * 2;
        T* newData = new T[newCap];

        for (int i = 0; i < capacity; i++)
            newData[i] = data[i];

        delete[] data;
        data = newData;
        capacity = newCap;

        cout << "[Info] Stack capacity increased "<< cap<<" to " << capacity << endl;
    }

public:
    // �غc�l
    MyStack(int cap = 5) {
        capacity = cap;
        data = new T[capacity];
        topIndex = -1;
    }

    // �Ѻc�l
    ~MyStack() {
        delete[] data;
    }

    // �O�_����
    bool isEmpty() const {
        return topIndex == -1;
    }

    // �O�_�w��
    bool isFull() const {
        return topIndex == capacity - 1;
    }

    // ���J����
    void push(const T& value) {
        if (isFull())
            resize();
        data[++topIndex] = value;
    }

    // �u�X����
    T pop() {
        if (isEmpty()) {
            cout << "[Warning] Stack is empty!" << endl;
            return T(); // �^�ǹw�]��
        }
        return data[topIndex--];
    }

    // ���o���ݤ���
    T top() const {
        if (isEmpty()) {
            cout << "[Warning] Stack is empty!" << endl;
            return T();
        }
        return data[topIndex];
    }

    // ���o�ثe�j�p
    int size() const {
        return topIndex + 1;
    }
};

#endif
