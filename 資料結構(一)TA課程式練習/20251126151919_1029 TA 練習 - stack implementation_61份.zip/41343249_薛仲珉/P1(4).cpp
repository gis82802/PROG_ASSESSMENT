#include <iostream>
#include "MyStack.hpp"
using namespace std;

int main() {
    // �إߥi�s int �� stack
    MyStack<int> intStk;
    // �إߥi�s double �� stack
    MyStack<double> doubleStk;
    intStk.push(12);
    doubleStk.push(2.3);
    // ���� push (�t�۰��X�R)
    cout << "Pushing integers..." << endl;
    for (int i = 2; i <= 12; ++i) {
        intStk.push(i * 10);
    }

    cout << "\nPushing doubles..." << endl;
    for (int i = 2; i <= 8; ++i) {
        doubleStk.push(i * 1.5);
    }

    // ��ܰ��|����
    cout << "\nTop of intStk = " << intStk.top() << endl;
    cout << "Top of doubleStk = " << doubleStk.top() << endl;

    // ���� pop
    cout << "\nPopping integers:" << endl;
    while (!intStk.isEmpty()) {
        cout << intStk.pop() << " ";
    }
    cout << endl;

    cout << "\nPopping doubles:" << endl;
    while (!doubleStk.isEmpty()) {
        cout << doubleStk.pop() << " ";
    }
    cout << endl;

    return 0;
}