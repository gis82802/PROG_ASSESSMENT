#include <iostream>
using namespace std;
#include "Stack.h"
#include "Stack.cpp"

int main() {
    MyStack<int>   intStk;
    MyStack<double> doubleStk;

    intStk.Push(12);
    doubleStk.Push(2.3);

    intStk.print();
    doubleStk.print();
    cout << endl;

    for (int i = 0; i < 20; ++i) {
        intStk.Push(i);
        doubleStk.Push(i * 0.2);
    }

    intStk.print();
    doubleStk.print();
    cout << endl;

    for (int i = 0; i < 3; ++i) intStk.Pop();
    for (int i = 0; i < 3; ++i) doubleStk.Pop();

    intStk.print();
    doubleStk.print();
    cout << endl;

    return 0;
}