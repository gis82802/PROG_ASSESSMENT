﻿#include <iostream>
#include <stdexcept>
#include <algorithm>

const int DEFAULT_CAPACITY = 2;

template <typename T>
class MyStack {
private:
    T* elements;
    int capacity;
    int size;

    void resize(int newCapacity) {
        // 容量調整通知訊息
        std::cout << ">>> 容量調整通知：堆疊已滿 (" << capacity << " 個元素)，正在自動擴容至 "
            << newCapacity << "。" << std::endl;

        T* newElements = new T[newCapacity];
        for (int i = 0; i < size; ++i) {
            newElements[i] = elements[i];
        }
        delete[] elements;
        elements = newElements;
        capacity = newCapacity;
    }
public:
    MyStack() : capacity(DEFAULT_CAPACITY), size(0) {
        elements = new T[capacity];
    }
    ~MyStack() {
        delete[] elements;
    }

    void push(const T& item) {
        if (size == capacity) {
            resize(capacity * 2);
        }
        elements[size++] = item;
    }

    T pop() {
        if (isEmpty()) {
            throw std::out_of_range("堆疊為空值，無法執行 pop() 操作。");
        }
        return elements[--size];
    }

    const T& peek() const {
        if (isEmpty()) {
            throw std::out_of_range("堆疊為空值，無法執行 peek() 操作。");
        }
        return elements[size - 1];
    }

    bool isEmpty() const {
        return size == 0;
    }

    int current_size() const {
        return size;
    }
};

