﻿#include <iostream>
#include "STACK.hpp"
using namespace std;
int main() {
    std::cout << "--- 1. 示範 MyStack<int> (IntStk) ---" << std::endl;
    MyStack<int> intStk;

    std::cout << "推入 12..." << std::endl;
    intStk.push(12);
    for (int i = 20; i < 30; i++) {
        intStk.push(i);
    }
    for (int i = 0; i < 3; i++)
    {
        std::cout << "彈出元素 (pop): " << intStk.pop() << std::endl;
    }
    std::cout << "堆疊是否為空: " << (intStk.isEmpty() ? "是" : "否") << std::endl;

    MyStack<double> Stk;

    std::cout << "推入 2.3..." << std::endl;
    Stk.push(2.3);
    std::cout << "彈出元素 (pop): " << Stk.pop() << std::endl;
    std::cout << "堆疊是否為空: " << (Stk.isEmpty() ? "是" : "否") << std::endl;

    std::cout << "\n--- 2. 示範 MyStack<double> (DoubleStk) 與容量調整 ---" << std::endl;
    MyStack<double> doubleStk;

    std::cout << "開始推入 11 個元素以觸發擴容 (預設容量: " << DEFAULT_CAPACITY << ")..." << std::endl;
    for (int i = 0; i < 11; i++) {
        doubleStk.push(i + 100.0 + 0.5);
    }

    std::cout << "DoubleStk 中元素數量: " << doubleStk.current_size() << std::endl;
    for (int i = 0; i < 11; i++) {
        std::cout << "彈出元素 (pop): " << doubleStk.pop() << std::endl;
    }

    std::cout << "\n--- 3. 示範 MyStack<std::string> ---" << std::endl;
    MyStack<std::string> strStk;
    strStk.push("Hello");
    strStk.push("World");
    std::cout << "彈出 String 元素: " << strStk.pop() << std::endl;

    return 0;
}