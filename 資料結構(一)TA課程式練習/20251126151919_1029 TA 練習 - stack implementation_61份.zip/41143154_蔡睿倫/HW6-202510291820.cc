#include "./Stack.h"
// #include "./Queue.h"


int32_t main() {
    std::cout << "Question 1" << std::endl;
    Stack<double> double_stack(2);
    Stack<int32_t> int_stack(2);
    double double_stack_value[] = {1.5, 2.5, 3.5, 4.5, 5.5, 1552.25};
    int32_t int_stack_value[] = {1, 2, 3, 4, 5, 1552};

    std::cout << "Pushing double values: " << std::endl;

    for (auto value : double_stack_value) {
        double_stack.push(value);
    }

    std::cout << "Popping all values: " << std::endl;
    while (!double_stack.empty()){
        double_stack.pop();
    }

    std::cout << "Pushing int values: " << std::endl;

    for (auto value : int_stack_value) {
        int_stack.push(value);
    }

    std::cout << "Popping all values: " << std::endl;
    while (!int_stack.empty()){
        int_stack.pop();
    }

    // std::cout << "Question 2" << std::endl;
    // std::cout << "Enter values (enter 00 to stop): " << std::endl;
    // Queue<double> q(2);
    // double queue_value[] = {1.5, 2.5, 3.5, 4.5, 5.5, 1552.25};
    // for (auto value : queue_value) {
    //     q.push(value);
    // }
    
    // std::cout << "Dequeuing all values: " << std::endl;
    // while (!q.empty()) {
    //     q.pop();
    // }

    return 0;
}