#include<iostream>
#include<algorithm>
#include<stdexcept>
#include<memory>

template<class T>
class Stack {
private:
    std::unique_ptr<T[]> stack;
    int32_t top = -1;
    int32_t capacity = 0;

    void change_size(int32_t newSize) {
        auto temp = std::make_unique<T[]>(newSize);
        std::copy(stack.get(), stack.get() + capacity, temp.get());
        stack = std::move(temp);
    }
    
public:
    explicit Stack(int32_t capacity = 10) {
        if (capacity <= 0)
            throw std::length_error("Capacity must be positive");
        this->capacity = capacity;
        stack = std::make_unique<T[]>(capacity);
    }

    ~Stack() = default;
    
    Stack(const Stack&) = delete;
    Stack& operator=(const Stack&) = delete;
    Stack(Stack&&) = default;
    Stack& operator=(Stack&&) = default;

    inline bool empty() const {
        return (top == -1);
    }

    inline T& top_element() const {
        if (top == -1)
            throw std::out_of_range("Stack is empty");
        return stack[top];
    }

    void push(const T& item) {
        if (capacity == top + 1) {
            change_size(capacity * 2);
            capacity *= 2;
        }
        stack[++top] = item;
        std::cout << "Pushed: " << item << "\tCurrent Capacity: " << capacity << "\tStack: ";
        for (int32_t i = 0; i <= top; ++i)
            std::cout << stack[i] << ", ";
        std::cout << std::endl;
    }

    void pop() {
        if (top == -1)
            throw std::out_of_range("Stack is empty");
        --top;
        std::cout << "Popped\tCurrent Capacity: " << capacity << "\tStack: ";
        for (int32_t i = 0; i <= top; ++i)
            std::cout << stack[i] << ", ";
        std::cout << std::endl;
    }
};