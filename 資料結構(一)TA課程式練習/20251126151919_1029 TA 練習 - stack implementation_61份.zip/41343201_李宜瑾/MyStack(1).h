#ifndef MYSTACK_H
#define MYSTACK_H

#include <iostream>
#include <stdexcept>

template <typename T>
class MyStack {
private:
    T* data;
    int topIndex;
    int capacity;

    void resize(int newCapacity) {
        if (newCapacity <= capacity) {
            return;
        }

        std::cout << "�e�q�վ㤤�G�q " << capacity << " �ܧ� " << newCapacity << std::endl;

        T* newData = new T[newCapacity];
        for (int i = 0; i <= topIndex; ++i) {
            newData[i] = data[i];
        }

        delete[] data;
        data = newData;
        capacity = newCapacity;
    }

public:
    MyStack(int initialCapacity = 10) : topIndex(-1), capacity(initialCapacity) {
        if (initialCapacity <= 0) {
            initialCapacity = 1;
        }
        data = new T[initialCapacity];
        std::cout << "MyStack ����إߡA��l�e�q: " << capacity << std::endl;
    }

    ~MyStack() {
        delete[] data;
    }

    MyStack(const MyStack&) = delete;
    MyStack& operator=(const MyStack&) = delete;

    bool empty() const {
        return topIndex == -1;
    }

    bool full() const {
        return topIndex == capacity - 1;
    }

    int size() const {
        return topIndex + 1;
    }

    void push(const T& element) {
        if (full()) {
            resize(capacity * 2);
        }

        topIndex++;
        data[topIndex] = element;
        std::cout << "���J���: " << element << ", ���|�j�p: " << size() << std::endl;
    }

    void pop() {
        if (empty()) {
            throw std::out_of_range("���~�G���|���šA�L�k���� pop �ާ@");
        }
        topIndex--;
    }

    const T& top() const {
        if (empty()) {
            throw std::out_of_range("���~�G���|���šA�L�k���� top �ާ@");
        }
        return data[topIndex];
    }

    void display() const {
        if (empty()) {
            std::cout << "Stack: [��] (�e�q: " << capacity << ")" << std::endl;
            return;
        }

        std::cout << "Stack (���h -> ���h): [";
        for (int i = 0; i <= topIndex; ++i) {
            std::cout << data[i];
            if (i < topIndex) {
                std::cout << ", ";
            }
        }
        std::cout << "] (�e�q: " << capacity << ")" << std::endl;
    }
};

#endif // MYSTACK_H