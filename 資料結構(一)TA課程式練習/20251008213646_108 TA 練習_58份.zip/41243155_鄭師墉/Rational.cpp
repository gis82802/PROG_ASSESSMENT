#include <iostream>
using namespace std;

class Rational {
private:
    int mol; // 分子
    int den; // 分母

    static int iabs(int x) { return x < 0 ? -x : x; }

    static int gcd_int(int a, int b) {
        a = iabs(a);
        b = iabs(b);
        while (b != 0) {
            int t = a % b;
            a = b;
            b = t;
        }
        return a; // 非負
    }

    void reduce() {
        if (den == 0) {
            cout << "ERROR: den = 0" << endl;
            den = 1; // 退回為 0/1 以避免未定義行為
            mol = 0;
            return;
        }
        if (mol == 0) { // 0/x -> 0/1
            den = 1;
            return;
        }
        if (den < 0) {  // 分母保持為正
            mol = -mol;
            den = -den;
        }
        int g = gcd_int(mol, den);
        if (g != 0) {
            mol /= g;
            den /= g;
        }
    }

public:
    Rational(int m = 0, int d = 1) : mol(m), den(d) { reduce(); }

    void add(const Rational &b) {
        mol = mol * b.den + b.mol * den;
        den = den * b.den;
        reduce();
    }

    void sub(const Rational &b) {
        mol = mol * b.den - b.mol * den;
        den = den * b.den;
        reduce();
    }

    void mul(const Rational &b) {
        mol = mol * b.mol;
        den = den * b.den;
        reduce();
    }

    void div(const Rational &b) {
        if (b.mol == 0) {
            cout << "ERROE:/0" << endl;
            return;
        }
        mol = mol * b.den;
        den = den * b.mol;
        reduce();
    }

    void print() {
        reduce();
        int amol = iabs(mol);
        if (amol >= den) {               // 帶分數
            int whole = mol / den;       // 朝 0 取整
            int rem = iabs(mol - whole * den);
            if (rem == 0)
                cout << whole << endl;
            else
                cout << whole << "+" << rem << "/" << den << endl;
        } else {
            cout << mol << "/" << den << endl;
        }
    }
};

int main() {
    Rational a(1, 2), b(3, 4);  // a=1/2, b=3/4

    a.add(b);  a.print();   // 1+1/4
    b.sub(a);  b.print();   // -1/2
    a.mul(b);  a.print();   // -5/8
    b.div(a);  b.print();   // 4/5

    return 0;
}
