#include <iostream>
#include <vector>
using namespace std;

vector<vector<int> > MagicMatrix(int n)
{
    vector<vector<int> > m(n, vector<int>(n, 0));

    int i = 0, j = n / 2; // 起始位置：第一列的中間
    for (int v = 1, N = n * n; v <= N; ++v)
    {
        m[i][j] = v; // 放入目前的數字

        // 下一步預設往「左上角」移動
        int ni = (i - 1 + n) % n; // 上一列（走出邊界則從底部出現）
        int nj = (j - 1 + n) % n; // 前一欄（走出邊界則從最右出現）

        // 若左上角已經有數字，改為往「下」移動一格
        if (m[ni][nj] != 0)
        {
            i = (i + 1) % n;
        }
        else
        { // 否則就照計劃往左上角移
            i = ni;
            j = nj;
        }
    }
    return m;
}

int main()
{
    int n;
    cout << "Enter the size of the matrix (n => odd): "; // 輸入奇數 n
    if (!(cin >> n) || n <= 0 || (n % 2 == 0))
    { // 檢查是否為正奇數
        cout << "Please enter a positive odd integer." << endl;
        return 1;
    }

    vector<vector<int> > matrix = MagicMatrix(n); // 生成魔術方陣

    for (int r = 0; r < n; ++r)
    {
        for (int c = 0; c < n; ++c)
            cout << matrix[r][c] << " ";
        cout << endl;
    }

    return 0;
}
