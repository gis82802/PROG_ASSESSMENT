#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;
void printMagicSquare(const vector<vector<int>>& square) {
    int n = square.size();
    cout << "--------------------" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            
            cout << setw(4) << square[i][j];
        }
        cout << endl; 
    }
    cout << "--------------------" << endl;
}

void createMagicSquare(int n) {
    
    vector<vector<int>> magicSquare(n, vector<int>(n, 0));

   
    int i = 0;
    int j = n / 2;

    
    for (int num = 1; num <= n * n; ++num) {
       // �b�ثe��m (i, j) ��J�Ʀr
        magicSquare[i][j] = num;

        int next_i = (i - 1 + n) % n; 
        int next_j = (j - 1 + n) % n; 

        if (magicSquare[next_i][next_j] != 0) {
            
            i = (i + 1) % n;
        }
        else {
            
            i = next_i;
            j = next_j;
        }
    }
    printMagicSquare(magicSquare);
}

int main() {
    int n;

    cout << "��J�_�Ưx�}�j�p n: ";
    cin >> n;

    // �ˬd��J�O�_�����_��
    if (n <= 0 || n % 2 == 0) {
        cout << "���~�G��J���Ʀr�����O���_��" << endl;
        return 1;
    }

    cout << endl << n << "x" << n << " ���x�}�G" << endl;
    createMagicSquare(n);

    return 0;
}
