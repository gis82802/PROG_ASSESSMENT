#include "RationalNumber.hpp" 
#include <iostream>
#include <cmath>

using namespace std;
static int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    else {
        return gcd(b, a % b);
    }
}

RationalNumber::RationalNumber(int n, int d) {
    num = n;
    den = d;

    normalize();
}
void RationalNumber::normalize() {
    if (den == 0) {
        cout << "���~�G�������o���s" << endl;
        num = 0;
        den = 1;
        return;
    }
    if (num == 0) {
        den = 1;
        return;
    }
    int common = gcd(abs(num), abs(den));
    num /= common;
    den /= common;
    if (den < 0) {
        num = -num;
        den = -den;
    }
}

void RationalNumber::print() {
    if (den == 1) {
        cout << num << endl;
    }
    else if (num > den) {
        cout << num / den << "+" << num % den << "/" << den << endl;
    }
    else {
        cout << num << "/" << den << endl;
    }
}

void RationalNumber::add(const RationalNumber& other) { 
    this->num = this->num * other.den + other.num * this->den; this->den = this->den * other.den; normalize(); 
}
void RationalNumber::sub(const RationalNumber& other) { 
    this->num = this->num * other.den - other.num * this->den; this->den = this->den * other.den; normalize(); 
}
void RationalNumber::mul(const RationalNumber& other) { 
    this->num *= other.num; this->den *= other.den; normalize(); 
}
void RationalNumber::div(const RationalNumber& other) {
    if (other.num == 0) {
        cout << "���~�G���ƪ��Ȭ��s" << endl;
        return;
    }
    this->num *= other.den;
    this->den *= other.num;
    normalize();
}

int main() {
    RationalNumber a(1, 2);
    RationalNumber b(3, 4);

    cout << "a = "; a.print();
    cout << "b = "; b.print();
    cout << "--------------------" << endl;

    // ���� a.add(b);
    cout << "���� a.add(b)" << endl;
    a.add(b);
    cout << "a = a + b = ";
    a.print();
    cout << "--------------------" << endl;

    // ���� b.sub(a);
    cout << "���� b.sub(a) (a ���Ȭ� 5/4)" << endl;
    b.sub(a);
    cout << "b = b - a = ";
    b.print();
    cout << "--------------------" << endl;

    // ���� a.mul(b);
    cout << "���� a.mul(b) (b ���Ȭ� -1/2)" << endl;
    a.mul(b);
    cout << "a = a * b = ";
    a.print();
    cout << "--------------------" << endl;

    // ���� b.div(a);
    cout << "���� b.div(a) (a ���Ȭ� -5/8)" << endl;
    b.div(a);
    cout << "b = b / a = ";
    b.print();
    cout << "--------------------" << endl;

    return 0;
}