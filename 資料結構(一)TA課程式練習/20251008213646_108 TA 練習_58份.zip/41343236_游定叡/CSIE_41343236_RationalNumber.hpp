#ifndef RATIONALNUMBER_HPP
#define RATIONALNUMBER_HPP

class RationalNumber {
private:
    int num;       //���l
    int den;       //����
    void normalize();

public:
    RationalNumber(int n = 0, int d = 1);
    void print();
    void add(const RationalNumber& other);
    void sub(const RationalNumber& other);
    void mul(const RationalNumber& other);
    void div(const RationalNumber& other);
};

#endif // RATIONALNUMBER_HPP