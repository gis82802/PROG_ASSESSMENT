#include "RationalNmuber.h"
#include <cstdlib> // for abs()

// �̤j���]�ơ]���j�^
int Rational::gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}

// ²�Ƥ���
void Rational::simplify() {
    if (denominator < 0) {
        denominator *= -1;
        numerator *= -1;
    }
    int g = gcd(std::abs(numerator), std::abs(denominator));
    numerator /= g;
    denominator /= g;
}

// �غc�l
Rational::Rational(int num, int den) {
    if (den == 0) {
        std::cerr << "�������i�� 0" << std::endl;
        exit(1);
    }
    numerator = num;
    denominator = den;
    simplify();
}

// �|�h�B��
void Rational::add(const Rational& r) {
    numerator = numerator * r.denominator + r.numerator * denominator;
    denominator *= r.denominator;
    simplify();
}

void Rational::sub(const Rational& r) {
    numerator = numerator * r.denominator - r.numerator * denominator;
    denominator *= r.denominator;
    simplify();
}

void Rational::mul(const Rational& r) {
    numerator *= r.numerator;
    denominator *= r.denominator;
    simplify();
}

void Rational::div(const Rational& r) {
    if (r.numerator == 0) {
        std::cerr << "���H 0 ���~" << std::endl;
        exit(1);
    }
    numerator *= r.denominator;
    denominator *= r.numerator;
    simplify();
}

// �L�X���G
void Rational::print() const {
    int whole = numerator / denominator;
    int remain = std::abs(numerator % denominator);

    if (remain == 0) {
        std::cout << whole << std::endl;
    }
    else if (whole == 0) {
        if (numerator < 0)
            std::cout << "-";
        std::cout << remain << "/" << denominator << std::endl;
    }
    else {
        std::cout << whole << "+" << remain << "/" << denominator << std::endl;
    }
}
