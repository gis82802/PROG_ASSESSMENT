#include "RationalNmuber.h"

int main() {
    Rational a(1, 2), b(3, 4);   // a = 1/2, b = 3/4

    a.add(b);   // a = 1/2 + 3/4 = 5/4
    a.print();  // 1+1/4

    b.sub(a);   // b = 3/4 - 5/4 = -1/2
    b.print();  // -1/2

    a.mul(b);   // a = 5/4 * (-1/2) = -5/8
    a.print();  // -5/8

    b.div(a);   // b = (-1/2) / (-5/8) = 4/5
    b.print();  // 4/5

    return 0;
}
