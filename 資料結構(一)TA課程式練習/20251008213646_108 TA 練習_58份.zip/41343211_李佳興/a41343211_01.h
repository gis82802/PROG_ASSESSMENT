#pragma once
#include <iostream>
using namespace std;

const int max_size = 99; // �̤j�ؤo

void generateMagicSquare(int n, int sc[99][99]) {
    int row = n / 2; // �q�����}�l
    int col = n - 1;
    int num = 1;

    // ��l�Ưx�}
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sc[i][j] = 0;
        }
    }

    // ��R�]�N��}
    while (num <= n * n) {
        if (row == -1 && col == n) { // ��ɳB�z
            col = n - 2;
            row = 0;
        }
        else {
            if (col == n) { // �W�L�k���
                col = 0;
            }
            if (row < 0) { // �W�L�W���
                row = n - 1;
            }
        }

        if (sc[row][col] != 0) { // �w�g���Ʀr�A����W�@��
            col -= 2;
            row++;
            continue;
        }
        else {
            sc[row][col] = num++;
        }

        row--;
        col++;
    }
}
