#include <iostream>
#include <cmath>

class RationalNumber {
private:
    int numerator;   // ���l
    int denominator; // ����

    // �p��̤j���]�ơ]GCD�^�Ω��²����
    int gcd(int a, int b) {
        a = std::abs(a);
        b = std::abs(b);
        while (b) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // ��²����
    void simplify() {
        if (denominator == 0) {
            throw std::invalid_argument("Denominator cannot be zero");
        }
        if (numerator == 0) {
            denominator = 1;
            return;
        }
        int g = gcd(numerator, denominator);
        numerator /= g;
        denominator /= g;
        if (denominator < 0) { // �T�O��������
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    // �غc���
    RationalNumber(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        simplify();
    }

    // �[�k
    RationalNumber add(const RationalNumber& other) {
        int new_num = numerator * other.denominator + other.numerator * denominator;
        int new_den = denominator * other.denominator;
        RationalNumber result(new_num, new_den);
        return result;
    }

    // ��k
    RationalNumber sub(const RationalNumber& other) {
        int new_num = numerator * other.denominator - other.numerator * denominator;
        int new_den = denominator * other.denominator;
        RationalNumber result(new_num, new_den);
        return result;
    }

    // ���k
    RationalNumber mul(const RationalNumber& other) {
        int new_num = numerator * other.numerator;
        int new_den = denominator * other.denominator;
        RationalNumber result(new_num, new_den);
        return result;
    }

    // ���k
    RationalNumber div(const RationalNumber& other) {
        if (other.numerator == 0) {
            throw std::invalid_argument("Division by zero");
        }
        int new_num = numerator * other.denominator;
        int new_den = denominator * other.numerator;
        RationalNumber result(new_num, new_den);
        return result;
    }

    // �L�X����
    void print() {
        if (numerator == 0) {
            std::cout << "0" << std::endl;
            return;
        }
        if (std::abs(numerator) < std::abs(denominator)) {
            // �u����
            std::cout << numerator << "/" << denominator << std::endl;
        }
        else {
            // �������ର�a����
            int whole = numerator / denominator;
            int remain = std::abs(numerator % denominator);
            if (remain == 0) {
                std::cout << whole << std::endl;
            }
            else {
                if (whole == 0) {
                    std::cout << numerator << "/" << denominator << std::endl;
                }
                else {
                    std::cout << whole << (whole > 0 ? "+" : "") << remain << "/" << denominator << std::endl;
                }
            }
        }
    }
};

int main() {
    int num1, denom1, num2, denom2;

    // ���ܨϥΪ̿�J�Ĥ@�Ӧ��z��
    std::cout << "Enter the numerator and denominator for the first rational number (e.g., 1 2 for 1/2): ";
    std::cin >> num1 >> denom1;

    // �ˬd�����O�_��0
    while (denom1 == 0) {
        std::cout << "Denominator cannot be zero. Please enter again: ";
        std::cin >> num1 >> denom1;
    }

    // ���ܨϥΪ̿�J�ĤG�Ӧ��z��
    std::cout << "Enter the numerator and denominator for the second rational number (e.g., 3 4 for 3/4): ";
    std::cin >> num2 >> denom2;

    // �ˬd�����O�_��0
    while (denom2 == 0) {
        std::cout << "Denominator cannot be zero. Please enter again: ";
        std::cin >> num2 >> denom2;
    }

    // �إߨ�Ӧ��z�ƪ���
    RationalNumber a(num1, denom1), b(num2, denom2);

    // ����[�k�ÿ�X
    std::cout << "a + b = ";
    a = a.add(b);
    a.print();

    // �����k�ÿ�X
    std::cout << "b - a = ";
    b = b.sub(a);
    b.print();

    // ���歼�k�ÿ�X
    std::cout << "a * b = ";
    a = a.mul(b);
    a.print();

    // ���氣�k�ÿ�X
    std::cout << "b / a = ";
    try {
        b = b.div(a);
        b.print();
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }

    return 0;
}