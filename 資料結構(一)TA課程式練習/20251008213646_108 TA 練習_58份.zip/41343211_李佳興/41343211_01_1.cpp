#include <iostream>
using namespace std;

const int max_size = 99; // �̤j�ؤo

void generateMagicSquare(int n, int sc[99][99]) {
    int row = n / 2; // �q�����}�l
    int col = n - 1;
    int num = 1;

    // ��l�Ưx�}
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sc[i][j] = 0;
        }
    }

    // ��R�]�N��}
    while (num <= n * n) {
        if (row == -1 && col == n) { // ��ɳB�z
            col = n - 2;
            row = 0;
        }
        else {
            if (col == n) { // �W�L�k���
                col = 0;
            }
            if (row < 0) { // �W�L�W���
                row = n - 1;
            }
        }

        if (sc[row][col] != 0) { // �w�g���Ʀr�A����W�@��
            col -= 2;
            row++;
            continue;
        }
        else {
            sc[row][col] = num++;
        }

        row--;
        col++;
    }
}

int main() {
    int n, sc[99][99];

    do {
        cout << "Please input the size of your magic square: ";
        cin >> n;
        if (n % 2 == 0 || n < 1 || n > max_size) { // �T�O�O�_�ƨåB�ŦX�d��
            cout << "Invalid input. Please input an odd number between 1 and " << max_size << endl;
        }
    } while (n % 2 == 0 || n < 1 || n > max_size);

    generateMagicSquare(n, sc);

    // ��X�]�N��}
    cout << "Magic Square of size " << n << ":\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << sc[i][j] << "\t";
        }
        cout << endl;
    }

    // �p��ÿ�X�C��B�C�C���`�M
    int magicSum = 0;
    for (int i = 0; i < n; i++) {
        magicSum += sc[0][i]; // ���]�C�檺�M���ӬۦP
    }
    cout << "Magic sum is: " << magicSum << endl;

    return 0;
}
