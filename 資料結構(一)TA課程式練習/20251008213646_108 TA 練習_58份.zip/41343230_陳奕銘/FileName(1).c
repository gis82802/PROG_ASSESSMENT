#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int num; // ���l numerator
    int den; // ���� denominator
} Rational;

// �p��̤j���]�� (����۰��k)
int gcd(int a, int b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a;
}

// �����ýT�O��������
void simplify(Rational* r) {
    if (r->den < 0) {
        r->den = -r->den;
        r->num = -r->num;
    }
    int g = gcd(r->num, r->den);
    if (g != 0) {
        r->num /= g;
        r->den /= g;
    }
}

// �إߤ@�� Rational ���c
Rational create(int n, int d) {
    if (d == 0) d = 1;
    Rational r = { n, d };
    simplify(&r);
    return r;
}

// �[�k
void add(Rational* a, Rational b) {
    a->num = a->num * b.den + b.num * a->den;
    a->den = a->den * b.den;
    simplify(a);
}

// ��k
void sub(Rational* a, Rational b) {
    a->num = a->num * b.den - b.num * a->den;
    a->den = a->den * b.den;
    simplify(a);
}

// ���k
void mul(Rational* a, Rational b) {
    a->num = a->num * b.num;
    a->den = a->den * b.den;
    simplify(a);
}

// ���k
void divi(Rational* a, Rational b) {
    a->num = a->num * b.den;
    a->den = a->den * b.num;
    simplify(a);
}

// �L�X���G
void print(Rational r) {
    if (r.num == 0) {
        printf("0\n");
        return;
    }

    int whole = r.num / r.den;      // ��Ƴ���
    int rem = abs(r.num % r.den);   // �l�Ƴ���

    if (rem == 0) {
        printf("%d\n", whole);
    }
    else if (whole == 0) {
        printf("%d/%d\n", r.num, r.den);
    }
    else {
        printf("%d+%d/%d\n", whole, rem, r.den);
    }
}

// �D�{������
int main() {
    Rational a = create(1, 2);
    Rational b = create(3, 4);

    add(&a, b);
    printf("a = ");
    print(a);   // 1+1/4

    sub(&b, a);
    printf("b = ");
    print(b);   // -1/2

    mul(&a, b);
    printf("a = ");
    print(a);   // -5/8

    divi(&b, a);
    printf("b = ");
    print(b);   // 4/5

    return 0;
}
