#include "./SiameseMagicSquare.h"
#include "./BorderExchangeMagicSquare.h"
#include "./SymmetricExchangeMagicSquare.h"
#include "./RationalNumber.h"


int32_t main() {
    std::cout << "Question 1" << std::endl;

    std::cout << "\nOdd Magic Square:" << std::endl;

    SiameseMagicSquare sms(5);
    if (sms.generate()) {
        sms.show();
        sms.verify();
    }

    std::cout << "\nDouble Even Magic Square:" << std::endl;

    SymmetricExchangeMagicSquare sems(8);
    if (sems.generate()) {
        sems.show();
        sems.verify();
    }

    std::cout << "\nSingle Even Magic Square:" << std::endl;

    BorderExchangeMagicSquare bems(10);
    if (bems.generate()) {
        bems.show();
        bems.verify();
    }

    std::cout << std::endl;

    std::cout << "Question 2" << std::endl;

    RationalNumber r1(1, 2);  // 1/2
    RationalNumber r2(3, 4);  // 3/4

    std::cout << "Rational Number 1: ";
    r1.show();

    std::cout << "Rational Number 2: ";
    r2.show();

    r1.add(r2);
    std::cout << "After Addition: ";
    r1.show();

    r1.sub(r2);
    std::cout << "After Subtraction: ";
    r1.show();

    r1.mul(r2);
    std::cout << "After Multiplication: ";
    r1.show();

    r1.div(r2);
    std::cout << "After Division: ";
    r1.show();

    return 0;
}