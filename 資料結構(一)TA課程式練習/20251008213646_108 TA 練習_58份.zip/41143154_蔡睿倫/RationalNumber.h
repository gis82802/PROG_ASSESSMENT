#include <iostream>

class RationalNumber {
private:
    int32_t numerator;
    int32_t denominator;
    
    int32_t gcd(int32_t a, int32_t b) {
        a = abs(a);
        b = abs(b);
        while (b != 0) {
            int32_t temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    void simplify() {
        if (denominator == 0) {
            std::cerr << "error: denominator cannot be zero!" << std::endl;
            return;
        }
        
        int32_t g = gcd(numerator, denominator);
        numerator /= g;
        denominator /= g;
        
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    RationalNumber(int32_t num = 0, int32_t den = 1) : numerator(num), denominator(den) {
        simplify();
    }
    
    // a/b + c/d = (ad + bc) / bd
    void add(const RationalNumber& other) {
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator = denominator * other.denominator;
        simplify();
    }
    
    // a/b - c/d = (ad - bc) / bd
    void sub(const RationalNumber& other) {
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator = denominator * other.denominator;
        simplify();
    }
    
    // (a/b) * (c/d) = ac / bd
    void mul(const RationalNumber& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        simplify();
    }
    
    // (a/b) / (c/d) = (a/b) * (d/c) = ad / bc
    void div(const RationalNumber& other) {
        if (other.numerator == 0) {
            std::cerr << "error: divisor cannot be zero!" << std::endl;
            return;
        }
        numerator *= other.denominator;
        denominator *= other.numerator;
        simplify();
    }

    void show() const {
        if (denominator == 1)
            std::cout << numerator << std::endl;
        else
            std::cout << numerator << "/" << denominator << std::endl;
    }
};