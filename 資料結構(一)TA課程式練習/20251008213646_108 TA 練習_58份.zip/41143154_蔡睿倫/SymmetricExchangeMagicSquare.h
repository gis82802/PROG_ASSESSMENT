#include <iostream>
#include <iomanip>
#include <vector>

class SymmetricExchangeMagicSquare {
private:
    int32_t n;
    std::vector<std::vector<int32_t>> square;
    int32_t magic_sum;

    void calculate_magic_sum() {
        magic_sum = n * (n * n + 1) / 2;
    }

    bool is_diagonal(int32_t row, int32_t col) {
        int32_t block_size = n / 4;
        int32_t block_row = row / block_size;
        int32_t block_col = col / block_size;
        int32_t in_block_row = row % block_size;
        int32_t in_block_col = col % block_size;

        if (in_block_row == in_block_col) {
            if (block_row == block_col) return true;
            if (block_row + block_col == 3) return true;
        }

        if (in_block_row + in_block_col == block_size - 1) {
            if (block_row + block_col == 3) return true;
            if (block_row == block_col) return true;
        }
        
        return false;
    }

public:
    SymmetricExchangeMagicSquare(int32_t size) 
        : n(size), square(size, std::vector<int32_t>(size, 0)) {
        calculate_magic_sum();
    }

    bool generate() {
        if (n % 4 != 0) {
            std::cout << "please input number for double even." << std::endl;
            return false;
        }

        int32_t num = 1;
        for (int32_t i = 0; i < n; ++i) {
            for (int32_t j = 0; j < n; ++j) {
                square[i][j] = num++;
            }
        }

        for (int32_t i = 0; i < n; ++i) {
            for (int32_t j = 0; j < n; ++j) {
                if (!is_diagonal(i, j)) {
                    int32_t sym_i = n - 1 - i;
                    int32_t sym_j = n - 1 - j;
                    
                    if (i < sym_i || (i == sym_i && j < sym_j)) {
                        std::swap(square[i][j], square[sym_i][sym_j]);
                    }
                }
            }
        }

        return true;
    }

    void show() const {
        for (const auto& row : square) {
            std::cout << "[";
            for (size_t i = 0; i < row.size(); ++i) {
                if (i > 0) std::cout << ",";
                std::cout << std::setw(4) << row[i];
            }
            std::cout << "]" << std::endl;
        }
    }

    bool verify() const {
        // Check rows and columns
        for (int32_t i = 0; i < n; ++i) {
            int32_t row_sum = 0;
            int32_t col_sum = 0;
            for (int32_t j = 0; j < n; ++j) {
                row_sum += square[i][j];
                col_sum += square[j][i];
            }
            if (row_sum != magic_sum || col_sum != magic_sum) {
                return false;
            }
            std::cout << "rows" << i << " sum: " << row_sum << std::endl;
            std::cout << "cols" << i << " sum: " << col_sum << std::endl;
        }

        // Check diagonals
        int32_t diag1_sum = 0;
        int32_t diag2_sum = 0;
        for (int32_t i = 0; i < n; ++i) {
            diag1_sum += square[i][i];
            diag2_sum += square[i][n - i - 1];
        }
        if (diag1_sum != magic_sum || diag2_sum != magic_sum) {
            return false;
        }
        std::cout << "diag1 sum: " << diag1_sum << std::endl;
        std::cout << "diag2 sum: " << diag2_sum << std::endl;

        return true;
    }
};