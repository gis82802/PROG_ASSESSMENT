#include <iostream>
#include <iomanip>
#include <vector>

class SiameseMagicSquare {
private:
    int32_t n;
    std::vector<std::vector<int32_t>> square;
    int32_t magic_sum;

    void calculate_magic_sum() {
        magic_sum = n * (n * n + 1) / 2;
    }

public:
    SiameseMagicSquare(int32_t size): n(size), square(size, std::vector<int32_t>(size, 0)) {
        calculate_magic_sum();
    }

    bool generate() {
        if (n % 2 == 0) {
            std::cout << "please input odd number." << std::endl;
            return false;
        }

        for (int32_t i = 0; i < n; ++i) {
            for (int32_t j = 0; j < n; ++j) {
                square[i][j] = 0;
            }
        }

        int32_t row = 0;
        int32_t col = n / 2;

        for (int32_t num = 1; num <= n * n; ++num) {
            square[row][col] = num;
            int32_t next_row = (row - 1 + n) % n;
            int32_t next_col = (col - 1 + n) % n;

            if (square[next_row][next_col] != 0) {
                row = (row + 1) % n;
            } else {
                row = next_row;
                col = next_col;
            }
        }

        return true;
    }

    void show() const {
        for (const auto& row : square) {
            std::cout << "[";
            for (size_t i = 0; i < row.size(); ++i) {
                if (i > 0) std::cout << ",";
                std::cout << std::setw(4) << row[i];
            }
            std::cout << "]" << std::endl;
        }
    }
    bool verify() const {
        // Check rows and columns
        for (int32_t i = 0; i < n; ++i) {
            int32_t row_sum = 0;
            int32_t col_sum = 0;
            for (int32_t j = 0; j < n; ++j) {
                row_sum += square[i][j];
                col_sum += square[j][i];
            }
            if (row_sum != magic_sum || col_sum != magic_sum) {
                return false;
            }
            std::cout << "rows" << i << " sum: " << row_sum << std::endl;
            std::cout << "cols" << i << " sum: " << col_sum << std::endl;
        }

        // Check diagonals
        int32_t diag1_sum = 0;
        int32_t diag2_sum = 0;
        for (int32_t i = 0; i < n; ++i) {
            diag1_sum += square[i][i];
            diag2_sum += square[i][n - i - 1];
        }
        if (diag1_sum != magic_sum || diag2_sum != magic_sum) {
            return false;
        }
        std::cout << "diag1 sum: " << diag1_sum << std::endl;
        std::cout << "diag2 sum: " << diag2_sum << std::endl;

        return true;
    }

};
