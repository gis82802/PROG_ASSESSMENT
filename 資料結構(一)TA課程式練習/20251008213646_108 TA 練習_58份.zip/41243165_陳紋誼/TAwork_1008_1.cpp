#include <iostream>
#include "TAwork_1008_1.h"

using namespace std;

// ���
int digits(int x) {
	int d = 0;

	if (x == 0) {
		return 1;
	}
	while (x) {
		x = x / 10;
		d++;
	}

	return d;
}

// �e��
void printWithWidth(int x, int width) {
	int d = digits(x);

	for (int i = d; i < width; i++) {
		cout << ' ';
	}
	cout << x;
}

void Magic(const int n) {
	if (n <= 0 || (n % 2 == 0)) {
		cout << "n �����O���_��" << endl;
		return;
	}

	int* a = new int[n * n];
	for (int i = 0; i < n * n; i++) {
		a[i] = 0;
	}

	int i = 0, j = n / 2;
	for (int key = 1; key <= n * n; key++) {
		a[i * n + j] = key;
		int ni = (i - 1 + n) % n;
		int nj = (j + 1) % n;
		if (a[ni * n + nj] != 0) {
			i = (i + 1) % n;
		}
		else {
			i = ni;
			j = nj;
		}
	}
	int cellW = digits(n * n) + 1;
	cout << "magic square of size " << n << "\n";
	for (int r = 0; r < n; r++) {
		for (int c = n - 1; c >= 0; c--) {
			printWithWidth(a[r * n + c], cellW);
		}
		cout << "\n";
	}

	delete[] a;
}

int main() {
	int n;
	cout << "�п�J�_�� n�G";
	if (!(cin >> n)) {
		return 0;
	}
	Magic(n);

	return 0;
}