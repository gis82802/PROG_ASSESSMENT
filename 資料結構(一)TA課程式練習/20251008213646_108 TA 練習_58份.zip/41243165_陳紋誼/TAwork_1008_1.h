#ifndef MAGIC_SQUARE_H
#define MAGIC_SQUARE_H

#include <iostream>

int digits(int x);
void printWithWidth(int x, int width);
void Magic(const int n);

#endif
