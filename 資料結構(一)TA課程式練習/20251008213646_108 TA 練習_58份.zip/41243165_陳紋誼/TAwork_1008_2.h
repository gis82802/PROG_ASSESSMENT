#ifndef MAGIC_SQUARE_H
#define MAGIC_SQUARE_H

#include <iostream>
#include <cstdlib>

using namespace std;

#endif
