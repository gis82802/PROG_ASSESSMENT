#include <iostream>
#include "TAwork_1008_2.h"

using namespace std;

class Rational {
    int num; // ���l
    int den; // ����(> 0)

    void normalize() {
        if (den == 0) {
            cerr << "�������i�� 0\n";
            exit(1);
        }

        // �����ॿ�A�t������l
        if (den < 0) {
            den = -den;
            num = -num;
        }

        // 0
        if (num == 0) {
            den = 1;
            return;
        }

        // �ڴX���o��k
        int a = (num >= 0 ? num : -num);
        int b = den;
        while (b != 0) {
            int t = a % b;
            a = b;
            b = t;
        }
        int g = (a == 0 ? 1 : a);

        num /= g;
        den /= g;
    }
public:
    Rational(int n = 0, int d = 1) : num(n), den(d) {
        normalize();
    }

    void add(const Rational& r) {
        num = num * r.den + r.num * den;
        den = den * r.den;
        normalize();
    }
    void sub(const Rational& r) {
        num = num * r.den - r.num * den;
        den = den * r.den;
        normalize();
    }
    void mul(const Rational& r) {
        num = num * r.num;
        den = den * r.den;
        normalize();
    }
    void div(const Rational& r) {
        if (r.num == 0) {
            cerr << "���H 0\n";
            exit(1);
        }
        num = num * r.den;
        den = den * r.num;
        normalize();
    }

    void print() const {
        // ���
        if (den == 1) {
            cout << num << "\n";
            return;
        }

        int nabs = (num >= 0 ? num : -num);

        // ������ -> �a����
        if (nabs >= den) {
            int k = nabs / den, r = nabs % den;
            if (r == 0) { cout << (num < 0 ? -k : k) << "\n"; }
            else {
                if (num < 0) cout << "-(" << k << "+" << r << "/" << den << ")\n";
                else          cout << k << "+" << r << "/" << den << "\n";
            }
        }
        else {
            if (num < 0) cout << "-" << nabs << "/" << den << "\n";
            else          cout << nabs << "/" << den << "\n";
        }
    }
};

int main() {
    Rational a(1, 2), b(3, 4);
    a.add(b);  a.print();  // 1+1/4
    b.sub(a);  b.print();  // -1/2
    a.mul(b);  a.print();  // -5/8
    b.div(a);  b.print();  // 4/5
    return 0;
}