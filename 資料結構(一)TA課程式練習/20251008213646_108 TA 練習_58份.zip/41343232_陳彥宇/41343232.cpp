#include<iostream>
using namespace std;
int main(void)
{
	int n;
	cout << "�п�J�@�ө_��n: " << endl;
	cin >> n;
	if (n % 2 == 0 || n <= 0)
	{
		cout << "��J���~!" << endl;
		return(0);
	}
	int** magic = new int* [n];
	for (int i = 0; i < n; i++)
	{
		magic[i] = new int[n];
		for (int j = 0; j < n; j++)
		{
			magic[i][j] = 0;
		}
	}
	int i = 0;
	int j = n / 2;
	for (int num = 1; num <= n * n; num++)
	{
		magic[i][j] = num;
		int new_i = (i - 1 + n) % n;
		int new_j = (j - 1 + n) % n;
		if (magic[new_i][new_j] != 0)
		{
			i = (i + 1) % n;
		}
		else
		{
			i = new_i;
			j = new_j;
		}
	}
	cout << "�]�N��}" << endl;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			cout << magic[i][j] << "\t";
		cout << endl;
	}
	for (int i = 0; i < n;i++)
	{
		delete[]magic[i];
	}
	delete[] magic;
	return(0);
}
