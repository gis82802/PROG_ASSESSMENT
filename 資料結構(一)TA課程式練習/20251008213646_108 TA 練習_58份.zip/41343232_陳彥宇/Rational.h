#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>
#include <cstdlib>  

class Rational {
private:
    int numerator;     
    int denominator;  

   
    int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }


    void simplify() {
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
        int g = gcd(abs(numerator), denominator);
        numerator /= g;
        denominator /= g;
    }

public:
  
    Rational(int n = 0, int d = 1) {
        numerator = n;
        denominator = d;
        simplify();
    }

 
    void add(const Rational& r) {
        numerator = numerator * r.denominator + r.numerator * denominator;
        denominator = denominator * r.denominator;
        simplify();
    }

 
    void sub(const Rational& r) {
        numerator = numerator * r.denominator - r.numerator * denominator;
        denominator = denominator * r.denominator;
        simplify();
    }

 
    void mul(const Rational& r) {
        numerator *= r.numerator;
        denominator *= r.denominator;
        simplify();
    }


    void div(const Rational& r) {
        numerator *= r.denominator;
        denominator *= r.numerator;
        simplify();
    }


    void print() const {
        if (numerator == 0) {
            std::cout << 0 << std::endl;
            return;
        }

        int whole = numerator / denominator;
        int remainder = abs(numerator % denominator);

        if (whole != 0 && remainder != 0) {
            std::cout << whole << "+" << remainder << "/" << denominator << std::endl;
        }
        else if (whole == 0) {
            if (numerator < 0)
                std::cout << "-" << remainder << "/" << denominator << std::endl;
            else
                std::cout << remainder << "/" << denominator << std::endl;
        }
        else {
            std::cout << whole << std::endl;
        }
    }
};

#endif

