#include <iostream>
#include<string>
#include<vector>
#include<iomanip>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cout << "請輸入奇數 n：";
    if (!(cin >> n)) return 0;

    if (n <= 0 || n % 2 == 0) {
        cout << "n 必須為正奇數！\n";
        return 0;
    }

    vector<vector<int>> a(n, vector<int>(n, 0));

    // 起點：第一列的中間
    int r = 0;
    int c = n / 2;

    for (int k = 1; k <= n * n; ++k) {
        a[r][c] = k;

        // 嘗試往右上
        int nr = (r - 1 + n) % n;  // 上越界就繞到底
        int nc = (c + 1) % n;      // 右越界就繞到最左

        if (a[nr][nc] != 0) {
            // 右上已被佔，往下
            r = (r + 1) % n;
            // c 不變
        }
        else {
            // 可以放在右上
            r = nr;
            c = nc;
        }
    }

    // 輸出
    // 找對齊寬度（最多到 n^2）
    int width = to_string(n * n).size();
    cout << "n = " << n << " 的奇數階魔方陣：\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << setw(width) << a[i][j] << (j + 1 == n ? '\n' : ' ');
        }
    }

    // 額外驗證：列和、欄和、對角和
    long long target = 1LL * n * (1LL * n * n + 1) / 2;
    cout << "理論魔方陣常數 M = " << target << "\n";

    // 檢查第一列和、第一欄和、兩條對角線
    long long row0 = 0, col0 = 0, d1 = 0, d2 = 0;
    for (int j = 0; j < n; ++j) row0 += a[0][j];
    for (int i = 0; i < n; ++i) col0 += a[i][0];
    for (int i = 0; i < n; ++i) d1 += a[i][i];
    for (int i = 0; i < n; ++i) d2 += a[i][n - 1 - i];

    cout << "第一列和 = " << row0 << "\n";
    cout << "第一欄和 = " << col0 << "\n";
    cout << "主對角線和 = " << d1 << "\n";
    cout << "副對角線和 = " << d2 << "\n";

    return 0;
}
