
#include <iostream>
#include <cstdlib>   // 為了 abs() 和 exit()
#include <cmath>     // abs() 的另一個來源（對整數有效時用 <cstdlib> 也行）
using namespace std;
int gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
};
class Rational {
private:
    int numerator;   // 分子
    int denominator; // 分母

    // 化簡函數：自動把分數化為最簡
    void reduce() {
        if (denominator < 0) { // 確保分母為正
            denominator = -denominator;
            numerator = -numerator;
        }
        int g = gcd(abs(numerator), abs(denominator));
        numerator /= g;
        denominator /= g;
    }

public:
    // 建構子
    Rational(int n = 0, int d = 1) {
        if (d == 0) {
            cout << "Error: denominator cannot be zero!" << endl;
            exit(1);
        }
        numerator = n;
        denominator = d;
        reduce();
    }

    // 加法
    void add(const Rational& r) {
        numerator = numerator * r.denominator + r.numerator * denominator;
        denominator *= r.denominator;
        reduce();
    }

    // 減法
    void sub(const Rational& r) {
        numerator = numerator * r.denominator - r.numerator * denominator;
        denominator *= r.denominator;
        reduce();
    }

    // 乘法
    void mul(const Rational& r) {
        numerator *= r.numerator;
        denominator *= r.denominator;
        reduce();
    }

    // 除法
    void div(const Rational& r) {
        if (r.numerator == 0) {
            cout << "Error: divide by zero!" << endl;
            exit(1);
        }
        numerator *= r.denominator;
        denominator *= r.numerator;
        reduce();
    }

    // 印出結果（包含帶分數判斷）
    void print() const {
        int whole = numerator / denominator;     // 整數部分
        int remain = abs(numerator % denominator); // 餘分數部分
        if (remain == 0) {
            cout << numerator / denominator << endl;
        }
        else if (whole == 0) {
            cout << numerator << "/" << denominator << endl;
        }
        else {
            cout << whole << "+" << remain << "/" << denominator << endl;
        }
    }
};