#ifndef CSIE_41343224_1008_2_H
#define CSIE_41343224_1008_2_H
class RationalNumber{
    private:
        int num;
        int den;
    public:
        RationalNumber(int setNum = 0 , int setDen = 1);
        void add(const RationalNumber &other);
        void sub(const RationalNumber &other);
        void mul(const RationalNumber &other);
        void div(const RationalNumber &other);
        void print();
        void normalizeSign();
        void simplified();
};

#endif