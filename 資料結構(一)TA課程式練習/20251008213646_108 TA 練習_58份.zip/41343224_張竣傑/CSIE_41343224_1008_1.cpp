#include <iostream>

using namespace std;

int main(){
    const int maxSize = 51;
    cout<<"請輸入魔術方陣的大小n(奇數):";
    int n;
    cin>>n;
    int **square = new int*[n]; 
    if(n>maxSize or n<1)
        throw "錯誤!!輸入值不在可執行範圍";
    else if(!(n%2)) throw "錯誤!!輸入值不是奇數";
    
    for(int i = 0 ; i < n ; i++){
        square[i] = new int[n];
        fill(square[i],square[i]+n,0);
    }
    
    square[0][((n-1)/2)] = 1;

    int count = 2 , row = 0 , col = (n-1)/2;
    
    while(count <= n*n){
        if((row - 1) < 0) row = n - 1;
        else row--;
        if((col-1) < 0) col = n - 1;
        else col--;
        if(square[row][col]!=0)row=(row+1)%n;
        square[row][col] = count;
        count++;
    }
    for(int i = 0 ; i < n ; i++){
        for(int j = 0 ; j < n ; j++)
            cout<<square[i][j]<<"\t";
        cout<<endl;
    }
    for(int i=0;i<n;i++) delete[] square[i];
    delete[] square;

}