#include <iostream>
#include <cmath>
#include "RationalNumber.hpp"
using namespace std;
int RationalNumber::gcd(int a, int b) {
    a = abs(a);
    b = abs(b);
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}
void RationalNumber::simplify() {
    if (numerator == 0) {
        denominator = 1;
        return;
    }
    int common_divisor = gcd(numerator, denominator);
    numerator /= common_divisor;
    denominator /= common_divisor;
    if (denominator < 0) {
        denominator = -denominator;
        numerator = -numerator;
    }
}
RationalNumber::RationalNumber(int num, int den) {
    if (den == 0) {
        cerr << "Error: Denominator cannot be zero. Initializing to 0/1." << endl;
        numerator = 0;
        denominator = 1;
    }
    else {
        numerator = num;
        denominator = den;
    }
    simplify();
}
void RationalNumber::print() const {
    if (numerator == 0) cout << 0 << endl;
    else if (denominator == 1) cout << numerator << endl;
    else if (abs(numerator) < denominator) cout << numerator << "/" << denominator << endl;
    else {
        int integer_part = numerator / denominator;
        int remainder_num = abs(numerator % denominator);
        if (remainder_num == 0) cout << integer_part << endl;
        else cout << integer_part << "+" << remainder_num << "/" << denominator << endl;
    }
}
void RationalNumber::add(const RationalNumber& other) {
    numerator = numerator * other.denominator + other.numerator * denominator;
    denominator = denominator * other.denominator;
    simplify();
}
void RationalNumber::sub(const RationalNumber& other) {
    numerator = numerator * other.denominator - other.numerator * denominator;
    denominator = denominator * other.denominator;
    simplify();
}
void RationalNumber::mul(const RationalNumber& other) {
    numerator *= other.numerator;
    denominator *= other.denominator;
    simplify();
}
void RationalNumber::div(const RationalNumber& other) {
    if (other.numerator == 0) {
        cerr << "Error: Division by zero (0/x) is not allowed." << endl;
        return;
    }
    numerator *= other.denominator;
    denominator *= other.numerator;
    simplify();
}
int main() {
    RationalNumber a(1, 2);
    RationalNumber b(3, 4);
    cout << "a = "; a.print();
    cout << "b = "; b.print();
    cout << "\na.add(b)..." << endl;
    a.add(b);
    cout << "ANS a = ";
    a.print();
    cout << "\nb.sub(a)..." << endl;
    b.sub(a);
    cout << "ANS b = ";
    b.print();
    cout << "\na.mul(b)..." << endl;
    a.mul(b);
    cout << "ANS a = ";
    a.print();
    cout << "\nb.div(a)..." << endl;
    b.div(a);
    cout << "ANS b = ";
    b.print();
}