#include "Rational.hpp"

int main()
{
    int a_num, a_den, b_num, b_den;

    // 手動輸入分數 a
    cout << "請輸入第一個分數 a 的分子和分母（空格分隔）: ";
    cin >> a_num >> a_den;

    // 手動輸入分數 b
    cout << "請輸入第二個分數 b 的分子和分母（空格分隔）: ";
    cin >> b_num >> b_den;

    Rational a(a_num, a_den), b(b_num, b_den);

    cout << "\n依序計算四則運算結果（帶分數形式）：\n";

    // 1. 加法 a + b
    a.add(b);
    cout << "a = a + b = ";
    a.print();
    cout << endl;

    // 2. 減法 b - a
    b.sub(a);
    cout << "b = b - a = ";
    b.print();
    cout << endl;

    // 3. 乘法 a * b
    a.mul(b);
    cout << "a = a * b = ";
    a.print();
    cout << endl;

    // 4. 除法 b / a
    b.div(a);
    cout << "b = b / a = ";
    b.print();
    cout << endl;

    return 0;
}
