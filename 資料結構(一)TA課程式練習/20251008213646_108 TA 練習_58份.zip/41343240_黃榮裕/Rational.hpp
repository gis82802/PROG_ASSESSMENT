#ifndef RATIONAL_HPP
#define RATIONAL_HPP

#include <iostream>
#include <cmath>
#include <cstdlib>
using namespace std;

// 計算最大公因數
inline int gcd(int a, int b) { return b ? gcd(b, a % b) : a; }

class Rational
{
    int n, d; // 分子、分母

    void reduce()
    {
        int g = gcd(abs(n), abs(d));
        n /= g;
        d /= g;
        if (d < 0)
        {
            n = -n;
            d = -d;
        }
    }

public:
    Rational(int a = 0, int b = 1)
    {
        if (b == 0)
        {
            cout << "分母不可為0\n";
            exit(1);
        }
        n = a;
        d = b;
        reduce();
    }

    void add(const Rational &x)
    {
        n = n * x.d + x.n * d;
        d *= x.d;
        reduce();
    }
    void sub(const Rational &x)
    {
        n = n * x.d - x.n * d;
        d *= x.d;
        reduce();
    }
    void mul(const Rational &x)
    {
        n *= x.n;
        d *= x.d;
        reduce();
    }
    void div(const Rational &x)
    {
        if (x.n == 0)
        {
            cout << "除數為0\n";
            exit(1);
        }
        n *= x.d;
        d *= x.n;
        reduce();
    }

    // 帶分數輸出
    void print() const
    {
        if (abs(n) >= d)
        {
            int integerPart = n / d;
            int remainder = abs(n % d);
            if (remainder == 0)
                cout << integerPart;
            else
                cout << integerPart << "+" << remainder << "/" << d;
        }
        else
        {
            cout << n << "/" << d;
        }
    }
};

#endif
