#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "請輸入奇數矩陣大小 n: ";
    cin >> n;

    // 驗證輸入必須是正奇數
    if (n % 2 == 0 || n <= 0)
    {
        cout << "錯誤：n 必須為奇數且大於 0。" << endl;
        return 0;
    }

    // 動態配置 n×n 的二維陣列，並初始化為 0
    int **magic = new int *[n];
    for (int i = 0; i < n; i++)
        magic[i] = new int[n](); // () 使每個元素初始為 0

    int num = 1;          // 要填入的數字
    int i = 0, j = n / 2; // 起始位置：第一列中間

    // 使用「Siamese method」生成奇數階魔方陣
    while (num <= n * n)
    {
        magic[i][j] = num++;        // 放入數字
        int newi = (i - 1 + n) % n; // 上一列（若超出頂端則回到底部）
        int newj = (j + 1) % n;     // 右一欄（若超出右邊則回到最左）

        // 若新位置已被填過，則移到原位置的下一列
        if (magic[newi][newj] != 0)
            i = (i + 1) % n;
        else
        {
            i = newi;
            j = newj;
        }
    }

    // 輸出結果
    cout << "\nMagic Matrix (" << n << "x" << n << "):\n";
    for (int r = 0; r < n; r++)
    {
        for (int c = 0; c < n; c++)
            cout << magic[r][c] << "\t";
        cout << endl;
    }

    // 釋放動態記憶體
    for (int i = 0; i < n; i++)
        delete[] magic[i];
    delete[] magic;

    return 0;
}
