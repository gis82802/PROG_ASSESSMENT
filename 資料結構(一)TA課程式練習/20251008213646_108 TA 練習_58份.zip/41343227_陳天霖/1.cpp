#include <iostream>
#include <vector>
using namespace std;

int main() {
	int n;
	cout << "�п�J�x�}�j�p n�]�������_�ơ^: ";
	cin >> n;

	if (n % 2 == 0) {
		cout << "���~�Gn �������_�ơI" << endl;
		return 0;
	}

	
	vector<vector<int>> magic(n, vector<int>(n, 0));

	int num = 1;
	int i = 0; 
	int j = n / 2; 

	while (num <= n * n) {
		magic[i][j] = num; 
		num++;

		int new_i = (i - 1 + n) % n;
		int new_j = (j + 1) % n; 

		if (magic[new_i][new_j] != 0) {
			
			i = (i + 1) % n;
		}
		else {
			i = new_i;
			j = new_j;
		}
	}

	
	cout << "\nMagic Matrix (" << n << "x" << n << "):\n";
	for (int r = 0; r < n; r++) {
		for (int c = 0; c < n; c++) {
			cout << magic[r][c] << "\t";
		}
		cout << endl;
	}



	return 0;
}