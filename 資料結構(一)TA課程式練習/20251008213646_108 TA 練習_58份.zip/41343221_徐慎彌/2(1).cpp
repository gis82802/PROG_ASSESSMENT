#include <iostream>
#include <cmath>  
using namespace std;

class Rational {
private:
    int num;  
    int den; 

    int gcd(int a, int b) {
        if (b == 0) return abs(a);
        return gcd(b, a % b);
    }


    void simplify() {
        int g = gcd(num, den);
        num /= g;
        den /= g;
        if (den < 0) {  
            num = -num;
            den = -den;
        }
    }

public:

    Rational(int n = 0, int d = 1) {
        num = n;
        den = d;
        simplify();
    }

    void add(const Rational& r) {
        num = num * r.den + r.num * den;
        den = den * r.den;
        simplify();
    }

    void sub(const Rational& r) {
        num = num * r.den - r.num * den;
        den = den * r.den;
        simplify();
    }

    void mul(const Rational& r) {
        num *= r.num;
        den *= r.den;
        simplify();
    }

    void div(const Rational& r) {
        num *= r.den;
        den *= r.num;
        simplify();
    }

    void print() const {
        if (num == 0) {
            cout << "0" << endl;
            return;
        }

        int whole = num / den;
        int remainder = abs(num % den);

        if (whole != 0 && remainder != 0)
            cout << whole << "+" << remainder << "/" << den << endl;
        else if (remainder == 0)
            cout << whole << endl;
        else if (whole == 0)
            cout << num << "/" << den << endl;
    }
};

int main() {
    Rational a(1, 2), b(3, 4);  

    a.add(b);
    a.print();  

    b.sub(a);
    b.print();  

    a.mul(b);
    a.print();  

    b.div(a);
    b.print();  

    return 0;
}
