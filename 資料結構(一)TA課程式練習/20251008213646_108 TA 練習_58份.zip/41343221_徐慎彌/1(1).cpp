#include <iostream>
#include <vector>
#include <iomanip> 
#include <stdexcept>

using namespace std;

vector<vector<int>> makeMagicMatrix(int n) {

    vector<vector<int>> magic(n, vector<int>(n, 0));

    int i = 0;      
    int j = n / 2;    
    for (int num = 1; num <= n * n; ++num) {
        magic[i][j] = num;
        int next_i = (i - 1 + n) % n;
        int next_j = (j + 1) % n;    

        if (magic[next_i][next_j] != 0) {
        
            i = (i + 1) % n;
        }
        else {
            i = next_i;
            j = next_j;
        }
    }
    return magic;
}

int main() {
    int n;
    cout << "�п�J�_�Ưx�}�j�p n�G";
    cin >> n;

    try {
        auto magic = makeMagicMatrix(n);
        cout << "\n�]�N��} (" << n << "x" << n << "):\n\n";

        for (const auto& row : magic) {
            for (int val : row)
                cout << setw(4) << val;  
            cout << '\n';
        }

        cout << "\n�]�N�`�� = " << n * (n * n + 1) / 2 << endl;

    }
    catch (const invalid_argument& e) {
        cerr << "���~�G" << e.what() << endl;
    }

    return 0;
}
