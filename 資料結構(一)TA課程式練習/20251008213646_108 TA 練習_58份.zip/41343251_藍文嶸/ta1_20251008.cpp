#include <iostream>
#include <algorithm>
#include <iterator>
#include<iomanip>
using namespace std;

void magic(const int n)
{
    int** square;  // �ϥΰʺA�G���}�C
    int k, l;

    if ((n < 1)) throw "Error! out of range";
    if (!(n % 2)) throw "Error! ..n is even";

    // �ʺA�t�m n x n �}�C
    square = new int* [n];
    for (int i = 0; i < n; i++)
    {
        square[i] = new int[n];
        fill(square[i], square[i] + n, 0); // ��l�Ƭ�0
    }

    square[0][(n - 1) / 2] = 1;

    int key = 2;
    int i = 0;
    int j = (n - 1) / 2;

    while (key <= n * n)
    {
        if (i - 1 < 0) k = n - 1; else k = i - 1;
        if (j - 1 < 0) l = n - 1; else l = j - 1;
        if (square[k][l]) i = (i + 1) % n;
        else { i = k; j = l; }

        square[i][j] = key;
        key++;
    }

    cout << "magic square of size " << n << endl;
    for (i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            cout << setw(4) << square[i][j]; 
        cout << endl;
    }

    // ����ʺA�O����
    for (int i = 0; i < n; i++)
        delete[] square[i];
    delete[] square;
}

// �d�� main
int main()
{
    int n;
    cout << "��J�_�ƥH�ͦ�magic matrix: ";
    cin >> n;
    try
    {
        magic(n);
    }
    catch (const char* msg)
    {
        cerr << msg << endl;
    }
    return 0;
}


