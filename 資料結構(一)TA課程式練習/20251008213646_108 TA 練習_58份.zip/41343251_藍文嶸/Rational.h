#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>
#include <cstdlib>
using namespace std;

class Rational {
private:
    int x; // ���l
    int y; // ����

    // ����۰��k�DGCD
    int gcd(int a, int b) const {
        while (b != 0) {
            int r = a % b;
            a = b;
            b = r;
        }
        return a;
    }

    // ²�Ƥ���
    void simplify() {
        int g = gcd(abs(x), abs(y));
        x /= g;
        y /= g;
        if (y < 0) {
            x = -x;
            y = -y;
        }
    }

public:
    // �غc�l�]�L�w�]�Ѽơ^
    Rational(int n, int d) : x(n), y(d) {
        simplify();
    }

    // �R�A��k�إ߱a�w�]�Ȫ� Rational
    static Rational make(int n = 0, int d = 1) {
        return Rational(n, d);
    }

    // �B��
    void add(const Rational& b) {
        x = x * b.y + b.x * y;
        y = y * b.y;
        simplify();
    }

    void sub(const Rational& b) {
        x = x * b.y - b.x * y;
        y = y * b.y;
        simplify();
    }

    void mul(const Rational& b) {
        x *= b.x;
        y *= b.y;
        simplify();
    }

    void div(const Rational& b) {
        x *= b.y;
        y *= b.x;
        simplify();
    }

    void print() const {
        if (abs(x) >= y) {
            int whole = x / y;
            int rem = abs(x % y);
            if (rem == 0)
                cout << whole << endl;
            else
                cout << whole << "+" << rem << "/" << y << endl;
        }
        else {
            cout << x << "/" << y << endl;
        }
    }
};

#endif
