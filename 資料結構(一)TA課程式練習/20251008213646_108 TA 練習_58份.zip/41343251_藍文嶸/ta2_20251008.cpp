#include <iostream>
#include <cstdlib>
#include "Rational.h"
using namespace std;

int main() {
    Rational a(1, 2), b(3, 4);  // a=1/2, b=3/4

    a.add(b);
    a.print();  // 1+1/4

    b.sub(a);
    b.print();  // -1/2

    a.mul(b);
    a.print();  // -5/8

    b.div(a);
    b.print();  // 4/5

    return 0;
}
