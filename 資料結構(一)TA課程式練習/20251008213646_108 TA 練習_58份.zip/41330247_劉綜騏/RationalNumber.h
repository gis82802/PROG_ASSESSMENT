#ifndef RATIONALNUMBER_H
#define RATIONALNUMBER_H

#include <iostream>
#include <stdexcept>

class RationalNumber {
private:
    int numerator;
    int denominator;

    int gcd_impl(int a, int b) const;
    void simplify();

public:
    RationalNumber(int num = 0, int den = 1);

    
    RationalNumber& add(const RationalNumber& other);
    RationalNumber& sub(const RationalNumber& other);
    RationalNumber& mul(const RationalNumber& other);
    RationalNumber& div(const RationalNumber& other);

    void print() const;
};

#endif 