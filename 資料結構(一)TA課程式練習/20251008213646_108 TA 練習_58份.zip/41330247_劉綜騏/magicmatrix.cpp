#include <iostream>
#include <vector>
#include <iomanip> 
using namespace std;

int main() {
    int n;
    cout << "�п�J�x�}�j�p n (�_��): ";
    cin >> n;

    const int Maxsize = 51;
    if ((n > Maxsize) || (n < 1)) {
        cout << "n ���A�d�򤺡]�̤j��51�A�̤p��1�^" << endl;
        return 1;
    }
    else if ((n % 2 == 0)) {
        cout << "n �����_��" << endl;
        return 1;
    }
    vector<vector<int>> magic(n, vector<int>(n, 0));

    int num = 1;           
    int i = 0;             
    int j = n / 2;         
    int temp_i, temp_j;

    while (num <= n * n) {
        magic[i][j] = num;
        num++;

        temp_i = i;
        temp_j = j;

        i = (i - 1 + n) % n;
        j = (j - 1 + n) % n;

        if (magic[i][j] != 0) {
            i = (temp_i + 1) % n;
            j = temp_j;
        }
    }

    cout << "\n�]��} (" << n << "x" << n << "):\n";
    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            cout << setw(4) << magic[r][c];
        }
        cout << endl;
    }

    return 0;
}
