#include "RationalNumber.h"
#include <iostream>
#include <stdexcept>

int main() {
    try {
        
        RationalNumber a(1, 2), b(3, 4);

        std::cout << "Initial: a="; a.print(); 
        std::cout << "Initial: b="; b.print(); 
        std::cout << "-----------------" << std::endl;
      
        std::cout << "a.add(b): a = ";
        a.add(b);
        a.print(); // 
        std::cout << "-----------------" << std::endl;
    
        std::cout << "b.sub(a): b = ";
        b.sub(a);
        b.print(); 
        std::cout << "-----------------" << std::endl;

        std::cout << "a.mul(b): a = ";
        a.mul(b);
        a.print(); 
        std::cout << "-----------------" << std::endl;

        std::cout << "b.div(a): b = ";
        b.div(a);
        b.print(); 
        std::cout << "-----------------" << std::endl;

    }
    catch (const std::exception& e) {
        std::cerr << "������~: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}