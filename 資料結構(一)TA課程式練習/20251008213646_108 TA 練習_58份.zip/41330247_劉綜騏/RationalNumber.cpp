﻿#include "RationalNumber.h"
#include <cmath>
#include <cstdlib>
#include <algorithm> 

int RationalNumber::gcd_impl(int a, int b) const {
    
    if (a < 0) a = -a;
    if (b < 0) b = -b;

    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

void RationalNumber::simplify() {
    if (denominator == 0) {
        throw std::runtime_error("Denominator cannot be zero.");
    }

    if (numerator == 0) {
        denominator = 1;
        return;
    }

    if (denominator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }


    int common_divisor = gcd_impl(numerator, denominator);
    numerator = numerator / common_divisor;
    denominator = denominator / common_divisor;
}


RationalNumber::RationalNumber(int num, int den) : numerator(num), denominator(den) {
    if (den == 0) {
        denominator = 1;
    }
    simplify();
}

RationalNumber& RationalNumber::add(const RationalNumber& other) {
    numerator = numerator * other.denominator + other.numerator * denominator;
    denominator = denominator * other.denominator;
    simplify();
    return *this;
}


RationalNumber& RationalNumber::sub(const RationalNumber& other) {
    numerator = numerator * other.denominator - other.numerator * denominator;
    denominator = denominator * other.denominator;
    simplify();
    return *this;
}


RationalNumber& RationalNumber::mul(const RationalNumber& other) {
    numerator = numerator * other.numerator;
    denominator = denominator * other.denominator;
    simplify();
    return *this;
}


RationalNumber& RationalNumber::div(const RationalNumber& other) {
    if (other.numerator == 0) {
        throw std::runtime_error("Division by zero is not allowed.");
    }
    numerator = numerator * other.denominator;
    denominator = denominator * other.numerator;
    simplify();
    return *this;
}

void RationalNumber::print() const {
    if (numerator == 0) {
        std::cout << "0" << std::endl;
        return;
    }

    int abs_num = std::abs(numerator);
    int sign = (numerator < 0) ? -1 : 1;

    int integer_part = abs_num / denominator;
    int remainder = abs_num % denominator;

    if (integer_part != 0) {
        std::cout << sign * integer_part;
    }

    if (remainder != 0) {
        if (integer_part != 0) {
            std::cout << "+";
        }
        if (integer_part == 0 && sign == -1) {
            std::cout << "-";
        }
        std::cout << remainder << "/" << denominator;
    }
    std::cout << std::endl;
}