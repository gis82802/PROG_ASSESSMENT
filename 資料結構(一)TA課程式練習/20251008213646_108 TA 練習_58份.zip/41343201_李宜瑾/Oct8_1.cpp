#include <iostream>
#include <vector>
#include <algorithm> 
using namespace std;

void magic(const int n) {
    if (n < 1 || !(n % 2)) {
        cerr << "Error: n must be a positive odd number." << endl;
        return;
    }
    vector<vector<int>> square(n, vector<int>(n, 0));

    int i = 0;
    int j = (n - 1) / 2;
    square[i][j] = 1;

    for (int key = 2; key <= n * n; ++key) {

        int next_i = i - 1; 
        int next_j = j - 1; 
      
        if (next_i < 0) {
            next_i = n - 1;
        }
        if (next_j < 0) {
            next_j = n - 1;
        }     
        if (square[next_i][next_j] != 0) {
         
            i = (i + 1) % n;
            
        }
        else {
            
            i = next_i;
            j = next_j;
        }

        
        square[i][j] = key;
    }
    cout << "�]�N��}�j�p�� " << n << endl;
    for (int r = 0; r < n; ++r) {
        for (int c = 0; c < n; ++c) {
            cout << square[r][c] << "\t";
        }
        cout << endl;
    }
}

int main() {
    int n;

    cout << "��J��}�j�p" << endl;
    if (!(cin >> n)) {
        cerr << "��J�L��" << endl;
        return 1;
    }

    magic(n);

    return 0;
}