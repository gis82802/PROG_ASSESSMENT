#ifndef RATIONALNUMBER_H
#define RATIONALNUMBER_H

#include <iostream>
#include <cmath> 
#include <numeric> 

class RationalNumber {
private:
    int numerator;   // ���l 
    int denominator; // ���� 
    int gcd(int a, int b) const;

    void reduce();

public:
    RationalNumber(int num = 0, int den = 1);

    // �B���k
    void add(const RationalNumber& other);
    void sub(const RationalNumber& other);
    void mul(const RationalNumber& other);
    void div(const RationalNumber& other);

    void print() const;
};

#endif 