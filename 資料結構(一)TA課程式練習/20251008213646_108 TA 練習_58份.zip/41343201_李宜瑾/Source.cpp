#include "RationalNumber.h"
#include <cmath>
#include <numeric> 

int RationalNumber::gcd(int a, int b) const {
    a = std::abs(a);
    b = std::abs(b);

    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}
void RationalNumber::reduce() {
    if (denominator == 0) {
        return;
    }

    if (numerator == 0) {
        denominator = 1;
        return;
    }

    int common = gcd(numerator, denominator);
    numerator /= common;
    denominator /= common;

    if (denominator < 0) {
        numerator *= -1;
        denominator *= -1;
    }
}

RationalNumber::RationalNumber(int num, int den) {
    if (den == 0) {
        std::cerr << "Error: Denominator cannot be zero. Setting to 1." << std::endl;
        denominator = 1;
    }
    else {
        denominator = den;
    }
    numerator = num;
    reduce();
}

void RationalNumber::add(const RationalNumber& other) {
    numerator = numerator * other.denominator + other.numerator * denominator;
    denominator = denominator * other.denominator;
    reduce();
}

void RationalNumber::sub(const RationalNumber& other) {
    numerator = numerator * other.denominator - other.numerator * denominator;
    denominator = denominator * other.denominator;
    reduce();
}

void RationalNumber::mul(const RationalNumber& other) {
    numerator = numerator * other.numerator;
    denominator = denominator * other.denominator;
    reduce();
}

void RationalNumber::div(const RationalNumber& other) {
    if (other.numerator == 0) {
        std::cerr << "Error: Division by zero is undefined. Operation aborted." << std::endl;
        return;
    }

    numerator = numerator * other.denominator;
    denominator = denominator * other.numerator;
    reduce();
}
void RationalNumber::print() const {
    if (denominator == 1 || numerator == 0) {
        std::cout << numerator;
    }
    else {
        int integer_part = numerator / denominator;
        int remainder = std::abs(numerator % denominator);

        if (integer_part != 0) {
            std::cout << integer_part;

            if (remainder != 0) {
                std::cout << "+" << remainder << "/" << denominator;
            }
        }
        else {
            std::cout << numerator << "/" << denominator;
        }
    }
    std::cout << std::endl;
}