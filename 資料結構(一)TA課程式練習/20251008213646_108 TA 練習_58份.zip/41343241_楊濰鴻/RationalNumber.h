// RationalNumber.h
#pragma once

#include <iostream>
#include <stdexcept>
using namespace std;

class RationalNumber {
private:
    int numerator;   // 分子
    int denominator; // 分母

    int gcd(int a, int b) {
        if (b == 0) return a;
        return gcd(b, a % b);
    }

    // 約分
    void reduce() {
        if (denominator < 0) { // 保持分母為正
            numerator = -numerator;
            denominator = -denominator;
        }
        if (numerator == 0) {
            denominator = 1; // 0/x 都化為 0/1
            return;
        }
        int g = gcd(abs(numerator), abs(denominator)); // 自寫 gcd 函式
        numerator /= g;
        denominator /= g;
    }

public:
    RationalNumber(int n=0, int d=1) : numerator(n), denominator(d) {
        reduce();
    }

    void add(const RationalNumber& rhs) {
        numerator = numerator * rhs.denominator + rhs.numerator * denominator;
        denominator = denominator * rhs.denominator;
        reduce();
    }

    void sub(const RationalNumber& rhs) {
        numerator = numerator * rhs.denominator - rhs.numerator * denominator;
        denominator = denominator * rhs.denominator;
        reduce();
    }

    void mul(const RationalNumber& rhs) {
        numerator = numerator * rhs.numerator;
        denominator = denominator * rhs.denominator;
        reduce();
    }

    void div(const RationalNumber& rhs) {
        if (rhs.numerator == 0) {
            throw std::runtime_error("Division by zero");
        }
        numerator = numerator * rhs.denominator;
        denominator = denominator * rhs.numerator;
        reduce();
    }

    void print() const {
        if (denominator == 1) {
            cout << numerator << endl;
        } else if (abs(numerator) > denominator) {
            int whole = numerator / denominator;
            int rem = abs(numerator % denominator);
            if (rem == 0) cout << whole << endl;
            else cout << whole << "+" << rem << "/" << denominator << endl;
        } else {
            cout << numerator << "/" << denominator << endl;
        }
    }
};

