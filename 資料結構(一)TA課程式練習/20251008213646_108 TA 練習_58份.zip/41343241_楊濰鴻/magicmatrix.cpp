#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    const int maxsize = 51;
    int n;
    int square[maxsize][maxsize], k, l;
    cout << "Enter the size of the magic matrix (odd number):";
    cin >> n;
    if (n % 2 == 0 || n > maxsize || n < 1)
    {
        cout << "Error:size must be an odd number and over or less than" << maxsize << endl;
        return 0;
    }
    else
    {
        for (int i = 0;i < n;i++)//initialize the matrix with 0
            fill(square[i], square[i] + n, 0);
        square[0][(n - 1) / 2] = 1;//the first number
        int i = 0, j = (n - 1) / 2;
        square[i][j] = 1;

        for (int key = 2; key <= n * n; key++) {
            int newi = (i - 1 + n) % n;// move up
            int newj = (j + 1) % n;// move right

            if (square[newi][newj] != 0) {
                i = (i + 1) % n; // move down
            }
            else {
                i = newi;
                j = newj;
            }
            square[i][j] = key;
        }
        cout << "The magic matrix is:" << endl;
        for (int i = 0;i < n;i++)
        {
            for (int j = 0;j < n;j++)
                cout << square[i][j] << "\t";
            cout << endl;
        }
    }
    return 0;
}