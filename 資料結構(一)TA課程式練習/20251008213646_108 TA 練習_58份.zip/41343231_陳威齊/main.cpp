#include <iostream>
#include "RationalNumber.h"  // �]�t���Y��

using namespace std;

int main() {
    try {
        // ���եΨ�
        RationalNumber a(1, 2);  // a = 1/2
        RationalNumber b(3, 4);  // b = 3/4

        cout << "��l a: ";
        a.print();
        cout << "��l b: ";
        b.print();
        cout << endl;

        // ����[�k
        cout << "���� a + b... " << endl;
        a.add(b);
        cout << "a = ";
        a.print();
        cout << endl;

        // �����k
        cout << "���� b - a... " << endl;
        b.sub(a);
        cout << "b = ";
        b.print();
        cout << endl;

        // ���歼�k
        cout << "���� a * b... " << endl;
        a.mul(b);
        cout << "a = ";
        a.print();
        cout << endl;

        // ���氣�k
        cout << "���� b / a... " << endl;
        b.div(a);
        cout << "b = ";
        b.print();
        cout << endl;

    }
    catch (const char* msg) {
        cout << msg << endl;
    }

    return 0;
}
