#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
    int n;

    if (!(cin >> n) || n <= 0 || (n % 2 == 0)) {

        return 1;
    }

    vector<vector<int>> ms(n, vector<int>(n, 0));

    int r = 0;
    int c = n / 2;

    for (int val = 1; val <= n * n; val++) {
        ms[r][c] = val;

        int nr = (r + 1) % n;
        int nc = (c + 1) % n;

        if (ms[nr][nc] == 0) {
            r = nr;
            c = nc;
        }
        else {
            r = (r - 1 + n) % n;
        }
    }
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            cout << setw(4) << ms[x][y];
        }
        cout << endl;
    }
    return 0;
}