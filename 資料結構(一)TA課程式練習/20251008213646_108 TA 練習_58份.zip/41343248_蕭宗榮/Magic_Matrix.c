#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    printf("�п�J�_�� n �M�wMagic Matrix�j�p�G");
    if (scanf("%d", &n) != 1) return 0;

    if (n <= 0 || n % 2 == 0) {
        printf("���~�G�п�J�@�Ӥj�� 0 ���_�ơC\n");
        return 0;
    }

    int** a = malloc(n * sizeof(int*));
    for (int i = 0; i < n; ++i) {
        a[i] = calloc(n, sizeof(int));
    }

    int num = 1;
    int maxnum = n * n;
    int row = 0;
    int col = n / 2;

    while (num <= maxnum) {
        a[row][col] = num;

        int next_row = (row - 1 + n) % n;
        int next_col = (col + 1) % n;

        if (a[next_row][next_col] != 0) {
            row = (row + 1) % n;
        }
        else {
            row = next_row;
            col = next_col;
        }
        ++num;
    }

    int width = 0, t = maxnum;
    while (t > 0) { width++; t /= 10; }
    width += 1;

    printf("\nMagic Square (n = %d):\n", n);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            printf("%*d", width, a[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < n; ++i) free(a[i]);
    free(a);
}