#include "Rational.h"
#include <cmath>

int gcd(int a, int b) {
    return b == 0 ? abs(a) : gcd(b, a % b);
}

Rational::Rational(int n, int d) {
    num = n;
    den = (d == 0 ? 1 : d);
    simplify();
}

void Rational::simplify() {
    int g = gcd(num, den);
    num /= g;
    den /= g;
    if (den < 0) {
        num = -num;
        den = -den;
    }
}

void Rational::add(const Rational& r) {
    num = num * r.den + r.num * den;
    den = den * r.den;
    simplify();
}

void Rational::sub(const Rational& r) {
    num = num * r.den - r.num * den;
    den = den * r.den;
    simplify();
}

void Rational::mul(const Rational& r) {
    num = num * r.num;
    den = den * r.den;
    simplify();
}

void Rational::div(const Rational& r) {
    num = num * r.den;
    den = den * r.num;
    simplify();
}

void Rational::print() const {
    if (num == 0) {
        cout << 0 << endl;
        return;
    }
    int n = num;
    int d = den;
    bool isNegative = n < 0;
    if (isNegative) n = -n;
    int integerPart = n / d;
    int remainder = n % d;
    if (isNegative) cout << "-";
    if (integerPart != 0) {
        cout << integerPart;
        if (remainder != 0) cout << "+" << remainder << "/" << d;
    }
    else {
        cout << remainder << "/" << d;
    }
    cout << endl;
}

int main() {
    int n1, d1, n2, d2;
    cout << "�п�J�Ĥ@�Ӧ��z�ƪ����l�P�����G";
    cin >> n1 >> d1;
    cout << "�п�J�ĤG�Ӧ��z�ƪ����l�P�����G";
    cin >> n2 >> d2;

    Rational a(n1, d1), b(n2, d2);

    cout << "a=" << n1 << "/" << d1 << endl;
    cout << "b=" << n2 << "/" << d2 << endl;
    a.add(b);
    cout << "a + b = ";
    a.print();

    b.sub(a);
    cout << "b - a = ";
    b.print();

    a.mul(b);
    cout << "a * b = ";
    a.print();

    b.div(a);
    cout << "b / a = ";
    b.print();

    return 0;
}
