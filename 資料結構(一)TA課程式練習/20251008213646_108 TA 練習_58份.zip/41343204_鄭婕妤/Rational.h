#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>
using namespace std;

class Rational {
private:
    int num;
    int den;
    void simplify();
public:
    Rational(int n = 0, int d = 1);
    void add(const Rational& r);
    void sub(const Rational& r);
    void mul(const Rational& r);
    void div(const Rational& r);
    void print() const;
};

#endif