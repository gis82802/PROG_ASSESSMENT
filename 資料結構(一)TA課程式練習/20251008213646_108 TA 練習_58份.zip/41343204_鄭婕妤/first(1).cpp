#include<iostream>
#include<vector>
using namespace std;

int main(void) {
    int n;
    cout << "��Jn�x�}:";
    cin >> n;
    if (n % 2 == 0) {
        cout << "n�����O�_��" << endl;
        return 0;
    }

    vector<vector<int>> magic(n, vector<int>(n, 0));
    int i = 0, j = n / 2;

    for (int num = 1; num <= n * n; num++) {
        magic[i][j] = num;
        int newi = (i - 1 + n) % n;
        int newj = (j + 1) % n;

        if (magic[newi][newj] != 0) {
            i = (i + 1) % n;
        }
        else {
            i = newi;
            j = newj;
        }
    }

    cout << "�]�N��}:" << endl;
    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            cout << magic[r][c] << "\t";
        }
        cout << endl;
    }
    return 0;
}
