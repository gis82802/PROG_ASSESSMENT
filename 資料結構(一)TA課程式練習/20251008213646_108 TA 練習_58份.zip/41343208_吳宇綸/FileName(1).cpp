#include <iostream>
#include "Rational.h"
using namespace std;

int main() {
    Rational a(1, 2), b(3, 4);

    a.add(b);
    cout << "a = "; a.print();  // 1+1/4

    b.sub(a);
    cout << "b = "; b.print();  // -1/2

    a.mul(b);
    cout << "a = "; a.print();  // -5/8

    b.div(a);
    cout << "b = "; b.print();  // 4/5

    return 0;
}
