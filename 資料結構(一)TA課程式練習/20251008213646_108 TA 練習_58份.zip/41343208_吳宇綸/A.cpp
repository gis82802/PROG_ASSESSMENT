#include <iostream>
#include <cmath>
#include "Rational.h"
using namespace std;

int Rational::gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

void Rational::reduce() {
    int g = gcd(abs(num), abs(den));
    num /= g;
    den /= g;
    if (den < 0) {
        num = -num;
        den = -den;
    }
}

Rational::Rational(int n, int d) {
    num = n;
    den = d;
    reduce();
}

void Rational::add(const Rational& r) {
    num = num * r.den + r.num * den;
    den = den * r.den;
    reduce();
}

void Rational::sub(const Rational& r) {
    num = num * r.den - r.num * den;
    den = den * r.den;
    reduce();
}

void Rational::mul(const Rational& r) {
    num *= r.num;
    den *= r.den;
    reduce();
}

void Rational::div(const Rational& r) {
    num *= r.den;
    den *= r.num;
    reduce();
}

void Rational::print() const {
    if (den == 1) cout << num << endl;
    else if (abs(num) > den) {
        int whole = num / den;
        int remainder = abs(num % den);
        if (remainder == 0)
            cout << whole << endl;
        else
            cout << whole << "+" << remainder << "/" << den << endl;
    }
    else {
        cout << num << "/" << den << endl;
    }
}
