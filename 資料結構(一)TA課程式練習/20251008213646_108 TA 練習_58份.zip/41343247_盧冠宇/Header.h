#include <iostream>
using namespace std;
class Rational {
private:
	int son = 0, mo = 0;
public:
	int gcd(int a, int b) {
		while (b != 0) {
			int temp = a % b;
			a = b;
			b = temp;
		}
		return a;
	}
	void sim() {
		if (mo < 0) { mo = -mo; son = -son; }
		int g = gcd(son, mo);
		son /= g; mo /= g;
	}
	Rational(int a, int b) { son = a; mo = b; }
	void add(Rational c2) {
		son = son * c2.mo + c2.son * mo;
		mo = mo * c2.mo;
		sim();
	}
	void sub(Rational c2) {
		son = son * c2.mo - c2.son * mo;
		mo = mo * c2.mo;
		sim();
	}
	void mul(Rational c2) {
		son = son * c2.son;
		mo = mo * c2.mo;
		sim();
	}
	void div(Rational c2) {
		son = son * c2.mo;
		mo = mo * c2.son;
		sim();
	}
	void print() {
		if (son >= mo)cout << int(son / mo) << "+" << son - mo << "/" << mo << endl;
		cout << son << "/" << mo << endl;
	}
};
