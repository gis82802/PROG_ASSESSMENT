#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;


int main(void) {
	int n = 0, k, l;
	cout << "��Jn:";
	cin >> n;
	int a[51][51] = { 0 };


	a[0][(n - 1) / 2] = 1;
	int key = 2, i = 0, j = (n - 1) / 2;
	while (key <= n * n) {
		if (i - 1 < 0)k = n - 1; else k = i - 1;
		if (j - 1 < 0)l = n - 1; else l = j - 1;
		if (a[k][l])i = (i + 1) % n;
		else { i = k; j = l; }
		a[i][j] = key++;
	}

	for (i = 0; i < n; i++) {
		copy(a[i], a[i] + n, ostream_iterator<int>(cout, " "));
		cout << endl;
	}
	return 0;
}