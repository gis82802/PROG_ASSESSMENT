#include <iostream>
#include <vector>

using namespace std;

void magicMatrix(vector<vector<int>> &, int);
void printMatrix(vector<vector<int>> &, int);
int magicConstant(int n);

int main() {
    int n;
    cout << "enter n: ";
    cin >> n;
    if (n % 2 == 0 || n <= 0) {
        cout << "n must be a positive odd number." << endl;
        return -1;
    }


    vector<vector<int>> matrix(n, vector<int> (n, 0));
    magicMatrix(matrix, n);
    printMatrix(matrix, n);

    int maagic_constant = magicConstant(n);
    cout << "magic constant: " << maagic_constant << endl;
    return 0;
}

void magicMatrix(vector<vector<int>> &matrix, int n) {
    int row = 0;
    int col = n / 2;
    int num = 1;

    for (int i = 1; i <= n * n; ++i) {
        matrix[row][col] = i;
        int next_row = (row - 1 + n) % n;
        int next_col = (col + 1) % n;
        if (matrix[next_row][next_col] == 0) {
            row = next_row;
            col = next_col;
        }

        else row = (row + 1) % n;

        num++;
    }

}

void printMatrix(vector<vector<int>> &matrix, int n) {
    cout << "magic square of size " << n << " X " << n << ":" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) cout << matrix[i][j] << "\t";

        cout << endl;
    }
}

int magicConstant(int n) {
    return n * (n * n + 1) / 2;
}