#include <iostream>
#include <numeric>
#include <cmath>
#include <stdexcept>

using namespace std;

class rationalNumber {
private:
    int num;
    int den;

    int findGCD(int a, int b) {
        a = abs(a);
        b = abs(b);
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    void simplify() {
        if (den == 0) {
            den = 1;
            num = 0;
            return;
        }

        int g = findGCD(num, den);
        num /= g;
        den /= g;

        if (den < 0) {
            num = -num;
            den = -den;
        }
    }

public:
    rationalNumber(int n = 0, int d = 1) : num(n), den(d) {
        simplify();
    }

    void add(const rationalNumber &other) {
        int new_num = num * other.den + other.num * den;
        int new_den = den * other.den;
        num = new_num;
        den = new_den;
        simplify();
    }

    void sub(const rationalNumber &other) {
        int new_num = num * other.den - other.num * den;
        int new_den = den * other.den;
        num = new_num;
        den = new_den;
        simplify();
    }

    void mul(const rationalNumber &other) {
        num *= other.num;
        den *= other.den;
        simplify();
    }

    void div(const rationalNumber &other) {
        if (other.num == 0) {
            throw runtime_error("除法錯誤: 除數為0");
        }

        int new_num = num * other.den;
        int new_den = den * other.num;
        num = new_num;
        den = new_den;
        simplify();
    }

    void toMixedNumber(int &whole, int &new_num, int &new_den) const {
        whole = num / den;
        new_num = abs(num % den);
        new_den = den;

        if (new_num == 0) {
            new_den = 1;
        }
    }

    void print() const {
        int whole, new_num, new_den;
        toMixedNumber(whole, new_num, new_den);

        if (whole != 0 && new_num != 0) {
            cout << whole << "+" << new_num << "/" << new_den << endl;
        } else if (whole != 0 && new_num == 0) {
            cout << whole << endl;
        } else if (whole == 0 && new_num != 0) {
            if (num < 0) {
                cout << "-" << new_num << "/" << new_den << endl;
            } else {
                cout << new_num << "/" << new_den << endl;
            }
        } else {
            cout << 0 << endl;
        }
    }
};