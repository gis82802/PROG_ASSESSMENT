#include <iostream>
#include "project2.h"

using namespace std;
RationalNumber::RationalNumber(int setNum, int setDen) {
	num = setNum;
	den = setDen;
}
void RationalNumber::simplified() {
	int a = num, b = den;
	while (b != 0) {
		int i = b;
		b = a % b;
		a = i;
	}
	num /= a;
	den /= a;
}
void RationalNumber::normalizeSign() {
	num = -num;
	den = -den;
}
void RationalNumber::print() {
	simplified();
	if (den < 0)normalizeSign();
	int n = num;
	int d = den;

	int integerPart = 0;
	int a = n >= 0 ? n : -n;
	int b = d;
	while (a >= b) {
		a -= b;
		integerPart++;
	}
	if (n < 0 && integerPart>0)
		integerPart = -integerPart;
	if (integerPart != 0)
		cout << integerPart << "+(" << a << "/" << d << ")" << endl;
	else
		cout << num << "/" << den << endl;
}
void RationalNumber::add(const RationalNumber& other) {
	num = num * other.den + other.num * den;
	den = den * other.den;
}
void RationalNumber::sub(const RationalNumber& other) {
	num = num * other.den - other.num * den;
	den = den * other.den;
}
void RationalNumber::mul(const RationalNumber& other) {
	num = num * other.num;
	den = den * other.den;
}
void RationalNumber::div(const RationalNumber& other) {
	num = num * other.den;
	den = den * other.num;
}