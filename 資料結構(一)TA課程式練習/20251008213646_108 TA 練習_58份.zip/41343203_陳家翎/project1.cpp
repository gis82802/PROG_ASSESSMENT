#include<iostream>
#include <vector>
#include<iomanip>
using namespace std;

void Magic(const int n){
	const int Max = 51;
	int sq[Max][Max], k, l;
	if ((n > Max) || (n < 1))
		throw"Out of range. ";
	else if (!(n % 2))
		throw"n is even. ";
	for (int i = 0; i < n; i++) 
		fill(sq[i], sq[i]+n, 0);
	sq[0][(n - 1) / 2] = 1;
	int key = 2, i = 0; int j = (n - 1) / 2;

	while (key <= n * n) {
		if (i - 1 < 0)k = n - 1; else k = i - 1;
		if (j - 1 < 0)l = n - 1; else l = j - 1;
		if (sq[k][l])i = (i + 1) % n;
		else {
			i = k, j = l;
		}
		sq[i][j] = key;
		key++;
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) 
			cout << setw(4) << sq[i][j];
			cout << endl;
	}
}
int main() {
	int n;
	cout << "��Jn:";
	cin >> n;
	try {
		Magic(n);
	}
	catch (const char* msg) {
		cout << msg << endl;
	}
	return 0;

}
