// Rational.h
#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>
using namespace std;

class Rational {
private:
    int num; // ���l
    int den; // ����

    void reduce();
    static int gcd(int a, int b); // �R�A gcd ���

public:
    Rational(int n = 0, int d = 1);

    void add(const Rational& r);
    void sub(const Rational& r);
    void mul(const Rational& r);
    void div(const Rational& r);

    void print() const;
};

#endif // RATIONAL_H

