#include "Rational.h"
#include <cstdlib>
#include <cmath>   

// gcd ��@�]�R�A��ơ^
int Rational::gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}

// ����
void Rational::reduce() {
    int g = gcd(abs(num), abs(den));
    num /= g;
    den /= g;
    if (den < 0) {
        num = -num;
        den = -den;
    }
}

// �غc�l
Rational::Rational(int n, int d) {
    if (d == 0) {
        cout << "�������i�H�� 0" << endl;
        exit(1);
    }
    num = n;
    den = d;
    reduce();
}

// �[�k
void Rational::add(const Rational& r) {
    num = num * r.den + r.num * den;
    den = den * r.den;
    reduce();
}

// ��k
void Rational::sub(const Rational& r) {
    num = num * r.den - r.num * den;
    den = den * r.den;
    reduce();
}

// ���k
void Rational::mul(const Rational& r) {
    num *= r.num;
    den *= r.den;
    reduce();
}

// ���k
void Rational::div(const Rational& r) {
    num *= r.den;
    den *= r.num;
    reduce();
}

// ��X
void Rational::print() const {
    if (den == 1) {
        cout << num << endl;
    } else if (abs(num) > den) {
        int whole = num / den;
        int remainder = abs(num % den);
        if (remainder == 0) {
            cout << whole << endl;
        } else {
            cout << whole << "+" << remainder << "/" << den << endl;
        }
    } else {
        cout << num << "/" << den << endl;
    }
}

