#include "magicSquare.h"

int main() {
    int n;
    cout << "�п�J�_�� n: ";
    cin >> n;
    magicSquare(n);
    return 0;
}

