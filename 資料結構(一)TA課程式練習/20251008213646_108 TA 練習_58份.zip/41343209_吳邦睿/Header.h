#pragma once
#include <iostream>
using namespace std;

int gcd(int a, int b) {
    return (b == 0) ? a : gcd(b, a % b);
}

class Rational {
private:
    int num;
    int den;

    void reduce() {
        int g = gcd(abs(num), abs(den));
        num /= g;
        den /= g;
        if (den < 0) {
            num = -num;
            den = -den;
        }
    }

public:
    Rational(int n = 0, int d = 1) {
        num = n;
        den = d;
        reduce();
    }

    void add(const Rational& r) {
        num = num * r.den + r.num * den;
        den = den * r.den;
        reduce();
    }

    void sub(const Rational& r) {
        num = num * r.den - r.num * den;
        den = den * r.den;
        reduce();
    }

    void mul(const Rational& r) {
        num *= r.num;
        den *= r.den;
        reduce();
    }

    void div(const Rational& r) {
        num *= r.den;
        den *= r.num;
        reduce();
    }

    void print() const {
        if (den == 1) {
            cout << num << endl;
        }
        else if (abs(num) > den) {
            int whole = num / den;
            int remainder = abs(num % den);
            if (remainder == 0)
                cout << whole << endl;
            else
                cout << whole << "+" << remainder << "/" << den << endl;
        }
        else {
            cout << num << "/" << den << endl;
        }
    }
};

