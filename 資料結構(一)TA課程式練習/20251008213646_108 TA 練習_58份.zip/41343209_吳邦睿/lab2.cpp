#include"Header.h"
int main() {
    int n1, d1, n2, d2;
    cout << "�п�J�Ĥ@�Ӥ��� a (���l ����): ";
    cin >> n1 >> d1;
    cout << "�п�J�ĤG�Ӥ��� b (���l ����): ";
    cin >> n2 >> d2;

    Rational a(n1, d1), b(n2, d2);

    // a = a + b
    a.add(b);
    cout << "a = a + b = ";
    a.print();

    // b = b - a
    b.sub(a);
    cout << "b = b - a = ";
    b.print();

    // a = a * b
    a.mul(b);
    cout << "a = a * b = ";
    a.print();

    // b = b / a
    b.div(a);
    cout << "b = b / a = ";
    b.print();

    return 0;
}
