#include <iostream>
using namespace std;
void mg(int n) {
    int matrix[50][50] = { 0 };
    int i = 0;
    int j = n / 2;

    for (int num = 1; num <= n * n; num++) {
        matrix[i][j] = num;
        int next_i = (i - 1 + n) % n;
        int next_j = (j - 1 + n) % n;

        if (matrix[next_i][next_j] != 0) {
            i = (i + 1) % n;
        }
        else {
            i = next_i;
            j = next_j;
        }
    }

    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            cout << matrix[r][c] << "\t";
        }
        cout << endl;
    }
}

int main() {
    int n;
    cin >> n;
    if (n % 2 == 0) {
        cout << "n �����O�_�ơI" << endl;
        return 0;
    }
    mg(n);
    return 0;
}
