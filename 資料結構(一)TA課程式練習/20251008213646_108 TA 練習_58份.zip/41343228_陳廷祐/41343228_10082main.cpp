#include "41343228_1008head.h"
#include "41343228_1008RationalNmuber.cpp"
int main() {
    RationalNumber a(1, 2); 
    RationalNumber b(3, 4);

    // ���ե[�k�Ga = a + b = 1/2 + 3/4 = 5/4
    a.add(b);
    a.print();

    // ���մ�k�Gb = b - a = 3/4 - 5/4 = -1/2
    b.sub(a);
    b.print(); 

    // ���խ��k�Ga = a * b = 5/4 * (-1/2) = -5/8
    a.mul(b);
    a.print(); 

    // ���հ��k�Gb = b / a = (-1/2) / (-5/8) = 4/5
    b.div(a);
    b.print(); 

    return 0;
}