#include <iostream>
#include <numeric>  // std::gcd ���
using namespace std;

class RationalNumber {
public:
    int n, d;

    RationalNumber(int numerator, int denominator) {
        n = numerator;
        d = denominator;
    }

    void print() const {
        if (d == 1) {
            cout << n << endl; 
        }
        else {
            cout << n << '/' << d << endl;
        }
    }

    void add(const RationalNumber& other) {
        n = n * other.d + other.n * d;
        d = d * other.d;

        int gcd_value = std::gcd(n, d);  
        n /= gcd_value;
        d /= gcd_value;
    }

    void sub(const RationalNumber& other) {
        n = n * other.d - other.n * d;
        d = d * other.d;

        int gcd_value = std::gcd(n, d);  
        n /= gcd_value;
        d /= gcd_value;
    }

    void mul(const RationalNumber& other) {
        n = n * other.n;
        d = d * other.d;

        int gcd_value = std::gcd(n, d);  
        n /= gcd_value;
        d /= gcd_value;
    }

    void div(const RationalNumber& other) {
        n = n * other.d;
        d = d * other.n;

        if (d < 0) {
            n = -n;
            d = -d;
        }

        int gcd_value = std::gcd(n, d);  
        n /= gcd_value;
        d /= gcd_value;
    }
};

int main() {
    RationalNumber a(1, 2);  
    RationalNumber b(3, 4);  

    a.add(b);
    a.print();  

    b.sub(a);
    b.print();  

    a.mul(b);
    a.print();  

    b.div(a);
    b.print();  

    return 0;
}
