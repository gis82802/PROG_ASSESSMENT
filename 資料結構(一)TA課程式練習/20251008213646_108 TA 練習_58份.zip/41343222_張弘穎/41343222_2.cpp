#include <iostream>
#include <cmath>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;

    // 計算最大公因數 (GCD) 的函式
    int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // 簡化分數的函式
    void reduce() {
        int gcd_value = gcd(abs(numerator), abs(denominator));
        numerator /= gcd_value;
        denominator /= gcd_value;

        // 處理分母為負數的情況
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    // 建構子，初始化分子和分母
    RationalNumber(int n, int d) : numerator(n), denominator(d) {
        if (denominator == 0) {
            cout << "Denominator cannot be zero!" << endl;
            exit(1);
        }
        reduce();  // 簡化分數
    }

    // 加法
    void add(const RationalNumber& other) {
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator = denominator * other.denominator;
        reduce();
    }

    // 減法
    void sub(const RationalNumber& other) {
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator = denominator * other.denominator;
        reduce();
    }

    // 乘法
    void mul(const RationalNumber& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        reduce();
    }

    // 除法
    void div(const RationalNumber& other) {
        if (other.numerator == 0) {
            cout << "Cannot divide by zero!" << endl;
            exit(1);
        }
        numerator *= other.denominator;
        denominator *= other.numerator;
        reduce();
    }

    // 印出帶分數形式
    void print() const {
        if (numerator == 0) {
            cout << "0";
            return;
        }

        int wholePart = numerator / denominator;  // 整數部分
        int remainder = abs(numerator % denominator);  // 餘數部分

        if (wholePart != 0) {
            cout << wholePart;  // 印出整數部分
            if (remainder != 0) {
                cout << "+" << remainder << "/" << denominator;  // 印出餘數部分
            }
        }
        else {
            cout << numerator << "/" << denominator;  // 只有分數部分
        }
        cout << endl;
    }
};

int main() {
    RationalNumber a(1, 2);  // a = 1/2
    RationalNumber b(3, 4);  // b = 3/4

    a.add(b);   // a = a + b = 1/2 + 3/4 = 5/4
    a.print();  // 結果印出 1 1/4

    b.sub(a);   // b = b - a = 3/4 - 5/4 = -1/4
    b.print();  // 結果印出 -1/4

    a.mul(b);   // a = a * b = 5/4 * -1/4 = -5/16
    a.print();  // 結果印出 -5/16

    b.div(a);   // b = b / a = -1/4 / -5/16 = 4/5
    b.print();  // 結果印出 4/5

    return 0;
}
