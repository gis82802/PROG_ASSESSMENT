#include<iostream>
#include <algorithm>
using namespace std;
void Magic(int**& a, int b) {
	if (b < 1 || !(b % 2)) {//判斷是否是基數
		throw  "Error! this is not a valid number";
	}
	a = new int* [b];
	for (int r = 0; r < b; r++) {
		a[r] = new int[b];
		fill(a[r], a[r] + b, 0);//要注意，如果用二維陣列會崩潰
	}
	a[0][b / 2] = 1;
	int y = 2, rows = 0, coles = b / 2;//紀錄目前狀況的
	while (y <= b * b) {
		int m = rows, n = coles;//改變陣列內數字
		if (rows - 1 < 0)m = (rows - 1 + b) % b; else m -= 1;
		if (coles - 1 < 0)n = (coles - 1 + b) % b; else n -= 1;
		if (a[m][n] == 0) {
			a[m][n] = y;
			rows = m;
			coles = n;
		}
		else {
			rows = (rows + 1) % b;//要注意，否則會超出邊界
			a[rows][coles] = y;
		}
		y++;
	}
	cout << "magic square of size" << b << endl;
	for (int e = 0; e < b; e++)
	{
		for (int r = 0; r < b; r++) {
			cout << a[e][r] << "   ";
		}
		cout << endl;
	}
}
int main() {
	int** Size = nullptr, Goal;
	cout << "輸入你想要的魔術陣列大小" << endl;
	cin >> Goal;
	//去抓取回傳的錯誤訊息
	try {
		Magic(Size, Goal);
	}
	catch (const char* msg) {
		cout << msg << endl;
		return 1;
	}
	//釋放記憶體
	for (int i = 0; i < Goal; i++)
		delete[] Size[i];
	delete[] Size;
}