#include "RationalNumber.h"

int main() {
    RationalNumber a(1, 2), b(3, 4); 

    cout << "��l�ȡG" << endl;
    cout << "a = "; a.print();
    cout << "b = "; b.print();
    cout << endl;

    a.add(b);
    cout << "a = a + b = ";
    a.print(); 

    b.sub(a);
    cout << "b = b - a = ";
    b.print();  

    a.mul(b);
    cout << "a = a * b = ";
    a.print(); 

    b.div(a);
    cout << "b = b / a = ";
    b.print();  

    return 0;
}
