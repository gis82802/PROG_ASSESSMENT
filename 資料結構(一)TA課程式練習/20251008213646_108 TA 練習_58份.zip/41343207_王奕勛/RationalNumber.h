#ifndef RATIONALNUMBER_H
#define RATIONALNUMBER_H

#include <iostream>
#include <cstdlib>  
using namespace std;

inline int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

class RationalNumber {
private:
    int numerator;   
    int denominator; 

    void simplify() {
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
        int g = gcd(abs(numerator), abs(denominator));
        if (g != 0) {
            numerator /= g;
            denominator /= g;
        }
    }

public:
    RationalNumber(int n = 0, int d = 1) {
        if (d == 0) {
            cout << "���~�G�������i�� 0�A�w�۰ʳ]�� 1" << endl;
            d = 1;
        }
        numerator = n;
        denominator = d;
        simplify();
    }

    void add(const RationalNumber& r) {
        numerator = numerator * r.denominator + r.numerator * denominator;
        denominator *= r.denominator;
        simplify();
    }

    void sub(const RationalNumber& r) {
        numerator = numerator * r.denominator - r.numerator * denominator;
        denominator *= r.denominator;
        simplify();
    }

    void mul(const RationalNumber& r) {
        numerator *= r.numerator;
        denominator *= r.denominator;
        simplify();
    }

    void div(const RationalNumber& r) {
        if (r.numerator == 0) {
            cout << "���~�G���Ƭ� 0�I" << endl;
            return;
        }
        numerator *= r.denominator;
        denominator *= r.numerator;
        simplify();
    }

    void print() const {
        int whole = numerator / denominator;
        int remain = abs(numerator % denominator);

        if (remain == 0) {
            cout << whole << endl;
        }
        else if (whole == 0) {
            cout << numerator << "/" << denominator << endl;
        }
        else {
            cout << whole << "+" << remain << "/" << denominator << endl;
        }
    }
};

#endif
