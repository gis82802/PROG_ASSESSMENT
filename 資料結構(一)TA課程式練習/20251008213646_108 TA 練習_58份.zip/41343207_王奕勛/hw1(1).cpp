#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

int main() {
    int n;
    cout << "�п�J�_�ƶ� n (n > 0 �B���_��): ";
    if (!(cin >> n)) {
        cerr << "��J���~�C\n";
        return 1;
    }

    if (n <= 0 || n % 2 == 0) {
        cerr << "n �����O�����_�ơC\n";
        return 1;
    }

    vector<vector<int>> M(n, vector<int>(n, 0));

    int num = 1;
    int maxNum = n * n;
    int row = 0;
    int col = n / 2;

    while (num <= maxNum) {
        M[row][col] = num;

        int nextRow = (row - 1 + n) % n;
        int nextCol = (col + 1) % n;

        if (M[nextRow][nextCol] != 0) {
            row = (row + 1) % n;
        }
        else {
            row = nextRow;
            col = nextCol;
        }

        ++num;
    }

    int width = 0, temp = maxNum;
    while (temp > 0) {
        width++;
        temp /= 10;
    }
    width += 1;

    cout << "\n" << n << "x" << n << " �]�N��}�G\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << setw(width) << M[i][j];
        }
        cout << "\n";
    }

    return 0;
}
