#include <iostream>
#include <cstdlib>
#include <numeric> 
using namespace std;
int gcd(int a, int b) {
	while (b != 0) {
		int temp = b;
		b = a % b;
		a = temp;
	}
	return a;
}
class RationalNmuber
{
private:
	double A, B;
public:
	RationalNmuber(int i, int j)
	{
		A = i;
		B = j;
	}
	void add(RationalNmuber& B1)
	{
		int f;
		if (B == B1.B)
		{
			A = A + B1.A;
	    }
		else if(B>B1.B)
		{
			f = B / B1.B;
			B1.A = B1.A * f;
			B1.B = B1.B * f;
			A = A + B1.A;
		}
		else
		{
			f =B1.B/B;
			A= A * f;
			B = B * f;
			A = A + B1.A;
		}
	}
	void sub(RationalNmuber& B1)
	{
		int f;
		if (B == B1.B)
		{
			A = A - B1.A;
		}
		else if (B > B1.B)
		{
			f = B / B1.B;
			B1.A = B1.A * f;
			B1.B = B1.B * f;
			A = A - B1.A;
		}
		else
		{
			f = B1.B / B;
			A = A * f;
			B = B * f;
			A = A - B1.A;
		}
	}
	void mul(const RationalNmuber& B1)
	{
		A = A * B1.A;
		B = B * B1.B;
	}
	void div(const RationalNmuber& B1)
	{
		A = A * B1.B;
		B = B * B1.A;
	}
	void print()
	{
		int g,a,h;
		g = A / B;
		if ((A < 0) && (B < 0))
		{ 
			A = A - 2 * A;
			B = B - 2 * B;
		}
		if ((h=gcd(A, B))!=0)
		{
			h = gcd(A,B);
			A =A/h;
			B=B/h;
		}
		if (B<0)
		{
			A = -A;
			B = -B;
		}
		if (g >= 1)
		{ 
			a = A-B;
			cout << g << "+" << a << "/" << B << endl;
		}
		else
			cout << A << "/" << B << endl;
	}
};
int main(void)
{
	RationalNmuber a(1, 2), b(3, 4);
	a.add(b);  a.print();
	b.sub(a);  b.print();
	a.mul(b);  a.print();
	b.div(a);   b.print();
	return 0;
}