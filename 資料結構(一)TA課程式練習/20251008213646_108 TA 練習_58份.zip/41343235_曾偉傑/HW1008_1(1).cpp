#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;
void Magic(const int n)
{
	try {
	if ((n <= 1) || (n % 2 == 0)) {
		throw"n not";
	}
	int** square=new int*[n];
	for (int i = 0; i < n; i++)
		square[i] = new int[n];
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			square[i][j] = 0;
	}

	int key = 1, a,b=0,c,d=0,e;
	a = n / 2 ;
	c = a;
	e = c;
	square[0][a] = key;
	key++;
	while (key <= n * n)
	{
		if ((b - 1) < 0)
			d = n-1;
		else
			d =b-1;
		if ((c - 1) < 0)
			e =n - 1;
		else
			e =c-1;
		if (square[d][e] == 0)
		{
			square[d][e] = key;
			b = d;
			c = e;
		}
		else
		{
			b = b + 1;
		}
		square[b][c] = key;
		key++;
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(4) << square[i][j]<<" ";
		}
		cout << endl;
	}	
	for (int i = 0; i < n; i++) 
		delete[] square[i];
	delete[] square;
	}
	catch (const char* msg) {
		cout << msg;
		return;
	}
}
int main(void)
{
		int n;
		cout << "�п�J�x�}�j�p(n�ݬ��_��):";
		cin >> n;
		Magic(n);
	return (0);
}