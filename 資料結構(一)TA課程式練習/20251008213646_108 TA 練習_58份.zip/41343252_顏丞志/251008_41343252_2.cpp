#include<iostream>
#include "Rational.cpp"
using namespace std;
int main() {
	Rational a(1, 2), b(3, 4);
	a.add(b);  a.print();  //  a = a + b = 1/2 + 3/4 = 5/4, 結果印出 1+1/4
	b.sub(a);  b.print();  //  b = b - a = 3/4 - (5/4) = -1/2, 結果印出 -1/2
	a.mul(b);  a.print();  //. a = a * b = 5/4 * (-1/2) = -5/8, 結果印出 -5/8
	b.div(a);   b.print();  //  b = b / a = (-1/2) / (-5/8) = 4/5, 結果印出 4/5
	return 0;
}