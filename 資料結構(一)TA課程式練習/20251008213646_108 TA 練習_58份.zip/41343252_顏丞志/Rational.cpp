#include<iostream>
#ifndef RECTANGLE_H
#define RECTANGLE_H
using namespace std;

class  Rational {
private:
	int a, b;
	int r1 = 0, r2 = 0, gcd = 0;
public:
	Rational(int x, int y) {
		a = x;
		b = y;
	}
	void add(Rational r) {
		if (b == r.b) {
			a = a + r.a;
		}
		else {
			a = a * r.b + b * r.a;
			b = b * r.b;
		}
		r1 = a; r2 = b;
		while (r2 != 0) {
			gcd = r1 % r2;
			r1 = r2;
			r2 = gcd;
		}
		if (a % r1 == 0 && b % r1 == 0) {
			a = a / r1; b = b / r1;
		}
	}
	void sub(Rational r) {
		if (b == r.b) {
			a = a - r.a;
		}
		else {
			a = a * r.b - b * r.a;
			b = b * r.b;
		}
		r1 = a; r2 = b;
		while (r2 != 0) {
			gcd = r1 % r2;
			r1 = r2;
			r2 = gcd;
		}
		if (a % r1 == 0 && b % r1 == 0) {
			a = a / r1; b = b / r1;
		}
	}
	void mul(Rational r) {
		a = a * r.a;
		b = b * r.b;
		r1 = a; r2 = b;
		while (r2 != 0) {
			gcd = r1 & r2;
			r1 = r2;
			r2 = gcd;
		}
		if (a % r1 == 0 && b % r1 == 0) {
			a = a / r1; b = b / r1;
		}
	}
	void div(Rational r) {
		a = a * r.b;
		b = b * r.a;
		r1 = a; r2 = b;
		while (r2 != 0) {
			gcd = r1 % r2;
			r1 = r2;
			r2 = gcd;
		}
		if (a % r1 == 0 && b % r1 == 0) {
			a = a / r1; b = b / r1;
		}
	}
	void print() {
		if (a < b && a>0 && b > 0) {
			cout << a << "/" << b << endl;
		}
		else if (a > b && a > 0 && b > 0)
		{
			cout << (int)a / b << "+" << a % b << "/" << b << endl;
		}
		else if (a > b && (a < 0 || b < 0)) {
			cout << "-" << abs(a) << "/" << abs(b) << endl;
		}
		else if (a < b && (a < 0 || b < 0)) {
			cout << "-" << (int)(abs(a) / abs(b)) << "+" << abs(a) % abs(b) << "/" << abs(b) << endl;
		}
	}
};
#endif