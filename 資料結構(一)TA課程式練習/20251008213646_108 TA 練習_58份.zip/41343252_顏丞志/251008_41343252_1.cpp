#include iostream
#includealgorithm
using namespace std;

int main()
{
	int n;
	int i, j, k, l;
	int s;
	cout  輸入n(1n51)&&n%2!=0  endl;
	cin  n;
	s = new int[n];
	if (n  1  n51) {
		cout  輸入正確範圍的數字  endl;
		return 0;
	}
	else if(n % 2 == 0) {
		cout  數字不是奇數  endl;
		return 0;
	}
	for (i = 0; i  n; i++) {
		s[i] = new int[n];
		fill(s[i], s[i] + n, 0);
	}
	s[0][(n - 1)  2] = 1;
	int key = 2;
	i = 0; j = (n - 1)  2;
	while (key=nn)
	{
		if (i - 1  0)k = n - 1; else k = i - 1;
		if (j - 1  0)l = n - 1; else l = j - 1;
		if (s[k][l]) i = (i + 1) % n;
		else {
			i = k; j = l;
		}
		s[i][j] = key++;
	}
	int sum=new int[(n  2) + 2];
	for (i = 0; i  n; i++) {
		for (j = 0; j  n; j++)
			sum[i] = s[i][j];
	}
	for (j = 0; j  n; j++) {
		for (i = 0; i  n; i++)
			sum[n+j] = s[i][j];
	}
	for(i=0;in;i++)
		sum[n2] = s[i][i];
	for (i = 0; i  n; i++)
		sum[n  2+1] = s[i][n-i];
	bool check = true;
	for (i = 1; i  n  2 + 2; i++)
		if (sum[0] == sum[i])
			check = false;
	if (check) {
		cout  magic square of size   n  endl;
		for (i = 0; i  n; i++) {
			for (j = 0; j  n; j++)
				cout  s[i][j]   ;
			cout  endl;
		}
		cout  最終加種  sum[0]  endl;
	}
	else{
		cout  生成失敗  endl;
	}
}
