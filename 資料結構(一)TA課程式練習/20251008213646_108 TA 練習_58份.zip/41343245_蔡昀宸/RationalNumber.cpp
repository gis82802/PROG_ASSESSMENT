#include <iostream>
#include <cstdlib>  // for abs()
using namespace std;

class Rational {
private:
    int numerator;     // ���l
    int denominator;   // ����

    // ����۰��k�D�̤j���]��
    int gcd(int a, int b) {
        return b == 0 ? abs(a) : gcd(b, a % b);
    }

    // �T�O���������A�ä�²
    void reduce() {
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }

        int g = gcd(numerator, denominator);
        numerator /= g;
        denominator /= g;
    }

public:
    Rational(int num = 0, int den = 1) {
        numerator = num;
        denominator = den;
        reduce();
    }

    void add(const Rational& r) {
        numerator = numerator * r.denominator + r.numerator * denominator;
        denominator = denominator * r.denominator;
        reduce();
    }

    void sub(const Rational& r) {
        numerator = numerator * r.denominator - r.numerator * denominator;
        denominator = denominator * r.denominator;
        reduce();
    }

    void mul(const Rational& r) {
        numerator *= r.numerator;
        denominator *= r.denominator;
        reduce();
    }

    void div(const Rational& r) {
        numerator *= r.denominator;
        denominator *= r.numerator;
        reduce();
    }

    void print() const {
        int whole = numerator / denominator;
        int remain = abs(numerator % denominator);

        if (numerator == 0) {
            cout << "0" << endl;
        }
        else if (remain == 0) {
            cout << whole << endl;
        }
        else if (abs(numerator) < denominator) {
            cout << numerator << "/" << denominator << endl;
        }
        else {
            cout << whole << "+" << remain << "/" << denominator << endl;
        }
    }
};

int main() {
    Rational a(1, 2), b(3, 4);

    a.add(b);
    a.print();       // �L�X 1+1/4

    b.sub(a);
    b.print();       // �L�X -1/2

    a.mul(b);
    a.print();       // �L�X -5/8

    b.div(a);
    b.print();       // �L�X 4/5

    system("pause");
    return 0;
}
