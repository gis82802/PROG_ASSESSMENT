#include <iostream>
#include <vector>
using namespace std;

void magicMatrix(int n) {
    vector<vector<int>> matrix(n, vector<int>(n, 0));

    int i = 0, j = n / 2;  
    for (int num = 1; num <= n * n; num++) {
        matrix[i][j] = num;
        int newi = (i - 1 + n) % n;
        int newj = (j + 1) % n;
        if (matrix[newi][newj] != 0) {
            i = (i + 1) % n; 
        }
        else {
            i = newi;
            j = newj;
        }
    }

    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            cout << matrix[r][c] << "\t";
        }
        cout << endl;
    }
}

int main() {
    int n;
    cout << "��J�_�� n: ";
    cin >> n;
    if (n % 2 == 0) {
        cout << "�п�J�_�ơI" << endl;
        return 0;
    }
    magicMatrix(n);
    return 0;
}

