#include <iostream>
#include <cmath>
using namespace std;

int gcd(int a, int b) {
    return (b == 0) ? a : gcd(b, a % b);
}

class RationalNumber {
private:
    int numerator;
    int denominator;

    void simplify() {
        int g = gcd(abs(numerator), abs(denominator));
        numerator /= g;
        denominator /= g;
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    RationalNumber(int n = 0, int d = 1) : numerator(n), denominator(d) {
        simplify();
    }

    void add(const RationalNumber& other) {
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator = denominator * other.denominator;
        simplify();
    }

    void sub(const RationalNumber& other) {
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator = denominator * other.denominator;
        simplify();
    }

    void mul(const RationalNumber& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        simplify();
    }

    void div(const RationalNumber& other) {
        numerator *= other.denominator;
        denominator *= other.numerator;
        simplify();
    }

    void print() const {
        if (numerator == 0) {
            cout << "0" << endl;
            return;
        }
        int n = numerator;
        int d = denominator;
        if (abs(n) >= d) {
            int integerPart = n / d;
            int remainder = abs(n % d);
            if (remainder == 0) {
                cout << integerPart << endl;
            }
            else {
                cout << integerPart << "+" << remainder << "/" << d << endl;
            }
        }
        else {
            cout << n << "/" << d << endl;
        }
    }
};

int main() {
    RationalNumber a(1, 2), b(3, 4);

    a.add(b);
    a.print();

    b.sub(a);
    b.print();

    a.mul(b);
    a.print();

    b.div(a);
    b.print();

    return 0;
}
