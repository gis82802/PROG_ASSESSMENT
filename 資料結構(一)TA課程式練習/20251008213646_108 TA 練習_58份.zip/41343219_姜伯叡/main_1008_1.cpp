#include <iostream>
#include <algorithm> 
#include <iterator> 
#include <string> 

using namespace std;

void MagicMartix(const int n)
{
	if (n < 1)
		throw "n cant be less than 1!";
	else if(n % 2 == 0) 
		throw "n must be odd!";
	
	int square[n][n], k, l;
	fill(square[0], square[0] + n * n, 0);
	square[0][(n - 1) / 2] = 1;
	
	int key=2,  i=0; int j = (n - 1) / 2;
	while(key <= n * n)
	{
		if(i - 1 < 0) k = n - 1; else k = i - 1;
		if(j - 1 < 0) l = n - 1; else l = j - 1;
		if(square[k][l]) i = (i + 1) % n;
		else { i = k; j = l;}
		square[i][j] = key;
		key++;
	}

	cout << "Magic square of size" << n << endl;
	cout << endl;	
	for(i=0;i<n;i++)
	{
		copy(square[i], square[i] + n, ostream_iterator<int>(cout, "\t"));
		cout << endl; cout << endl;	
	} 
}

int main() 
{
	try{
		int n;
		cin >> n;
		MagicMartix(n);
	}catch(const char* msg){
		cout << "ERROR! " << msg << endl;
	}
	
	system("pause");
	return 0;
}
