#include <iostream>
#include <algorithm> 

using namespace std;

class Rational
{
	private: 
		int num, denom;
	public:
		Rational(int a, int b){
			num = a; denom = b;
		}
		void add(Rational &x) { 
			num = num * x.denom + x.num * denom; 
			denom *= x.denom;
		}
		void sub(Rational &x) { 
			num = num * x.denom - x.num * denom; 
			denom *= x.denom;
		}
		void mul(Rational &x) 
		{
			num = num * x.num;
			denom = denom * x.denom;
		}
		void div(Rational &x) 
		{ 
			num = num * x.denom;
			denom = denom * x.num; 
		}
		void print(){
			int gcd = __gcd(num, denom);	
			if(gcd){
				if(gcd < 0) gcd = -gcd;
				num /= gcd; denom /= gcd;
			}
			if(num < 0 && denom < 0)
			{
				num = -num;
				denom = -denom;
			}
			if(abs(num) < abs(denom))
				cout << num << "/" << denom << endl;
			else if(abs(num) > abs(denom))
				cout << num % denom << "+" << num / denom << "/" << denom << endl;
			else
				cout << num % denom << endl;
		}
}; 

int main() 
{
	Rational a(1,2), b(3,4);  // a=1/2,  b=3/4
	a.add(b);  a.print();  //  a = a + b = 1/2 + 3/4 = 5/4, ���G�L�X 1+1/4
	b.sub(a);  b.print();  //  b = b - a = 3/4 - (5/4) = -1/2, ���G�L�X -1/2
	a.mul(b);  a.print();  //. a = a * b = 5/4 * (-1/2) = -5/8, ���G�L�X -5/8
	b.div(a);   b.print();  //  b = b / a = (-1/2) / (-5/8) = 4/5, ���G�L�X 4/5
	
	system("pause");
	return 0;
}
