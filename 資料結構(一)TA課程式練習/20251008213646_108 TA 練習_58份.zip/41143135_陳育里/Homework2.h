#include <iostream>
#include <cstdlib>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;

    int gcd(int a, int b) const {
        while (b != 0) {
            int t = b;
            b = a % b;
            a = t;
        }
        return (a < 0) ? -a : a;
    }

    void simplify() {
        int g = gcd(numerator, denominator);
        numerator /= g;
        denominator /= g;

        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    Rational(int num = 0, int den = 1) {
        if (den == 0) {
            cout << "���~�G�������ର 0" << endl;
            exit(1);
        }
        numerator = num;
        denominator = den;
        simplify();
    }

    void print() const {
        int num = numerator;
        int den = denominator;

        if (num == 0) {
            cout << "0";
            return;
        }

        bool negative = false;
        if (num < 0) {
            negative = true;
            num = -num;
        }

        int whole = num / den;
        int remain = num % den;

        if (negative) cout << "-";

        if (whole != 0 && remain != 0) {
            cout << whole << "+" << remain << "/" << den;
        } else if (remain == 0) {
            cout << whole;
        } else if (whole == 0) {
            cout << remain << "/" << den;
        }
    }

    // �o�̥[�@��²�檺���Ʈ榡��X�A���βV�X�ơA��K��X�⦡��
    void printFraction() const {
        cout << numerator << "/" << denominator;
    }

    void add(const Rational& r) {
        cout << "�[ ";
        printFraction();
        cout << " + ";
        r.printFraction();
        cout << " = ";
        numerator = numerator * r.denominator + r.numerator * denominator;
        denominator = denominator * r.denominator;
        simplify();
        print();
        cout << endl;
    }

    void sub(const Rational& r) {
        cout << "�� ";
        printFraction();
        cout << " - ";
        r.printFraction();
        cout << " = ";
        numerator = numerator * r.denominator - r.numerator * denominator;
        denominator = denominator * r.denominator;
        simplify();
        print();
        cout << endl;
    }

    void mul(const Rational& r) {
        cout << "�� ";
        printFraction();
        cout << " * ";
        r.printFraction();
        cout << " = ";
        numerator = numerator * r.numerator;
        denominator = denominator * r.denominator;
        simplify();
        print();
        cout << endl;
    }

    void div(const Rational& r) {
        if (r.numerator == 0) {
            cout << "���~�G���ణ�H 0" << endl;
            exit(1);
        }
        cout << "�� ";
        printFraction();
        cout << " / ";
        r.printFraction();
        cout << " = ";
        numerator = numerator * r.denominator;
        denominator = denominator * r.numerator;
        simplify();
        print();
        cout << endl;
    }
};


