#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;


void showSquare(const vector<vector<int>>& square) {
    int n = square.size();
    cout << "--------------------" << endl;
    for (int r = 0; r < n; ++r) {
        for (int c = 0; c < n; ++c) {
            cout << setw(4) << square[r][c];
        }
        cout << endl;
    }
    cout << "--------------------" << endl;
}

void makeMagicSquare(int n) {
    vector<vector<int>> square(n, vector<int>(n, 0));

    int row = 0;
    int col = n / 2;

    for (int num = 1; num <= n * n; ++num) {
        square[row][col] = num; 

        int nextRow = (row - 1 + n) % n;
        int nextCol = (col - 1 + n) % n;

        if (square[nextRow][nextCol] != 0) {
            row = (row + 1) % n;
        }
        else {
            row = nextRow;
            col = nextCol;
        }
    }

    showSquare(square);
}

int main() {
    int n;
    cout << "��J�_�Ưx�}�j�p n: ";
    cin >> n;

    if (n <= 0 || n % 2 == 0) {
        cout << "���~�G��J���Ʀr�����O�_��" << endl;
        return 1;
    }

    cout << endl << n << "x" << n << " ���x�}�G" << endl;
    makeMagicSquare(n);
    return 0;
}