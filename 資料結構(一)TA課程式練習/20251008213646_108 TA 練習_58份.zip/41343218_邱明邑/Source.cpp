#include "RationalNumber.hpp"
#include <iostream>
#include <cmath>
using namespace std;

// �D�̤j���]�ơ]���U�禡�^
static int gcd(int a, int b) {
    if (b == 0)
        return a;
    else
        return gcd(b, a % b);
}

// �غc�l
RationalNumber::RationalNumber(int n, int d) {
    num = n;
    den = d;
    normalize();
}

// ��²����
void RationalNumber::normalize() {
    if (den == 0) {
        cout << "���~�G�������o���s" << endl;
        num = 0;
        den = 1;
        return;
    }

    if (num == 0) {
        den = 1;
        return;
    }

    int common = gcd(abs(num), abs(den));
    num /= common;
    den /= common;

    if (den < 0) {
        num = -num;
        den = -den;
    }
}

// �L�X���ơ]�۰ʱa���Ʈ榡�^
void RationalNumber::print() {
    if (den == 1) {
        cout << num << endl;
    }
    else if (num > den) {
        cout << num / den << "+" << num % den << "/" << den << endl;
    }
    else {
        cout << num << "/" << den << endl;
    }
}

// �[�k
void RationalNumber::add(const RationalNumber& other) {
    num = num * other.den + other.num * den;
    den = den * other.den;
    normalize();
}

// ��k
void RationalNumber::sub(const RationalNumber& other) {
    num = num * other.den - other.num * den;
    den = den * other.den;
    normalize();
}

// ���k
void RationalNumber::mul(const RationalNumber& other) {
    num *= other.num;
    den *= other.den;
    normalize();
}

// ���k
void RationalNumber::div(const RationalNumber& other) {
    if (other.num == 0) {
        cout << "���~�G���ƪ��Ȭ��s" << endl;
        return;
    }
    num *= other.den;
    den *= other.num;
    normalize();
}

// ���եD�{��
int main() {
    RationalNumber a(1, 2);
    RationalNumber b(3, 4);

    cout << "a = "; a.print();
    cout << "b = "; b.print();
    cout << "--------------------" << endl;

    cout << "���� a.add(b)" << endl;
    a.add(b);
    cout << "a = a + b = ";
    a.print();
    cout << "--------------------" << endl;
    cout << "���� b.sub(a) (a ���Ȭ� 5/4)" << endl;
    b.sub(a);
    cout << "b = b - a = ";
    b.print();
    cout << "--------------------" << endl;

    cout << "���� a.mul(b) (b ���Ȭ� -1/2)" << endl;
    a.mul(b);
    cout << "a = a * b = ";
    a.print();
    cout << "--------------------" << endl;

    cout << "���� b.div(a) (a ���Ȭ� -5/8)" << endl;
    b.div(a);
    cout << "b = b / a = ";
    b.print();
    cout << "--------------------" << endl;

    return 0;
}