#include <iostream>
#include "magic.h"
using namespace std;

int main() {
    int N;
    cout << "��J�_�ƶ� N�G";
    cin >> N;

    if (N % 2 == 0) {
        cout << "��J���~" << endl;
        return 0;
    }

    magic(N);

    return 0;
}
