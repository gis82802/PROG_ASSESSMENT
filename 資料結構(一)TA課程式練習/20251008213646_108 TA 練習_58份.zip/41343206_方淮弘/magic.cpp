#include <iostream>
#include <iomanip>
#include "magic.h"
using namespace std;

void magic(int N) {
    int matrix[20][20] = { 0 };

    int i = 0;
    int j = (N + 1) / 2;
    int key;
    for (key = 1; key <= N * N; key++) {
        if ((key % N) == 1)
            i++;
        else {
            i--;
            j++;
        }

        if (i == 0)
            i = N;
        if (j > N)
            j = 1;

        matrix[i - 1][j - 1] = key;
    }

    int m, n;
    for (m = 0; m < N; m++) {
        for (n = 0; n < N; n++)
            cout << setw(3) << matrix[m][n] << " ";
        cout << endl;
    }
}
