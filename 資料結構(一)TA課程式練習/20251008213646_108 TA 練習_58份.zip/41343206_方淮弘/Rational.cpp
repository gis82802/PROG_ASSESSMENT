#include "Rational.h"
#include <iostream>
#include <cmath>
using namespace std;

int Rational::gcd(int a, int b) {
    return (b == 0) ? a : gcd(b, a % b);
}

void Rational::reduce() {
    int g = gcd(abs(num), abs(den));
    num /= g;
    den /= g;
    if (den < 0) {
        den = -den;
        num = -num;
    }
}

Rational::Rational(int n, int d) {
    num = n;
    den = d;
    reduce();
}

void Rational::add(const Rational& r) {
    num = num * r.den + r.num * den;
    den = den * r.den;
    reduce();
}

void Rational::sub(const Rational& r) {
    num = num * r.den - r.num * den;
    den = den * r.den;
    reduce();
}

void Rational::mul(const Rational& r) {
    num = num * r.num;
    den = den * r.den;
    reduce();
}

void Rational::div(const Rational& r) {
    num = num * r.den;
    den = den * r.num;
    reduce();
}

void Rational::print() const {
    if (den == 1)
        cout << num << endl;
    else if (abs(num) > abs(den)) {
        int whole = num / den;
        int remain = abs(num % den);
        if (remain == 0)
            cout << whole << endl;
        else
            cout << whole << "+" << remain << "/" << den << endl;
    }
    else {
        cout << num << "/" << den << endl;
    }
}
