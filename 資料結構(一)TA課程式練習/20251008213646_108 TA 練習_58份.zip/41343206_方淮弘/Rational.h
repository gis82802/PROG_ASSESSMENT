#ifndef RATIONAL_H
#define RATIONAL_H

class Rational {
private:
    int num;
    int den;
    void reduce();
    int gcd(int a, int b);

public:
    Rational(int n = 0, int d = 1);
    void add(const Rational& r);
    void sub(const Rational& r);
    void mul(const Rational& r);
    void div(const Rational& r);
    void print() const;
};

#endif
