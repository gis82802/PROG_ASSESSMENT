#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator, denominator;

    // Helper function to find the greatest common divisor
    int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Helper function to simplify the fraction
    void simplify() {
        int gcdValue = gcd(numerator, denominator);
        numerator /= gcdValue;
        denominator /= gcdValue;
    }

    // Convert to mixed fraction if possible
    void printMixed() {
        int wholePart = numerator / denominator;
        int fractionPart = numerator % denominator;

        // If the whole part is 0, only print the fraction part
        if (wholePart != 0) {
            if (fractionPart != 0) {
                cout << wholePart << " + " << fractionPart << "/" << denominator << endl;
            }
            else {
                cout << wholePart << endl;
            }
        }
        else {
            cout << fractionPart << "/" << denominator << endl;
        }
    }

public:
    // Constructor to initialize RationalNumber
    RationalNumber(int num, int denom) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Denominator cannot be zero!" << endl;
            exit(1);
        }
        simplify();
    }

    // Addition of two rational numbers
    void add(RationalNumber& other) {
        numerator = numerator * other.denominator + denominator * other.numerator;
        denominator = denominator * other.denominator;
        simplify();
    }

    // Subtraction of two rational numbers
    void sub(RationalNumber& other) {
        numerator = numerator * other.denominator - denominator * other.numerator;
        denominator = denominator * other.denominator;
        simplify();
    }

    // Multiplication of two rational numbers
    void mul(RationalNumber& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        simplify();
    }

    // Division of two rational numbers
    void div(RationalNumber& other) {
        if (other.numerator == 0) {
            cout << "Cannot divide by zero!" << endl;
            exit(1);
        }
        numerator *= other.denominator;
        denominator *= other.numerator;
        simplify();
    }

    // Print the rational number in mixed fraction form
    void print() {
        printMixed();
    }
};

int main() {
    int num_a, denom_a, num_b, denom_b;

    // Get input for rational number a
    cout << "a: ";
    cin >> num_a >> denom_a;
    RationalNumber a(num_a, denom_a);

    // Get input for rational number b
    cout << "b: ";
    cin >> num_b >> denom_b;
    RationalNumber b(num_b, denom_b);

    // Perform and print operations as described in the image

    // a + b
    a.add(b);  // Update a with a + b
    cout << "a.add(b);// a = a + b" << endl;
    a.print();  // Print the result of a + b

    // Now use b for next calculation
    b.sub(a);  // Update b with b - a
    cout << "b.sub(a);// b = b - a" << endl;
    b.print();  // Print the result of b - a

    // Now use a for next calculation
    a.mul(b);  // Update a with a * b
    cout << "a.mul(b);// a = a * b" << endl;
    a.print();  // Print the result of a * b

    // Now use b for next calculation
    b.div(a);  // Update b with b / a
    cout << "b.div(a);// b = b / a" << endl;
    b.print();  // Print the result of b / a

    return 0;
}
