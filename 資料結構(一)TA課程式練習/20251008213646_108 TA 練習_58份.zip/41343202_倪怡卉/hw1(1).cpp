/*#include<iostream>
#include<vector>
#include<iomanip>
#include<string>

using namespace std;

class MM {
private:
	vector<vector<int>>matrix;
	int n;
public:

	MM(int size) :n(size) {
		matrix.resize(n, vector<int>(n, 0));
	}

	void generate() {

		int row = 0;
		int col = n / 2;

		for (int num = 1; num <= n * n; num++) {
			matrix[row][col] = num;

			int nextrow = (row - 1 + n) % n;
			int nextcol = (col + 1) % n;

			if (matrix[nextrow][nextcol] != 0) {
				row = (row + 1) % n;
			}
			else
			{
				row = nextrow;
				col = nextcol;
			}
		}
	}

	void show() {
		cout << "\n" << n << "*" << n << "�]��}:\n\n";

		int maxdigits = to_string(n * n).length();

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				cout << setw(maxdigits + 2) << matrix[i][j];
			}
			cout << endl;
		}

		verify();
	}

	void verify() {
		int magicsum = n * (n * n + 1) / 2;
		//���Ҧ檺�M
		for (int i = 0; i < n; i++) {
			int rowsum = 0;
			for (int j = 0; j < n; j++) {
				rowsum += matrix[i][j];
			}
		}


		//���ҦC���M
		for (int j = 0; j < n; j++) {
			int colsum = 0;
			for (int i = 0; i < n; i++) {
				colsum += matrix[i][j];
			}
		}

		//���ҹ﨤�u���M
		int diag1 = 0,diag2 = 0;
		for (int i = 0; i < n; i++) {
			diag1 += matrix[i][i];
			diag2 += matrix[i][n - 1 - i];
		}
	}
};
int main() {
	int n;
	cout << "========�]��}�ͦ�:========\n";

	while (true)
	{
		cout << "��J�x�}�j�p:";
		cin >> n;

		if (n == 0) {
			cout << "�����ϥ�" << endl;
			break;
		}

		if (n % 2 == 0) {
			cout << "n�����O�_��\n" << endl;
			continue;
		}

		if (n < 1) {
			cout << "n�����O�����\n" << endl;
			continue;
		}

		MM magic(n);
		magic.generate();
		magic.show();

		cout << "\n" << string(50, '=') << "\n" << endl;
	}

	return 0;
}*/
