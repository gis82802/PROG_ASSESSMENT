#include <iostream>
using namespace std;

class RationalNumber {
public:
    int num, den;

    RationalNumber(int n = 0, int d = 1) {
        num = n;
        den = d;
        simplify();
    }

    int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    void simplify() {
        int g = gcd(abs(num), abs(den));
        num /= g;
        den /= g;
        if (den < 0) { num = -num; den = -den; }
    }

    void add(RationalNumber r) {
        cout << num << "/" << den << " + " << r.num << "/" << r.den << " = ";
        num = num * r.den + r.num * den;
        den = den * r.den;
        simplify();
        print();
    }

    void sub(RationalNumber r) {
        cout << num << "/" << den << " - " << r.num << "/" << r.den << " = ";
        num = num * r.den - r.num * den;
        den = den * r.den;
        simplify();
        print();
    }

    void mul(RationalNumber r) {
        cout << num << "/" << den << " * " << r.num << "/" << r.den << " = ";
        num = num * r.num;
        den = den * r.den;
        simplify();
        print();
    }

    void div(RationalNumber r) {
        cout << num << "/" << den << " / " << r.num << "/" << r.den << " = ";
        num = num * r.den;
        den = den * r.num;
        simplify();
        print();
    }

    void print() {
        if (abs(num) > den) { // 轉成帶分數
            int whole = num / den;
            int remainder = abs(num % den);
            if (remainder == 0) cout << whole << endl;
            else cout << whole << "+" << remainder << "/" << den << endl;
        } else {
            cout << num << "/" << den << endl;
        }
    }
};

int main() {
    int a1, a2, b1, b2;
    cout << "Enter a numerator and denominator: ";
    cin >> a1 >> a2;
    cout << "Enter b numerator and denominator: ";
    cin >> b1 >> b2;

    RationalNumber a(a1, a2), b(b1, b2);

    a.add(b);
    b.sub(a);
    a.mul(b);
    b.div(a);

    return 0;
}
