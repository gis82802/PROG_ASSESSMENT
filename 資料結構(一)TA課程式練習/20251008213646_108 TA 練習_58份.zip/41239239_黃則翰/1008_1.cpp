#include <iostream>
using namespace std ;

int main(){
    int n;
    cout <<"please enter an odd number n: " ;
    cin >> n;

    if (n<0 || n % 2 == 0){
    cout << "Error , Please enter a positive odd number";
    return 0;
    }

    int **magic = new int*[n];
    for(int i=0 ; i<n ; i++){
        magic [i]= new int[n];
        for (int j = 0; j<n ; j++ )
            magic [i][j] = 0;
    }

    int row = 0, col = n/2, num = 1;
    while (num <= n*n) {
        magic[row][col] = num;

        int nextRow = (row - 1 + n) % n;
        int nextCol = (col - 1 + n) % n;

        if (magic[nextRow][nextCol] != 0)
            row = (row + 1) % n;
        else {
            row = nextRow;
            col = nextCol;
        }

        num++;
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            cout << magic[i][j] << "\t";
        cout << "\n";
    }

    for (int i = 0; i < n; i++)
        delete[] magic[i];
    delete[] magic;

    return 0;
}