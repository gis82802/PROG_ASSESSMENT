#include <iostream>
#include <cmath>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;


    void reduce() {
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
        int g = gcd(abs(numerator), abs(denominator));
        if (g != 0) {
            numerator /= g;
            denominator /= g;
        }
    }

    int gcd(int a, int b) {
        return (b == 0) ? a : gcd(b, a % b);
    }

public:
    Rational(int n = 0, int d = 1) {
        numerator = n;
        denominator = d;
        reduce();
    }


    void add(const Rational& other) {
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator = denominator * other.denominator;
        reduce();
    }


    void sub(const Rational& other) {
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator = denominator * other.denominator;
        reduce();
    }


    void mul(const Rational& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        reduce();
    }


    void div(const Rational& other) {
        numerator *= other.denominator;
        denominator *= other.numerator;
        reduce();
    }


    void print() const {
        int whole = numerator / denominator;
        int remain = abs(numerator % denominator);

        if (remain == 0) {
            cout << whole << endl;
        }
        else if (whole == 0) {
            cout << numerator << "/" << denominator << endl;
        }
        else {
            cout << whole << "+" << remain << "/" << denominator << endl;
        }
    }
};

int main() {
    Rational a(1, 2), b(3, 4);

    a.add(b);
    a.print();

    b.sub(a);
    b.print();

    a.mul(b);
    a.print();

    b.div(a);
    b.print();

    return 0;
}