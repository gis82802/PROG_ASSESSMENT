#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

void Magic(const int n)
{
    if ((n <= 1) || (n % 2 == 0))
        throw "n�����~��!!";


    int** square = new int* [n];
    for (int i = 0; i < n; i++)
        square[i] = new int[n];


    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            square[i][j] = 0;

    int num = 1;
    int row = 0;
    int col = n / 2;

    square[row][col] = num++;

    while (num <= n * n)
    {
        int nextRow = (row - 1 + n) % n;
        int nextCol = (col - 1 + n) % n;

        if (square[nextRow][nextCol] == 0)
        {
            row = nextRow;
            col = nextCol;
        }
        else
        {
            row = (row + 1) % n;
        }

        square[row][col] = num++;
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            cout << setw(4) << square[i][j] << " ";
        cout << endl;
    }

    for (int i = 0; i < n; i++)
        delete[] square[i];
    delete[] square;
}

int main()
{
    int n;
    cout << "�п�J�x�}�j�p(n�ݬ��_��): ";
    cin >> n;

    try {
        Magic(n);
    }
    catch (const char* msg) {
        cerr << msg << endl;
    }

    return 0;
}
