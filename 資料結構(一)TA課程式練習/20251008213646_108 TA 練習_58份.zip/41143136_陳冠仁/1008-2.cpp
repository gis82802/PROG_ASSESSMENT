#include <iostream>
using namespace std;

class Rational {
private:
    double real;  // �곡
    double imag;  // �곡

public:
    Rational(double r = 0, double i = 0) {
        real = r;
        imag = i;
    }

    void add(const Rational& b) {
        real += b.real;
        imag += b.imag;
    }

    void sub(const Rational& b) {
        real -= b.real;
        imag -= b.imag;
    }

    void mul(const Rational& b) {
        double r = real * b.real - imag * b.imag;
        double i = real * b.imag + imag * b.real;
        real = r;
        imag = i;
    }

    void div(const Rational& b) {
        double denominator = b.real * b.real + b.imag * b.imag;
        double r = (real * b.real + imag * b.imag) / denominator;
        double i = (imag * b.real - real * b.imag) / denominator;
        real = r;
        imag = i;
    }

    void print() const {
        if (imag >= 0)
            cout << real << "+" << imag << "i" << endl;
        else
            cout << real << imag << "i" << endl;
    }
};

int main() {
    Rational a(1, 2), b(3, 4);

    cout << "��l��:" << endl;
    cout << "a = "; a.print();
    cout << "b = "; b.print();

    a.add(b);
    cout << "\nAfter a.add(b): ";
    a.print();

    b.sub(a);
    cout << "After b.sub(a): ";
    b.print();

    a.mul(b);
    cout << "After a.mul(b): ";
    a.print();

    b.div(a);
    cout << "After b.div(a): ";
    b.print();

    return 0;
}
