#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n;
    cout << "�п�J�_�Ưx�}�j�p n: ";
    cin >> n;

    if (n % 2 == 0) {
        cout << "n �������_�ơI" << endl;
        return 0;
    }

    vector<vector<int>> magic(n, vector<int>(n, 0));

    int num = 1;
    int i = 0;          // �q�Ĥ@�C
    int j = n / 2;      // ������}�l

    while (num <= n * n) {
        magic[i][j] = num;
        num++;

        int newi = (i - 1 + n) % n;  // ���W
        int newj = (j + 1) % n;      // ���k

        if (magic[newi][newj] != 0) {
            i = (i + 1) % n;         // �U���@�C
        }
        else {
            i = newi;
            j = newj;
        }
    }

    cout << "\nMagic Matrix (" << n << "x" << n << "):\n";
    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            cout << magic[r][c] << "\t";
        }
        cout << endl;
    }

    return 0;
}
