#include <iostream>
#include <stdexcept>
using namespace std; 
class Rational {
public:
    Rational(long long num = 0, long long den = 1) : n(num), d(den) {
        normalize();
    }
    void add(const Rational& rhs) { n = n * rhs.d + rhs.n * d; d *= rhs.d; normalize(); }
    void sub(const Rational& rhs) { n = n * rhs.d - rhs.n * d; d *= rhs.d; normalize(); }
    void mul(const Rational& rhs) { n *= rhs.n; d *= rhs.d; normalize(); }
    void div(const Rational& rhs) {
        if (rhs.n == 0) throw runtime_error("divide by zero");
        n *= rhs.d; d *= rhs.n; normalize();
    }
    void print() const {
        if (n == 0) { cout << 0 << '\n'; return; }
        long long sign = (n < 0) ? -1 : 1;
        long long an = sign * n;          
        long long q = an / d, r = an % d; 

        if (r == 0) {
            cout << (sign < 0 ? "-" : "") << q << '\n';
        }
        else if (q == 0) { 
            cout << (sign < 0 ? "-" : "") << r << '/' << d << '\n';
        }
        else {
            if (sign > 0) cout << q << '+' << r << '/' << d << '\n';
            else          cout << "-(" << q << '+' << r << '/' << d << ")\n";
        }
    }

private:
    long long n, d;
    static long long gcdll(long long a, long long b) {
        if (a < 0) a = -a; if (b < 0) b = -b;
        while (b) { long long t = a % b; a = b; b = t; }
        return a;
    }
    void normalize() {
        if (d == 0) throw runtime_error("denominator cannot be zero");
        if (d < 0) { n = -n; d = -d; }   
        long long g = gcdll(n, d);
        if (g) { n /= g; d /= g; }
    }
};
int main() {
    Rational a(1, 2), b(3, 4);
    a.add(b);  a.print();   
    b.sub(a);  b.print();   
    a.mul(b);  a.print();   
    b.div(a);  b.print();   
}