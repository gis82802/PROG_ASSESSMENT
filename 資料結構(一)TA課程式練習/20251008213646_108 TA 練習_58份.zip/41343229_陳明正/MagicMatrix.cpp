#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    int n;
    cout << "�п�J�_�� n�G";
    if (!(cin >> n) || n < 1 || n % 2 == 0) {
        cout << "n �����O >= 1 ���_�ơC\n";
        return 0;
    }
    vector<vector<int>> a(n, vector<int>(n, 0));
    int r = 0, c = n / 2;
    for (int v = 1; v <= n * n; ++v) {
        a[r][c] = v;
        int nr = (r - 1 + n) % n;
        int nc = (c + 1) % n;
        if (a[nr][nc] != 0) {
            r = (r + 1) % n;      
        }
        else {
            r = nr; c = nc;       
        }
    }
    long long magic = 1LL * n * (1LL * n * n + 1) / 2;  
    int width = static_cast<int>(to_string(n * n).length()) + 1;

    cout << "Magic constant = " << magic << "\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j)
            cout << setw(width) << a[i][j];
        cout << '\n';
    }
    return 0;
}
