#include "RationalNumber.h"
#include <iostream>
#include <cstdlib>  // abs
#include <stdexcept>
using namespace std;

// gcd ����
int gcd(int a, int b) {
    while (b != 0) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a;
}

// ----------------- RationalNumber ���� -----------------
RationalNumber::RationalNumber(int num, int denom) : numerator(num), denominator(denom) {
    if (denominator == 0)
        throw invalid_argument("Denominator cannot be zero");
    simplify();
}

void RationalNumber::simplify() {
    int g = gcd(abs(numerator), abs(denominator));
    numerator /= g;
    denominator /= g;
    if (denominator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }
}

void RationalNumber::add(const RationalNumber& other) {
    numerator = numerator * other.denominator + other.numerator * denominator;
    denominator = denominator * other.denominator;
    simplify();
}

void RationalNumber::sub(const RationalNumber& other) {
    numerator = numerator * other.denominator - other.numerator * denominator;
    denominator = denominator * other.denominator;
    simplify();
}

void RationalNumber::mul(const RationalNumber& other) {
    numerator *= other.numerator;
    denominator *= other.denominator;
    simplify();
}

void RationalNumber::div(const RationalNumber& other) {
    if (other.numerator == 0)
        throw invalid_argument("Division by zero");
    numerator *= other.denominator;
    denominator *= other.numerator;
    simplify();
}

void RationalNumber::print() const {
    if (numerator == 0) {
        cout << 0 << endl;
    }
    else if (abs(numerator) >= denominator) {
        int whole = numerator / denominator;
        int remain = abs(numerator % denominator);
        if (remain == 0)
            cout << whole << endl;
        else
            cout << whole << "+" << remain << "/" << denominator << endl;
    }
    else {
        cout << numerator << "/" << denominator << endl;
    }
}
