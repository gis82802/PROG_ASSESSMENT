#ifndef RATIONALNUMBER_H
#define RATIONALNUMBER_H

class RationalNumber {
private:
    int numerator;   // ����
    int denominator; // ��ĸ

    void simplify(); // �����֔�

public:
    RationalNumber(int num = 0, int denom = 1);

    void add(const RationalNumber& other);
    void sub(const RationalNumber& other);
    void mul(const RationalNumber& other);
    void div(const RationalNumber& other);

    void print() const;
};

// �Լ��� gcd ����
int gcd(int a, int b);

#endif
