#include <iostream>
#include <iterator>
#include <algorithm>
using namespace std;

void Magic(const int n)
{
    const int MaxSize = 51;
    int square[MaxSize][MaxSize] = { 0 };
    int i, j, k, l;

    if ((n > MaxSize) || (n < 1))
        throw "Error! n out of range";
    else if (!(n % 2))
        throw "Error! n is even";

    // ��ʼλ�ã���һ�����g
    i = 0;
    j = (n - 1) / 2;
    square[i][j] = 1;

    // �������딵�� 2~n^2
    for (int key = 2; key <= n * n; key++)
    {
        // �������Ͻǡ��Ƅ�
        k = (i - 1 + n) % n;
        l = (j + 1) % n;

        // ��ԓ���ѱ����^ �� ������
        if (square[k][l])
            i = (i + 1) % n;
        else
        {
            i = k;
            j = l;
        }

        square[i][j] = key;
    }

    // ӡ���Y��
    cout << "\nMagic Square of size " << n << ":\n";
    for (i = 0; i < n; i++)
    {
        copy(square[i], square[i] + n, ostream_iterator<int>(cout, "\t"));
        cout << endl;
    }
}

int main()
{
    int n;
    cout << "n <= 51: ";
    cin >> n;

    try {
        Magic(n);
    }
    catch (const char* msg) {
        cerr << msg << endl;
    }

    return 0;
}
