#include "RationalNumber.h"
#include <iostream>


using namespace std;

int main() {
    RationalNumber a(1, 2), b(3, 4);

    a.add(b);  a.print();  // 1/2 + 3/4 = 5/4 -> ӡ�� 1+1/4
    b.sub(a);  b.print();  // 3/4 - 5/4 = -1/2
    a.mul(b);  a.print();  // 5/4 * (-1/2) = -5/8
    b.div(a);  b.print();  // (-1/2) / (-5/8) = 4/5

    return 0;
}
