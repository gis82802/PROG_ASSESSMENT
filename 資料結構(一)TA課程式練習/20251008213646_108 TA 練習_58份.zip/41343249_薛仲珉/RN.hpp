#include <iostream>
#include <cstdlib> 
using namespace std;
class Rational {
private:
    long long num; // ���l
    long long den; // ���� (�û���)

    static long long gcd(long long a, long long b) {
        a = llabs(a); b = llabs(b);
        if (a == 0 && b == 0) return 1;
        while (b != 0) {
            long long t = a % b;
            a = b;
            b = t;
        }
        return a == 0 ? 1 : a;
    }

    void reduce() {
        if (num == 0) { den = 1; return; }
        long long g = gcd(num, den);
        num /= g; den /= g;
        if (den < 0) { den = -den; num = -num; }
    }

public:
    // �غc�l
    Rational(long long n = 0, long long d = 1) {
        if (d == 0) {
            cerr << "Error: denominator cannot be zero. Using 0/1 instead.\n";
            num = 0; den = 1;
        }
        else {
            num = n; den = d;
            reduce();
        }
    }

    // a = a + b
    void add(const Rational& b) {
        long long n = num * b.den + b.num * den;
        long long d = den * b.den;
        num = n; den = d;
        reduce();
    }

    // a = a - b
    void sub(const Rational& b) {
        long long n = num * b.den - b.num * den;
        long long d = den * b.den;
        num = n; den = d;
        reduce();
    }

    // a = a * b
    void mul(const Rational& b) {
        long long n = num * b.num;
        long long d = den * b.den;
        num = n; den = d;
        reduce();
    }

    // a = a / b
    void div(const Rational& b) {
        if (b.num == 0) {
            cerr << "Error: divide by zero!\n";
            return;
        }
        long long n = num * b.den;
        long long d = den * b.num;
        num = n; den = d;
        reduce();
    }

    void print() const {
        if (den == 1) cout << num << '\n';
        else cout << num << '/' << den << '\n';
    }
};