
#include "RN.hpp"



int main() {

    Rational a(1, 2), b(3, 4);
    cout << "\n��l��:\n";
    cout << "a = "; a.print();
    cout << "b = "; b.print();

    a.add(b); cout << "\na = a + b => "; a.print();   // 1/2 + 3/4 = 5/4
    b.sub(a); cout << "b = b - a => "; b.print();      // 3/4 - 5/4 = -1/2
    a.mul(b); cout << "\na = a * b => "; a.print();   // 5/4 * -1/2 = -5/8
    b.div(a); cout << "b = b / a => "; b.print();      // (-1/2) / (-5/8) = 4/5

    return 0;
}
