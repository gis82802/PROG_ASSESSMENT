#include <iostream>
#include <iterator>
#include <algorithm>
using namespace std;

void Magic(const int n) {
    if (n < 1)
        throw "Error... n out of range";
    else if ((n % 2) == 0)
        throw "Error... n is even";

    // �ʺA�t�m
    int** sq = new int* [n];
    for (int i = 0; i < n; i++) {
        sq[i] = new int[n];
        fill(sq[i], sq[i] + n, 0); // ��l�Ƭ� 0
    }

    int i = 0, j = n / 2; // �_�l��m�]�Ĥ@�C�����^
    for (int key = 1; key <= n * n; key++) {
        sq[i][j] = key;
        int k = (i - 1 + n) % n; // �W�@�C
        int l = (j - 1 + n) % n; // ���@��

        if (sq[k][l] != 0)  // �Y�Ӯ�w�Q����
            i = (i + 1) % n;    // ���U��
        else {                  // �_�h�����W����
            i = k;
            j = l;
        }
    }

    // ��X
    cout << "Magic square of size " << n << endl;
    for (int r = 0; r < n; r++) {
        copy(sq[r], sq[r] + n, ostream_iterator<int>(cout, "\t"));
        cout << endl;
    }

    // ����
    for (int r = 0; r < n; r++)
        delete[] sq[r];
    delete[] sq;
}

int main() {
    int n;
    cout << "Enter an odd number for magic square: ";
    cin >> n;

    try {
        Magic(n);
    }
    catch (const char* msg) {
        cerr << msg << endl;
    }
}
