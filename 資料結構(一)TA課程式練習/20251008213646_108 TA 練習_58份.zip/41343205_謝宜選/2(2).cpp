#include <iostream>
#include "2.h"

using namespace std;


int main() {
    RationalNumber a(1, 2), b(3, 4);
    a.add(b); a.print();
    b.sub(a); b.print();
    a.mul(b); a.print();
    b.div(a); b.print();
}
