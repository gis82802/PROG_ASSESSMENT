#ifndef Project2_H
#define Project2_H
class RationalNumber {
private:
    int num;
    int den;
public:
    RationalNumber(int setNum = 0, int setDen = 1);
    void add(const RationalNumber& other);
    void sub(const RationalNumber& other);
    void mul(const RationalNumber& other);
    void div(const RationalNumber& other);
    void print();
    void normalizeSign();
    void simplified();
};

#endif