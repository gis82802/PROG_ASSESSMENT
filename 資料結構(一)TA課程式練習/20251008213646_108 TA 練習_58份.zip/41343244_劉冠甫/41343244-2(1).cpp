#include <iostream>
#include <cmath>
using namespace std;

class Rational {
private:
    int numerator;     // ���l
    int denominator;   // ����

    // ²�Ƥ���
    void reduce() {
        if (denominator < 0) {   // �O�Ҥ�������
            numerator = -numerator;
            denominator = -denominator;
        }
        int g = gcd(abs(numerator), abs(denominator));
        if (g != 0) {
            numerator /= g;
            denominator /= g;
        }
    }

    // �p��̤j���]��
    int gcd(int a, int b) {
        return (b == 0) ? a : gcd(b, a % b);
    }

public:
    // �غc�l
    Rational(int n = 0, int d = 1) {
        numerator = n;
        denominator = d;
        reduce();
    }

    // �[�k
    void add(const Rational& other) {
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator = denominator * other.denominator;
        reduce();
    }

    // ��k
    void sub(const Rational& other) {
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator = denominator * other.denominator;
        reduce();
    }

    // ���k
    void mul(const Rational& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        reduce();
    }

    // ���k
    void div(const Rational& other) {
        numerator *= other.denominator;
        denominator *= other.numerator;
        reduce();
    }

    // �L�X���G
    void print() const {
        int whole = numerator / denominator;
        int remain = abs(numerator % denominator);

        if (remain == 0) {
            cout << whole << endl;
        }
        else if (whole == 0) {
            cout << numerator << "/" << denominator << endl;
        }
        else {
            cout << whole << "+" << remain << "/" << denominator << endl;
        }
    }
};

int main() {
    Rational a(1, 2), b(3, 4);  // a=1/2, b=3/4

    a.add(b);  // a = a + b = 5/4
    a.print(); // �L�X 1+1/4

    b.sub(a);  // b = b - a = -1/2
    b.print(); // �L�X -1/2

    a.mul(b);  // a = a * b = -5/8
    a.print(); // �L�X -5/8

    b.div(a);  // b = b / a = 4/5
    b.print(); // �L�X 4/5

    return 0;
}
