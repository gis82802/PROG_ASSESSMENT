#include<iostream>
#include <cmath>
#include <algorithm>

using namespace std;

class RationalNmuber {
private:
    int x;
    int y;

    int w = 0, a = 0, b = 0, g = 0;

    int calculate_gcd(int i, int j) {
        i = abs(i);
        j = abs(j);
        while (j) {
            i = i % j;
            swap(i, j);
        }
        return i;
    }

    void simplify() {
        if (y == 0) {
            cout << "警告：分母不能為零，有理數設為 0。" << endl;
            x = 0;
            y = 1;
            return;
        }

        if (y < 0) {
            x = -x;
            y = -y;
        }

        g = calculate_gcd(x, y);
        if (g > 1) {
            x = x / g;
            y = y / g;
        }
    }

public:
    RationalNmuber(int a, int b) {
        x = a;
        y = b;
        simplify();
    }

    void print() {
        if (y == 1) {
            cout << x << endl;
            return;
        }

        w = x / y;
        int remainder = abs(x % y);

        if (w == 0) {
            cout << x << "/" << y << endl;
        }
        else {
            cout << w;
            if (x < 0) {
                cout << "-" << remainder << "/" << y << endl;
            }
            else {
                cout << "+" << remainder << "/" << y << endl;
            }
        }
    }

    void add(RationalNmuber& other) {
        x = x * other.y + other.x * y;
        y = y * other.y;
        simplify();
    }

    void sub(RationalNmuber& other) {
        x = x * other.y - other.x * y;
        y = y * other.y;
        simplify();
    }

    void mul(RationalNmuber& other) {
        x = x * other.x;
        y = y * other.y;
        simplify();
    }

    void div(RationalNmuber& other) {
        if (other.x == 0) {
            cout << "警告：除數為零，結果設為 0。" << endl;
            x = 0;
            y = 1;
            return;
        }
        x = x * other.y;
        y = y * other.x;
        simplify();
    }
};

int main(void) {
    RationalNmuber a(1, 2), b(3, 4);
    cout << "a = "; a.print();
    cout << "b = "; b.print();

    cout << "--- a.add(b) ---" << endl;
    a.add(b);
    cout << "a = "; a.print();

    cout << "--- b.sub(a) ---" << endl;
    b.sub(a);
    cout << "b = "; b.print();

    cout << "--- a.mul(b) ---" << endl;
    a.mul(b);
    cout << "a = "; a.print();

    cout << "--- b.div(a) ---" << endl;
    b.div(a);
    cout << "b = "; b.print();

    return 0;
}