#include<iostream>
using namespace std;
int main(void) {
	int size = 0,k,l;
	int** square;
	cout << "輸入方陣的大小:";
	cin >> size;
	if (!(size % 2)) throw "方陣大小不能為偶數";
	square = new int*[size];
	for (int i = 0; i < size; i++) {
		square[i] =new int[size];
	}
	for (int i = 0; i < size;i++) {
		fill(square[i], square[i] + size, 0);
	}
	square[0][(size - 1) / 2] = 1;
	int key = 2, i = 0, j = (size - 1) / 2;
	while (key <= size * size) {
		if (i - 1 < 0) k = size - 1; else k = i - 1;
		if (j - 1 < 0) l = size - 1; else l = j - 1;
		if (square[k][l])i = (i + 1) % size;
		else {
			i = k; j = l;
		}
		square[i][j]=key;
		key++;
	}
	cout << "魔術方陣大小:" << size << endl;
	for (i = 0; i < size; i++) {
		copy(square[i], square[i] + size, ostream_iterator<int>(cout, " "));
		cout << endl;
	}

	for (int i = 0; i < size; i++) {
		delete[] square[i];
	}
	delete[] square;

	return 0;
}