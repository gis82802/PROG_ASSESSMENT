#include "Header.hpp"
#include <iostream>
#include <cmath>

using namespace std;

// Private member function definitions
int RationalNumber::gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}

void RationalNumber::simplify() {
    if (den == 0) return;
    int common = gcd(abs(num), abs(den));
    num /= common;
    den /= common;
    if (den < 0) {
        num = -num;
        den = -den;
    }
}

// Public member function definitions
RationalNumber::RationalNumber(int n, int d) {
    if (d == 0) {
        cerr << "Error: Denominator cannot be zero." << endl;
        num = 0;
        den = 1;
    }
    else {
        num = n;
        den = d;
        simplify();
    }
}

void RationalNumber::add(const RationalNumber& other) {
    num = num * other.den + other.num * den;
    den = den * other.den;
    simplify();
}

void RationalNumber::sub(const RationalNumber& other) {
    num = num * other.den - other.num * den;
    den = den * other.den;
    simplify();
}

void RationalNumber::mul(const RationalNumber& other) {
    num = num * other.num;
    den = den * other.den;
    simplify();
}

void RationalNumber::div(const RationalNumber& other) {
    if (other.num == 0) {
        cerr << "Error: Division by zero." << endl;
        return;
    }
    num = num * other.den;
    den = den * other.num;
    simplify();
}

void RationalNumber::print() {
    if (den == 1 || num == 0) {
        cout << num << endl;
    }
    else if (abs(num) >= den) {
        int whole = num / den;
        int remainder = abs(num % den);
        cout << whole << "+" << remainder << "/" << den << endl;
    }
    else {
        cout << num << "/" << den << endl;
    }
}

// Main function
int main() {
    RationalNumber a(1, 2);
    RationalNumber b(3, 4);

    a.add(b);
    a.print();

    b.sub(a);
    b.print();

    a.mul(b);
    a.print();

    b.div(a);
    b.print();

    cin.get();
    return 0;
}