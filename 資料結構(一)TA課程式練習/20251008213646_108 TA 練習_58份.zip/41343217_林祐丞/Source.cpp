#include <iostream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <cmath>

using namespace std;

void Magic(int n) {
    if (n <= 0 || n % 2 == 0) {
        cout << "Error: n �����O�@�ӥ��_�� (�Ҧp 3, 5, 7 ��)�C" << endl;
        return;
    }

    int N = n * n;
    vector<int> square(N, 0);

    int r = 0;
    int c = n / 2;

    int key = 1;

    while (key <= N) {
        square[r * n + c] = key;

        int next_r = r - 1;
        int next_c = c - 1;

        if (next_r < 0) {
            next_r = n - 1;
        }
        if (next_c < 0) {
            next_c = n - 1;
        }

        if (square[next_r * n + next_c] != 0) {
            r = r - 1;
            if (r < 0) {
                r = n - 1;
            }
        }
        else {
            r = next_r;
            c = next_c;
        }

        key++;
    }

    cout << "Modified Matrix (n = " << n << "):" << endl;

    int w = floor(log10(N)) + 1;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << setw(w + 1) << square[i * n + j];
        }
        cout << endl;
    }
}

int main() {
    int n;
    cout << "�п�J�x�}�j�p n (n �������_��): ";

    if (!(cin >> n)) {
        return 1;
    }

    Magic(n);
    system("pause");
    return 0;
}