#pragma once
#ifndef RATIONALNUMBER_HPP
#define RATIONALNUMBER_HPP

class RationalNumber {
private:
    int num;
    int den;

    int gcd(int a, int b);
    void simplify();

public:
    RationalNumber(int n, int d);

    void add(const RationalNumber& other);
    void sub(const RationalNumber& other);
    void mul(const RationalNumber& other);
    void div(const RationalNumber& other);
    void print();
};

#endif // RATIONALNUMBER_HPP