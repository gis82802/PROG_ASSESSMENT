#include <iostream>
#include <cstdlib> 

using namespace std;

class Rational {
private:
    int num;
    int den;


    int gcd(int a, int b) const {
        return b == 0 ? a : gcd(b, a % b);
    }

    void simplify() {
        int g = gcd(abs(num), abs(den));
        num /= g;
        den /= g;

        if (den < 0) {
            num = -num;
            den = -den;
        }
    }

public:

    Rational(int n = 0, int d = 1) {
        if (d == 0) {
            throw invalid_argument("�������i�� 0");
        }
        num = n;
        den = d;
        simplify();
    }

    void add(const Rational& r) {
        num = num * r.den + r.num * den;
        den = den * r.den;
        simplify();
    }

    void sub(const Rational& r) {
        num = num * r.den - r.num * den;
        den = den * r.den;
        simplify();
    }

    void mul(const Rational& r) {
        num *= r.num;
        den *= r.den;
        simplify();
    }

    void div(const Rational& r) {
        if (r.num == 0) {
            throw invalid_argument("���H 0 ���~");
        }
        num *= r.den;
        den *= r.num;
        simplify();
    }


    void print() const {
        if (den == 1) {

            cout << num << endl;
        }
        else if (abs(num) > den) {

            int whole = num / den;
            int remainder = abs(num % den);
            cout << whole << "+" << remainder << "/" << den << endl;
        }
        else {

            cout << num << "/" << den << endl;
        }
    }
};
