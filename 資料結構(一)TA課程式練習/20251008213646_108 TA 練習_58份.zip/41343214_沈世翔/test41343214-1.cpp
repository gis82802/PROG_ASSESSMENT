#include <iostream>

using namespace std;

void printMagicMatrix(int** matrix, int n) {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << matrix[i][j] << "\t";
        }
        cout << endl;
    }
}

int** generateMagicMatrix(int n) {
  
    int** matrix = new int* [n];
    for (int i = 0; i < n; ++i) {
        matrix[i] = new int[n]();
    }

    int row = 0, col = n / 2; 
    matrix[row][col] = 1;    

    for (int num = 2; num <= n * n; ++num) {
        int newRow = (row - 1 + n) % n;  
        int newCol = (col + 1) % n;    

        if (matrix[newRow][newCol] != 0) {
            newRow = (row + 1) % n;
            newCol = col;
        }

        
        matrix[newRow][newCol] = num;

        
        row = newRow;
        col = newCol;
    }

    return matrix;
}


void freeMemory(int** matrix, int n) {
    for (int i = 0; i < n; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix; 
}

int main() {
    int n;
    cout << "��J: ";
    cin >> n;

    if (n % 2 == 0) {
        cout << "�п�J�_��" << endl;
        return 1;
    }

    int** magicMatrix = generateMagicMatrix(n);

    cout << "MagicMatrix\n";
    printMagicMatrix(magicMatrix, n);

    freeMemory(magicMatrix, n);

    return 0;
}
