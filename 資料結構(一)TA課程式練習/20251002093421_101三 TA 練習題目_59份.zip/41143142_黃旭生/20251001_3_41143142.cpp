#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int N = 8;
int grid[N][N] = {
    {522,703,366,131,167,938,935,553},
    {35,842,39,346,169,82,37,702},
    {139,942,649,77,835,81,813,537},
    {618,246,208,599,44,662,655,365},
    {703,983,680,333,462,365,652,31},
    {46,978,832,702,812,850,641,176},
    {848,266,281,849,715,38,370,81},
    {160,865,262,849,570,647,553,902}
};

bool used[N];
int bestSum = -1;
vector<int> bestChoice;

void dfs(int row, int sum, vector<int>& choice) {
    if (row == N) {
        if (sum > bestSum) {
            bestSum = sum;
            bestChoice = choice;
        }
        return;
    }

    for (int col = 0; col < N; col++) {
        if (!used[col]) {
            used[col] = true;
            choice[row] = col;
            dfs(row + 1, sum + grid[row][col], choice);
            used[col] = false;
        }
    }
}

int main() {
    vector<int> choice(N, -1);
    fill(used, used + N, false);

    dfs(0, 0, choice);

    cout << "�̤j�`�M: " << bestSum << endl;
    cout << "�t��覡:" << endl;
    string rows[8] = { "��","�A","��","�B","��","�v","��","��" };
    string cols[8] = { "A","B","C","D","E","F","G","H" };

    for (int i = 0; i < N; i++) {
        cout << rows[i] << " -> " << cols[bestChoice[i]]
            << " (" << grid[i][bestChoice[i]] << ")" << endl;
    }
    return 0;
}
