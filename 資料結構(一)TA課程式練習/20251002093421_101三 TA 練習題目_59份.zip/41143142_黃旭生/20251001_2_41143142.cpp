﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>  // for fabs

using namespace std;

const double EPS = 1e-9;

// Binary Search: 找到一個符合 target 的 index
int binarySearch(const vector<double>& arr, double target) {
    int low = 0, high = arr.size() - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (fabs(arr[mid] - target) < EPS) {
            return mid;
        }
        else if (arr[mid] > target) {
            high = mid - 1;
        }
        else {
            low = mid + 1;
        }
    }
    return -1;
}

int main() {
    ifstream inputFile("sorted_double.txt");
    if (!inputFile) {
        cerr << "無法開啟 sorted_double.txt !" << endl;
        return 1;
    }

    vector<double> numbers;
    double number;
    while (inputFile >> number) {
        numbers.push_back(number);
    }
    inputFile.close();

    double target;
    cout << "輸入要搜尋的數字: ";
    cin >> target;

    int index = binarySearch(numbers, target);

    if (index == -1) {
        cout << "找不到數字 " << target << endl;
    }
    else {
        cout << "找到數字 " << target << " 出現位置: ";

        // 向左擴展
        int left = index;
        while (left - 1 >= 0 && fabs(numbers[left - 1] - target) < EPS) {
            left--;
        }

        // 向右擴展
        int right = index;
        while (right + 1 < numbers.size() && fabs(numbers[right + 1] - target) < EPS) {
            right++;
        }

        // 輸出所有位置
        for (int i = left; i <= right; i++) {
            cout << i << " ";
        }
        cout << endl;
    }

    return 0;
}
