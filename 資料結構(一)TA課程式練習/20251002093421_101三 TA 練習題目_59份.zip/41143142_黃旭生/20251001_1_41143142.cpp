#include <iostream>
#include <fstream>
#include <vector>
#include <limits>

using namespace std;

// Selection sort function
void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // Swap the found minimum element with the first element
        swap(arr[i], arr[minIndex]);
    }
}

int main() {
    ifstream inputFile("double_data.txt");  // Open the input file
    if (!inputFile) {
        cerr << "�}���ɮ׵o�Ϳ��~!" << endl;
        return 1;
    }

    vector<double> numbers;
    double number;

    // Read numbers from file and store in the vector
    while (inputFile >> number) {
        numbers.push_back(number);
    }

    inputFile.close();  // Close the input file

    // Sort the numbers using selection sort
    selectionSort(numbers);

    // Open the output file
    ofstream outputFile("sorted_double.txt");
    if (!outputFile) {
        cerr << "�}�ҿ�X�ɮ׵o�Ϳ��~!" << endl;
        return 1;
    }

    // Write sorted numbers to the output file
    for (double num : numbers) {
        outputFile << num << endl;
    }

    outputFile.close();  // Close the output file

    cout << "�Ƨǧ������x�s�� 'sorted_double.txt'." << endl;

    return 0;
}
