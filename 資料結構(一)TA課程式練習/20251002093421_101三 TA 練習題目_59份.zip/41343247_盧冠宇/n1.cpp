#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

int main() {
    ifstream in("C:\\Users\\user\\Downloads\\double_data(1).txt");

    vector<float> a;
    float number;

    while (in >> number) {
        a.push_back(number);
    }
    in.close();

    int n = a.size();

    for (int x = 0; x < n - 1; x++) {
        int b = x;
        for (int y = x + 1; y < n; y++) {
            if (a[y] < a[b]) {
                b = y;
            }
        }
        float temp = a[b];
        a[b] = a[x];
        a[x] = temp;
    }

    ofstream out("C:\\Users\\user\\Downloads\\double_data(1).txt");

    for (int x = 0; x < n; x++) {
        out << a[x] << endl;
    }
    out.close();
    return 0;
}
