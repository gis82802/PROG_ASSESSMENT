#include <iostream>
#include <vector>
using namespace std;

int a[8][8] = {
    {522,703,366,131,167,938,935,553},
    {35,842,39,346,169,82,37,702},
    {139,942,649,77,835,81,813,537},
    {618,246,208,599,44,662,655,365},
    {703,983,680,333,462,365,652,31},
    {46,978,832,702,812,850,641,176},
    {848,266,281,849,715,38,370,81},
    {160,865,262,849,570,647,553,902}
};

int bests = 0;
vector<int> besta;
vector<int> assign(8);
bool used[8] = { false };

void ddd(int row, int sum) {
    if (row == 8) {//���erow�⧹
        if (sum > bests) {
            bests = sum;
            besta = assign;
        }
        return;
    }
    for (int col = 0; col < 8; col++) {
        if (!used[col]) {
            used[col] = true;
            assign[row] = col;
            ddd(row + 1, sum + a[row][col]);
            used[col] = false;
        }
    }
}

int main(void) {
    ddd(0, 0);

    cout << "�̰���:" << bests << endl;
    cout << "�t��:" << endl;
    string people[8] = {"��","�A","��","�B","��","�v","��","��"}, abc = "ABCDEFGH";
    for (int x = 0; x < 8; x++) {
        cout << people[x] << " " << abc[besta[x]] << " " << a[x][besta[x]] << endl;
    }
    return 0;
}
