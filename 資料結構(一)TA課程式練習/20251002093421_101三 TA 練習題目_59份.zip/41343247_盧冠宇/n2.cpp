#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main(void) {
    ifstream in("C:\\Users\\user\\Downloads\\double_data(1).txt");

    vector<double> a;
    double number;

    while (in >> number) {
        a.push_back(number);
    }
    in.close();
    int  l = 0, r = a.size(), m = 0;
    double n;
    cin >> n;

    while (r >= l) {
        m = (r + l) / 2;
        if (n < a[m]) {
            r = m - 1;
        }
        else if (n > a[m]) {
            l = m + 1;
        }
        else {
            cout << m << endl;
            break;
        }
    }

    if (r < l) {
        cout << "���s�b" << endl;
    }

    return 0;
}
