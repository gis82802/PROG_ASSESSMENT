#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <string>
#include <cmath>     
#include <iomanip>   

using namespace std;

int binarySearch(const vector<double>& arr, double target) {
    int left = 0;
    int right = arr.size() - 1;
    const double epsilon = 1e-9; 

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (abs(arr[mid] - target) < epsilon) {
            return mid; 
        }

        if (arr[mid] < target) {
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }
    return -1; 
}

int main() {
    string filePath = "C:\\Datastructure\\hw-2\\hw1-1\\prog1-1\\Project1\\sorted_output.txt";
    ifstream inputFile(filePath);
    vector<double> data;
    double number_from_file;

    if (!inputFile.is_open()) {
        cerr << "���~�G�L�k�}���ɮ� \"" << filePath << "\"" << endl;
        cerr << "�нT�{�ɮ׸��|�O�_���T" << endl;
        return 1;
    }

    while (inputFile >> number_from_file) {
        data.push_back(number_from_file);
    }
    inputFile.close();

    if (data.empty()) {
        cout << "�ɮ� \"" << filePath << "\" ���S�������ơC" << endl;
        return 0;
    }

    sort(data.begin(), data.end());

    cout << "Ū������ " << endl;

    double number_to_find;
    cout << "�п�J�M�䪺�Ʀr�G";
    cin >> number_to_find;

    int result_index = binarySearch(data, number_to_find);

    cout << fixed << setprecision(15);

    if (result_index != -1) {
        cout << "\n���w�Ʀr " << number_to_find << " ���Ƨǫ��ƪ����ަ�m" << result_index  << endl;
            
        //cout << "��Ʈw�����Ʀr��: " << data[result_index] << endl;
    }
    else {
        cout << "\n�b��Ƥ��䤣����w�Ʀr " << number_to_find << "�C" << endl;
    }

    return 0;
}