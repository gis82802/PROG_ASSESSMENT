#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <string>
#include <iomanip> 

using namespace std;

void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            swap(arr[i], arr[min_idx]);
        }
    }
}

int main() {
    string inputFilePath = "C:\\Users\\Morris.Yo\\Documents\\double_data.txt";
    ifstream inputFile(inputFilePath);

    if (!inputFile.is_open()) {
        cerr << "�L�k�}���ɮ� \"" << inputFilePath << "\"" << endl;
        return 1;
    }

    vector<double> numbers;
    double num;
    while (inputFile >> num) {
        numbers.push_back(num);
    }
    inputFile.close();

    cout << "�q�ɮ� \"" << inputFilePath << "\" Ū���F " << numbers.size() << " �ӼƦr" << endl;

    selectionSort(numbers);
    cout << "�Ƨǧ���" << endl;

    ofstream outputFile("sorted_output.txt");
    if (!outputFile.is_open()) {
        cerr << "���~�G�L�k�إ� sorted_output.txt �ɮסC" << endl;
        return 1;
    }

    
    outputFile << fixed << setprecision(15);

    for (const double& sorted_num : numbers) {
        outputFile << sorted_num << endl;
    }
    outputFile.close();

    cout << "�Ƨǵ��G�w�x�s�� sorted_output.txt" << endl;

    return 0;
}