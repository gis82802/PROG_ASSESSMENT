#include <iostream>
#include <vector>
#include <string>
#include <numeric>
#include <algorithm>

using namespace std;

int main() {

    vector<vector<int>> scores = {
        //   A,   B,   C,   D,   E,   F,   G,   H
        {  522, 703, 366, 131, 167, 938, 935, 553}, // ��
        {   35, 842,  39, 346, 169,  82,  37, 702}, // �A
        {  139, 942, 649,  77, 835,  81, 813, 537}, // ��
        {  618, 246, 208, 599,  44, 662, 655, 365}, // �B
        {  703, 983, 680, 333, 462, 365, 652,  31}, // ��
        {   46, 978, 832, 702, 812, 850, 641, 176}, // �v
        {  848, 266, 281, 849, 715,  38, 370,  81}, // ��
        {  160, 865, 262, 849, 570, 647, 553, 902}  // ��
    };

    vector<string> row_labels = { "��", "�A", "��", "�B", "��", "�v", "��", "��" };
    vector<char> col_labels = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };

    int num_items = row_labels.size();

    vector<int> p(num_items);

    for (int i = 0; i < num_items; ++i) {
        p[i] = i;
    }

    long long max_score = 0;
    vector<int> best_pairing = p;

    do {
        long long current_score = 0;
        for (int i = 0; i < num_items; ++i) {
     
            current_score += scores[i][p[i]];
        }

        if (current_score > max_score) {
            max_score = current_score;
            best_pairing = p;
        }
    } while (next_permutation(p.begin(), p.end()));

    cout << "���R�����I" << endl;
    cout << "---------------------------------" << endl;
    cout << "�[�`�Ȭ�: " << max_score << endl;
    cout << "�̰������t��覡: " << endl;

    for (int i = 0; i < num_items; ++i) {
        int col_index = best_pairing[i];
        cout << row_labels[i] << " <---> " << col_labels[col_index]
            << " ����: " << scores[i][col_index] << endl;
    }
    cout << "---------------------------------" << endl;

    return 0;
}