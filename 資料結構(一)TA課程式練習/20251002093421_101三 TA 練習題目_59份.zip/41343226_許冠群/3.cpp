﻿#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>

using namespace std;

const vector<vector<int>> scores = {
    {522, 703, 366, 131, 167, 938, 935, 553},
    {35, 842, 39, 346, 169, 82, 37, 702},
    {139, 942, 649, 77, 835, 81, 813, 537},
    {618, 246, 208, 599, 44, 662, 655, 365},
    {703, 983, 680, 333, 462, 365, 652, 31},
    {46, 978, 832, 702, 812, 850, 641, 176},
    {848, 266, 281, 849, 715, 38, 370, 81},
    {160, 865, 262, 849, 570, 647, 553, 902}
};

void recursion(int k, int m, vector<int>& assignments, long long& max_score, vector<int>& best_assignments) {
    if (k == m + 1) {
        long long current_score = 0;
        for (int i = 0; i <= m; ++i) {
            current_score += scores[i][assignments[i]];
        }

        if (current_score > max_score) {
            max_score = current_score;
            best_assignments = assignments;
        }
    }
    else {
        for (int i = k; i <= m; ++i) {
            swap(assignments[k], assignments[i]);
            recursion(k + 1, m, assignments, max_score, best_assignments);
            swap(assignments[k], assignments[i]);
        }
    }
}

int main() {
    vector<int> task_indices(8);
    for (int i = 0; i < 8; ++i) {
        task_indices[i] = i;
    }

    long long max_score = 0;
    vector<int> best_assignments;

    recursion(0, 7, task_indices, max_score, best_assignments);

    string rows[] = { "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛" };
    char cols[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };

    for (int i = 0; i < 8; ++i) {
        int task_idx = best_assignments[i];
        cout << rows[i] << " = " << cols[task_idx] << " = " << scores[i][task_idx] << endl;
    }

    cout << "MAX = " << max_score << endl;

    return 0;
}