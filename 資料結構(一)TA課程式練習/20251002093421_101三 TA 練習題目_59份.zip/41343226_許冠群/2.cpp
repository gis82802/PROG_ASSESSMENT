#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int binary_search(vector<double> check, double goal,int left,int right)
{
	
	while (left < right)
	{
		int mid = (right + left) / 2;
		if (check[mid] > goal)right = mid - 1;
		else if (check[mid] < goal) left = mid+1;
		else if (check[mid] == goal)return mid;
	}
	return left+1;
}
int main()
{
	ifstream in;
	double num;
	vector<double> tmp;
	in.open("double_data(1).txt");
	while (in >> num)
	{
		tmp.push_back(num);
	}
	double go;
	while (cin >> go)
	{
		cout << binary_search(tmp, go, 0, tmp.size() - 1)<<endl;
	}
}