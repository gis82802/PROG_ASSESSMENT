#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
	ifstream in;
	in.open("double_data(1).txt");
	double m;
	vector<double> tmp;
	while (in >> m)
	{
		tmp.push_back(m);
	}
	int check;
	for (int i = 0; i < tmp.size()-1; i++)
	{
		check = i;
		for (int j = i + 1; j < tmp.size() - 1; j++)
		{
			if (tmp[check] > tmp[j])
			{
				check = j;
			}
		}
		swap(tmp[i], tmp[check]);
	}
	ofstream file_writer("double_data(1).txt", ios_base::out);
	ofstream ou;
	ou.open("double_data(1).txt");
	for (int i = 0; i < tmp.size(); i++)
	{
		ou << tmp[i] << endl;
	}
}