#include <stdio.h>
#include <string.h>

#define N 8

int scores[N][N] = {
    {522, 703, 366, 131, 167, 938, 935, 553},
    {35, 842, 39, 346, 169, 82, 37, 702},
    {139, 942, 649, 77, 835, 81, 813, 537},
    {618, 246, 208, 599, 44, 662, 655, 365},
    {703, 983, 680, 333, 462, 365, 652, 31},
    {46, 978, 832, 702, 812, 850, 641, 176},
    {848, 266, 281, 849, 715, 38, 370, 81},
    {160, 865, 262, 849, 570, 647, 553, 982}
};

const char* row_labels[N] = { "��","�A","��","�B","��","�v","��","��" };
const char* col_labels[N] = { "A","B","C","D","E","F","G","H" };

int best_perm[N];
long long max_score = 0;

void permute(int perm[], int start, int used[]) {
    if (start == N) {
        long long sum = 0;
        for (int i = 0; i < N; i++) sum += scores[i][perm[i]];
        if (sum > max_score) {
            max_score = sum;
            for (int i = 0; i < N; i++) best_perm[i] = perm[i];
        }
        return;
    }
    for (int i = 0; i < N; i++) {
        if (!used[i]) {
            perm[start] = i;
            used[i] = 1;
            permute(perm, start + 1, used);
            used[i] = 0;
        }
    }
}

int main() {
    int perm[N], used[N] = { 0 };
    permute(perm, 0, used);

    printf("���̰������t��覡�I\n---\n");
    for (int i = 0; i < N; i++) {
        int col = best_perm[i];
        printf("%s �t�� %s (����: %d)\n", row_labels[i], col_labels[col], scores[i][col]);
    }
    printf("�̰��`��: %lld\n", max_score);
    return 0;
}
