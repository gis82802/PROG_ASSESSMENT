
#include <iostream>
#include <algorithm>
using namespace std;

// dfs 函式：row = 當前行, cols = 當前排列, bestCols = 儲存最佳排列, maxSum = 目前最大總和, demo = 矩陣
void dfs(int row, int* cols, int* bestCols, int& maxSum, int demo[8][8]) {
    if (row == 8) { 
        int sum = 0;
        for (int i = 0; i < 8; i++) sum += demo[i][cols[i]];
        if (sum > maxSum) {
            maxSum = sum;
            for (int i = 0; i < 8; i++) bestCols[i] = cols[i];
        }
        return;
    }

    for (int i = row; i < 8; i++) {
        swap(cols[row], cols[i]);       
        dfs(row + 1, cols, bestCols, maxSum, demo);
        swap(cols[row], cols[i]);       
    }
}

int main() {
    int demo[8][8] = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,559,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };

    int cols[8] = { 0,1,2,3,4,5,6,7 };
    int bestCols[8];
    int maxSum = 0;

    dfs(0, cols, bestCols, maxSum, demo);

    cout << "最大總和: " << maxSum << endl;
    cout << "最佳組合: " << endl;
    cout << "甲對應到幾行" << bestCols[0] +1<< " "<<endl;
    cout << "乙對應到幾行" << bestCols[1]+1 << " " << endl;
    cout << "丙對應到幾行" << bestCols[2]+1 << " " << endl;
    cout << "丁對應到幾行" << bestCols[3]+1 << " " << endl;
    cout << "戊對應到幾行" << bestCols[4]+1 << " " << endl;
    cout << "己對應到幾行" << bestCols[5]+1 << " " << endl;
    cout << "更對應到幾行" << bestCols[6]+1 << " " << endl;
    cout << "辛對應到幾行" << bestCols[7]+1 << " " << endl;
    cout << endl;

    return 0;
}
