#include<iostream>
#include <fstream>
using namespace std;
void selectionSort(double*& a, const int b) {
	double* f = a;
	for (int n = 0; n < b; n++) {
		int men = n;
		for (int m = n + 1; m < b; m++) {
			if (a[m] < a[men]) {
				men = m;

			}
		}
		if (men != n) {
			double chan = a[men];
			a[men] = a[n];
			a[n] = chan;
		}
	}
}
int main() {
	ifstream inFile("C:\\Users\\user\\Downloads\\double_data(1).txt");
	if (!inFile) {
		cerr << "檔案開啟失敗！" << endl;
		return 1;
	}
	int count = 0;
	double temp;
	while (inFile >> temp) {
		count++;
	}
	inFile.close();

	inFile.open("C:\\Users\\user\\Downloads\\double_data(1).txt");
	double* arr = new double[count]; 
	for (int i = 0; i < count; i++) {
		inFile >> arr[i];
	}
	inFile.close();

	
	selectionSort(arr, count);

	
	ofstream outFile("out.txt");
	if (!outFile) {
		cout << "無法建立 out.txt" << endl;
		delete[] arr;
		return 1;
	}
	else cout << "排序完成，結果已儲存在 out.txt" << endl;

	for (int i = 0; i < count; i++) {
		outFile << arr[i] << endl;
	}
	outFile.close();
	delete[] arr; 
	return 0;
}