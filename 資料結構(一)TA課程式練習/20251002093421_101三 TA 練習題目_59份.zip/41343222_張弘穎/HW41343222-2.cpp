#include<iostream>
#include<fstream>
using namespace std;
void binarySearch(double* a, int min, int max,const double b) {
	if (min > max) { 
		cout << "找不到目標值" << endl;
		return;
	}
	int mid = (min + max) / 2;
	if (a[mid] < b)binarySearch(a, mid + 1, max, b);
	else if (b < a[mid])binarySearch(a, min, mid - 1, b);
	else if(b == a[mid]) {
		cout << "尋找目標值" << a[mid]<<endl <<"他在陣列位置:"<<mid << endl;
		return;
	}
}
void selectionSort(double*& a, const int b) {
	double* f = a;
	for (int n = 0; n < b; n++) {
		int men = n;
		for (int m = n + 1; m < b; m++) {
			if (a[m] < a[men]) {
				men = m;

			}
		}
		if (men != n) {
			double chan = a[men];
			a[men] = a[n];
			a[n] = chan;
		}
	}
}

int main() {
	double a;
	cout << "請輸入你要搜尋的數字" << endl;
	cin >> a;
	ifstream inFile("C:\\Users\\user\\Downloads\\double_data(1).txt");
	if (!inFile) {
		cerr << "檔案開啟失敗！" << endl;
		return 1;
	}
	int count = 0;
	double temp;
	while (inFile >> temp) {
		count++;
	}
	inFile.close();

	inFile.open("C:\\Users\\user\\Downloads\\double_data(1).txt");
	double* arr = new double[count];
	for (int i = 0; i < count; i++) {
		inFile >> arr[i];
	}
	inFile.close();

	selectionSort(arr, count);

	binarySearch(arr, 0, count-1, a);
	delete[] arr;
	return 0;
}