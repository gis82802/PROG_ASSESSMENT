#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <iomanip>
using namespace std;
void selectionsort(vector<double>& arr) {
    int n = arr.size();
    if (n < 2) return;
    for (int i = 0; i < n - 1; ++i) {
        int min_idx = i;
        for (int j = i + 1; j < n; ++j) if (arr[j] < arr[min_idx])  min_idx = j;
        if (min_idx != i) swap(arr[i], arr[min_idx]);
    }
}
int main() {
    string infile = "double_data(1).txt";
    string outfile = "sorted.txt";
    vector<double> numbers;
    double temp;
    ifstream inputFile(infile);
    if (!inputFile.is_open()) {
        cerr << "error" << infile << endl;
        return 1;
    }
    while (inputFile >> temp) numbers.push_back(temp);
    inputFile.close();
    selectionsort(numbers);
    cout << "sorted" << endl;
    ofstream outputFile(outfile);
    if (!outputFile.is_open()) {
        cerr << "error cant output file" << outfile << endl;
        return 1;
    }

    for (const double& num : numbers) outputFile << setprecision(17) << num << endl;
    outputFile.close();
    cout << "finish" << endl;
}
