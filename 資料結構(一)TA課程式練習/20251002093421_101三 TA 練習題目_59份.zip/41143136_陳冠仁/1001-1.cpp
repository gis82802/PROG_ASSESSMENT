#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        swap(arr[i], arr[minIndex]);
    }
}

int main() {
    ifstream infile("double_data.txt");
    ofstream outfile("sorted.txt");

    vector<double> numbers;
    double x;
    while (infile >> x) {
        numbers.push_back(x);
    }

    selectionSort(numbers);

    for (double num : numbers) {
        outfile << num << endl;
    }

    infile.close();
    outfile.close();
    return 0;
}
