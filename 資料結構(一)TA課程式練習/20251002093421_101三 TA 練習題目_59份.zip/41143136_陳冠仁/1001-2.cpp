#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int binarySearch(const vector<double>& arr, double target) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (arr[mid] == target) return mid;   // �^�ǯ��� (0-based)
        else if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;  // �S���
}

int main() {
    ifstream infile("sorted.txt");
    vector<double> numbers;
    double x;
    while (infile >> x) numbers.push_back(x);

    double target;
    cout << "�п�J�n�d�䪺�Ʀr: ";
    cin >> target;

    int pos = binarySearch(numbers, target);
    if (pos != -1)
        cout << "��� " << target << " �b�Ƨǫ᪺��m (index) = " << pos << endl;
    else
        cout << "�䤣�� " << target << endl;

    return 0;
}
