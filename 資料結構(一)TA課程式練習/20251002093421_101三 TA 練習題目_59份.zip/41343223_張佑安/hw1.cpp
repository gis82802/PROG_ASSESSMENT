#include <iostream>
#include <fstream>
#include <windows.h>
#include <vector>
using namespace std;

// Selection Sort 函式
void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // 交換
        if (minIndex != i) {
            double temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}

int main() {
   // SetConsoleOutputCP(CP_UTF8);
    //SetConsoleCP(CP_UTF8);
    ifstream fin("double_data.txt");   // 輸入檔
    ofstream fout("sorted_data.txt");  // 輸出檔

    if (!fin.is_open()) {
        cerr << "讀取檔案失敗！\n";
        return 1;
    }

    vector<double> data;
    double value;

    // 讀入所有數字
    while (fin >> value) {
        data.push_back(value);
    }
    fin.close();

    cout << "共讀入 " << data.size() << " 筆資料。" << endl;

    // 排序
    selectionSort(data);

    // 輸出結果
    for (double num : data) {
        fout << num << endl;   // 每行一個數字
    }
    fout.close();

    cout << "排序完成，結果已輸出到 sorted_data.txt" << endl;

    return 0;
}
