#include <iostream>
#include <fstream>
#include <windows.h>
#include <vector>
using namespace std;

// 回傳任意一個等於 x 的索引；找不到回傳 -1
int binary_search_any(vector<double>& arr, int n, double x) {
    int left = 0, right = n - 1;

    while (left <= right) {
        int mid = (left + right) / 2;
        if (arr[mid] == x) {
            return mid; // 找到就回傳索引
        }
        else if (arr[mid] < x) {
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }

    return -1; // 沒找到
}

int main() {
    //SetConsoleOutputCP(CP_UTF8);
    //SetConsoleCP(CP_UTF8);
    ifstream fin("data.txt");
    if (!fin.is_open()) {
        cerr << "讀取檔案失敗！\n";
        return 1;
    }
    vector<double> data;
    double value;
    int n=0;
    // 讀入所有數字
    while (fin >> value) {
        data.push_back(value);
        n++;
    }
    
    //int n = sizeof(data) / sizeof(data[0]);//確認陣列大小
    //cout << n << endl;//debug用
    double x;
    cout << "輸入要找的數字" << endl;
    cin >> x;

    int result = binary_search_any(data, n, x);
    if (result != -1) {
        cout << "找到索引：" << result << endl;
    }
    else {
        cout << "找不到" << endl;
    }
    fin.close();
    return 0;
}

