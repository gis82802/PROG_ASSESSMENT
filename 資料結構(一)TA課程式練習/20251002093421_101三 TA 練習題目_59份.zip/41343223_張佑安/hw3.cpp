#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <limits>
#include <windows.h>

using namespace std;

/* 匈牙利演算法（最小化版本，C++11）
 * 功能：計算一個 n×n 成本矩陣中的最小指派成本
 * 輸入: cost[n][n] （每個行 i 派到列 j 的成本）
 * 輸出: (最小成本, matchR)
 *       matchR[j] = 被指派到「欄 j」的「列 i」 (1-based)
 */
pair<long long, vector<int>> hungarian_min_cost(const vector<vector<long long>>& cost) {
    int n = (int)cost.size();
    const long long INF =1e15;

    // u, v 是「勢能」陣列，用來調整邊權，確保正確性
    vector<long long> u(n + 1, 0), v(n + 1, 0);
      
    // p[j] = 欄 j 現在配對的「行 i」
    // way[j] = 紀錄最佳路徑的前一個欄
    vector<int> p(n + 1, 0), way(n + 1, 0);

    for (int i = 1; i <= n; ++i) {
        p[0] = i;        // 從第 i 行開始嘗試找配對
        int j0 = 0;      // 當前考慮的列
        vector<long long> minv(n + 1, INF);  // 最小鬆弛值
        vector<char> used(n + 1, false);     // 記錄某列是否已經處理過

        do {
            used[j0] = true;
            int i0 = p[j0];  // 當前配對的行
            long long delta = INF;
            int j1 = 0;

            // 嘗試鬆弛其他未使用的欄
            for (int j = 1; j <= n; ++j) if (!used[j]) {
                long long cur = cost[i0 - 1][j - 1] - u[i0] - v[j];
                if (cur < minv[j]) {
                    minv[j] = cur;
                    way[j] = j0;   // 紀錄路徑
                }
                if (minv[j] < delta) {
                    delta = minv[j];
                    j1 = j;
                }
            }

            // 更新勢能
            for (int j = 0; j <= n; ++j) {
                if (used[j]) {
                    u[p[j]] += delta;
                    v[j] -= delta;
                }
                else {
                    minv[j] -= delta;
                }
            }
            j0 = j1;
        } while (p[j0] != 0);  // 找到一個未匹配的列為止

        // 沿著 way 陣列回溯，完成一次增廣
        do {
            int j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
        } while (j0);
    }

    // 匹配結果
    vector<int> matchR(n + 1, 0);
    for (int j = 1; j <= n; ++j) matchR[j] = p[j];

    long long minCost = -v[0];
    return make_pair(minCost, matchR);
}

int main() {
    // 設定 console 輸出為 UTF-8，確保顯示中文
   // SetConsoleOutputCP(CP_UTF8);
    //SetConsoleCP(CP_UTF8);

    // 分數矩陣（行：甲乙丙丁戊己庚辛；列：A..H）
    vector<vector<long long>> w = {
        {522,703,366,131,167,938,935,553},
        { 35,842, 39,346,169, 82, 37,702},
        {139,942,649, 77,835, 81,813,537},
        {618,246,208,599, 44,662,655,365},
        {703,983,680,333,462,365,652, 31},
        { 46,978,832,702,812,850,641,176},
        {848,266,281,849,715, 38,370, 81},
        {160,865,262,849,570,647,553,902}
    };

    int n = (int)w.size();

    // 找到矩陣中最大值，用來轉換成「最小化問題」
    long long mx = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            mx = max(mx, w[i][j]);

    // 將「最大化」問題轉換成「最小化」問題
    // cost[i][j] = mx - w[i][j]
    vector<vector<long long>> cost(n, vector<long long>(n, 0));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            cost[i][j] = mx - w[i][j];

    // 執行匈牙利演算法
    pair<long long, vector<int>> result = hungarian_min_cost(cost);
    long long minCost = result.first;
    vector<int> matchR = result.second; // 1-based：欄 j -> 行 i

    // 行、列的名稱
    vector<string> rowName = { "甲","乙","丙","丁","戊","己","庚","辛" };
    vector<string> colName = { "A","B","C","D","E","F","G","H" };

    // 將結果轉成「行 -> 欄」的對應
    vector<int> colOfRow(n, -1);
    for (int j = 1; j <= n; ++j) {
        int i = matchR[j] - 1; // 行 index
        int jj = j - 1;        // 列 index
        colOfRow[i] = jj;
    }

    // 輸出最佳配對與分數
    long long total = 0;
    cout << "最佳配對與分數：\n";
    for (int i = 0; i < n; ++i) {
        int j = colOfRow[i];
        cout << rowName[i] << " -> " << colName[j]
            << " : " << w[i][j] << "\n";
        total += w[i][j];
    }
    cout << "最大總分 = " << total << "\n";
    return 0;
}
