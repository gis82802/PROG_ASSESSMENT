#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
const vector<vector<int>> scores = {
    {522, 783, 366, 131, 167, 938, 935, 553}, //甲
    {35,  842, 39,  346, 169, 82,  37,  702}, //乙
    {139, 942, 649, 77,  835, 81,  813, 537}, //丙
    {618, 246, 288, 599, 44,  662, 655, 365}, //丁
    {703, 983, 680, 333, 462, 365, 652, 31},  //戊
    {46,  978, 832, 702, 812, 850, 641, 176}, //己
    {848, 266, 281, 849, 715, 38,  370, 81},  //庚
    {160, 865, 262, 849, 578, 647, 553, 902}  //辛
};
void recursion(int k, int m, vector<int>& assignments, long long& max, vector<int>& best) {
    if (k == m) {
        long long current = 0;
        for (int i = 0; i <= m; ++i) current += scores[i][assignments[i]];
        if (current > max) {
            max = current;
            best = assignments;
        }
    }
    else {
        for (int i = k; i <= m; ++i) {
            swap(assignments[k], assignments[i]);
            recursion(k + 1, m, assignments, max, best);
            swap(assignments[k], assignments[i]);
        }
    }
}
int main() {
    vector<int> task(8);
    for (int i = 0; i < 8; ++i) task[i] = i;
    long long max = 0;
    vector<int> best;
    recursion(0, 7, task, max, best);
    string rows[] = { "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛" };
    char cols[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };
    for (int i = 0; i < 8; ++i) {
        int task_idx = best[i];
        cout << rows[i] << " = " << cols[task_idx] << " = " << scores[i][task_idx] << endl;
    }
    cout << "MAX = " << max << endl;
}