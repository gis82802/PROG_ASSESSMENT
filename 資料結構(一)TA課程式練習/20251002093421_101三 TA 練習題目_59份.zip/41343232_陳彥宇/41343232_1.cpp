
#include <iostream>
#include <fstream>
using namespace std;
void saveData(double*& dataBank, double newData, int& dataCount, int* dataBankSize);

int main() {
    int dataBankSize = 10;
    double* dataBank = new double[dataBankSize];
    double newData;
    int dataCount = 0;

    ifstream infile("C:\\Users\\user\\Desktop\\41343232(1)\\abc\\double.txt");
    if (!infile) {
        cerr << "無法開啟檔案 double.txt\n";
        delete[] dataBank;
        return 1;
    }

    while (infile >> newData) {
        saveData(dataBank, newData, dataCount, &dataBankSize);
    }
    infile.close();

    if (dataCount == 0) {
        std::cout << "檔案中沒有數據。\n";
        delete[] dataBank;
        return 0;
    }
    for (int i = 0; i < dataCount; i++)
    {
        int min = i;
        for (int j = i + 1; j < dataCount; j++)
        {
            if (dataBank[min] > dataBank[j])
                min = j;
        }
        swap(dataBank[min], dataBank[i]);
    }
    ofstream outfile("out.txt");
    if (!outfile)
    {
        cout << "error" << endl;
        return 0;
    }
    for (int i = 0; i < dataCount; i++)
    {
        outfile << dataBank[i] << endl;
    }
    outfile.close();

    delete[] dataBank;
    return 0;
}

void saveData(double*& dataBank, double newData, int& dataCount, int* dataBankSize) {
    if (dataCount >= *dataBankSize) {
        int oldSize = *dataBankSize;
        int newSize = oldSize * 2;
        if (newSize == 0) newSize = 1;
        double* newBank = new double[newSize];

        for (int i = 0; i < dataCount; ++i) {
            newBank[i] = dataBank[i];
        }

        delete[] dataBank;
        dataBank = newBank;
        *dataBankSize = newSize;

        cout << "記憶體擴大: " << oldSize << " -> " << newSize << "（已自動擴充）\n";
    }

    dataBank[dataCount++] = newData;
}
