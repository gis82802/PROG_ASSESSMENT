#include<iostream>
#include<fstream>
using namespace std;
const int MAX_size = 10009;
int binarysearch(double a[], int n, double target)
{
	int left = 0, right = n - 1;
	while (left <= right)
	{
		int mid = (left + right) / 2;
		if (a[mid] == target)
			return mid;
		else if (a[mid] < target)
			left = mid + 1;
		else if (a[mid] > target)
			right = mid - 1;
	}
	return -1;
}
int main(void)
{
	double sortnumber[MAX_size];
	int count = 0;

	ifstream inputfile("C:\\Users\\user\\Desktop\\41343232(1)\\abc\\abc\\out.txt");
	if (!inputfile)
	{
		cout << "error" << endl;
		return 0;
	}
	while (inputfile >> sortnumber[count])
	{
		count++;
		if (count > MAX_size)
			break;
	}
	inputfile.close();
	double target;
	cout << "輸入搜尋的數字:";
	cin >> target;

	int position = binarysearch(sortnumber, count, target);
	if (position != -1)
	{
		cout << "找到數字" << target << "在位置:" << position << endl;

		cout << "所有出現的位置:" << position;
		int left = position - 1;
		while (left >= 0 && sortnumber[left] == target)
		{
			cout << ", " << left;
			left--;
		}
		int right = position + 1;
		while (right < count && sortnumber[right] == target)
		{
			cout << ", " << right;
			right++;
		}
		cout << endl;
	}
	else
	{
		cout << "沒有找到數字 " << target << endl;
	}

}