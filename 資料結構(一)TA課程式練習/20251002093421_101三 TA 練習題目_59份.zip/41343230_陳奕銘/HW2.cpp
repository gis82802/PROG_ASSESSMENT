#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

// Function to perform selection sort
void selectionSort(vector<double>& data) {
    int n = data.size();
    for (int i = 0; i < n - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (data[j] < data[minIndex]) {
                minIndex = j;
            }
        }
        swap(data[i], data[minIndex]);
    }
}


int binarySearch(const vector<double>& data, double target) {
    int left = 0, right = data.size() - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (data[mid] == target)
            return mid; // return index
        else if (data[mid] < target)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;
}

int main() {
    vector<double> numbers;
    double num;


    ifstream inputFile("double.txt");
    if (!inputFile) {
        cerr << "�L�k�}�� double.txt �ɮסC" << endl;
        return 1;
    }

    while (inputFile >> num) {
        numbers.push_back(num);
    }
    inputFile.close();

    // ���� selection sort
    selectionSort(numbers);

    // �N�Ƨǵ��G�g�J sorted.txt
    ofstream outputFile("sorted.txt");
    for (double n : numbers) {
        outputFile << n << endl;
    }
    outputFile.close();
    cout << "�Ƨǧ����A���G�w�x�s�� sorted.txt �ɮפ��C\n";

    // ���ϥΪ̿�J�n�j�M���Ʀr
    cout << "�п�J�n�j�M���Ʀr�G";
    double target;
    cin >> target;

    int position = binarySearch(numbers, target);
    if (position != -1) {
        cout << "�Ʀr " << target << " �X�{�b�Ƨǫ᪺��m�]index�^�G " << position << endl;
    }
    else {
        cout << "�䤣��Ʀr " << target << "�C\n";
    }

    return 0;
}
