#include<iostream>
#include <fstream>
#include <vector>
using namespace std;

int binarySearch(const vector<double>& arr, double target)
{
	int left = 0, right = arr.size() - 1;
	while (left <= right)
	{
		int mid = left + (right - left) / 2;
		if (arr[mid] > target) right = mid - 1;
		else if (arr[mid] < target) left = mid + 1;
		else return mid;
	}
	return -1;
}
int main()
{
	ifstream input("sorted_data.txt");
	if (!input) {
		cerr << "�L�k�}�ҿ�J�ɮ� sorted_data.txt" << endl;
		return 1;
	}
	vector<double> data;
	double value;

	while (input >> value) {
		data.push_back(value);
	}
	input.close();

	double target;
	cout << "�п�J�n�j�M���Ʀr: ";
	cin >> target;

	int index = binarySearch(data, target);

	if (index != -1) {
		cout << "���Ʀr " << target << " �b���ަ�m " << index << endl;
	}
	else {
		cout << "�䤣��Ʀr " << target << endl;
	}

	return 0;
}