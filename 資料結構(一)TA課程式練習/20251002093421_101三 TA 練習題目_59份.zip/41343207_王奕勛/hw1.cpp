#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        if (minIndex != i) {
            double temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}

int main() {
    ifstream input("double_data.txt");
    if (!input) {
        cerr << "�L�k�}�ҿ�J�ɮ� double_data.txt" << endl;
        return 1;
    }

    vector<double> data;
    double value;

    while (input >> value) {
        data.push_back(value);
    }
    input.close();

    selectionSort(data);

    ofstream output("sorted_data.txt");
    if (!output) {
        cerr << "�L�k�إ߿�X�ɮ� sorted_data.txt" << endl;
        return 1;
    }

    for (double num : data) {
        output << num << "\n";
    }

    output.close();

    cout << "�Ƨǧ����A���G�w�s�� sorted_data.txt" << endl;

    return 0;
}