#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    
    int score[8][8] = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,599,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };

    vector<int> perm = { 0,1,2,3,4,5,6,7 };
    int bestScore = -1;
    vector<int> bestMatch;

    
    do {
        int total = 0;
        for (int i = 0; i < 8; i++) {
            total += score[i][perm[i]];
        }
        if (total > bestScore) {
            bestScore = total;
            bestMatch = perm;
        }
    } while (next_permutation(perm.begin(), perm.end()));

    
    cout << "�̰����� = " << bestScore << endl;
    cout << "�覡�G" << endl;
    string rowNames[8] = { "��","�A","��","�B","��","�v","��","��" };
    char colNames[8] = { 'A','B','C','D','E','F','G','H' };

    for (int i = 0; i < 8; i++) {
        cout << rowNames[i] << " & " << colNames[bestMatch[i]]
            << " ( " << score[i][bestMatch[i]] << ")" << endl;
    }

    return 0;
}
