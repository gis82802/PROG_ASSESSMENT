#include <iostream>
#include <fstream>
using namespace std;

int binarySearch(double arr[], int n, double target) {
    int left = 0, right = n - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (arr[mid] == target) return mid;
        else if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

int main() {
    ifstream fin("sorted.txt");
    if (!fin) {
        cout << "�ɮ� sorted.txt �L�k�}�ҡI" << endl;
        return 1;
    }

    double numbers[10000];
    int count = 0;

    while (fin >> numbers[count]) {
        count++;
    }
    fin.close();

    cout << "Ū�J " << count << " �����" << endl;

    double target;
    while (1) {
        cout << "��J�n�j�M���Ʀr: ";
        cin >> target;

        int pos = binarySearch(numbers, count, target);

        if (pos != -1) {
            cout << "��� " << target << " ���� " << pos+1 << " �����" << endl;
        }
        else {
            cout << "�䤣�� " << target << endl;
        }
    }
    system("pause");
    return 0;
}
