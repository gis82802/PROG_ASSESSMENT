﻿#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
// Binary Search
int binarySearch(const vector<double>& arr, double target) {
    int left = 0;
    int right = arr.size() - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) {
            return mid;  // 找到目標，返回其索引
        }
        else if (arr[mid] < target) {
            left = mid + 1;  // 目標在右半邊
        }
        else {
            right = mid - 1;  // 目標在左半邊
        }
    }
    return -1;  // 若未找到目標，返回 -1
}
int main() {
    ifstream inFile("sorted.txt");
    if (!inFile) {
        cerr << "無法開啟 sorted.txt 檔案！" << endl;
        return 1;
    }
    vector<double> numbers;
    double value;
    // 讀檔
    while (inFile >> value) {
        numbers.push_back(value);
    }
    inFile.close();
    // 讓使用者輸入想要搜尋的數字
    double target;
    cout << "請輸入要搜尋的數字：";
    cin >> target;
    // 使用二分搜尋找出目標數字的位置
    int index = binarySearch(numbers, target);
    if (index != -1) {
        cout << "數字 " << target << " 在 sorted.txt 中的位置是： " << index << endl;
    }
    else {
        cout << "數字 " << target << " 不在 sorted.txt 中。" << endl;
    }
    return 0;
}
