#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
// Selection Sort
void selectionSort(vector<double>& arr) {
	int n = arr.size();
	for (int i = 0; i < n - 1; i++) {
		int minIndex = i;
		for (int j = i + 1; j < n; j++) {
			if (arr[j] < arr[minIndex]) {
				minIndex = j;
			}
		}
		// �洫
		if (minIndex != i) {
			double temp = arr[i];
			arr[i] = arr[minIndex];
			arr[minIndex] = temp;
		}
	}
}
int main() {
	ifstream inFile("double_data.txt");
	if (!inFile) {
		cerr << "�L�k�}�� double.txt �ɮסI" << endl;
		return 1;
	}
	vector<double> numbers;
	double value;
	// Ū��
	while (inFile >> value) {
		numbers.push_back(value);
	}
	inFile.close();
	// �Ƨ�
	selectionSort(numbers);
	// ��X���G
	ofstream outFile("sorted.txt");
	if (!outFile) {
		cerr << "�L�k�إ� sorted.txt �ɮסI" << endl;
		return 1;
	}
	for (double num : numbers) {
		outFile << num << endl;
	}
	outFile.close();
	cout << "�Ƨǧ����A���G�w�s�� sorted.txt" << endl;
	return 0;
}