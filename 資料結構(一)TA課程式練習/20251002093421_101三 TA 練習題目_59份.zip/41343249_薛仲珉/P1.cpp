#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
            }
        }
        swap(arr[i], arr[minIdx]);
    }
}

int main() {
    ifstream inFile("double_data.txt"); // ��J�ɮ�
    vector<double> arr;
    double num;

    while (inFile >> num) {
        arr.push_back(num);
    }
    inFile.close();

    selectionSort(arr);

    ofstream outFile("sorted_data.txt"); // ��X�ɮ�
    for (double d : arr) {
        outFile << d << endl;
    }
    outFile.close();

    cout << "�Ƨǧ����A���G�w��X�� sorted_data.txt" << endl;
    return 0;
}