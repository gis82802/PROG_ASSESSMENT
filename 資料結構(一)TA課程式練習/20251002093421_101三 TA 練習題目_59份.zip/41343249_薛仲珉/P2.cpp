#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int binarySearch(const vector<double>& arr, double target) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (arr[mid] == target) return mid;
        else if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

int main() {
    ifstream inFile("sorted_data.txt"); // Ū���Ƨǫ᪺�ɮ�
    vector<double> arr;
    double num;
    while (inFile >> num) arr.push_back(num);
    inFile.close();

    double target;
    cout << "�п�J�n�j�M���Ʀr: ";
    cin >> target;

    int pos = binarySearch(arr, target);
    if (pos != -1)
        cout << "���Ʀr " << target << " �b�Ƨǫ�}�C����m: " << pos << endl;
    else
        cout << "�Ʀr " << target << " ���s�b��}�C���C" << endl;

    return 0;
}