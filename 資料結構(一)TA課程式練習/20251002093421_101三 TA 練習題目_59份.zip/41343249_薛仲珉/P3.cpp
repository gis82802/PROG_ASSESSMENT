#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// �x�}�G�ҤA���B �� 0,1,2,3
vector<vector<int>> score = {
    {522,703,366,131,167,938,935,553},
    {35,842,39,346,169,82,37,702},
    {139,942,649,77,835,81,813,537},
    {618,246,208,599,44,662,655,365},
    {703,983,680,333,462,365,652,31},
    {46,978,832,702,812,850,641,176},
    {848,266,281,849,715,38,370,81},
    {160,865,262,849,570,647,553,902}
};

int main() {
    int n = score.size();
    vector<int> jobs(n);
    for (int i = 0; i < n; i++) jobs[i] = i;

    int maxSum = -1;
    vector<int> bestAssign;

    do {
        int sum = 0;
        for (int i = 0; i < n; i++) sum += score[i][jobs[i]];
        if (sum > maxSum) {
            maxSum = sum;
            bestAssign = jobs;
        }
    } while (next_permutation(jobs.begin(), jobs.end()));

    cout << "�̨ΰt����� = " << maxSum << endl;
    for (int i = 0; i < n; i++) {
        cout << "�H�� " << i << " �t��� �u�@ " << bestAssign[i] << endl;
    }

    return 0;
}
