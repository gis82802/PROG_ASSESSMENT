#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_SIZE 1000
#define EPSILON 1e-6

// SelectionSort
void selection_sort(double arr[], int n) {
	for (int i = 0; i < n - 1; i++) {
		int min_idx = i;
		for (int j = i + 1; j < n; j++) {
			if (arr[j] < arr[min_idx]) {
				min_idx = j;
			}
		}
		if (min_idx != i) {
			double temp = arr[i];
			arr[i] = arr[min_idx];
			arr[min_idx] = temp;
		}
	}
}

// BinarySearch
int binary_search(double arr[], int n, double target) {
	int left = 0, right = n - 1;
	while (left <= right) {
		int mid = (left + right) / 2;

		if (fabs(arr[mid] - target) < EPSILON) {
			return mid;
		}
		else if (arr[mid] < target) {
			left = mid + 1;
		}
		else {
			right = mid - 1;
		}
	}
	return -1;
}

int main() {
	FILE* fp_in;
	double numbers[MAX_SIZE];
	int count = 0;

	fp_in = fopen("double_data.txt", "r");
	if (fp_in == NULL) {
		perror("�L�k�}�� double_data.txt");
		return 1;
	}

	while (fscanf(fp_in, "%lf", &numbers[count]) == 1) {
		count++;
		if (count >= MAX_SIZE) break;
	}
	fclose(fp_in);

	selection_sort(numbers, count);

	printf("�Ƨǫ᪺�Ʀr:\n");
	for (int i = 0; i < count; i++) {
		printf("%.6lf ", numbers[i]);
	}
	printf("\n");

	double target;
	printf("�п�J�n�d�䪺�Ʀr: ");
	scanf("%lf", &target);

	int pos = binary_search(numbers, count, target);
	if (pos != -1) {
		printf("�Ʀr %.6lf �X�{�b�Ƨǫ᪺�� %d �Ӧ�m (���ޱq0�}�l)\n", target, pos);
	}
	else {
		printf("�Ʀr %.6lf ���b��Ƥ�\n", target);
	}

	return 0;
}