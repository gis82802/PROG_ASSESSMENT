#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n = 8;
    int score[8][8] = {
        {522,703,366,131,167,938,935,553},
        { 35,842, 39,346,169, 82, 37,702},
        {139,942,649, 77,835, 81,813,537},
        {618,246,208,599, 44,662,655,365},
        {703,983,680,333,462,365,652, 31},
        { 46,978,832,702,812,850,641,176},
        {848,266,281,849,715, 38,370, 81},
        {160,865,262,849,570,647,553,902}
    };

    vector<int> job(n);
    for (int i = 0; i < n; i++) job[i] = i;

    int bestSum = -1;
    vector<int> bestAssign;

    do {
        int total = 0;
        for (int i = 0; i < n; i++) {
            total += score[i][job[i]];
        }
        if (total > bestSum) {
            bestSum = total;
            bestAssign = job;
        }
    } while (next_permutation(job.begin(), job.end()));

    cout << "�̤j�`�o��: " << bestSum << endl;
    cout << "�̨Τ��t: " << endl;
    for (int i = 0; i < n; i++) {
        cout << "�H " << i << " �� �u�@ " << char('A' + bestAssign[i]) << endl;
    }

    return 0;
}
