#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

// Selection Sort ���
void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // �洫
        double temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}

int main() {
    ifstream inFile("double_data(1).txt");   // Ū�J�ɮ�
    if (!inFile) {
        cout << "�L�k�}���ɮ�!" << endl;
        return 1;
    }

    vector<double> numbers;
    double num;

    // Ū���Ҧ��Ʀr��}�C
    while (inFile >> num) {
        numbers.push_back(num);
    }
    inFile.close();

    // �Ƨ�
    selectionSort(numbers);

    // �N�Ƨǫ᪺���G�s��
    ofstream outFile("sorted_data.txt");
    for (double n : numbers) {
        outFile << n << endl;
    }
    outFile.close();

    cout << "�Ƨǧ����A���G�w�s�� sorted_data.txt" << endl;

    return 0;
}
