﻿#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>  // 用於排序
#include <iomanip>    // 用於設置顯示小數位數
using namespace std;

// 二元搜尋
int BinarySearch(const vector<double>& a, const double x)
{
    int L = 0, R = a.size() - 1;
    while (L <= R)
    {
        int M = (L + R) / 2;
        if (x < a[M]) R = M - 1;
        else if (x > a[M]) L = M + 1;
        else return M;
    }
    return -1;
}

int main()
{
    vector<double> arr;  // 改為儲存浮點數
    double x;
    ifstream infile("sorted.txt"); // 假設資料存在 data.txt 檔案中

    // 檢查檔案是否成功打開
    if (!infile.is_open()) {
        cout << "無法打開檔案!" << endl;
        return 1;
    }

    string line;
    // 讀取檔案中的每一行資料
    while (getline(infile, line)) {
        stringstream ss(line);
        double temp;
        // 逐個讀取浮點數並放入 vector
        while (ss >> temp) {
            arr.push_back(temp);
        }
    }
    infile.close();

    // 顯示讀入的資料
    cout << "資料已讀入，總共有 " << arr.size() << " 筆資料。" << endl;

    // 排序資料
    sort(arr.begin(), arr.end());  // 排序浮點數

    // 顯示排序後的資料
    cout << "排序後的資料: ";
    for (int i = 0; i < arr.size(); ++i) {
        cout << fixed << setprecision(3) << arr[i] << " ";  // 設置顯示小數點後三位
    }
    cout << endl;

    // 輸入要搜尋的數字
    cout << "請輸入要搜尋的數字: ";
    cin >> x;

    // 二分搜尋
    int index = BinarySearch(arr, x);
    if (index != -1)
        cout << "數字 " << fixed << setprecision(3) << x << " 出現在索引 " << index << endl;
    else
        cout << "找不到數字 " << fixed << setprecision(3) << x << endl;

    return 0;
}