#include<iostream>
#include<algorithm>//用來做排序
#include<fstream>//用來做檔案讀取
#include<limits>//用來取得資料型態的最大值與最小值
using namespace std;
int binarySearch(double* databank, double target, int size)//回傳目標值所在的index，找不到回傳0
{
    int left =0;
    int right = size -1;
    while(left <=right)
    {
        int min = (left + right)/2;
        if(databank[min] == target)//找到了
            return min;
        else if(databank[min] < target)//目標值在右半邊
            left = min + 1;
        else
            right = min -1;
    }
    return 0;
}
void savadata(double* &databank,double newdata,int &dataspace,int &datacount)//儲存資料用
{
    if(dataspace<=datacount)
    {
        int newspace = dataspace*2;
        double* newbank = new double[newspace];
        for(int i=0;i<datacount;i++)
        {
            newbank[i] = databank[i];
        }
        delete[] databank;
        databank = newbank;
        dataspace = newspace;
    }
    databank[datacount] = newdata;
    datacount++;
}
int main()
{
    double* databank = new double[10];
    int dataspace=10;
    int datacount =0;
    double newdata;
    fstream inFile("output.txt");
    if(!inFile)
    {
        cout<<"Error opening file!"<<endl;
        delete[] databank;//釋放記憶體
        return 0;
    }
    while(inFile>>newdata)
    {
        savadata(databank,newdata,dataspace,datacount);
    }
    inFile.close();
    double target;
    cout<<"Enter a number to search: ";
    cin>>target;
    cout<<"The number is at index: "<<binarySearch(databank,target,datacount)+1<<endl;
    delete[] databank;
    return 0;
}