#include<iostream>
#include<algorithm>//用來做排序
#include<vector>//用來做二維陣列
#include<string>
using namespace std;
int hungarian(const vector<vector<int>>& score)//回傳最大分數 這段是暴力解法
{
    int n = score.size();//假設是n*n的二維陣列
    vector<int> test(n);//用來存放排列組合
    for(int i=0;i<n;i++)//初始化
        test[i] = i;
    int maxScore = 0;
    vector<int> bestMatch;
    do{
        int currentScore = 0;//目前分數
        for(int i=0;i<n;i++)
        {
            currentScore+=score[i][test[i]];//計算分數
        }
        if(currentScore>maxScore)
        {
            maxScore = currentScore;
            bestMatch = test;
        }
    } while (next_permutation(test.begin(),test.end()));//列出所有排列組合
    string row[] = {"甲","乙","丙","丁","戊","己","庚","辛"};
    char col[] = {'A','B','C','D','E','F','G','H'};
    cout<<"Max Score: "<<maxScore<<endl;
    cout<<"Best assignment: "<<endl;
    for(int i=0;i<n;i++)
        cout<<row[i]<<" ->. "<<col[bestMatch[i]]<<" "<<endl;
    return maxScore;
}
int main()
{
    vector<vector<int>> score = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,599,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };
    hungarian(score);
    return 0;
}