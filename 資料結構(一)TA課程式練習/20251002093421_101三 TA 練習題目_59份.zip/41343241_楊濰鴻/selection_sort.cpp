#include<iostream>
#include<algorithm>//用來做排序
#include<fstream>//用來做檔案讀取
#include<limits>//用來取得資料型態的最大值與最小值
using namespace std;
void savedata(double* &databank,double newdata,int &dataspace,int &datacount)//儲存資料用
{
    if(dataspace<=datacount)
    {
        int newspace = dataspace*2;
        double* newbank = new double[newspace];
        for(int i=0;i<datacount;i++)
        {
            newbank[i] = databank[i];
        }
        delete[] databank;
        databank = newbank;
        dataspace = newspace;
    }
    databank[datacount] = newdata;
    datacount++;

}
int main()
{
    double* databank  = new double[10];
    int dataspace=10;
    int datacount =0;
    ifstream inFile("/Users/yangy/文件/code file/C++/double_data(1).txt");
    if(!inFile)
    {
        cout<<"Error opening file!"<<endl;
        delete[] databank;//釋放記憶體
        return 1;
    }
    double newdata;//接收資料用
    while(inFile >> newdata)
    {
        savedata(databank,newdata,dataspace,datacount);
    }
    inFile.close();
    for(int i=0;i<datacount;i++)    //selection sort
    {
        int minIndex = i; //假設目前最小值的index是i
        for(int j=i+1;j<datacount;j++)//從i+1開始找
        {
            if(databank[j]<databank[minIndex])//找到更小的值
                minIndex = j;
        }
        swap(databank[i],databank[minIndex]);//交換
    }
    ofstream outfile("output.txt");//輸出檔案
    if(!outfile)
    {
        cout<<"Error creating file!"<<endl;
        return 0;
    }
    for(int i=0;i<datacount;i++)
    {
        outfile<<databank[i]<<endl;//每筆資料一行
    }
    outfile.close();
    return 0;
}