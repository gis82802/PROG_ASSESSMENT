	#include<iostream>
	#include<fstream>
	
	using namespace std;
	
	void saveData(double *&dataBank,double newData,int& dataCount,int*dataBankSize){
		if(dataCount>=*dataBankSize){
			double *newDataBank = new double[*dataBankSize];
			for(int i = 0 ; i < *dataBankSize ;i++){
				newDataBank[i] = dataBank[i];
			}
			delete []dataBank;
			dataBank = new double[*dataBankSize*2];
			for(int i = 0 ; i < *dataBankSize ;i++){
				dataBank[i]=newDataBank[i];
			}
			*dataBankSize*=2 ;
		}
		dataBank[dataCount] =newData;
		dataCount++; 
	}
	int main(){
		double *dataBank = new double[10];
		double newData;
		int dataCount=0;
		int dataBankSize=10;
		
		ifstream inFile("C:\\Users\\user\\Downloads\\double_data.txt");
		if (!inFile){
			cout<<"�}���ɮץ���!"<<endl;
			return 1; 
		}
		while(inFile>>newData){
			saveData(dataBank,newData,dataCount,&dataBankSize);
		}
	
		for(int i = 0 ; i < dataCount ;i++){
			int min = i;
			for(int j = i+1;j<dataCount;j++){
				if(dataBank[j]<dataBank[min]) min = j;
			}
			swap(dataBank[i],dataBank[min]);
		}
		ofstream outFile("C:\\Users\\user\\Desktop\\result.txt", ios::out);
		if (!outFile) {
        cout << "�إ��ɮץ���!" << endl;
        return 1;
    }
		for(int i = 0 ; i < dataCount;i++){
			outFile << dataBank[i] << endl;
		}
		outFile.close();
		inFile.close();
		
	}
