	#include<iostream>
	#include<fstream>
	
	using namespace std;
	
	int binarySearch(double *dataBank , int left , int right , double target ){
			if(left>right){
				return -1;
			}
			int middle = (left+right)/2;
			if(dataBank[middle]==target){
				return middle; 
			}
			else if(dataBank[middle]>target){
				return binarySearch(dataBank,left,middle-1,target);
			}
			else 
				return binarySearch(dataBank,middle+1,right,target);
	}
	
	void saveData(double *&dataBank,double newData,int& dataCount,int*dataBankSize){
		if(dataCount>=*dataBankSize){
			double *newDataBank = new double[*dataBankSize];
			for(int i = 0 ; i < *dataBankSize ;i++){
				newDataBank[i] = dataBank[i];
			}
			delete []dataBank;
			dataBank = new double[*dataBankSize*2];
			for(int i = 0 ; i < *dataBankSize ;i++){
				dataBank[i]=newDataBank[i];
			}
			*dataBankSize*=2 ;
		}
		dataBank[dataCount] =newData;
		dataCount++; 
	}
	int main(){
		double *dataBank = new double[10];
		double newData;
		int dataCount=0;
		int dataBankSize=10;
		
		ifstream file("C:\\Users\\user\\Desktop\\result.txt");
		if (!file){
			cout<<"�}���ɮץ���!"<<endl;
			return 1; 
		}
		while(file>>newData){
			saveData(dataBank,newData,dataCount,&dataBankSize);
		}
		cout<<"�п�J�A�n�䪺��";
		double target;
		cin >>target;
		cout<<"���F!��l�b:"<<binarySearch(dataBank,0,dataCount-1,target)<<endl;
		file.close();
	}
