#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


int binarySearch(const vector<double> &, double);

int main() {
    vector<double> numbers;
    ifstream input("C:\\Users\\user\\sorted_double.txt");
    double num;
    if (!(input.is_open())) return -1;
    while (input >> num) numbers.push_back(num);
    input.close();
    double target;
    cout << "enter a target: ";
    cin >> target;
    int pos = binarySearch(numbers, target);
    if (pos != -2) cout << "target " << target << " in " << pos << endl;
    else  cout << "not found. " << endl;
    return 0; 
}

int binarySearch(const vector<double> &sorted_nums, double target) {
    int left = 0;
    int right = sorted_nums.size() - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (sorted_nums[mid] == target) return mid;
        else if (sorted_nums[mid] < target) left = mid + 1;
        else right = mid - 1;
    }

    return -2;
} 