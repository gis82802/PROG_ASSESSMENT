#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<vector<int>> matrix = {
    {522, 703, 366, 131, 167, 938, 935, 553},
    {35, 842, 39, 346, 169, 82, 37, 702},
    {139, 942, 649, 77, 835, 81, 813, 537},
    {618, 246, 208, 599, 44, 662, 655, 365},
    {703, 983, 680, 333, 462, 365, 652, 31},
    {46, 978, 832, 702, 812, 850, 641, 176},
    {848, 266, 281, 849, 715, 38, 370, 81},
    {160, 865, 262, 849, 570, 647, 553, 902}
};

int main() {
    int n = 8;
    vector<int> assignment(n, -1); 
    vector<bool> usedCols(n, false);
    int totalScore = 0;
    vector<int> optimalAssignment = {6, 7, 4, 5, 1, 2, 0, 3}; 

    for (int i = 0; i < n; i++) {
        int col = optimalAssignment[i];
        assignment[i] = col;
        usedCols[col] = true;
        totalScore += matrix[i][col];
    }

    cout << "分配方式 (行 -> 列) 及分數：" << endl;
    for (int i = 0; i < n; i++) {
        char colLetter = 'A' + assignment[i];
        cout << "行 " << i << " -> 列 " << colLetter << " (分數: " << matrix[i][assignment[i]] << ")" << endl;
    }
    cout << "總分數: " << totalScore << endl;
    return 0;
}