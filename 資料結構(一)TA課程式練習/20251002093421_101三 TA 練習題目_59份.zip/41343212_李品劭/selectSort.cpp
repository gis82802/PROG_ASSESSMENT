#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void selectSort(vector<double> &);

int main() {
    vector<double> numbers;
    ifstream input("C:\\Users\\user\\double.txt");
    double num;
    if (!(input.is_open())) return -1;
    while (input >> num) numbers.push_back(num);
    input.close();
    selectSort(numbers);
    ofstream output("C:\\Users\\user\\sorted_double.txt");
    for (double elm : numbers) output << elm << endl;
    output.close();
    return 0; 
}

void selectSort(vector<double> &nums) {
    for (int i = 0; i < nums.size() - 1; ++i) {
        int min = i;
        for (int j = i + 1; j < nums.size(); ++j) {
            if (nums[j] < nums[min]) min = j;
        } 
        swap(nums[i], nums[min]);
    }
}