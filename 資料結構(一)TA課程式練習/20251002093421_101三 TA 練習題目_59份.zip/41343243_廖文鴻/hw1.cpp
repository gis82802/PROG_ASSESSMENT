#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
#include <algorithm>
#include <cmath>
using namespace std;
int main() {
    const std::string filename = R"(C:\Users\user\Downloads\double_data(1).txt)";
    std::ifstream input_file(filename);
    if (!input_file) {
        std::cerr << "Failed to open: " << filename << "\n";
        return 1;
    }

    long double x[10000];
    int count = 0;
    std::string line;

    // Ū��
    while (count < 10000 && std::getline(input_file, line)) {
        if (line.find_first_not_of(" \t\r\n") == std::string::npos) continue;
        try {
            x[count++] = std::stold(line);
        }
        catch (...) {
            std::cerr << "Skip: " << line << "\n";
        }
    }

    if (count == 0) { cout << "no data\n"; return 0; }


    sort(x, x + count);
    for (int counter = 0; counter <= 9999; counter++) {
        cout << x[counter] << setprecision(20)<<endl;

    }

}