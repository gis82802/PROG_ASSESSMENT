#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
#include <algorithm>
#include <cmath>

int main() {
    const std::string filename = R"(C:\Users\user\Downloads\double_data(1).txt)";
    std::ifstream input_file(filename);
    if (!input_file) {
        std::cerr << "Failed to open: " << filename << "\n";
        return 1;
    }

    long double x[10000];
    int count = 0;
    std::string line;

    // Ū��
    while (count < 10000 && std::getline(input_file, line)) {
        if (line.find_first_not_of(" \t\r\n") == std::string::npos) continue;
        try {
            x[count++] = std::stold(line);
        }
        catch (...) {
            std::cerr << "Skip: " << line << "\n";
        }
    }

    if (count == 0) { std::cout << "no data\n"; return 0; }

    
    std::sort(x, x + count);

   
    long double y;
    std::cout << "Enter value to search: ";
    std::cin >> y;

  
    const long double eps = 1e-12L; // ����Ƥث׽վ�
    int left = 0, right = count - 1;
    int found_idx = -1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (std::fabsl(x[mid] - y) <= eps) { // �����۵�
            found_idx = mid;
            break;
        }
        else if (x[mid] < y - eps) {      
            left = mid + 1;
        }
        else {                              
            right = mid - 1;
        }
    }

    //std::cout << std::fixed << std::setprecision(20);
  
        std::cout << "Found ~== at index " << found_idx
             << "\n";
    
    
    return 0;
}
