#include <iostream>
#include <algorithm>
#include <limits>
using namespace std;
void pm(int a[8][8], int k, const int m, int& max_sum, int maxlog[8]);
int main()
{
    int n[8][8] = {
        {522, 703, 366, 131, 167, 938, 935, 533},
        {35, 842, 39, 346, 169, 82, 37, 702},
        {139, 942, 649, 77, 835, 81, 813, 537},
        {618, 246, 208, 599, 44, 662, 655, 365},
        {703, 983, 680, 333, 462, 365, 652, 31},
        {46, 978, 832, 702, 812, 850, 641, 176},
        {848, 266, 281, 849, 715, 38, 370, 81},
        {160, 865, 262, 849, 570, 647, 553, 902} };

    int max_sum = 0;
    int maxlog[8] = { 0 };
    string c1[8] = { "��","�A","��" ,"�B" ,"��" ,"�v" ,"��" ,"��" };
    char c2[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    int c1log[8] = { 0 };
    bool check = false;
    pm(n, 0, 8, max_sum, maxlog);
    cout << "Max Sum: " << max_sum << endl;
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++) 
        {
            check = false;
            if (n[j][i] == maxlog[i])
            {
                for (int k = 0; k < 8; k++) {
            
                    if (c1log[k] != j) {
                        check = true;
                    }
                    else
                        break;
                }
                if (check==true) {
                    cout << c2[i] << "," << c1[j] << ":";
                    c1log[i] = j;
                }
            }
        }
        cout << maxlog[i] << endl;
    }
    return 0;
}

void pm(int a[8][8], int k, const int m, int& max_sum, int maxlog[8])
{
    if (k == m)
    {
        int current_sum = 0;
        for (int i = 0; i < m; i++)
        {
            current_sum += a[i][i];
        }
        if (current_sum > max_sum)
        {
            max_sum = current_sum;
            for (int i = 0; i < m; i++)
                maxlog[i] = a[i][i];
        }
    }
    else
    {
        for (int i = k; i < m; i++)
        {
            for (int j = 0; j < 8; j++)
                swap(a[k][j], a[i][j]);
            pm(a, k + 1, m, max_sum, maxlog);
            for (int j = 0; j < 8; j++)
                swap(a[k][j], a[i][j]);
        }
    }
}
