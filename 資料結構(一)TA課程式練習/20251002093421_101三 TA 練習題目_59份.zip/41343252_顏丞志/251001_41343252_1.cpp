#include <iostream>
#include <fstream>
using namespace std;
void saveData(double *&dataBank, double newData, int &dataCount, int *dataBankSize);
int main()
{
    int dataBankSize = 10;
    double *dataBank = new double[dataBankSize]; // ��l�ʺA�t�m�Ŷ��j�p�� 10
    double newData;                              // �x�s�ɮ׷sŪ�J���Ʀr
    int dataCount = 0;                           // �ثe�x�s���Ʀr�ƶq
    double temp;
    ifstream inputdata("./double_data.txt");
    ofstream outputdata("./output.txt");
    if (!inputdata)
    {
        cout << "�ɮ׵L�k�}��\n";
        return 1;
    }
    while (inputdata >> newData)
    {
        saveData(dataBank, newData, dataCount, &dataBankSize);
    }
    for (int i = 0; i < dataCount; i++) // �w�j�ƧǪk
    {
        for (int j = i + 1; j < dataCount; j++)
        {
            temp = dataBank[j];     // Ū����i+n���Ʀr
            if (dataBank[i] > temp) // �p�Gi+n���Ʀr�p��i���Ʀr�A�h�N�o��ӥ洫
            {
                dataBank[j] = dataBank[i];
                dataBank[i] = temp;
            }
        }
        cout << dataBank[i] << endl;       // �̲׿�X���G���Ѥp��j
        outputdata << dataBank[i] << endl; // ��X��outputdata.txt�ɮ��ح�
    }
}
void saveData(double *&dataBank, double newData, int &dataCount, int *dataBankSize)
{
    if (*dataBankSize == dataCount)
    {
        double *temp = new double[*dataBankSize];
        for (int i = 0; i < dataCount; i++)
        {
            *(temp + i) = *(dataBank + i);
        }
        dataBank = new double[(*dataBankSize) * 2];
        for (int i = 0; i < dataCount; i++)
        {
            *(dataBank + i) = *(temp + i);
        }
        *dataBankSize *= 2;
        cout << "��}�j�p�w�X�R��" << *dataBankSize << endl;
    }
    *(dataBank + dataCount) = newData;
    dataCount += 1;
}