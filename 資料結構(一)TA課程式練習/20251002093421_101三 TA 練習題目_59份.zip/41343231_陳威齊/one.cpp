#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;


void selecionSort(vector<long double> &arr ) {
	int n = arr.size();
	for (int i = 0; i < n - 1; ++i) {
		int min = i;
		for (int j = i + 1; j < n; ++j) {
			if (arr[j] < arr[min]) {
				min = j;
			}
		}

		swap(arr[min] , arr[i]);

	}
}



int main() {
	ifstream input("double_data.txt");
	
	if (!input.is_open()) {
		cerr << "file cant open !" << endl;
		return 1;
	}

	vector<long double> number;
	long double num;

	while (input >> num) {
		number.push_back(num);
	}

	input.close();

	selecionSort(number);
	ofstream output("C:\\Users\\user\\source\\repos\\chr\\double_data.txt");

	cout << "�Ƨǫ�G" << endl;
	for (int i = 0; i < number.size(); ++i) {
		output << number[i] << " " << endl;
	}
	output.close();
	cout << endl;
	return 0;
}