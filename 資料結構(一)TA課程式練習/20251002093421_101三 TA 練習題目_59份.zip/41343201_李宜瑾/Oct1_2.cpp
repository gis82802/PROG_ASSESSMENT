#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

int binarySearch(const vector<double>& arr, double target) {
    int low = 0;
    int high = arr.size() - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (arr[mid] == target) {
            return mid;
        }
        else if (arr[mid] < target) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }
    return -1;
}

int main() {
    vector<double> sorted_data;
    double num;
    double target_number;
    const char* filename = "sorted_double.txt";

    ifstream fin(filename);

    if (!fin.is_open()) {
        cerr << "���~�G�L�k�}���ɮ� " << filename << "�C���ˬd�ɮ׸��|�C" << endl;
        return 1;
    }

    while (fin >> num) {
        sorted_data.push_back(num);
    }
    fin.close();

    if (sorted_data.empty()) {
        cout << "�ɮפ��S���i�ѷj�M���Ʀr�C" << endl;
        return 0;
    }

    cout << "�п�J�n�j�M���Ʀr: ";
    if (!(cin >> target_number)) {
        cerr << "��J���~�C�{�������C" << endl;
        return 1;
    }

    int index = binarySearch(sorted_data, target_number);

    if (index != -1) {
        cout << "�Ʀr " << target_number
            << " ���F�A�b���ަ�m: " << index << endl;
    }
    else {
        cout << "�Ʀr " << target_number << " �S�����C" << endl;
    }

    return 0;
}