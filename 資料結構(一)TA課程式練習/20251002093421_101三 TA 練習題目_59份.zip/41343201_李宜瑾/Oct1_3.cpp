#include <iostream>
#include <vector>
using namespace std;

int n = 8; // 8x8 �x�}
int bestScore = 0;
vector<int> bestMatch;

void dfs(vector<vector<int>>& matrix, int row, vector<bool>& used, int currentSum, vector<int>& currentMatch) {
    if (row == n) { // �C�ӤH�����t�n�F
        if (currentSum > bestScore) {
            bestScore = currentSum;
            bestMatch = currentMatch;
        }
        return;
    }

    for (int col = 0; col < n; col++) {
        if (!used[col]) { // �p�G�o�ӿﶵ�٨S�Q�ιL
            used[col] = true; // �аO�w��
            currentMatch[row] = col; // �O���o�ӤH��F���Ӥ��
            dfs(matrix, row + 1, used, currentSum + matrix[row][col], currentMatch);
            used[col] = false; // �^���A��o�ӿﶵ����X��
        }
    }
}

int main() {
    vector<vector<int>> matrix = {
        {522, 703, 366, 131, 167, 738, 935, 553},
        {35, 842, 39, 346, 169, 82, 37, 702},
        {139, 942, 649, 77, 835, 81, 813, 537},
        {618, 246,208, 599, 44, 662, 655, 365},
        {703, 983, 680, 333, 462, 365, 652, 31},
        {46, 978, 832, 702, 812, 850, 641, 176},
        {848, 266, 281, 849, 715, 38, 370, 81},
        {160, 865, 262, 849, 570, 647, 553, 902}
    };

    vector<bool> used(n, false); // ���ǿﶵ�w�g�Q��
    vector<int> currentMatch(n, -1); // �O���C�ӤH�t�諸�ﶵ

    dfs(matrix, 0, used, 0, currentMatch);

    cout << "�̨��`��: " << bestScore << endl;
    cout << "�̨ΰt��覡:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "��" << i + 1 << "�ӤH -> �� " << char('A' + bestMatch[i])
            << " (�o�� " << matrix[i][bestMatch[i]] << ")" << endl;
    }

    return 0;
}
