#include <iostream>
#include <vector>
#include <fstream>



using namespace std;


void selectionSort(vector<double>& arr) {
    size_t n = arr.size();
    for (size_t i = 0; i < n - 1; ++i) {
        size_t min_idx = i;
        for (size_t j = i + 1; j < n; ++j) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        swap(arr[i], arr[min_idx]);
    }
}

int main() {
    vector<double> numbers;
    double num;
    const char* input_filename = "double.txt";
    const char* output_filename = "sorted_double.txt";

    // Ū���ɮ�
    ifstream inputFile(input_filename);

    if (!inputFile.is_open()) {
        cerr << "���~�G�L�k�}�ҿ�J�ɮ� " << input_filename << endl;
        return 1;
    }

    while (inputFile >> num) {
        numbers.push_back(num);
    }
    inputFile.close();

    ofstream fout("sorted_double.txt");
    for (double x : numbers) {
        fout << x << " ";
    }
    fout.close();

    // �ˬd vector �O���O�Ū�
    if (numbers.empty()) {
        cout << "�ɮפ��S���iŪ�����Ʀr�C�{�������C" << endl;
        return 0;
    }

    // �Ƨ�
    selectionSort(numbers);
    cout << "Selection Sort �Ƨǧ����C" << endl;

    // �g�J�ɮ�
    ofstream outputFile(output_filename);

    if (!outputFile.is_open()) {
        cerr << "���~�G�L�k�}�ҿ�X�ɮ� " << output_filename << endl;
        return 1;
    }

    for (const double& sorted_num : numbers) {
        outputFile << sorted_num << "\n";
    }

    outputFile.close();
    cout << "�Ƨǵ��G���\�x�s���ɮ� " << output_filename << endl;

    return 0;
}