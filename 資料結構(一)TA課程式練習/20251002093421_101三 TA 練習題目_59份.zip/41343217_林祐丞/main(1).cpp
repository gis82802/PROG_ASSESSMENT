#include <bits/stdc++.h> 
using namespace std;

void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; ++i) {
        int min_idx = i;      
        for (int j = i + 1; j < n; ++j) {
            if (arr[j] < arr[min_idx])  min_idx = j;
        }  
        swap(arr[i], arr[min_idx]);
        
    }
}
int main() {
    ifstream input("C:\\Frijava114\\lxj\\double_data(1).txt");
    vector<double> data;
    double val;
    while (input >> val) {
        data.push_back(val);
    }
    input.close();
    selectionSort(data);
    ofstream output("C:\\Frijava114\\lxj\\double_data(1).txt");
    output << fixed << setprecision(17); 
    for (int i = 0; i < data.size(); ++i) {
        output << data[i] << endl;
    }
    output.close();
    return 0;
}
