#include <bits/stdc++.h>
using namespace std;
const int N = 8;  
const int S[N][N] = {
    {522, 703, 366, 131, 167, 938, 935, 553},
    {35, 842, 39, 346, 169, 82, 37, 702},
    {139, 942, 649, 77, 835, 81, 813, 537},
    {618, 246, 208, 599, 44, 662, 655, 365},
    {703, 983, 680, 333, 462, 365, 652, 31},
    {46, 978, 832, 702, 812, 850, 641, 176},
    {848, 266, 281, 849, 715, 38, 370, 81},
    {160, 865, 262, 849, 570, 647, 553, 982}
};
const char R[N] = {'��', '�A', '��', '�B', '��', '�v', '��', '��'};
const char C[N] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
long long max_s = 0;
vector<int> best_p(N);
// * p: ���e���b�ͦ�������ޱƦC
 //* k: ���e���b�T�w���C���� (�� k�ӤH)
void recursive_search(vector<int>& p, int k) {
    if (k == N) {
        long long current_s = 0;
        
        for (int i = 0; i < N; ++i) {
            current_s += S[i][p[i]];
        }

        if (current_s > max_s) {
            max_s = current_s;
            best_p = p;
        }
        return;
    } 

    for (int i = k; i < N; ++i) {
        swap(p[k], p[i]);
        recursive_search(p, k + 1);
        swap(p[k], p[i]);
    }
}
void find_best_assignment() {
    vector<int> p(N);
    for (int i = 0; i < N; ++i) {
        p[i] = i; 
    }
    recursive_search(p, 0);
    for (int i = 0; i < N; ++i) {
        int j = best_p[i];
        
        cout << R[i] << "�t�� " << C[j] 
             << " (���ơG " << S[i][j] << ")" << endl;
    }
	cout<<endl;
    cout << "�̰��`��: " << max_s << endl;
}

int main() {
    find_best_assignment();
    return 0;
}
