#include <bits/stdc++.h> 
using namespace std;

int binarySearch(const vector<long double>& a, const long double x) {
    int left = 0;
    int right = a.size() - 1; 
    
    while (left <= right) {
        int middle = left + (right - left) / 2;
        
        if (x == a[middle]) {
            return middle;
        } else if (x < a[middle]) {
            right = middle - 1;
        } else {
            left = middle + 1;
        }
    }
    return -1;
}

void processSearch() {
    const char* file_path = "C:\\Frijava114\\lxj\\double_data(1).txt";
    ifstream input(file_path);
    
    if (!input.is_open()) {
        cerr << "���~: �L�k�}���ɮ� [" << file_path << "]" << endl;
        return;
    }

    vector<long double> a;
    long double value;

    while (input >> value) {
        a.push_back(value);
    }
    input.close();
    
    sort(a.begin(), a.end());
    
    if (a.empty()) {
        cout << "�ɮפ��S�������ơC" << endl;
        return;
    }
    
    long double target;
    cout << "�п�J�z�n�j�M���ؼЭ� (target): ";
    
    if (cin.fail() || !(cin >> target)) {
        cerr << "��J���~�A�п�J�@�Ӧ��Ī��Ʀr�C" << endl;
        return;
    }
    
    int idx = binarySearch(a, target);
    
    cout << fixed << setprecision(17);
    
    if (idx != -1) {
        cout << "���ؼЭ� [" << target << "]�A�����Ƨǫ᪺�}�C���� a[" << idx << "]" << endl;
    } else {
        cout << "�ؼЭ� [" << target << "] not found" << endl;
    }
}

int main() {
    processSearch();
    return 0;
}

