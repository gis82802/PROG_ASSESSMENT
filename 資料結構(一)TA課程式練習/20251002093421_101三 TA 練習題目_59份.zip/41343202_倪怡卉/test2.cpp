/*#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

int binarySearch(const vector<double>& arr, double target) {
	int left = 0;
	int right = arr.size() - 1;

	while (left<=right)
	{
		int mid = left + (right - left) / 2;

		if (arr[mid] == target) {
			return mid;
		}
		else if(arr[mid]<target)
		{
			left = mid + 1;
		}
		else
		{
			right = mid - 1;
		}
	}
	return -1;
}
int main() {
	vector<double> sorted_numbers;

	ifstream inputFile("sorted_double_data.txt");
	if (!inputFile.is_open()) {
		cerr << "�L�k���}���!" << endl;
		return 1;
	}
	double num;
	while (inputFile >> num)
	{
		sorted_numbers.push_back(num);
	}
	inputFile.close();
	cout << "�w���J" << sorted_numbers.size() << "�ӱƧǼƦr" << endl;

	while (true)
	{
		cout << "�n�j�M���Ʀr:" << endl;
		string input;
		cin >> input;

		try {
			double target = stod(input);
			int position = binarySearch(sorted_numbers, target);

			if (position != -1) {
				cout << "����m!" << position << endl;
			}
			else
			{
				cout << "�䤣��" << endl;
			}

		}
		catch (...) {
			cout << "�п�J���ļƦr" << endl;
		}
	}

	return 0;
}*/