#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

pair<int, vector<int>> hungar_max(const vector<vector<int>>& profit) {
	int n = profit.size();

	int max_val = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (profit[i][j] > max_val) {
				max_val = profit[i][j];
			}
		}
	}

	vector<vector<int>> cost(n, vector<int>(n));
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cost[i][j] = max_val - profit[i][j];
		}
	}

	vector<int> u(n + 1, 0), v(n + 1, 0), p(n + 1, 0), way(n + 1, 0);

	for (int i = 1; i <= n; i++) {
		p[0] = i;
		int j0 = 0;
		vector<int> minv(n + 1, INT_MAX);
		vector<bool> used(n + 1, false);

		int j1 = 0;

		do {
			used[j0] = true;
			int i0 = p[j0];
			int delta = INT_MAX;

			for (int j = 1; j <= n; j++) {
				if (!used[j]) {
					int cur = cost[i0 - 1][j - 1] - u[i0] - v[j];
					if (cur < minv[j]) {
						minv[j] = cur;
						way[j] = j0;
					}
					if (minv[j] < delta) {
						delta = minv[j];
						j1 = j;
					}
				}
			}

			for (int j = 0; j <= n; j++) {
				if (used[j]) {
					u[p[j]] += delta;
					v[j] -= delta;
				}
				else
				{
					minv[j] -= delta;
				}
			}

			j0 =j1;
		} while (p[j0] != 0);

		do {
			int j1 = way[j0];
			p[j0] = p[j1];
			j0 = j1;
		} while (j0);
	}
	vector<int> assignmant(n);
	for (int j = 1; j <= n; j++) {
		assignmant[p[j] - 1] = j - 1;
	}
	int max_total = n * max_val + v[0];
	return make_pair(max_total, assignmant);
}

int main() {
	vector<vector<int>>scores = {
		{522,35,139,618,703,46,848,160},
		{703,842,942,246,983,978,266,865},
		{366,39,649,208,680,832,281,262},
		{131,346,77,599,333,702,849,849},
		{167,69,835,44,462,812,715,570},
		{938,82,81,662,365,850,38,647},
		{935,37,813,655,652,641,370,553},
		{553,702,537,365,31,176,81,902}
	};
	vector<string> english_labels = { "A","B","C","D","E","F","G","H" };
	vector<string> chinese_labels = { "��","�A","��","�B","��","�v","��","��" };

	auto result = hungar_max(scores);
	int max_total = result.first;
	vector<int> assignment = result.second;

	cout << "�̤j�Ȥι�����m:" << endl;
	cout << "==========================" << endl;

	int total_score = 0;
	for (int i = 0; i < assignment.size(); i++) {
		int j = assignment[i];
		int score = scores[i][j];
		cout << english_labels[i] << "�ƹ���" << chinese_labels[j] << ":����" << score << endl;
		total_score += score;
	}
	
	cout << "===================================" << endl;
	cout << "�`��:" << total_score << endl;

	return 0;

}