/*#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;
void selectionSort(vector<double>& arr) {
	int n = arr.size();
	for (int i = 0; i < n - 1; i++) {
		int minindex = i;
		for (int j = i + 1; j < n; j++) {
			if (arr[j] < arr[minindex]) {
				minindex = j;
			}
		}

		if (minindex != i) {
			swap(arr[i], arr[minindex]);
		}
	}
}
int main() {
	vector<double> numbers;

	ifstream inputFile("double_data(1).txt");
	if (!inputFile.is_open()) {
		cerr << "�L�k���}���!" << endl;
		return 1;
	}
	double num;
	while (inputFile >> num)
	{
		numbers.push_back(num);
	}
	inputFile.close();
	cout << "Ū���F" << numbers.size() << "�ӼƦr" << endl;

	selectionSort(numbers);

	ofstream outputFile("sorted_double_data.txt");
	if (!outputFile.is_open()) {
		cerr << "�L�k�Ыؤ��" << endl;
		return 1;
	}

	outputFile.precision(15);
	for (const double& value : numbers) {
		outputFile << value << endl;
	}
	outputFile.close();

	cout << "�Ƨǧ���!" << endl;
	return 0;
}*/