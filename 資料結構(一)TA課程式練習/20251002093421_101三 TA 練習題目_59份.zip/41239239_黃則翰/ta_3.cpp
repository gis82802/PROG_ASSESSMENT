#include <iostream>
#include <vector>
using namespace std;

int scores[8][8] = {
    {522, 703, 366, 131, 167, 938, 935, 553},
    {35, 842, 39, 346, 169, 82, 37, 702},
    {139, 942, 649, 77, 835, 81, 813, 537},
    {618, 246, 208, 599, 44, 662, 655, 365},
    {703, 983, 680, 333, 462, 365, 652, 31},
    {46, 978, 832, 702, 812, 850, 641, 176},
    {848, 266, 281, 849, 715, 38, 370, 81},
    {160, 865, 262, 849, 570, 647, 553, 902}
};

int maxTotal = 0;
int best[8];  // 每列選到哪個行
int current[8];
bool used[8] = {false};

void backtrack(int row, int total) {
    if(row == 8) {
        if(total > maxTotal) {
            maxTotal = total;
            for(int i = 0; i < 8; i++) best[i] = current[i];
        }
        return;
    }

    for(int col = 0; col < 8; col++) {
        if(!used[col]) {
            used[col] = true;
            current[row] = col;
            backtrack(row + 1, total + scores[row][col]);
            used[col] = false;
        }
    }
}

int main() {
    backtrack(0, 0);

    cout << "Max total score: " << maxTotal << endl;
    cout << "\nRow -> Column pairing:" << endl;
    for(int i = 0; i < 8; i++){
        cout << "Row " << i+1 << " -> Column " << best[i]+1 << endl;
    }

    // 顯示每個 Column 被哪些 Row 選到
    vector<vector<int>> colUsed(8);
    for(int i = 0; i < 8; i++){
        colUsed[best[i]].push_back(i+1); // i+1 表示列號
    }

    cout << "\nColumn usage (which rows chose this column):" << endl;
    for(int col = 0; col < 8; col++){
        cout << "Column " << col+1 << " used by rows: ";
        if(colUsed[col].empty()) cout << "none";
        else {
            for(int r : colUsed[col]) cout << r << " ";
        }
        cout << endl;
    }

    return 0;
}
