#include <iostream>
#include <fstream>
using namespace std;

int binarysearch(double arr[], int n, double target){
    int l = 0 , r = n-1;
    while (l <= r){
        int m = (l + r) /2;

        if (arr[m] == target)
            return m;

        if (arr[m] < target)
            l = m + 1;

        if (arr[m] > target)
            r = m - 1;
    }
    return -1;
}
int main() {
    ifstream inff("new_data.txt");  // 讀檔
    if (!inff.is_open()) {
        cout << "檔案無法開啟!" << endl;
        return 0;
    }

    double numbers[10000];  // 假設最多 10000 個數字
    int n = 0;         

    double num;
    while (inff >> num) {   // 讀檔
        numbers[n] = num;
        n++;
    }
    inff.close();

    double target;
    cout <<"number : " ;
    cin >> target ;

    int idx = binarysearch(numbers ,n, target);
    if (idx != -1)
        cout << target << "in line" << idx + 1 << ""<< endl;
    else
        cout <<  target << " not found" << endl;

    return 0;

}

    