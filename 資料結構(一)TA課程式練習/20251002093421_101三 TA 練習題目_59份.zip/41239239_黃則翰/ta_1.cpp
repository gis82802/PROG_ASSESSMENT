#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream inff("double_data(1).txt");  // 讀檔
    if (!inff.is_open()) {
        cout << "檔案無法開啟!" << endl;
        return 0;
    }

    double numbers[10000];  // 假設最多 10000 個數字
    int n = 0;         

    double num;
    while (inff >> num) {   // 讀檔
        numbers[n] = num;
        n++;
    }
    inff.close();

    // Selection Sort
    for (int i = 0; i < n - 1; i++) {
        int min = i;
        for (int j = i + 1; j < n; j++) {
            if (numbers[j] < numbers[min])
                min = j;
        }
        double temp = numbers[i];
        numbers[i] = numbers[min];
        numbers[min] = temp;
    }

    // 寫檔
    ofstream outff("new_data.txt");
    if (!outff.is_open()) {
        cout << "無法寫入檔案!" << endl;
        return 0;
    }

    for (int i = 0; i < n; i++) {
        outff << numbers[i] << endl ;
    }
    outff.close();

    cout << "Sorting completed. Result saved in new_data.txt" << endl;
    return 0;
}
