#include<iostream>
#include<vector>
#include<fstream>
using namespace std;

int bs(const vector<double>&arr,double target) {
	int left = 0, right = arr.size() - 1;
	while (left <= right) {
		int mid = (left + right) / 2;
		if (target < arr[mid])right = mid - 1;
		else if (target > arr[mid])left = mid + 1;
		else return mid;
	}
	return -1;
}

int main() {
	ifstream fin("sort.txt");
	vector<double>data;
	double num;

	while (fin >> num) {
		data.push_back(num);
	}
	fin.close();

	double target;
	cout << "��J�n�j�M���Ʀr" << endl;

	cin >> target;

	int pos = bs(data, target);
	if (pos != -1) cout << "�b" << pos << endl;

	else cout << "�Ʀr���s�b" << endl;
	return 0;
}