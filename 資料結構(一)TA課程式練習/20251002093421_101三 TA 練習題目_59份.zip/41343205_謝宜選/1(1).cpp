#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

void ss(vector<double>& arr) {
	int n = arr.size();
	for (int i = 0; i < n - 1; i++) {
		int min = i;
		for (int j = i + 1; j < n; j++) {
			if (arr[j] < arr[min]) {
				min = j;	
			}
		}
		swap(arr[i], arr[min]);
	}

}

int main() {
	ifstream fin("double_data(1).txt");
	vector<double>data;
	double num;

	while (fin >> num) {
		data.push_back(num);
	}
	fin.close();

	ss(data);

	ofstream fout("sort.txt");
	for (double x : data) {
		fout << x << endl;
	}
	fout.close();
	cout << "�Ƨǧ���" << endl;
	return 0;
}