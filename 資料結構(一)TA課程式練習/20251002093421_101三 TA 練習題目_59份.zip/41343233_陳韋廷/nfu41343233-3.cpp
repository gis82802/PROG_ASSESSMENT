#include <iostream>
#include <vector>
#include <algorithm>

// 使用全域變數來儲存陣列、最佳總和與指派結果，以便在遞迴函式中存取。
std::vector<std::vector<int>> arr = {
    {522, 35, 139, 68, 703, 46, 848, 160},
    {703, 842, 942, 246, 983, 978, 266, 865},
    {366, 39, 649, 208, 680, 832, 281, 262},
    {131, 346, 77, 599, 333, 702, 849, 849},
    {167, 169, 835, 44, 462, 812, 715, 570},
    {938, 82, 81, 662, 365, 850, 38, 647},
    {935, 37, 813, 655, 652, 641, 370, 553},
    {553, 702, 537, 365, 31, 176, 81, 902}
};

std::vector<int> best_assignment(8); // 儲存最佳的欄位指派
int max_sum = 0; // 儲存最大總和

// 遞迴函式，用於尋找最佳指派
void findMaxAssignment(int row, int current_sum, std::vector<int>& current_assignment, std::vector<bool>& used_cols) {
    // 遞迴結束條件：已為每一列都找到了不重複的欄位
    if (row == 8) {
        // 如果當前的總和比已找到的最大總和大，就更新結果
        if (current_sum > max_sum) {
            max_sum = current_sum;
            best_assignment = current_assignment;
        }
        return;
    }

    // 遍歷所有欄位，嘗試為當前列找到最佳指派
    for (int col = 0; col < 8; ++col) {
        // 如果該欄位還沒有被其他列使用過
        if (!used_cols[col]) {
            // 1. 進行選擇：將當前欄位標記為已使用
            used_cols[col] = true;
            current_assignment[row] = col;

            // 2. 遞迴呼叫：進入下一列的決策
            findMaxAssignment(row + 1, current_sum + arr[row][col], current_assignment, used_cols);

            // 3. 回溯：遞迴結束後，取消該欄位的標記，
            //    以便讓其他組合也能使用這個欄位
            used_cols[col] = false;
        }
    }
}

int main() {
    std::cout << "原始 8x8 陣列：" << std::endl;
    for (const auto& row_vec : arr) {
        for (int val : row_vec) {
            std::cout << val << "\t";
        }
        std::cout << std::endl;
    }

    std::vector<int> current_assignment(8);
    std::vector<bool> used_cols(8, false); // 用於追蹤已使用的欄位
    findMaxAssignment(0, 0, current_assignment, used_cols);

    std::cout << "\n----------------------------------------\n" << std::endl;
    std::cout << "最終結果 (每列選取一個不重複欄位的最大值)：" << std::endl;
    for (int i = 0; i < 8; ++i) {
        std::cout << "列 " << i << " 的數值為 " << arr[i][best_assignment[i]]
            << "，位於欄 " << best_assignment[i] << std::endl;
    }
    std::cout << "\n所有選定數值的總和為：" << max_sum << std::endl;

    return 0;
}