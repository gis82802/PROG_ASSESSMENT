#include<iostream>
#include<fstream>
#include<cstring>
#include<algorithm>
using namespace std;
void saveData(double*& dataBank, double newData, int& dataCount, int& dataBankSize) {
	if (dataBankSize > dataCount) {
		dataBank[dataCount] = newData;
		dataCount += 1;
	}
	else {
		double* indataBank = new double[dataBankSize];
		for (int i = 0; i < dataCount; i++) {
			indataBank[i] = dataBank[i];
		}
		dataBankSize *= 2;
		dataBank = new double[dataBankSize];
		for (int i = 0; i < dataCount; i++) {
			dataBank[i] = indataBank[i];
		}
		dataBank[dataCount] = newData;
		dataCount += 1;
		delete[] indataBank;
	}

}
void sort(double* dataBank, const int dataCount) {
	int b;
	for (int i = 0; i < dataCount; i++) {
		b = i;
		for (int j = b; j < dataCount; j++) {
			if (dataBank[j] < dataBank[b])b = j;
		}
		swap(dataBank[i], dataBank[b]);
	}
}
int bs(double* dataBank, const int dataCount,double T){
	int L, R, M=0;
	L = 0; R = dataCount - 1;
	while (L<=R) {
		M = (L + R) / 2;
		if (T == dataBank[M])return M;
		else if (T < dataBank[M])R = M - 1;
		else L = M + 1;
	}
	return -1;
}
int main() {
	int  dataBankSize = 10;
	double* dataBank = new double[dataBankSize];
	double newData,T=0;
	int dataCount = 0;
	ifstream in;
	in.open("C:\\Users\\user\\source\\repos\\nfu1001\\Project1\\out.txt");
	while (in >> newData) {
		saveData(dataBank, newData, dataCount, dataBankSize);
	}
	sort(dataBank, dataCount);
	for (int i = 0; i < dataCount; i++) {
		cout << dataBank[i] << endl;
	}
	cout << "輸入目標值:";
	cin >> T;
	cout<<"目標值所在位置:"<< bs(dataBank, dataCount, T)<<endl;
	delete[] dataBank;
	in.close();
	return 0;
}