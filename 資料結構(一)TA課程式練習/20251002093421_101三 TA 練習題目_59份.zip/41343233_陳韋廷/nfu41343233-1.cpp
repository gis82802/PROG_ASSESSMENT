#include<iostream>
#include<fstream>
#include<cstring>
#include<algorithm>
using namespace std;
void saveData(double*& dataBank, double newData, int& dataCount, int& dataBankSize) {
	if (dataBankSize > dataCount) {
		dataBank[dataCount] = newData;
		dataCount += 1;
	}
	else {
		double* indataBank = new double[dataBankSize];
		for (int i = 0; i < dataCount; i++) {
			indataBank[i] = dataBank[i];
		}
		dataBankSize *= 2;
		dataBank = new double[dataBankSize];
		for (int i = 0; i < dataCount; i++) {
			dataBank[i] = indataBank[i];
		}
		dataBank[dataCount] = newData;
		dataCount += 1;
		delete[] indataBank;
	}
	
}
void sort(double* dataBank, const int dataCount) {
	int b;
	for (int i = 0; i < dataCount; i++) {
		b = i;
		for (int j = b; j < dataCount; j++) {
			if (dataBank[j] < dataBank[b])b = j;
		}
		swap(dataBank[i], dataBank[b]);
	}
}
int main() {
	int  dataBankSize = 10;
	double* dataBank = new double[dataBankSize];
	double newData;
	int dataCount = 0;
	ifstream in;
	ofstream out("out.txt");
	in.open("double_data(1).txt");
	while (in >> newData) {
		saveData(dataBank, newData, dataCount, dataBankSize);
	}
	sort(dataBank, dataCount);
	for (int i = 0; i < dataCount; i++) {
		out << dataBank[i] << endl;
	}
	delete[] dataBank;
	in.close();
	return 0;
}