#include <iostream>
#include <fstream>
using namespace std;

 
int BinarySearch(double*& a, const double x, const int left, const int right)
{
    if (left <= right)
    {
        int middle = (left + right) / 2;
        if (x < a[middle])
            return BinarySearch(a, x, left, middle - 1);   
        else if (x > a[middle])
            return BinarySearch(a, x, middle + 1, right);   
        return middle;   
    }
    return -1;   
}

 
void SelectionSort(double* a, const int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        int j = i;
        for (int k = i + 1; k < n; k++)
        {
            if (a[k] < a[j])
                j = k;
        }

        if (i != j)
            swap(a[i], a[j]);
    }
}

 
void savadata(double*& databank, double newdata, int datacount, int* databanksize)
{
    if (datacount + 1 >= *databanksize)
    {
        *databanksize *= 2;   
        double* newdatabank = new double[*databanksize];
        for (int i = 0; i < datacount; i++)
        {
            newdatabank[i] = databank[i];   
        }
        delete[] databank;   
        databank = newdatabank;  
    }
    databank[datacount] = newdata;  
}

int main(void)
{
    int databanksize = 2;
    double* databank = new double[databanksize];
    double newdata;
    int datacount = 0;

    fstream in;
    in.open("sorted_data.txt");  
    if (in.fail()) {
        cout << "input file opening failed" << endl;
        exit(1);
    }

   
    while (in >> newdata)
    {
        savadata(databank, newdata, datacount, &databanksize);
        datacount++;
    }

  
    //SelectionSort(databank, datacount);

    
    double x;
    int y;
    cout << "��J�Q�d�ߪ����: ";
    cin >> x;

   
    y = BinarySearch(databank, x, 0, datacount -1);

    
    if (y != -1)
        cout << "����ơA���ަ�m��: " << y << endl;
    else
        cout << "�������" << endl;

   
    in.close();
    delete[] databank;

    return 0;
}
