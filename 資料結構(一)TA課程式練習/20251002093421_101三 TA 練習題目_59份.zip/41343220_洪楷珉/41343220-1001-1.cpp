#include <iostream>
#include <fstream>
using namespace std;
void SelectionSort(double* a, const int n)
{
    for (int i = 0; i < n - 1; i++)  
    {
        int j = i;
        for (int k = i + 1; k < n; k++)   
        {
            if (a[k] < a[j])   
                j = k;
        }
         
        if (i != j)   
            swap(a[i], a[j]);
    }
}
void savadata(double*& databank, double newdata, int datacount, int* databanksize)
{
    if (datacount + 1 >= *databanksize)   
    {
        *databanksize *= 2;   
        double* newdatabank = new double[*databanksize];   
        for (int i = 0; i < datacount; i++)   
        {
            newdatabank[i] = databank[i];
        }
        delete[] databank;   
        databank = newdatabank;   
    }
    databank[datacount] = newdata;  
}
int main(void)
{
    int databanksize = 2;
    double* databank = new double[databanksize];  
    double newdata;
    int datacount = 0;

    fstream in;
    in.open("double_data.txt");
    if (in.fail()) {
        cout << "input file opening failed";
        exit(1);
    }

   
    while (in >> newdata)
    {
        savadata(databank, newdata, datacount, &databanksize);
        datacount++;
    }

  
    SelectionSort(databank, datacount);
    ofstream out("sorted_data.txt");
    
    cout << endl;
    for (int i = 0; i < datacount; i++) {
        out << databank[i] << endl; 
    }
    
    in.close();
    delete[]databank;
    return 0;
}
