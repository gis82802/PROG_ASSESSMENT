#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void selectionSort(vector<double> &arr){
    int n = arr.size();
    for (int i = 0; i < n - 1; i++){
        int min = i;
        for (int j = i + 1; j < n; j++){
            if (arr[j] < arr[min]){
                min = j;
            }
        }
        // swap
        if (min != i){
            double temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }
}

int main() {
    ifstream inFile("double_data.txt");

    vector<double> numbers;
    double value;

    while (inFile >> value) {
        numbers.push_back(value);
    }
    inFile.close();

    selectionSort(numbers);

    ofstream outFile("sorted_double.txt");

    for (double num : numbers) {
        outFile << num << endl;
    }
    outFile.close();

    cout << "�Ƨǧ���" << endl;
    return 0;
}
