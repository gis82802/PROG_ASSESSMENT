#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>
using namespace std;

const int N = 8;
const int INF = numeric_limits<int>::max();

int cost[N][N] = {
    {522, 703, 366, 131, 167, 938, 935, 553},
    {35, 842, 39, 346, 169, 82, 37, 702},
    {139, 942, 649, 77, 835, 81, 813, 537},
    {618, 246, 208, 599, 44, 662, 655, 365},
    {703, 983, 680, 333, 462, 365, 652, 31},
    {46, 978, 832, 702, 812, 850, 641, 176},
    {848, 266, 281, 849, 715, 38, 370, 81},
    {160, 865, 262, 849, 570, 647, 553, 902}
};

int hungarian(const int cost[N][N], int matchR[N]) {
    int u[N + 1], v[N + 1], p[N + 1], way[N + 1];
    for (int i = 0; i <= N; i++) {
        u[i] = 0;
        v[i] = 0;
        p[i] = 0;
        way[i] = 0;
    }

    for (int i = 1; i <= N; i++) {
        p[0] = i;
        int j0 = 0;
        vector<int> minv(N + 1, INF);
        vector<bool> used(N + 1, false);
        do {
            used[j0] = true;
            int i0 = p[j0], j1 = 0;
            int delta = INF;
            for (int j = 1; j <= N; j++) {
                if (!used[j]) {
                    int cur = -cost[i0 - 1][j - 1] - u[i0] - v[j];
                    if (cur < minv[j]) {
                        minv[j] = cur;
                        way[j] = j0;
                    }
                    if (minv[j] < delta) {
                        delta = minv[j];
                        j1 = j;
                    }
                }
            }
            for (int j = 0; j <= N; j++) {
                if (used[j]) {
                    u[p[j]] += delta;
                    v[j] -= delta;
                }
                else {
                    minv[j] -= delta;
                }
            }
            j0 = j1;
        } while (p[j0] != 0);

        do {
            int j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
        } while (j0);
    }

    for (int j = 1; j <= N; j++) {
        matchR[p[j] - 1] = j - 1;
    }

    int maxSum = 0;
    for (int i = 0; i < N; i++) {
        maxSum += cost[i][matchR[i]];
    }
    return maxSum;
}

int main() {
    int matchR[N];
    int maxScore = hungarian(cost, matchR);

    string rows = "ABCDEFGH";
    string cols[8] = { "��","�A","��","�B","��","�v","��","��" };

    cout << "�̨ΰt��覡�G" << endl;
    for (int i = 0; i < N; i++) {
        cout << rows[i] << " -> " << cols[matchR[i]]
            << " (����: " << cost[i][matchR[i]] << ")\n";
    }
    cout << "�̰��t���`���G " << maxScore << endl;

    return 0;
}
