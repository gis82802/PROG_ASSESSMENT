#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int binarySearch(const vector<double>& arr, double target) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] == target) {
            return mid; 
        }
        else if (arr[mid] < target) {
            left = mid + 1; 
        }
        else {
            right = mid - 1; 
        }
    }
    return -1;
}

int main() {
    ifstream inFile("sorted_double.txt");
  
    vector<double> numbers;
    double value;
    while (inFile >> value) {
        numbers.push_back(value);
    }
    inFile.close();

    double target;
    cout << "�п�J�n�d�䪺�Ʀr�G";
    cin >> target;

    int pos = binarySearch(numbers, target);

    if (pos != -1) {
        cout << "��� " << target << "�A�b�Ƨǫ�}�C������m�O " << pos << endl;
    }
    else {
        cout << "�䤣�� " << target << endl;
    }

    return 0;
}
