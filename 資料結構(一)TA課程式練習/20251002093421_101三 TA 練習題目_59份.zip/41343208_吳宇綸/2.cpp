#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


int binarySearch(const vector<double>& arr, double x) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int middle = (left + right) / 2;
        if (x < arr[middle]) right = middle - 1;
        else if (x > arr[middle]) left = middle + 1;
        else return middle;
    }
    return -1;
}

int main() {
    ifstream fin("sorted.txt");  
    if (!fin) {
        cerr << "Error: cannot open sorted.txt!" << endl;
        return 1;
    }

    vector<double> numbers;
    double num;
    while (fin >> num) {  
        numbers.push_back(num);
    }
    fin.close();

    cout << "Loaded " << numbers.size() << " numbers from sorted.txt" << endl;

    
    double user;
    while (cout << "Enter number to search (Ctrl+D to quit): ", cin >> user) {
        int idx = binarySearch(numbers, user);
        if (idx != -1)
            cout << user << " is in sorted array at index " << idx << endl;
        else
            cout << "Not found" << endl;
    }

    return 0;
}
