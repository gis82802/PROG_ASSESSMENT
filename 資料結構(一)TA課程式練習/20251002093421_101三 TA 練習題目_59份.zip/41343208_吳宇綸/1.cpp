#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // �洫
        if (minIndex != i) {
            double temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}

int main() {
    ifstream fin("double_data.txt");  
   
    vector<double> numbers;
    double value;
   
    while (fin >> value) {
        numbers.push_back(value);
    }
    fin.close();

    selectionSort(numbers);

    ofstream fout("sorted.txt");
    for (double num : numbers) {
        fout << num << endl;
    }
    fout.close();

    return 0;
}
