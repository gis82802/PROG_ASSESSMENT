#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 1000

// SelectionSort
void selection_sort(double arr[], int n) {
	for (int i = 0; i < n - 1; i++) {
		int min_idx = i;
		for (int j = i + 1; j < n; j++) {
			if (arr[j] < arr[min_idx]) {
				min_idx = j;
			}
		}

		if (min_idx != i) {
			double temp = arr[i];
			arr[i] = arr[min_idx];
			arr[min_idx] = temp;
		}
	}
}

int main() {
	FILE* fp_in;
	double numbers[MAX_SIZE];
	int count = 0;

	fp_in = fopen("double_data.txt", "r");
	if (fp_in == NULL) {
		perror("�L�k�}�� double_data.txt");
		return 1;
	}

	while (fscanf(fp_in, "%lf", &numbers[count]) == 1) {
		count++;
		if (count >= MAX_SIZE) break;
	}
	fclose(fp_in);

	selection_sort(numbers, count);

	printf("�Ƨǫ᪺���G:\n");
	for (int i = 0; i < count; i++) {
		printf("%.6lf\n", numbers[i]);
	}

	return 0;
}
