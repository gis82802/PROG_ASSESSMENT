#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

int bi(const vector<double>& da, const double tv, const int as) {
    int st = 0;
    int en = as - 1;

    while (st <= en) {
        int mi = st + (en - st) / 2;

        if (tv < da[mi]) {
            en = mi - 1;
        }
        else if (tv > da[mi]) {
            st = mi + 1;
        }
        else {
            return mi;
        }
    }
    return -1;
}

int main() {
    string df = "sorted_double_data(1).txt";
    vector<double> nd;
    double cv;

    ifstream is(df);
    if (!is.is_open()) {
        cerr << "���~" << df << endl;
        return 1;
    }

    while (is >> cv) {
        nd.push_back(cv);
    }
    is.close();

    if (nd.empty()) {
        cout << "�ɮ׬��šC" << endl;
        return 0;
    }

    double stg;
    cout << "�j�M���Ʀr " << endl;
    while (cin >> stg) {
        int ds = nd.size();
        int fi = bi(nd, stg, ds);

        if (fi != -1) {
            cout << stg << " �b [" << fi << "] " << endl;
        }
        else {
            cout << stg << " ���Q���C" << endl;
        }
    }

    return 0;
}