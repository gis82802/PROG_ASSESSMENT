#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <string>

using namespace std;

bool rf(const string& fn, vector<double>& ns) {
    ifstream ifm(fn);
    if (!ifm.is_open()) {
        cerr << "���~ " << fn << endl;
        return false;
    }
    double tp;
    while (ifm >> tp) {
        ns.push_back(tp);
    }
    ifm.close();
    return true;
}

void sd(vector<double>& ar) {
    int sz = ar.size();
    if (sz < 2) {
        return;
    }
    for (int i = 0; i < sz - 1; ++i) {
        int mi = i;
        for (int j = i + 1; j < sz; ++j) {
            if (ar[j] < ar[mi]) {
                mi = j;
            }
        }
        if (mi != i) {
            swap(ar[i], ar[mi]);
        }
    }
}

bool wf(const string& fn, const vector<double>& ns) {
    ofstream ofm(fn);
    if (!ofm.is_open()) {
        cerr << "���~ " << fn << endl;
        return false;
    }
    for (const double& nm : ns) {
        ofm << nm << endl;
    }
    ofm.close();
    return true;
}

int main() {
    string in = "double_data(1).txt";
    string ou = "sorted_double_data(1).txt";
    vector<double> ns;

    cout << "�{���}�l" << endl;

    if (!rf(in, ns)) {
        cout << "���ѦӲפ�C" << endl;
        return 1;
    }
    cout << "�q " << in << " Ū " << ns.size() << " ��" << endl;

    if (ns.empty()) {
        cout << "�ɮ׬���" << endl;
    }
    else {
        cout << "��ܱƧ�" << endl;
        sd(ns);
        cout << "�Ƨǧ����C" << endl;
    }

    if (!wf(ou, ns)) {
        cout << "���ѦӲפ�C" << endl;
        return 1;
    }
    cout << "���\�x�s " << ou << endl;

    cout << "�����C" << endl;
    return 0;
}