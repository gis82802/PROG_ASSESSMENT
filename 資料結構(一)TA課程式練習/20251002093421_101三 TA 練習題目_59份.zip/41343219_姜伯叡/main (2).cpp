#include <iostream> 
#include <fstream>
#include <vector>

using namespace std;

int binarySrh(vector<double> &a, double x, int r)
{
	int l=0;
	while(l<=r)
	{
		int m = (l + r) / 2;
		if(x < a[m]) r = m - 1;
		else if(x > a[m]) l = m + 1;
		else return m;
	}
	return -1;
}

int main(int argc, char** argv) {
	vector<double> ary;
	
	ifstream iFile;
	iFile.open("../hw1/double_data_out.txt", ios::in);
	if(!iFile.is_open()){
		cout << "�ɮ׵L�k�}��" << endl; system("pause"); return 0;
	}
	
	double in;
	while(iFile>>in) ary.push_back(in);
	
	double find;
	cout << "�п�J�n�䪺�Ʀr: ";
	cin >> find;
	
	int point = binarySrh(ary, find, ary.size());
	if(point==-1) cout << "�}�C���L���Ʀr" << endl;
	else cout << "�L����m�b -> " << point + 1;
	
	return 0;
}
