#include<iostream>
#include<cstdlib>
#include<fstream>
#include<vector>
#include<iomanip> 

using namespace std;

void selectionSort(vector<double> &a, int &n)
{
	for(int i = 0 ; i < n ; i++)
	{
		int j = i;
		for(int k = i + 1 ; k < n ; k++)
			if(a[k] < a[j]) j = k;
		swap(a[i], a[j]); 
	} 
}

int main(int argc, char** argv) 
{
	ifstream iFile;
	iFile.open("double_data(1).txt", ios::in);
	if(!iFile.is_open()){
		cout << "�ɮ׵L�k�}��" << endl; system("pause"); return 0;
	}
	
	ofstream oFile;
	oFile.open("double_data_out.txt", ios::out);
	
	vector<double> dAry;
	double in;
	while(iFile >> in) dAry.push_back(in);
	int n = dAry.size();
	selectionSort(dAry, n);	
			 	
	for(int i=0;i<n;i++) oFile << setprecision(18) << dAry[i] << endl; 
	
	return 0;
}
