#include <iostream>
#include <algorithm>
#include <vector> 

using namespace std;

int main(int argc, char** argv) {
	int ary[8][8]=
	{
		{522, 703, 366, 131, 167, 938, 935, 553},
		{35, 842, 39, 346, 169, 82, 37, 702},
		{139, 942, 649, 77, 835, 81, 813, 537},
		{618, 246, 208, 599, 44, 662, 655, 365},
		{703, 983, 680, 333, 462, 365, 652, 31},
		{46, 978, 832, 702, 812, 850, 641, 176},
		{848, 266, 281, 849, 715, 38, 370, 81},
		{16, 865, 262, 849, 570, 647, 553, 902},
	};
	
	vector<int> col;
	for(int i=0;i<8;i++) col.push_back(i);
	int max = -1;
	vector<int> maxCol;
	
	do
	{
		int total=0;
		for(int i=0;i<8;i++) total += ary[i][col[i]];
		if(total > max)
		{
			max = total;
			maxCol = col;
		}
	}while(next_permutation(col.begin(), col.end()));
	
	
	char *row = "�ҤA���B���v����"; 
	
	cout << "MaxScore: " << max << endl;
	for(int i=0;i<8;i++)
		cout << row[i*2] << row[i*2+1] << " -> " << (char)('A' +  maxCol[i]) <<endl;
	
	return 0;
}
