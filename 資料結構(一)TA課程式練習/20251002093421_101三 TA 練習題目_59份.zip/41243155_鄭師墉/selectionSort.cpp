#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

void selectionSort(vector<double> &arr) // selection sort
{
    int n = arr.size();
    for (int i = 0; i < n - 1; i++)
    {
        int min = i;
        for (int j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[min])
                min = j;
        }
        if (min != i)
            swap(arr[i], arr[min]);
    }
}

int main(int argc, char const *argv[])
{
    ifstream inputFile("double_data(1).txt"); // input file
    ofstream outputFile("sorted_double.txt"); // output file
    if (!inputFile)
    {
        cout << "double_data.txt ERROR" << endl;
        return 1;
    }

    vector<double> data;
    double num;

    while (inputFile >> num) // read data
        data.push_back(num);
    inputFile.close();

    selectionSort(data);

    for (int i = 0; i < data.size(); i++)
    {
        outputFile << data[i] << endl; // write to file
        cout << data[i] << endl;
    }

    outputFile.close();
    return 0;
}