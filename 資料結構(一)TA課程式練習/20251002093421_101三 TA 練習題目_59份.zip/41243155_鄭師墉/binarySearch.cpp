#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
using namespace std;

int binarySearch(vector<double> arr, double target) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        // cout << left << ' ' << mid << ' ' << right << endl;
        // cout << arr[mid] << ' ' << target << endl;
        if(arr[mid] == target)
            return mid + 1;
        else if (arr[mid] < target) // between right & mid
            left = mid + 1;
        else    // between left & mid
            right = mid - 1;
    }
    return -1;
}

int main(int argc, char const *argv[])
{
    ifstream inputFile("double_data.txt"); //load file
    if (!inputFile)
    {
        cout << "double_data.txt ERROR" << endl;
        return 1;
    }

    vector<double> data;
    double num;

    while (inputFile >> num) // read data
        data.push_back(num);
    inputFile.close();

    double target;
    cout << "Input the target:";
    cin >> target;

    sort(data.begin(), data.end()); //sort

    int result = binarySearch(data, target);

    cout << "Sort:";
    for(int i = 0; i < data.size(); i++)
        cout << data[i] << ' ';
    cout << endl;

    if(result == -1) {cout << "not find num";}
    else
        cout << "Find num in:" << result;
    return 0;
}
