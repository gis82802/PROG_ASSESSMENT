#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

int main() {
    int arr[8][8] = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,599,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };

    string str1[8] = {"��","�A","��","�B","��","�v","��","��"};
    string str2[8] = {"A","B","C","D","E","F","G","H"};

    int bestScore = 0;
    int best[8];
    int perm[8] = {0,1,2,3,4,5,6,7};

    do {
        int sum = 0;
        for (int i = 0; i < 8; i++)
            sum += arr[i][perm[i]];

        if (sum > bestScore) {
            bestScore = sum;
            for (int i = 0; i < 8; i++)
                best[i] = perm[i];
        }
    } while (next_permutation(perm, perm + 8));

    cout << "�̰��`���G" << bestScore << endl;
    cout << "�̨ΰt��p�U�G" << endl;

    for (int i = 0; i < 8; i++)
        cout << str1[i] << " -> " << str2[best[i]] << " (" << arr[i][best[i]] << ")" << endl;

    return 0;
}

