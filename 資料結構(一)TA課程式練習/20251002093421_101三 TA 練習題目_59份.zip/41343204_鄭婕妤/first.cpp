#include<iostream>
#include<fstream>
#include<vector>

using namespace std;

void selectionsort(vector<double>& arr) {
	int n = arr.size();
	int i;
	for (i = 0; i < n; i++) {
		int min = i;
		for (int j = i + 1; j < n; j++) {
			if (arr[j] < arr[min]) min = j;
		}
		swap(arr[i], arr[min]);
	}
}
int main() {
	ifstream fin("double_data.txt");
	vector<double> arr;
	double num;
	while (fin >> num) {
		arr.push_back(num);
	}
	fin.close();
	selectionsort(arr);
	ofstream fout("sorted_data.txt");
	for (double x : arr) {
		fout << x << " ";
	}
	fout.close();

	cout << "sorted finish" << endl;
	return 0;
}