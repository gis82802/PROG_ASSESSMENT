#include<iostream>
#include<vector>
using namespace std;

int n = 8;
int bestsum = 0;
vector<int> bestmatch;

void R(vector<vector<int>>& arr, int row, vector<bool>& used, int sum, vector<int>& match) {
    if (row == n) {
        if (sum > bestsum) {
            bestsum = sum;
            bestmatch = match;  
        }
        return;
    }

    for (int co = 0; co < n; co++) {
        if (!used[co]) {
            used[co] = true; 
            match[row] = co; 
            R(arr, row + 1, used, sum + arr[row][co], match);
            used[co] = false; 
        }
    }
}

int main() {
    vector<vector<int>> arr = {
        {522, 703, 366, 131, 167, 938, 935, 553},
        {35, 842, 39, 346, 169, 82, 37, 702},
        {139, 942, 649, 77, 835, 81, 813, 537},
        {618, 246, 208, 599, 44, 662, 655, 365},
        {703, 983, 680, 333, 462, 365, 652, 31},
        {46, 987, 832, 702, 812, 850, 641, 176},
        {848, 266, 281, 849, 715, 38, 370, 81},
        {160, 865, 262, 849, 570, 647, 553, 902}
    };

    vector<bool> used(n, false); 
    vector<int> match(n, -1); 

    R(arr, 0, used, 0, match);

    cout << "bestsum: " << bestsum << endl;
    cout << "�̨�match:" << endl;
    for (int i = 0; i < n; i++) {
        cout << i + 1 << "��" << char('A' + match[i]) << "�o��:" << arr[i][match[i]] << endl;
    }

    return 0;
}
