#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

int binarysearch(const vector<double>& arr, double target) {
    int left = 0, right = arr.size() - 1;  
    while (left <= right) {  
        int mid = (left + right) / 2;
        if (arr[mid] == target) {
            return mid;
        }
        else if (arr[mid] < target)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;
}

int main() {
    ifstream fin("sorted_data.txt");
    vector<double> arr;
    double x;
    while (fin >> x) {
        arr.push_back(x);
    }
    fin.close();

    double target;
    cout << "�n�䪺�Ʀr:";
    cin >> target;

    int position = binarysearch(arr, target);

    if (position != -1)
        cout << target << " �b��m: " << position << endl;
    else
        cout << "not found" << endl;

    return 0;
}
