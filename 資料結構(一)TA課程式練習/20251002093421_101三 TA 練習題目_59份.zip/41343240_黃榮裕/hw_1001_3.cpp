#include <iostream>
#include <string>
using namespace std;

const int N = 8;

// 函式：交換兩個整數
void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

// 函式：生成排列並計算總分
void permute(int perm[], int l, int r, int score[N][N], string people[],
             int &bestScore, int bestAssign[])
{
    if (l == r)
    {
        int sum = 0;
        for (int i = 0; i < N; i++)
            sum += score[i][perm[i]]; // 計算總分
        if (sum > bestScore)
        {
            bestScore = sum;
            for (int i = 0; i < N; i++)
                bestAssign[i] = perm[i]; // 記錄最佳排列
        }
    }
    else
    {
        for (int i = l; i <= r; i++)
        {
            swap(perm[l], perm[i]);
            permute(perm, l + 1, r, score, people, bestScore, bestAssign);
            swap(perm[l], perm[i]);
        }
    }
}

int main()
{
    int score[N][N] = {
        {522, 703, 366, 131, 167, 938, 935, 553},
        {35, 842, 39, 346, 169, 82, 37, 702},
        {139, 942, 649, 77, 835, 81, 813, 537},
        {618, 246, 208, 599, 44, 662, 655, 365},
        {703, 983, 680, 333, 462, 365, 652, 31},
        {46, 978, 832, 702, 812, 850, 641, 176},
        {848, 266, 281, 849, 715, 38, 370, 81},
        {160, 865, 262, 849, 570, 647, 553, 902}};

    string people[N] = {"甲", "乙", "丙", "丁", "戊", "己", "庚", "辛"};

    int perm[N];
    for (int i = 0; i < N; i++)
        perm[i] = i; // 初始排列 0~7

    int bestScore = 0;
    int bestAssign[N];

    // 計算最佳總分與對應排列
    permute(perm, 0, N - 1, score, people, bestScore, bestAssign);

    // 輸出結果
    cout << "最佳配對結果:\n";
    for (int i = 0; i < N; i++)
    {
        cout << people[i] << " -> "
             << char('A' + bestAssign[i])
             << " (分數=" << score[i][bestAssign[i]] << ")\n";
    }
    cout << "最大總分 = " << bestScore << endl;

    return 0;
}
