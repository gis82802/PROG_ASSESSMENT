#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

// Selection Sort：選擇排序法，將陣列從小到大排序
void selectionSort(vector<double> &arr)
{
    int n = arr.size();
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i; // 假設目前 i 位置是最小值
        for (int j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[minIndex])
                minIndex = j; // 找到更小的元素
        }
        if (minIndex != i)
            swap(arr[i], arr[minIndex]); // 交換
    }
}

// Binary Search：二元搜尋法
// 前提：arr 必須已排序
int binarySearch(const vector<double> &arr, double target)
{
    int left = 0, right = arr.size() - 1;
    while (left <= right)
    {
        int mid = (left + right) / 2;
        if (arr[mid] == target)
            return mid;
        else if (arr[mid] < target)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1; // 沒找到
}

int main()
{
    ifstream inFile("double_data.txt");
    if (!inFile)
    {
        cerr << "無法開啟 double_data.txt" << endl;
        return 1;
    }

    vector<double> original, sorted;
    double num;

    // 讀檔存入 vector
    while (inFile >> num)
    {
        original.push_back(num);
        sorted.push_back(num);
    }
    inFile.close();

    // 排序
    selectionSort(sorted);

    // 輸出排序結果
    ofstream outFile("sorted.txt");
    for (double val : sorted)
        outFile << val << endl;
    outFile.close();

    // 查詢數字
    double key;
    while (true)
    {
        cout << "請輸入要查找的數字 (輸入 -1 結束): ";
        cin >> key;
        if (key == -1)
        {
            cout << "程式結束。" << endl;
            break;
        }

        int pos = binarySearch(sorted, key);
        if (pos != -1)
        {
            cout << "找到 " << key << " ，在原始檔案中的位置: ";
            for (size_t i = 0; i < original.size(); i++)
            {
                if (original[i] == key)
                    cout << i << " ";
            }
            cout << endl;
        }
        else
        {
            cout << key << " 不存在，請重新輸入。" << endl;
        }
    }

    return 0;
}
