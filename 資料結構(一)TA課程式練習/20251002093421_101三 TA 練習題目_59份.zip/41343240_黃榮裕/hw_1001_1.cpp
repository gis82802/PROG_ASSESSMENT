#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

// Selection Sort for strings based on numeric value
void selectionSort(vector<string> &arr)
{
    int n = arr.size();
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;
        for (int j = i + 1; j < n; j++)
        {
            // 用 stold 比較數值大小，但不改變原始字串
            if (stold(arr[j]) < stold(arr[minIndex]))
            {
                minIndex = j;
            }
        }
        if (minIndex != i)
        {
            swap(arr[i], arr[minIndex]);
        }
    }
}

int main()
{
    ifstream inFile("double_data.txt");
    if (!inFile)
    {
        cout << "無法開啟 double_data.txt" << endl;
        return 1;
    }

    vector<string> arr;
    string line;

    // 讀檔，存每行字串
    while (getline(inFile, line))
    {
        if (!line.empty())
            arr.push_back(line);
    }
    inFile.close();

    // 排序
    selectionSort(arr);

    // 輸出排序後結果，保留原始格式
    ofstream outFile("sorted.txt");
    for (const string &s : arr)
    {
        outFile << s << endl;
    }
    outFile.close();

    cout << "排序完成，結果已輸出到 sorted.txt" << endl;
    return 0;
}
