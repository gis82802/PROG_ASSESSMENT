#include <iostream>
#include <vector>
#include <climits>
using namespace std;

// �I���Q�t��k (�̤j�������D)
class Hungarian {
public:
    Hungarian(const vector<vector<int>>& costMatrix)
        : n(costMatrix.size()), cost(costMatrix),
        u(n + 1, 0), v(n + 1, 0), p(n + 1, 0), way(n + 1, 0) {}

    int solve(vector<int>& assignment) {
        for (int i = 1; i <= n; i++) {
            p[0] = i;
            int j0 = 0;
            vector<int> minv(n + 1, INT_MAX);
            vector<bool> used(n + 1, false);

            do {
                used[j0] = true;
                int i0 = p[j0], delta = INT_MAX, j1 = 0;
                for (int j = 1; j <= n; j++) {
                    if (!used[j]) {
                        int cur = -(cost[i0 - 1][j - 1]) - u[i0] - v[j];
                        if (cur < minv[j]) {
                            minv[j] = cur;
                            way[j] = j0;
                        }
                        if (minv[j] < delta) {
                            delta = minv[j];
                            j1 = j;
                        }
                    }
                }
                for (int j = 0; j <= n; j++) {
                    if (used[j]) {
                        u[p[j]] += delta;
                        v[j] -= delta;
                    }
                    else {
                        minv[j] -= delta;
                    }
                }
                j0 = j1;
            } while (p[j0] != 0);

            do {
                int j1 = way[j0];
                p[j0] = p[j1];
                j0 = j1;
            } while (j0);
        }

        assignment.resize(n + 1);
        for (int j = 1; j <= n; j++) assignment[p[j]] = j;

        int result = 0;
        for (int i = 1; i <= n; i++)
            result += cost[i - 1][assignment[i] - 1];
        return result;
    }

private:
    int n;
    vector<vector<int>> cost;
    vector<int> u, v, p, way;
};

int main() {
    // �q�����ഫ�Ӫ� 8��8 �x�}
    vector<vector<int>> matrix = {
        {522, 703, 366, 131, 167, 938, 935, 553}, // ��
        { 35, 842,  39, 346, 169,  82,  37, 702}, // �A
        {139, 942, 649,  77, 835,  81, 813, 537}, // ��
        {618, 246, 208, 599,  44, 662, 655, 365}, // �B
        {703, 983, 680, 333, 462, 365, 652,  31}, // ��
        { 46, 978, 832, 702, 812, 850, 641, 176}, // �v
        {848, 266, 281, 849, 715,  38, 370,  81}, // ��
        {160, 865, 262, 849, 570, 647, 553, 902}  // ��
    };

    Hungarian hungarian(matrix);
    vector<int> assignment;
    int maxScore = hungarian.solve(assignment);

    vector<string> persons = { "��","�A","��","�B","��","�v","��","��" };
    vector<string> jobs = { "A","B","C","D","E","F","G","H" };

    cout << "�̰��`�� = " << maxScore << endl;
    cout << "�̨ΰt��覡�G" << endl;
    for (int i = 1; i <= 8; i++) {
        cout << persons[i - 1] << " -> " << jobs[assignment[i] - 1]
            << " (���� " << matrix[i - 1][assignment[i] - 1] << ")" << endl;
    }
    return 0;
}
