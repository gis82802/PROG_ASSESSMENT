#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
using namespace std;

// ��ܱƧǡ]�Ѥp��j�^
void selectionSort(vector<double>& a) {
    for (size_t i = 0; i + 1 < a.size(); ++i) {
        size_t minIdx = i;
        for (size_t j = i + 1; j < a.size(); ++j) {
            if (a[j] < a[minIdx]) minIdx = j;
        }
        if (minIdx != i) swap(a[i], a[minIdx]);
    }
}

int main() {
    const string inFile = "double.txt";
    const string outFile = "sorted.txt";

    ifstream fin(inFile);
    if (!fin) {
        cerr << "�L�k�}�ҿ�J�ɮסG" << inFile << "\n";
        return 1;
    }

    vector<double> data;
    data.reserve(1024);
    double x;
    while (fin >> x) data.push_back(x);
    fin.close();

    if (data.empty()) {
        cerr << "��J�ɮ׬��ũεL���ļƦr�C\n";
        return 1;
    }

    selectionSort(data);

    ofstream fout(outFile);
    if (!fout) {
        cerr << "�L�k�}�ҿ�X�ɮסG" << outFile << "\n";
        return 1;
    }
    fout << setprecision(17);
    for (double v : data) fout << v << "\n";
    fout.close();

    cout << "�w�q " << inFile << " Ū�J " << data.size()
        << " ����ơA������ܱƧǡA���G�w�g�J " << outFile << "\n";
    return 0;
}
