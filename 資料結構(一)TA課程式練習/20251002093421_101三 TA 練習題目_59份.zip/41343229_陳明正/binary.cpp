#include <iostream>
#include <vector>
#include <fstream>
#include <string>
using namespace std;
int binarySearch(const vector<double>& a, const double x, const int n) {
    int left = 0, right = n - 1;
    while (left <= right) {
        int middle = left + (right - left) / 2;
        if (x < a[middle]) right = middle - 1;
        else if (x > a[middle]) left = middle + 1;
        else return middle;
    }
    return -1;
}
int main() {
    string filename = "sorted.txt";
    vector<double> numbers;
    double temp;
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "error " << filename << endl;
        return 1;
    }
    while (inputFile >> temp) numbers.push_back(temp);
    inputFile.close();
    if (numbers.empty()) cout << "empty" << endl;
    double number_to_find;
    while (cin >> number_to_find) {
        int n = numbers.size();
        int idx = binarySearch(numbers, number_to_find, n);
        if (idx != -1) cout << number_to_find << " is in a[" << idx << "]" << endl;
        else cout << "not found" << endl;
    }
}
