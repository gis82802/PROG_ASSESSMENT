#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

void swap(double* a, double* b) {
    double t = *a;
	*a = *b;
	*b = t;
}

void SelectionSort(double* a, const int n) {
	for (int i = 0; i < n; i++) {
		int j = i;
		for (int k = i + 1; k < n; k++) {
			if (a[k] < a[j]) {
				j = k;
			}
			swap(&a[i], &a[j]);
		}
	}
}

void saveData(double *&dataBank, double newData, int& dataCount, int* dataBankSize) {
    if (dataCount >= *dataBankSize) {
        int oldSize = *dataBankSize;
        int newSize = (oldSize * 2);
        double* tmp = new double[newSize];
        for (int i = 0; i < dataCount; i++) {
            tmp[i] = dataBank[i];
        }
        delete[] dataBank;
        dataBank = tmp;
        *dataBankSize = newSize;
        //  cout << "�O����� " << oldSize << " �X�R�� " << newSize << endl;
    }
    dataBank[dataCount] = newData;
    dataCount++;
}

int main() {
    ifstream fileIn;
    int dataBankSize = 10;
    double* dataBank = new double[dataBankSize];
    int dataCount = 0;
    double newData;

    fileIn.open("double_data.txt");
    if (fileIn.fail()) {
        cout << "input file opening failed";
        exit(1);
    }

    while (fileIn >> newData) {
        saveData(dataBank, newData, dataCount, &dataBankSize);
    }
    fileIn.close();

    cout << fixed << setprecision(15);  // �p���I�� 15 ��
    cout << "�@Ū�J�G" << dataCount << " ��" << endl;
    cout << "dataBankSize�G" << dataBankSize << endl;

    SelectionSort(dataBank, dataCount);

    // �g�J
    ofstream fileOut("double_SelectionSort.txt");
    if (!fileOut) {
        cout << "input file opening failed";
        exit(1);
    }
    fileOut << fixed << setprecision(15);
    for (int i = 0; i < dataCount; i++) {
        fileOut << dataBank[i] << "\n";
    }
    cout << "�g�J�ɮק���" << endl;

    delete[] dataBank;

    return 0;
}
