#include <iostream>

using namespace std;

void swap(char* a, char* b) {
    char t = *a;
    *a = *b;
    *b = t;
}

void Permutations(char *b, const int k, const int m, int (*score)[8], int *bestScore, char *bestPerm) {
    if (k == m) {
        int total = 0;
        for (int i = 0; i <= m; i++) {
            int row = i;
            int col = b[i] - 'A';   // A~H �ন 0~7
            total += score[row][col];
        }
        if (total > *bestScore) {
            *bestScore = total;
            for (int i = 0; i <= m; i++) {
                bestPerm[i] = b[i];
            }
        }
    }
    else {
        for (int i = k; i <= m; i++) {
            swap(b[k], b[i]);
            Permutations(b, k + 1, m, score, bestScore, bestPerm);
            swap(b[k], b[i]);
        }
    }
}

int main() {
    int score[8][8] = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,599,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };
    const char* a[8] = {"��", "�A", "��", "�B", "��", "�v", "��", "��"};
    char b[8] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
    char bestPerm[8];
    int bestScore = -1;

    Permutations(b, 0, 7, score, &bestScore, bestPerm);

    cout << "�̰����� = " << bestScore << endl;
    cout << "�̨ΰt��G" << endl;
    for (int i = 0; i < 8; i++) {
        int bIndex = bestPerm[i] - 'A';
        cout << a[i] << " -> " << bestPerm[i] << " (���� = " << score[i][bIndex] << ")" << endl;
    }

    return 0;
}
