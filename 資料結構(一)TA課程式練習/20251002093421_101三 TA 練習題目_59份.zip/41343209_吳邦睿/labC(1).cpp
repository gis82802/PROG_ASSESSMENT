#include <iostream>
using namespace std;

bool next_permutation(int arr[], int n) {
    int i = n - 2;
    while (i >= 0 && arr[i] >= arr[i + 1])
        i--;
    if (i < 0)
        return false;

    int j = n - 1;
    while (arr[j] <= arr[i])
        j--;

    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;

    int left = i + 1, right = n - 1;
    while (left < right) {
        temp = arr[left];
        arr[left] = arr[right];
        arr[right] = temp;
        left++;
        right--;
    }

    return true;
}

int main() {
    int score[8][8] = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,599,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };

    int perm[8] = { 0,1,2,3,4,5,6,7 };
    int best[8];
    int maxScore = -1;

    do {
        int sum = 0;
        for (int i = 0; i < 8; i++)
            sum += score[i][perm[i]];

        if (sum > maxScore) {
            maxScore = sum;
            for (int i = 0; i < 8; i++)
                best[i] = perm[i];
        }
    } while (next_permutation(perm, 8));

    cout << "�̰����զX�G" << endl;
    for (int i = 0; i < 8; i++) {
        if (i == 0) cout << "��";
        else if (i == 1) cout << "�A";
        else if (i == 2) cout << "��";
        else if (i == 3) cout << "�B";
        else if (i == 4) cout << "��";
        else if (i == 5) cout << "�v";
        else if (i == 6) cout << "��";
        else if (i == 7) cout << "��";

        cout << " " << char('A' + best[i]) << " " << score[i][best[i]] << endl;
    }

    cout << "�`���G" << maxScore << endl;

    return 0;
}
