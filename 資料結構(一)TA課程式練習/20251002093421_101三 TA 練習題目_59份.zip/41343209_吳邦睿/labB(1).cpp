#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

void selectionSort(double arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        double temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}

int binarySearch(double arr[], int n, double key) {
    int left = 0, right = n - 1;
    const double EPS = 1e-6;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (fabs(arr[mid] - key) < EPS) return mid;
        else if (arr[mid] < key) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

int main() {
    const int MAX_SIZE = 1000;
    double arr[MAX_SIZE];
    int n = 0;

    ifstream inFile("double.txt");
    if (!inFile) return 1;
    while (inFile >> arr[n]) {
        n++;
        if (n >= MAX_SIZE) break;
    }
    inFile.close();

    selectionSort(arr, n);

    ofstream outFile("sorted.txt");
    if (!outFile) return 1;
    for (int i = 0; i < n; i++) {
        outFile << arr[i] << endl;
    }
    outFile.close();

    double sortedArr[MAX_SIZE];
    int m = 0;
    ifstream sortedFile("sorted.txt");
    if (!sortedFile) return 1;
    while (sortedFile >> sortedArr[m]) {
        m++;
        if (m >= MAX_SIZE) break;
    }
    sortedFile.close();

    double key;
    cout << "�п�J�n�j�M���Ʀr: ";
    cin >> key;

    int pos = binarySearch(sortedArr, m, key);
    if (pos != -1) cout << "�Ʀr�X�{�b�Ƨǫ᪺��m: " << pos << endl;
    else cout << "�䤣��ӼƦr" << endl;

    return 0;
}
