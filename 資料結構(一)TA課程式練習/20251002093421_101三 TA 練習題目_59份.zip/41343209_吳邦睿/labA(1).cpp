#include <iostream>
#include <fstream>
using namespace std;

void selectionSort(double arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        double temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}

int main() {
    ifstream fin("double.txt");
    if (!fin) {
        cout << "�L�k�}��double.txt" << endl;
        return 1; 
    }

    double data[1000];
    int count = 0;

    while (count < 1000 && (fin >> data[count])) {
        count++;
    }
    fin.close();

    if (count == 0) {
        cout << "�ɮפ��S��������" << endl;
        return 0;
    }

    selectionSort(data, count);

    ofstream fout("sorted.txt");
    if (!fout) {
        cout << "�L�k�إ�sorted.txt" << endl;
        return 1;
    }

    for (int i = 0; i < count; i++) {
        fout << data[i] << endl;
    }
    fout.close();

    cout << "�Ƨǧ����A���G�w��X��sorted.txt" << endl;
    return 0;
}
