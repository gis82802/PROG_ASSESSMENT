#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

void ss(vector<double>& arr) {
	int n = arr.size();
	for (int i = 0; i < n - 1; i++) {
		int min = i;
		for (int j = i + 1; j < n; j++){
			if (arr[j] < arr[min]) {
				min = j;
			}
		}
		double temp = arr[i];
		arr[i] = arr[min];
		arr[min] = temp;
	}
}
int main() {
	vector<double>numbers;
	ifstream inputFile("double.txt");

	if (!inputFile) {
		cerr << "�L�k�}��" << endl;
		return 1;
	}
	double num;
	while (inputFile >> num) {
		numbers.push_back(num);
	}
	inputFile.close();
	ss(numbers);
	ofstream outputFile("program1.txt");
	if (!outputFile) {
		cerr << "�L�k�}��" << endl;
		return 1;
	}
	for (double n : numbers) {
		outputFile << n << endl;
	}
	outputFile.close();
	cout << "��X���`" << endl;
	return 0;
}