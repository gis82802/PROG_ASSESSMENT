#include<iostream>
#include<fstream>
#include<vector>
using namespace std;
int bs(const vector<double>&arr,double target) {
	int left = 0, right = arr.size() - 1;
	while (left <= right) {
		int mid = left + (right-left)/2;
		if (arr[mid] == target) {
			return mid;
		}
		else if (arr[mid] < target) {
			left = mid + 1;
		}
		else {
			right = mid - 1;
		}
	}
	return -1;
}
int main() {
	vector<double>numbers;
	ifstream inputFile("program1.txt");

	if (!inputFile) {
		cerr << "�L�k�}��" << endl;
		return 1;
	}
	double num;
	while (inputFile >> num) {
		numbers.push_back(num);
	}
	inputFile.close();

	double target;
	cout << "��J:";
	cin >> target;
	int pos = bs(numbers, target);
	if (pos != -1) {
		cout << "�b" << pos << endl;
	}
	else {
		cout << "���s�b" << endl;
	}
	return 0;


}