#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


vector<double> read(const string& filename) {
    ifstream file(filename);
    vector<double> numbers;
    double number;

    if (!file) {
        cout << "�L�k�}���ɮסG" << filename << endl;
        return numbers;
    }

  
    while (file >> number) {
        numbers.push_back(number);
    }

    return numbers;
}

void write(const vector<double>& arr, const string& filename) {
    ofstream file(filename);
    if (!file) {
        cout << "�L�k�}���ɮסG" << filename << endl;
        return;
    }

    
    for (const double& num : arr) {
        file << num << endl;
    }
}


void selectionSort(vector<double>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int min = i;  
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min]) {
                min = j;  
            }
        }
        
        if (min != i) {
            swap(arr[i], arr[min]);
        }
    }
}

int main() {
    
    string inputFile = "C:\\Users\\user\\Downloads\\double_data(1).txt";
    string outputFile = "C:\\Users\\user\\Desktop\\soft.txt"; 
    
    vector<double> numbers = read(inputFile);
    if (numbers.empty()) {
        cout << "�ɮ�Ū�����ѩ��ɮ׵L���e�C" << endl;
        return -1;
    }

   
    selectionSort(numbers);

   
    write(numbers, outputFile);

    cout << "��ܱƧǧ����A�Ƨǵ��G�w�x�s�� " << outputFile << endl;

    return 0;
}
