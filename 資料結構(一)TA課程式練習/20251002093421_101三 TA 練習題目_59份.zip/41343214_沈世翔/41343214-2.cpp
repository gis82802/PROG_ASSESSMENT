#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm> 
using namespace std;


vector<double> read(const string& filename) {
    ifstream file(filename);
    vector<double> numbers;
    double number;

    if (!file) {
        cout << "�L�k�}���ɮסG" << filename << endl;
        return numbers;
    }

    
    while (file >> number) {
        numbers.push_back(number);
    }

    return numbers;
}

int binarySearch(const vector<double>& arr, double target) {
    int low = 0, high = arr.size() - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (arr[mid] == target) {
            return mid; 
        }
        else if (arr[mid] < target) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }

    return -1; 
}

int main() {
    
    string inputFile = "C:\\Users\\user\\Desktop\\soft.txt";
    vector<double> numbers = read(inputFile);
    if (numbers.empty()) {
        cout << "�ɮ�Ū�����ѩ��ɮ׵L���e�C" << endl;
        return -1;
    }

    sort(numbers.begin(), numbers.end());  


    double target;
    cout << "�п�J�n�d�䪺�Ʀr: ";
    cin >> target;

    int pos = binarySearch(numbers, target);

    if (pos != -1) {
        cout << "�Ʀr " << target << " ����m�O: " << pos << endl;
    }
    else {
        cout << "�Ʀr " << target << " �����I" << endl;
    }

    return 0;
}
