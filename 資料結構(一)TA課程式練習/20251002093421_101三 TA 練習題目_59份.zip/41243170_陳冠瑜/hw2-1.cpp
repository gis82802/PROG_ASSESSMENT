#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;

void saveDate(double*& dataBank/*�s��ƪ��a��*/, double newData/*�s���n�ǤJ�����*/, int& dataCount/*�ثe���X�����*/, int* dataBankSize/*�ثe�s��ƪ��a�誺�j�p*/) {
	if (dataCount >= *dataBankSize) {
		cout << "��" << *dataBankSize;
		int newsize = *dataBankSize * 2;
		cout << "�X�R��" << newsize << endl;
		double* newdatabank = new double[newsize];

		for (int i = 0; i < dataCount; i++) {
			newdatabank[i] = dataBank[i];
		}

		delete[] dataBank;
		dataBank = newdatabank;
		*dataBankSize = newsize;
	}
	dataBank[dataCount] = newData;
	dataCount++;
}

void selection(double* a, const int n) {
	double c;
	for (int i = 0; i < n - 1; i++) {
		int j = i;
		for (int k = i + 1; k < n; k++) {
			if (a[k] < a[j]) j = k;
		}
		if (j != i) {
			c = a[i];
			a[i] = a[j];
			a[j] = c;
		}
	}
}

int main() {
	double newdata;
	ifstream infile("double_data(1).txt");
	ofstream outfile("out.txt");

	//save data
	int dataBankSize = 10;
	double* dataBank = new double[dataBankSize];
	int dataCount = 0;
	while (infile >> newdata) {
		saveDate(dataBank, newdata, dataCount, &dataBankSize);
	}

	selection(dataBank, dataCount);

	outfile << fixed << setprecision(15);

	for (int x=0; x < dataCount; x++) {
		outfile << dataBank[x] <<endl;
	}
}