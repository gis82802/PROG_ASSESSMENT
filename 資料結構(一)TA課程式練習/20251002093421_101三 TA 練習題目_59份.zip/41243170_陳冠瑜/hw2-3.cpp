#include<iostream>
using namespace std;

void swap(int& a, int& b) {
	int temp = a;
	a = b;
	b = temp;
}

int bestScore = -1;   
int bestAssign[8];

int score[8][8] =
{
	{522,703,366,131,167,928,935,553},
	{35 ,842,39 ,346,169,82 ,37 ,702},
	{139,942,649,77 ,835,81 ,813,537},
	{618,246,208,599,44 ,662,655,365},
	{703,983,680,333,462,365,652,31 },
	{46 ,978,832,702,812,850,641,176},
	{848,266,281,849,715,38 ,370,81 },
	{160,865,262,849,570,647,553,902}
};

void permutations(int* a, const int k, const int m) {


	if (k == m) {
		int total = 0;
		for (int i = 0; i < 8; i++) {
			total += score[i][a[i]];
		}
		if (total > bestScore) {
			bestScore = total;
			for (int i = 0; i < 8; i++) bestAssign[i] = a[i];
		}
	}
	else
		for (int i = k; i <= m; i++) {
			swap(a[k], a[i]);
			permutations(a, k + 1, m);
			swap(a[k], a[i]);
		}
}


int main() {

	int a[8];
	for (int i = 0; i < 8; i++) a[i] = i; // ��l�ƦC [0,1,2,3,4,5,6,7]

	permutations(a, 0, 8 - 1);

	string people[8] = { "��","�A","��","�B","��","�v","��","��" };
	string objects[8] = { "A","B","C","D","E","F","G","H" };

	cout << "�̨ΰt�ﵲ�G:\n";
	for (int i = 0; i < 8; i++) {
		cout << people[i] << " -> " << objects[bestAssign[i]]
			<< " (���� " << score[i][bestAssign[i]] << ")\n";
	}
	cout << "�`���� = " << bestScore << endl;

	return 0;
}

