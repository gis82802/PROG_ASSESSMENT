#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int binarySearch(const vector<double> &a, double x) {
    int left = 0, right = a.size() - 1;
    while (left <= right) {
        int middle = (left + right) / 2;
        if (x < a[middle])
            right = middle - 1;
        else if (x > a[middle])
            left = middle + 1;
        else
            return middle;  // ���
    }
    return -1;  // �S���
}

int main() {
    // Ū�ɡA�� sorted_data.txt ���Ʀr�s�i vector
    ifstream inFile("E:\\sorted_data.txt");
    if (!inFile) {
        cout << "�ɮ׶}�ҥ��ѡI" << endl;
        return 1;
    }

    vector<double> numbers;
    double x;
    while (inFile >> x) {
        numbers.push_back(x);
    }
    inFile.close();

    // ��J�Q�n�d�䪺�Ʀr
    double target;
    cout << "�п�J�n�d�䪺�Ʀr�G";
    cin >> target;

    int idx = binarySearch(numbers, target);

    if (idx != -1)
        cout << target << " is in numbers[" << idx << "]\n";
    else
        cout << "not found\n";

    return 0;
}

