#include <iostream>
using namespace std;

int binarySearch(int *a, const int x, const int n) {
    int left = 0, right = n - 1;
    while (left <= right) {
        int middle = (left + right) / 2;
        if (x < a[middle])
            right = middle - 1;
        else if (x > a[middle])
            left = middle + 1;
        else
            return middle;  // ���
    }
    return -1;  // �S���
}

int main() {
    int a[] = {1, 5, 7, 32, 55, 68, 91, 101, 200};
    int n = sizeof(a) / sizeof(a[0]);   // �}�C����

    int target = 32;                     // �Q�n�d�䪺�Ʀr
    int idx = binarySearch(a, target, n);

    if (idx != -1)
        cout << target << " is in a[" << idx << "]\n";
    else
        cout << "not found\n";

    return 0;
}


