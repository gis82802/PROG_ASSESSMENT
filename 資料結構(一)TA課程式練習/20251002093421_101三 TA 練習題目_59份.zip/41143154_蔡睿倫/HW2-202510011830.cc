#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>

void load_file_context(const std::string& filename, std::vector<double>& data) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }
    double value;
    while (file >> value) {
        data.push_back(value);
    }
    file.close();
}

void save_to_file(const std::string& filename, const std::vector<double>& data) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error creating file: " << filename << std::endl;
        return;
    }
    
    for (const auto& num : data) {
        file << std::fixed << std::setprecision(15) << num << std::endl;
    }
    file.close();
    std::cout << "Saved sorted data to " << filename << std::endl;
}

void select_sort(std::vector<double>& arr) {
    std::size_t n = arr.size();

    for (std::size_t i = 0; i < n; i++) {
        std::size_t temp = i;
        for (std::size_t j = i + 1; j < n; j++) {
            if (arr[j] < arr[temp]) {
                temp = j;
            }
        }

        if (temp != i) {
            std::swap(arr[i], arr[temp]);
        }
    }
}

void binary_search_number(double number, const std::vector<double>& arr) {
    std::size_t number_left = 0;
    std::size_t number_right = arr.size() - 1;
    std::size_t near_number = 0;

    while (number_left <= number_right) {
        std::size_t mid = number_left + (number_right - number_left) / 2;
        if (arr[mid] == number) {
            near_number = mid + 1;
            number_right = mid - 1;
        }
        else if (arr[mid] < number) {
            number_left = mid + 1;
        }
        else {
            number_right = mid - 1;
        }
    }

    if (near_number != 0) {
        std::cout << "found the number " << number << " index " << near_number << std::endl;
    }
    else {
        std::cout << "number " << number << " not found" << std::endl;
    }
}

void find_best_match(
    int32_t person, 
    std::vector<int32_t>& currentMatch, 
    std::vector<bool>& used, 
    int32_t current_score, 
    int32_t& max_score, 
    std::vector<int32_t>& best_match, 
    int32_t score[8][8]
) {
    if (person == 8) {
        if (current_score > max_score) {
            max_score = current_score;
            best_match = currentMatch;
        }
        return;
    }
    
    for (int option = 0; option < 8; option++) {
        if (!used[option]) { 
            used[option] = true;
            currentMatch[person] = option;

            find_best_match(person + 1, currentMatch, used, current_score + score[person][option], max_score, best_match, score);

            used[option] = false;
        }
    }
}


int32_t main() {
    std::string load_file;
    double search_number;
    std::vector<double> number;

    std::vector<int32_t> best_match(8);
    int32_t max_score = 0;
    int32_t score[8][8] = {
        {522, 703, 366, 131, 167, 938, 935, 553},
        {35, 842, 39, 346, 169, 82, 37, 702},
        {139, 942, 649, 77, 835, 81, 813, 537},
        {618, 246, 208, 599, 44, 662, 655, 365},
        {703, 983, 680, 333, 462, 365, 652, 31},
        {46, 978, 832, 702, 812, 850, 641, 176},
        {848, 266, 281, 849, 715, 38, 370, 81},
        {160, 865, 262, 849, 570, 647, 553, 902}
    };
    std::string persons[] = {"甲", "乙", "丙", "丁", "戊", "己", "庚", "辛"};
    std::string options[] = {"A", "B", "C", "D", "E", "F", "G", "H"};
    std::vector<int32_t> current_match(8);
    std::vector<bool> used(8, false);

    std::cout << "Question 1" << std::endl;
    load_file_context("double.txt", number);
    select_sort(number);
    save_to_file("sortedDoubles.txt", number);

    std::cout << "Question 2" << std::endl;
    std::cout << "search number: ";
    std::cin >> search_number;
    binary_search_number(search_number, number);

    std::cout << "Question 3" << std::endl;
    find_best_match(0, current_match, used, 0, max_score, best_match, score);
    std::cout << "Best Match Score: " << max_score << std::endl;

    std::cout << "Best Match: " << std::endl;
    for (int i = 0; i < 8; i++) {
        std::cout << persons[i] << ", " << options[best_match[i]] << std::endl;
    }

    return 0;
}