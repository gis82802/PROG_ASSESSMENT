#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

const int N = 8;

int grid[N][N] = {
    {522,703,366,131,167,938,935,553},  // ��
    {35,842,39,346,169,82,37,702},      // �A
    {139,942,649,77,835,81,813,537},    // ��
    {618,246,208,599,44,662,655,365},   // �B
    {703,983,680,333,462,365,652,31},   // ��
    {46,978,832,702,812,850,641,176},   // �v
    {848,266,281,849,715,38,370,81},    // ��
    {160,865,262,849,570,647,553,902}   // ��
};

string rows[N] = { "��","�A","��","�B","��","�v","��","��" };
string cols[N] = { "A","B","C","D","E","F","G","H" };

int main() {
    int perm[N];
    for (int i = 0; i < N; i++) perm[i] = i;  // 0~7 ������~��

    long long bestSum = -1;
    int bestPerm[N];

    // ���ͩҦ� 8! �ƦC
    do {
        long long sum = 0;
        for (int j = 0; j < N; j++) {
            int row = perm[j]; // �� j ��� perm[j] �o�C
            sum += grid[row][j];
        }
        if (sum > bestSum) {
            bestSum = sum;
            copy(perm, perm + N, bestPerm);
        }
    } while (next_permutation(perm, perm + N));

    // ��X���G
    cout << "�̤j�`�M = " << bestSum << endl;
    for (int j = 0; j < N; j++) {
        cout << "�� " << cols[j] << " �� " << rows[bestPerm[j]]
            << " (�� " << grid[bestPerm[j]][j] << ")" << endl;
    }

    return 0;
}
