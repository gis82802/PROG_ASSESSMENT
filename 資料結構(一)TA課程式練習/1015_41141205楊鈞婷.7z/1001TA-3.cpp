#include <iostream>
using namespace std;

const int N = 8;

int main() {
    int score[N][N] = {
        {522,703,366,131,167,938,935,553},
        {35,842,39,346,169,82,37,702},
        {139,942,649,77,835,81,813,537},
        {618,246,208,599,44,662,655,365},
        {703,983,680,333,462,365,652,31},
        {46,978,832,702,812,850,641,176},
        {848,266,281,849,715,38,370,81},
        {160,865,262,849,570,647,553,902}
    };

    const char* rowLabel[] = {
        "\u7532","\u4E59","\u4E19","\u4E01",
        "\u620A","\u5DF1","\u5E9A","\u8F9B"
    };

    const char* colLabel[] = {
        "A","B","C","D","E","F","G","H"
    };

    bool usedCol[N] = { false }; // �O���w�ϥΪ��C
    int sumMax = 0;

    for (int i = 0; i < N; i++) {
        int maxVal = -1;
        int maxCol = -1;
        for (int j = 0; j < N; j++) {
            if (!usedCol[j] && score[i][j] > maxVal) {
                maxVal = score[i][j];
                maxCol = j;
            }
        }
        usedCol[maxCol] = true; // ��w�ӦC
        sumMax += maxVal;
        cout << rowLabel[i] << "��̤j�Ȭ�: " << maxVal
            << " (�����C " << colLabel[maxCol] << ")" << endl;
    }

    cout << "�Ҧ��̤j�Ȫ��`�M��: " << sumMax << endl;

    return 0;
}
