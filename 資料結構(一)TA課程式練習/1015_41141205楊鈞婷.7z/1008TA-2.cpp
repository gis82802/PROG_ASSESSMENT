#include <iostream>
using namespace std;

// �ۭq gcd �禡
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

class Rational {
private:
    int numerator;   // ���l
    int denominator; // ����

    void simplify() {
        int g = gcd(numerator, denominator);
        numerator /= g;
        denominator /= g;
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    Rational(int n = 0, int d = 1) : numerator(n), denominator(d) {
        simplify();
    }

    // �[�k (�ק糧��)
    void add(const Rational& other) {
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator = denominator * other.denominator;
        simplify();
    }

    // ��k (�ק糧��)
    void sub(const Rational& other) {
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator = denominator * other.denominator;
        simplify();
    }

    // ���k (�ק糧��)
    void mul(const Rational& other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        simplify();
    }

    // ���k (�ק糧��)
    void div(const Rational& other) {
        numerator *= other.denominator;
        denominator *= other.numerator;
        simplify();
    }

    // ��X����²���ƩβV�X��
    void print() const {
        if (abs(numerator) >= denominator && numerator % denominator != 0) {
            int whole = numerator / denominator;
            int rem = abs(numerator % denominator);
            cout << whole << "+" << rem << "/" << denominator;
        }
        else if (denominator == 1) {
            cout << numerator;
        }
        else {
            cout << numerator << "/" << denominator;
        }
        cout << endl;
    }
};

int main() {
    int a_num, a_den, b_num, b_den;

    cout << "�п�J�Ĥ@�Ӧ��z�� (���l ����): ";
    cin >> a_num >> a_den;
    cout << "�п�J�ĤG�Ӧ��z�� (���l ����): ";
    cin >> b_num >> b_den;

    Rational a(a_num, a_den);
    Rational b(b_num, b_den);

    a.add(b); a.print(); // a = a + b
    b.sub(a); b.print(); // b = b - a
    a.mul(b); a.print(); // a = a * b
    b.div(a); b.print(); // b = b / a

    return 0;
}