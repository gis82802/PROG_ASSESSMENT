<?php
declare(strict_types=1);
session_start();

// 放在 session_start() 後面、驗證區塊前面
if (isset($_GET['dev']) && $_GET['dev'] === '1') {
    $_SESSION['selected_class_id']    = 6;      // 你的測試班級ID
    $_SESSION['UserID']               = 9999;   // 測試教師ID
    $_SESSION['selected_homework_id'] = 1;      // 測試作業ID
}


// 1) 取得參數（Session 驗證）
if (!isset($_SESSION['selected_class_id'], $_SESSION['UserID'])) {
    json_exit(401, '未登入或 Session 遺失');
}

// 嚴格驗證：必須是整數
$classID    = filter_var($_SESSION['selected_class_id'], FILTER_VALIDATE_INT);
$teacherID  = filter_var($_SESSION['UserID'], FILTER_VALIDATE_INT);
// homeworkID 可能是字串，先取再驗證
$rawHomeworkID = $_SESSION['selected_homework_id'] ?? null;
$homeworkID    = is_string($rawHomeworkID) || is_int($rawHomeworkID)
    ? filter_var($rawHomeworkID, FILTER_VALIDATE_INT)
    : false;

if ($classID === false || $teacherID === false) {
    http_response_code(401);
    exit('未登入或 Session 遺失');
}

if ($homeworkID === false) {
    http_response_code(400);
    exit('未指定或非法的作業 ID');
}

// 2) 組路徑（固定根 + realpath 防跳脫）
$root    = dirname(__DIR__);
$dataDir = $root . '/data';
$target  = $dataDir . "/$classID/$homeworkID/homework";

// 先取得 data 根目錄的實路徑（應存在）
$realData = realpath($dataDir);
if ($realData === false) {
    // 伺服器設定錯誤
    json_exit(500, '伺服器設定錯誤：資料根目錄不存在');
}

// 取得目標目錄實路徑
$realTarget = realpath($target);

// 目錄必須存在且位於 data 根目錄之下
if ($realTarget === false || strncmp($realTarget, $realData . DIRECTORY_SEPARATOR, strlen($realData) + 1) !== 0) {
    // 要隱匿細節就用泛化訊息
    json_exit(404, '作業資料夾不存在，請確認作業 ID 是否正確');
}

// 3) 腳本路徑 WebtoLB.py
$scriptPath = dirname(__DIR__) . '/LingoBridge/WebtoLB.py'; // 假設腳本在 LingoBridge 資料夾
if (!is_file($scriptPath) || !is_readable($scriptPath)) { // 檢查腳本是否存在且可讀
    http_response_code(500);
    exit('無法存取 WebtoLB.py 腳本，請聯繫管理員');
}
$baseDir = dirname(__DIR__) . "/data/$classID/$homeworkID"; // 作業根目錄
if (!is_dir($baseDir)) {
    http_response_code(404);
    exit('作業資料夾不存在，請確認作業 ID 是否正確');
}

// 4) 自動尋找題目/程式檔 + 執行 Python
$topicPath = $baseDir . "/homework_texts/Q1.txt";
$codePath  = $baseDir . "/homework/188/Q1/test.java";
if (!is_file($topicPath) || !is_readable($topicPath)) { // 假設題目檔是 Q1.txt
    http_response_code(404);
    exit('找不到題目檔，請確認作業資料是否完整');
}
if (!is_file($codePath) || !is_readable($codePath)) { // 假設程式檔是 test.java
    http_response_code(404);
    exit('找不到程式檔，請確認作業資料是否完整');
}
// 執行 Python 腳本 
// 這裡的 "1" 是指使用 Gemini 模型 "2" 是指使用 Mistral 模型
$command = escapeshellcmd(escapeshellarg($scriptPath) . " " . 2 . " " . escapeshellarg($topicPath) . " " . escapeshellarg($codePath));

// 5) 回傳結果（讀取 WebQuiz.txt 的內容）
$filegemini  = __DIR__ . "/../LingoBridge/data/temp/gemini-2.0-flash-exp_feedback.txt";
$filemistral = __DIR__ . "/../LingoBridge/data/temp/feedback";

// 讀取檔案內容gemini
if (file_exists($filegemini)) {
    $output[0] = file_get_contents($filegemini);
} else {
    $output[0] = "檔案不存在: " . $filegemini;
}
// 讀取檔案內容mistral
if (file_exists($filemistral)) {
    $output[1] = file_get_contents($filemistral);
} else {
    $output[1] = "檔案不存在: " . $filemistral;
}

// 寫入結果到 session 以便在下一頁使用
$_SESSION['gemini_output'] = $output[0];
$_SESSION['mistral_output'] = $output[1];

// 轉向到顯示課程內容的頁面
header("Location: ../homeworkscoresedit.php");
exit();
?>