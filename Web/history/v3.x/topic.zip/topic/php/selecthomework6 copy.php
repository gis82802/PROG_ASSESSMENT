<?php
declare(strict_types=1);
session_start();

// 1) 取得參數（Session 驗證）
if (!isset($_SESSION['selected_class_id'], $_SESSION['UserID'])) {
    json_exit(401, '未登入或 Session 遺失');
}

// 嚴格驗證：必須是整數
$classID    = filter_var($_SESSION['selected_class_id'], FILTER_VALIDATE_INT);
$teacherID  = filter_var($_SESSION['UserID'], FILTER_VALIDATE_INT);
// homeworkID 可能是字串，先取再驗證
$rawHomeworkID = $_SESSION['selected_homework_id'] ?? null;
$homeworkID    = is_string($rawHomeworkID) || is_int($rawHomeworkID)
    ? filter_var($rawHomeworkID, FILTER_VALIDATE_INT)
    : false;

if ($classID === false || $teacherID === false) {
    http_response_code(401);
    exit('未登入或 Session 遺失');
}

if ($homeworkID === false) {
    http_response_code(400);
    exit('未指定或非法的作業 ID');
}

// 2) 組路徑（固定根 + realpath 防跳脫）
$root    = dirname(__DIR__);
$dataDir = $root . '/data';
$target  = $dataDir . "/$classID/$homeworkID/homework";

// 先取得 data 根目錄的實路徑（應存在）
$realData = realpath($dataDir);
if ($realData === false) {
    // 伺服器設定錯誤
    json_exit(500, '伺服器設定錯誤：資料根目錄不存在');
}

// 取得目標目錄實路徑
$realTarget = realpath($target);

// 目錄必須存在且位於 data 根目錄之下
if ($realTarget === false || strncmp($realTarget, $realData . DIRECTORY_SEPARATOR, strlen($realData) + 1) !== 0) {
    json_exit(404, '作業資料夾不存在，請確認作業 ID 是否正確');
}

// 3) 自動尋找題目/程式檔 + 執行 Python
$scriptPath = dirname(__DIR__) . '/LingoBridge/WebtoLB.py';
if (!is_file($scriptPath) || !is_readable($scriptPath)) {
    http_response_code(500);
    exit('無法存取 WebtoLB.py 腳本，請聯繫管理員');
}
$baseDir = dirname(__DIR__) . "/data/$classID/$homeworkID";
if (!is_dir($baseDir)) {
    http_response_code(404);
    exit('作業資料夾不存在，請確認作業 ID 是否正確');
}

// 假設題目檔和程式檔的命名規則如下（可根據實際情況調整）
$topicPath = $baseDir . "/homework_texts/Q1.txt";
$codePath  = $baseDir . "/homework/188/Q1/test.java";

$cmd = "python3 " . escapeshellarg($scriptPath) . " " 
    . escapeshellarg($topicPath) . " "
    . escapeshellarg($codePath);

exec($cmd, $output, $returnVar);

if ($returnVar !== 0) {
    http_response_code(500);
    exit("執行批改腳本失敗：\n" . implode("\n", $output));
}

// 4) 回傳結果
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'message' => '批改完成',
    'output' => $output,
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
exit;
function json_exit(int $code, string $message): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => $message,
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
?>