public class CSIE_41343240_0919_1{
	public static void main(String[] args){
	System.out.print("Hello World!");
	}
}