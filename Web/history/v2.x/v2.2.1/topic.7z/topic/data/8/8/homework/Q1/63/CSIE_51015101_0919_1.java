public class CSIE_51015101_0919_1 {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}