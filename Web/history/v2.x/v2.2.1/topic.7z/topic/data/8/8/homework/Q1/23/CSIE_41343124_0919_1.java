public class CSIE_41343124_0919_1{
  public static void main(String[] argv){
    System.out.print("Hello World!");
  }
}