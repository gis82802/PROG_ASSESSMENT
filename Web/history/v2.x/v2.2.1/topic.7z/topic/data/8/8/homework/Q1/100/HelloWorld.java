class test1{
	public static void main(String argsl[]){
		System.out.println("Hello World!");
	}
}
