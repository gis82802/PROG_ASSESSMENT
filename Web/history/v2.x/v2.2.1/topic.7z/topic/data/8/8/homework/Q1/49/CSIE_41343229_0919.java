public class CSIE_41343229_0919{
	public static void main(String[] args){
		System.out.println("Hello World!");
		}
	}