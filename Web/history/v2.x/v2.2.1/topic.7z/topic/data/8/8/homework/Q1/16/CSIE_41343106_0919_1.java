public class HelloWorld{
  public static voif main(String[] args){
      System.out.println("Hello World!");
	}
}