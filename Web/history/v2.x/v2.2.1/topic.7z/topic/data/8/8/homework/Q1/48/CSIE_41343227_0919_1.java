public class CSIE_41343227_0919_1 {
   public static void main(String[] args) {
      System.out.println("Hello World!");
   }
}