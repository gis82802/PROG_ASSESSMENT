public class CSIE_41343112_0919_1{
public static void main(String[] args){
System.out.println("Hello World!");
}
}