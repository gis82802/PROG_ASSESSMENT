public class HW{
	public static void main(String[] args){
		System.out.println("Hello 虎科大");
	}
}