public class CSIE_51015105_0919_1 {
	public static void main(String[] args){
		System.out.println("Hello World!");
	}
}