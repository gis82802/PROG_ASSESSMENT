//package h4w;

public class CSIE_41143122_0919_1 {
    public static void main(String[] args){
        System.out.printf("Hello World!\n");
    }
}
