<?php
declare(strict_types=1);
session_start();

@set_time_limit(600);       // 最多跑 10 分鐘
@ignore_user_abort(true);   // 瀏覽器關掉也繼續跑

// 1) 取得參數（Session 驗證）
if (!isset($_SESSION['selected_class_id'], $_SESSION['UserID'], $_SESSION['selected_homework_id'])) {
    http_response_code(401);
    exit('未登入或 Session 遺失');
}
$classID    = (int)($_SESSION['selected_class_id']    ?? 6);
$homeworkID = (int)($_SESSION['selected_homework_id'] ?? 1);

// 2) 路徑組好
$baseDir = dirname(__DIR__) . '/data' . "/$classID/$homeworkID"; // 作業根
$topicDir = $baseDir . '/homework_texts'; // 題目資料夾
$files = glob($topicDir . '/Q*.txt') ?: []; // 找出所有 Q*.txt 檔
natsort($files); // 讓 Q1, Q2, Q10 依自然順序

$topicPath = $files ? array_values($files)[0] : null; // 取第一個題目檔
$scriptPath = dirname(__DIR__) . '/LingoBridge/WebtoLB.py'; // 腳本

// 可擴充的副檔名清單
$extensions = ['java', 'cpp', 'py']; // 想加就加

$codeFiles = [];
$iter = new RecursiveIteratorIterator(  // 遞迴找出所有程式碼檔
    new RecursiveDirectoryIterator($baseDir . '/homework', FilesystemIterator::SKIP_DOTS)
);
foreach ($iter as $f) {
    if ($f->isFile() && in_array(strtolower($f->getExtension()), $extensions, true)) { // 副檔名符合
        $codeFiles[] = $f->getPathname(); // 完整路徑
    }
}

natsort($codeFiles); // 讓 Q1, Q2, Q10 依自然順序
$codeFiles = array_values($codeFiles); // 重設索引

if (empty($codeFiles)) { // 沒有程式碼檔
    http_response_code(404);
    exit('找不到任何支援的程式碼檔');
}

// 針對每個程式碼檔案執行
foreach ($codeFiles as $codePath) {

    // 3) 檢查路徑
    if (!is_file($scriptPath) || !is_readable($scriptPath)) {
        http_response_code(500);
        exit('無法存取 WebtoLB.py 腳本，請聯繫管理員');
    }
    if (!is_dir($baseDir)) {
        http_response_code(404);
        exit('作業資料夾不存在，請確認作業 ID 是否正確');
    }
    if (!is_file($topicPath) || !is_readable($topicPath)) {
        http_response_code(404);
        exit('題目檔不存在，請聯繫管理員');
    }
    if (!is_file($codePath) || !is_readable($codePath)) {
        http_response_code(404); 
        exit('程式碼檔不存在，請確認作業是否已繳交');
    }

    // 4) 執行 Python
    $python = 'python';
    $cmd = implode(' ', [ // 組合命令列
        escapeshellarg($python),
        escapeshellarg($scriptPath), // 腳本
        escapeshellarg($topicPath), // 題目
        escapeshellarg($codePath), // 程式
    ]);

    // debug. 2>&1：把 stderr(2) 重新導向到 stdout(1)，因此錯誤訊息也會被收集到 $out。
    $out = [];
    exec($cmd . ' 2>&1', $out, $rc); // 執行並取得回傳值
    if ($rc !== 0) { // 失敗
        header('Content-Type: text/plain; charset=utf-8');
        echo "RC=$rc\n" . implode("\n", $out); // 顯示錯誤訊息
        exit;
    }

    // 5) 複製到其他路徑（例如 data/output.log）
    $filegemini = __DIR__ . "/../LingoBridge/data/temp/feedback"; // 來源檔案(過度用途檔)
    // $filegemini = __DIR__ . "/../LingoBridge/data/temp/Gemini_feedback"; // Gemini 來源檔案
    // $filemistral = __DIR__ . "/../LingoBridge/data/temp/Mistral_feedback"; // Mistral 來源檔案
    $srcPath = realpath($filegemini); // 嘗試正規化路徑
    $dstDir = dirname($codePath) . DIRECTORY_SEPARATOR . "feedback" . DIRECTORY_SEPARATOR; // 目標資料夾

    // 確認來源檔案存在
    if (!file_exists($srcPath)) {
        echo "找不到來源檔案: $srcPath<br>";
        exit;
    }

    // 確保目標目錄存在
    if (!is_dir($dstDir)) {
        mkdir($dstDir, 0777, true);
    }

    // 在目標資料夾裡，用來源檔案的檔名
    $savePath = $dstDir . "Gemini_feedback.txt";
    // 若要 Mistral 回饋，改這行即可
    // $savePathMistral = $dstDir . "Mistral_feedback.txt";
    // $savePathGemini = $dstDir . "Gemini_feedback.txt";

    // debug:確認路徑是否正確
    // echo "來源: $srcPath<br>"; 
    // echo "目標: $savePath<br>";
    // if (copy($srcPath, $savePath)) {
    //     echo "複製成功: $savePath";
    // } else {
    //     echo "複製失敗";
    // }

    // 執行複製
    copy($srcPath, $savePath);

} // end foreach

// 6) 轉頁
header("Location: ../homeworkscoresedit.php"); 
exit;
?>