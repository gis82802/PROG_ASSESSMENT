#include <iostream>
int main()
{
    std::cout << "NFU is good\n";
    return 0;
}
