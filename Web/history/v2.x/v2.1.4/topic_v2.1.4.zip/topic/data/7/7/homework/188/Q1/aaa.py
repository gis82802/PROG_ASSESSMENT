print("NFU is good")
