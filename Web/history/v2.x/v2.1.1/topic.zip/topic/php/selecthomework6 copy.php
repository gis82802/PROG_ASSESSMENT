<?php
declare(strict_types=1);
session_start();

// 1) 取得參數（Session 驗證）
if (!isset($_SESSION['selected_class_id'], $_SESSION['UserID'], $_SESSION['selected_homework_id'])) {
    http_response_code(401);
    exit('未登入或 Session 遺失');
}
$classID    = (int)($_SESSION['selected_class_id']    ?? 6);
$homeworkID = (int)($_SESSION['selected_homework_id'] ?? 1);

// 2) 路徑組好
$root       = dirname(__DIR__);                         // .../topic
$scriptPath = $root . '/LingoBridge/WebtoLB.py';        // 腳本
$baseDir    = $root . "/data/$classID/$homeworkID";     // 作業根
$topicPath  = $baseDir . "/homework_texts/Q1.txt";      // 題目
$codePath   = $baseDir . "/homework/188/Q1/test.java";  // 程式

// 3) 檢查路徑
if (!is_file($scriptPath) || !is_readable($scriptPath)) { // 檢查腳本是否存在且可讀
    http_response_code(500);
    exit('無法存取 WebtoLB.py 腳本，請聯繫管理員');
}
if (!is_dir($baseDir)) {
    http_response_code(404);
    exit('作業資料夾不存在，請確認作業 ID 是否正確');
}
if (!is_file($topicPath) || !is_readable($topicPath)) {
    http_response_code(404);
    exit('題目檔不存在，請聯繫管理員');
}
if (!is_file($codePath) || !is_readable($codePath)) {
    http_response_code(404);
    exit('程式碼檔不存在，請確認作業是否已繳交');
}

// 4) 執行 Python
$python = 'python';
$cmd = implode(' ', [ 
    escapeshellarg($python),
    escapeshellarg($scriptPath), // 腳本
    escapeshellarg($topicPath), // 題目
    escapeshellarg($codePath), // 程式
]);

// debug用
$out = [];
// 2>&1：把 stderr(2) 重新導向到 stdout(1)，因此錯誤訊息也會被收集到 $out。
exec($cmd . ' 2>&1', $out, $rc); // 取得輸出與回傳碼
if ($rc !== 0) { // 失敗
    header('Content-Type: text/plain; charset=utf-8');
    echo "RC=$rc\n" . implode("\n", $out); // 顯示錯誤訊息
    exit;
    }

// 5) 讀取結果並存入 Session
$filegemini  = __DIR__ . "/../LingoBridge/data/temp/feedback";
// $filegemini  = __DIR__ . "/../LingoBridge/data/temp/feedback_gemini";
// $filemistral = __DIR__ . "/../LingoBridge/data/temp/feedback_mistral";

$_SESSION['gemini_output']  = is_file($filegemini)  ? (file_get_contents($filegemini)  ?: '') : ''; // 讀取檔案內容，若無內容則設為空字串
$_SESSION['mistral_output'] = is_file($filemistral) ? (file_get_contents($filemistral) ?: '') : '';

// 6) 轉頁
header("Location: ../homeworkscoresedit.php"); 
exit;
?>