<!DOCTYPE html>
<html lang="zh-Hant">
    <?php
		session_start();
		// 資料庫連線
		$conn = new mysqli("localhost", "root", "", "topic");
		if ($conn->connect_error) {
			$conn->close();
			header("Location: ../index.php");
			die("連線失敗: " . $conn->connect_error);
		}

		$homeworkID = $_SESSION['selected_homework_id'];

		$sql = "SELECT HomeworkName FROM homeworkslist WHERE HomeworkID = '$homeworkID'";
		$result = $conn->query($sql);

		if ($result->num_rows === 1) {
			$row = $result->fetch_assoc();
			$homeworkName = $row['HomeworkName']; 
		} else {
			$conn->close();
			header("Location: ../index.php");
		}

		$conn->close();
	?>
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<title><?php echo $homeworkName; ?></title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1"> <!--適配不同裝置的螢幕寬度-->
  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,700,800" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
</head>
<body>
    <?php
		// 資料庫連線
		$conn = new mysqli("localhost", "root", "", "topic");
		if ($conn->connect_error) {
			header("Location: ../index.php");
			die("連線失敗: " . $conn->connect_error);
		}

		$userid = $_SESSION['UserID'];

		// 查詢該 UserID 對應的姓名
		$sql = "SELECT FirstName, LastName FROM users WHERE UserID = '$userid'";
		$result = $conn->query($sql);

		$fullname = "";
		if ($result->num_rows === 1) {
			$row = $result->fetch_assoc();
			$fullname = $row['FirstName'] . $row['LastName']; // 姓在前
		} else {
			header("Location: ../index.php");
		}

		$conn->close();
	?>
    <div class="fh5co-loader"><div class="loader-text">正在批改程式中，請稍候...</div></div>
	
	<div id="page">
	<nav class="fh5co-nav" role="navigation">
		<div class="top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 text-right">
						<p class="num"><?php echo $fullname; ?></p>
						<ul class="fh5co-social">
							<li><a href="index.php">登出</i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-xs-1">
						<a href="student.php"><img src="./images/NFU_Logo.png" alt="LOGO" style="height: 50px;"></a>
					</div>
					<div class="col-xs-11 text-right menu-1">
						<ul>
							<?php
							 	echo '    <li class="btn-cta"><a href="./php/selecthomework2.php?homework_id=' . urlencode($homeworkID) . '"><span>作業回饋與評分</span></a></li>';
							?>
							<li class="btn-cta"><a href="studentclass.php"><span>返回</span></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</nav>

	<header id="fh5co-header" class="fh5co-bgm" role="banner" style="background-image:url(images/img_bg_2.jpg);" data-stellar-background-ratio="0.5">
		
	</header>
	<div class="container center-container">
    <div class="upload-box text-center">
        <h2 class="mb-4">上傳檔案</h2>
        <h4 class="mb-5">每次上傳作業一份為限</h4>
		<p></p>
        <?php
        
        // 顯示回報(成功)訊息
        if (isset($_SESSION['report'])) {
            echo '<p style="color:green; text-align:center;">' . $_SESSION['report'] . '</p>';
            unset($_SESSION['report']);
        }
        // 顯示錯誤(失敗)訊息
        if (isset($_SESSION['error'])) {
            echo '<p style="color:red; text-align:center;">' . $_SESSION['error'] . '</p>';
            unset($_SESSION['error']);
        }

        // 連接資料庫
        $conn = new mysqli("localhost", "root", "", "topic");
        if ($conn->connect_error) {
            die("連線失敗: " . $conn->connect_error);
        }

        $homeworkID = $_SESSION['selected_homework_id'] ?? null;
        if (!$homeworkID) {
            echo "<p style='color:red;'>找不到作業 ID</p>";
            exit;
        }

        $sql = "SELECT * FROM homeworkslist WHERE HomeworkID = '$homeworkID'";
        $result = $conn->query($sql);
        if (!$result || $result->num_rows === 0) {
            echo "<p style='color:red;'>查無此作業</p>";
            exit;
        }

        $row = $result->fetch_assoc();
        for ($i = 1; $i <= $row['QuestionSum']; $i++) {
			$filepath = __DIR__ . '/data/' . $row['ClassID'] . "/" . $homeworkID . "/homework_texts/Q" . $i . ".txt";
			if (file_exists($filepath)) {
				$content = file_get_contents($filepath);
			} else {
				$content = "檔案不存在！";
			}
            
            echo '<h4>題目 ' . $i .'：<br></h4>';
            echo '<pre style="white-space: pre-wrap; text-align:left;">' . htmlspecialchars($content) . '</pre>';
            echo '<input type="file" name="file" required accept=".c,.cpp,.cs,.java,.py" class="form-control mb-2">';
            echo '<input type="hidden" name="Question_id" value="' . $i . '">';
            echo '<button type="submit" class="btn btn-primary">上傳作業 ' . $i . '</button>';
            
            //echo '
            //<form id="uploadForm" method="POST" enctype="multipart/form-data" action="./php/uploadhomework.php">
            //    <label class="form-label">題目 ' . $i . '：<br>' . nl2br($content).'</label>
            //    <input type="file" name="file" required accept=".c,.cpp,.cs,.java,.py" class="form-control mb-2">
            //    <input type="hidden" name="Question_id" value="' . $i . '">
            //    <button type="submit" class="btn btn-primary">上傳作業 ' . $i . '</button>
            //</form>';
        }
		
        $conn->close();
        ?>
		<script>
		document.addEventListener("DOMContentLoaded", function () {
			// 對所有表單綁定 submit 事件
			document.querySelectorAll("form").forEach(function (form) {
				form.addEventListener("submit", function () {
					// 顯示 loader 畫面
					document.querySelector(".fh5co-loader").style.display = "block";
					document.body.classList.add("loading");

					// 鎖定這個表單裡的按鈕，避免多次點擊
					const button = form.querySelector("button[type='submit']");
					if (button) button.disabled = true;
				});
			});
		});
		</script>


    </div>
</div>

	<div class="col-md-12 text-center">
		<p>
			<small class="block">測資批改系統 by 蔡品辰 </small> <br>
			<small class="block">國立虎尾科技大學 資訊工程系</small> 
		</p>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>
</body>
</html>