import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))  # 目前所在資料夾路徑
items_path  = os.path.normpath(os.path.join(current_dir, 'data/items.json')) # items 資料路徑
logs_dir    = os.path.normpath(os.path.join(current_dir, 'logs/'))   # 紀錄檔儲存路徑
base_path   = os.path.normpath(os.path.join(current_dir, '../data/')) # 資料基本路徑 (eg. ../xampp/htdocs/topic/data/)
output_dir  = os.path.normpath(os.path.join(current_dir, 'logs/feedback/')) # 預設輸出路徑

str1 = "Hello World!"
str1 = sys.argv[1] if len(sys.argv) > 1 else str1

num = 789

print(str1)

def F1():
    print("in F1")

class F2:
    def __init__(self, num):
        self.num = 456
    def run(self):
        print(self.num)
        return 2
    def run2(self):
        print("here")
        r1 = self.run()
        print("r1: " + str(r1))
    def run3(self, abc):
        print(abc)
    def run4(self):
        print("in 4")

print("END")
tester = F2(123)
tester.run4()