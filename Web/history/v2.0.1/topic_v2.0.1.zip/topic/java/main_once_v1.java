import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class main_once_v1 {

    public static void main(String[] args) {
        // 1. 驗證與接收從 PHP 傳來的參數
        /*
        if (args.length < 5) {
            System.out.println("00"); // 參數不足，回報失敗
            return;
        }
        */

        // 從參數取得作業和測資的實際路徑
        String homeworkDirStr = args[0]; // 學生作業所在的完整目錄路徑
        String studentFileName = args[1];     // 學生上傳的原始檔名 (e.g., "StudentCode.java")
        String testerDirStr = args[2];     // 該題目對應的測資目錄路徑
        String classID = args[3];        // (備用參數)
        String homeworkID = args[4];     // (備用參數)

        Path homeworkDir = Paths.get(homeworkDirStr);
        Path studentJavaFile = homeworkDir.resolve(studentFileName);
        Path testerDir = Paths.get(testerDirStr);
        // String className = studentFileName.replace(".java", ""); // 這個變數不再直接使用，而是動態獲取

        // 2. 檢查必要的檔案和目錄是否存在
        if (!Files.exists(studentJavaFile) || !Files.exists(testerDir)) {
            System.out.println("01"); // 作業檔案或測資目錄不存在，回報失敗
            return;
        }

        // 聲明在 try 塊之外，以便在 finally 塊中使用
        String actualClassName = null;

        try {
            // 3. 執行編譯 (javac)
            boolean compileSuccess = compileJavaFile(studentJavaFile, homeworkDir);
            if (!compileSuccess) {
                System.out.println("02"); // 編譯失敗
                return;
            }

            // --- 新增邏輯：找到實際的 Main Class Name ---
            actualClassName = findMainClassName(homeworkDir);
            if (actualClassName == null) {
                System.out.println("06"); // 找不到 main class 或有多個 main class
                return;
            }
            // --- 新增邏輯結束 ---

            // 4. 讀取所有 .out 測資檔案 (作為基礎，因為一定有輸出)
            List<File> outputFiles = Files.list(testerDir)
                                        .filter(p -> p.toString().endsWith(".out"))
                                        .map(Path::toFile)
                                        .sorted(Comparator.comparing(File::getName)) // 按檔名排序，確保執行順序
                                        .collect(Collectors.toList());

            if (outputFiles.isEmpty()) {
                System.out.println("03"); // 找不到任何 .out 測資，回報失敗
                return;
            }

            // 5. 執行並比對所有測資
            for (File testCaseOutFile : outputFiles) {
                // 使用找到的 actualClassName 執行
                boolean pass = runAndCompare(homeworkDir, actualClassName, testerDir, testCaseOutFile);
                if (!pass) {
                    System.out.println("04"); // 只要有一個測資沒過，就立即回報失敗並終止
                    return;
                }
            }

            // 6. 如果所有選中的測資都通過
            System.out.println("1"); // 全部通過，回報成功

        } catch (Exception e) {
            // e.printStackTrace(); // 方便除錯，實際部署時可移除或記錄到日誌
            System.out.println("05"); // 任何意外都視為失敗
        } finally {
            // 7. 清理產生的 .class 檔案
            if (actualClassName != null) {
                clearClassFile(homeworkDir, actualClassName);
            }
            // 還要清理所有可能的 .class 檔案，因為編譯時可能生成多個內部類別的 .class 檔案
            clearAllClassFiles(homeworkDir);
        }
    }

    /**
     * 編譯指定的 .java 檔案
     */
    private static boolean compileJavaFile(Path javaFile, Path workingDir) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("javac", "-encoding", "UTF-8", javaFile.toString());
        pb.directory(workingDir.toFile());
        // 將編譯器輸出導入到黑洞，避免干擾標準輸出
        pb.redirectErrorStream(true); // 將錯誤流和標準輸出流合併
        Process process = pb.start();
        
        // 讀取編譯器的輸出（如果有錯誤或警告）
        StringBuilder compilerOutput = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                compilerOutput.append(line).append(System.lineSeparator());
            }
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            // 編譯失敗，將編譯器輸出打印出來
            System.err.println("Compilation Error:\n" + compilerOutput.toString());
        }
        return exitCode == 0;
    }

    /**
     * 尋找編譯後目錄中唯一的 main class。
     * 適用於類別名稱與檔案名稱不符的情況。
     *
     * @param homeworkDir 學生作業編譯後的目錄
     * @return 找到的 main class 名稱，如果找不到或有多個則返回 null
     * @throws IOException
     */
    private static String findMainClassName(Path homeworkDir) throws IOException {
        List<String> mainClasses = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(homeworkDir, "*.class")) {
            for (Path entry : stream) {
                String fileName = entry.getFileName().toString();
                String className = fileName.replace(".class", "");

                try {
                    // 嘗試載入類別並檢查是否有 main 方法
                    // 注意：這會載入類別到 JVM，但我們只是檢查方法，不會執行
                    // 這裡的 Class.forName 需要 ClassLoader 能夠找到路徑
                    // 更安全的做法是避免在判斷時載入Class，而是透過外部工具如 javap
                    // 但對於簡單作業，此方法可行，只是可能不夠健壯

                    // 這裡使用外部命令 javap -public -l -s -v 來檢查 .class 檔案內容
                    // 尋找 public static void main(String[]) 方法
                    ProcessBuilder pb = new ProcessBuilder("javap", "-public", "-l", "-s", "-v", className);
                    pb.directory(homeworkDir.toFile());
                    pb.redirectErrorStream(true); // 將錯誤流和標準輸出流合併

                    Process process = pb.start();
                    StringBuilder javapOutput = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            javapOutput.append(line);
                        }
                    }
                    process.waitFor();

                    // 檢查 javap 輸出中是否包含 main 方法的簽名
                    // 查找類似 "public static void main(java.lang.String[])"
                    if (javapOutput.toString().contains("public static void main(java.lang.String[])")) {
                        mainClasses.add(className);
                    }

                } catch (Exception e) {
                    // 忽略無法載入的類別或 javap 執行錯誤
                    // System.err.println("Warning: Could not check class " + className + ": " + e.getMessage());
                }
            }
        }

        if (mainClasses.size() == 1) {
            return mainClasses.get(0);
        } else if (mainClasses.size() > 1) {
            System.err.println("Error: Found multiple main classes: " + String.join(", ", mainClasses));
            return null; // 找到多個 main class
        } else {
            return null; // 找不到 main class
        }
    }


    /**
     * 執行 .class 檔案並比對測資結果
     */
    private static boolean runAndCompare(Path workingDir, String className, Path testerDir, File outFile) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("java", className);
        pb.directory(workingDir.toFile());

        String testName = outFile.getName().replace(".out", "");
        Path inFile = testerDir.resolve(testName + ".in");

        // 如果存在對應的 .in 檔案，則重定向輸入
        if (Files.exists(inFile)) {
            pb.redirectInput(inFile.toFile());
        }

        Process process = pb.start();

        // 讀取程式的實際輸出 (使用UTF-8)
        List<String> actualOutput = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                actualOutput.add(line);
            }
        }
        
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            // 程式執行異常結束 (例如運行時錯誤)
            // 可以讀取錯誤流以獲取更多信息
            try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream(), "UTF-8"))) {
                String errorLine;
                while ((errorLine = errorReader.readLine()) != null) {
                    System.err.println("Runtime Error (Student Program): " + errorLine); // 輸出到標準錯誤流
                }
            }
            return false;
        }

        // 讀取測資的預期輸出 (使用UTF-8)
        List<String> expectedOutput = Files.readAllLines(outFile.toPath(), java.nio.charset.StandardCharsets.UTF_8);
        
        // 嚴格比對，需要確保內容和行數完全一致
        return actualOutput.equals(expectedOutput);
    }

    /**
     * 刪除指定的 .class 檔案
     */
    private static void clearClassFile(Path workingDir, String className) {
        try {
            Path classFile = workingDir.resolve(className + ".class");
            Files.deleteIfExists(classFile);
        } catch (IOException e) {
            // 刪除失敗，可以忽略或記錄
        }
    }

    /**
     * 刪除指定目錄下所有 .class 檔案
     */
    private static void clearAllClassFiles(Path workingDir) {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(workingDir, "*.class")) {
            for (Path entry : stream) {
                try {
                    Files.deleteIfExists(entry);
                } catch (IOException e) {
                    // 刪除個別檔案失敗，可以忽略或記錄
                }
            }
        } catch (IOException e) {
            // 讀取目錄失敗，可以忽略或記錄
        }
    }
}